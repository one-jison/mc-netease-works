# -*- coding: utf-8 -*-
# ============================================================
#  好斗生物 - 客户端
#  收到服务端的广播后，在本地放出愤怒的叫声、头顶火气、咬中的火花。
#  声音和粒子由每个客户端各自播放，所以房间里的玩家都能看到、听到。
# ============================================================
import mod.client.extraClientApi as clientApi
from BattleBrewScripts import modConfig
from BattleBrewScripts import battleBrewConfig as cfg

ClientSystem = clientApi.GetClientSystemCls()

# 粒子名从配置文件读，方便改
# 注意：minecraft:basic_crit_particle 这类粒子不能用脚本生成，
# 它依赖一个脚本给不了的 variable.direction，会每帧报错刷屏。
ANGRY_PARTICLE = str(getattr(cfg, "ANGRY_PARTICLE_NAME", "minecraft:villager_angry"))
HIT_PARTICLE = str(getattr(cfg, "HIT_PARTICLE_NAME", "minecraft:villager_angry"))

# 自定义音效万一加载不出来，就用原版的顶上
SOUND_FALLBACK = {
    "battlebrew.bite": "mob.ravager.bite",
}
SOUND_FALLBACK_ANY = "mob.wolf.growl"


class BattleBrewClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(BattleBrewClientSystem, self).__init__(namespace, systemName)
        self._listenEvents()

    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        try:
            self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                                modConfig.EventFx, self, self.OnFx)
        except Exception:
            pass

    # ==================== 小工具 ====================
    def _sameDimension(self, dim):
        if dim is None:
            return True
        try:
            mine = clientApi.GetEngineCompFactory().CreateDimension(
                clientApi.GetLocalPlayerId()).GetEntityDimensionId()
            return int(mine) == int(dim)
        except Exception:
            return True

    def _failed(self, musicId):
        # 播放失败时接口会返回负数（-1 ~ -6），成功则返回一个字符串 id
        if musicId is None:
            return True
        if isinstance(musicId, int):
            return musicId < 0
        try:
            return str(musicId).strip().startswith("-")
        except Exception:
            return False

    # ==================== 收到广播 ====================
    def OnFx(self, args):
        if not args:
            return
        if not self._sameDimension(args.get("dim")):
            return
        try:
            pos = (float(args.get("x", 0.0)),
                   float(args.get("y", 0.0)),
                   float(args.get("z", 0.0)))
        except Exception:
            return
        kind = args.get("t") or ""
        if kind == "angry":
            self._spawnAngry(pos)
            return
        if kind == "hit":
            self._spawnHit(pos)
            return
        try:
            pitch = float(args.get("p", 1.0))
        except Exception:
            pitch = 1.0
        self._playSound(kind, pos, pitch)

    # ==================== 愤怒的叫声 ====================
    def _playSound(self, name, pos, pitch):
        if not getattr(cfg, "SOUND_ENABLED", True):
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateCustomAudio(
                clientApi.GetLevelId())
        except Exception:
            return
        volume = float(getattr(cfg, "SOUND_VOLUME", 1.0))
        volume = max(0.0, min(1.0, volume))
        mid = None
        try:
            mid = comp.PlayCustomMusic(name, pos, volume, pitch, False, None)
        except Exception:
            mid = None
        if self._failed(mid):
            fb = SOUND_FALLBACK.get(name) or SOUND_FALLBACK_ANY
            if fb:
                try:
                    comp.PlayCustomMusic(fb, pos, volume, pitch, False, None)
                except Exception:
                    pass

    # ==================== 咬中的小火花 ====================
    def _spawnHit(self, pos):
        # 咬中：一声撕咬 + 一点火花
        if getattr(cfg, "HIT_PARTICLE", True):
            try:
                comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
                comp.Create(HIT_PARTICLE, pos, (0.0, 0.0, 0.0))
            except Exception:
                pass
        self._playSound("battlebrew.bite", pos, 1.0)

    # ==================== 头顶火气 ====================
    def _spawnAngry(self, pos):
        if not getattr(cfg, "ANGRY_PARTICLE", True):
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
            comp.Create(ANGRY_PARTICLE, pos, (0.0, 0.0, 0.0))
        except Exception:
            pass
