# -*- coding: utf-8 -*-
# ============================================================
#  好斗生物 - 可调参数（想改玩法只改这个文件，改完重新打包即可）
# ============================================================

ENABLED = True                  # 整个玩法的总开关

# ---------------- 药水本体 ----------------
ITEM = "battlebrew:battle_potion"   # 战斗药水的物品名（别改）
ITEM_NAME = u"战斗药水"          # 提示里显示的名字
JOIN_GIVE = 1                   # 进游戏送几瓶（0 = 不送）
CHAT_COMMAND = True             # 允许聊天输 #战斗药水 拿一瓶（方便手机端测试）
CHAT_WORDS = (u"#战斗药水", u"#好斗", u"#battlebrew")

# ---------------- 扔出去 ----------------
SPLASH_PROJECTILE = "minecraft:splash_potion"   # 扔的还是原版喷溅药水（有碎裂动画）
SPLASH_POWER = 1.25             # 出手力量（越大扔越远）
SPLASH_GRAVITY = 0.06           # 重力（越小飞得越平）
SPLASH_THROW_UP = 0.18          # 出手稍微往上抬一点
SPLASH_TIMEOUT = 8.0            # 扔出去多久还没落地就按最后位置生效
SPLASH_COOLDOWN = 0.45          # 两次投掷最短间隔，防止一次点击扔出两瓶
SPLASH_RADIUS = 3.5             # 落地后多少格内的生物一起发狂（格）
SPLASH_TIP = True               # 扔出 / 中招时提示一句
SPLASH_FALLBACK = 1.2          # 扔出多久还没收到落地信号，就按预判落点先生效
AIM_RANGE = 24.0               # 预判落点最远往前看多少格

# ---------------- 发狂 ----------------
ANGRY_DURATION = 30.0           # 发狂维持多少秒
TARGET_RANGE = 12.0             # 在多少格内挑打架对象
TARGET_REFRESH = 1.0            # 多久重新随机挑一次目标
TARGET_INCLUDE_PLAYER = False   # 也打玩家（默认关掉：只对生物生效，不惹玩家）
TARGET_INCLUDE_CREATURE = True  # 打其他生物
# 附近同时有生物和玩家时，优先打生物（设 False 就回到完全随机）
PREFER_CREATURE = True
MAX_ANGRY = 16                  # 同时最多几只生物发狂（防止卡服）

# ---------------- 聚会：打架时转身面对面 ----------------
FACE_TARGET = True             # 打架时转身面对着对手
FACE_INTERVAL = 0.1            # 隔多久摆正一次朝向

# ---------------- 扑咬 ----------------
LUNGE = True                    # 会自己朝目标扑过去
LUNGE_INTERVAL = 0.8            # 隔多久扑一次
LUNGE_SPEED = 0.5               # 扑的力道
LUNGE_UP = 0.28                 # 扑的时候抬多高
LUNGE_MIN_DIST = 2.0            # 这么近就不扑了
BITE_DAMAGE = 3.0               # 咬一口多少伤害
BITE_INTERVAL = 1.2             # 隔多久咬一口
BITE_DIST = 2.6                 # 离这么近才算咬到

# ---------------- 粒子（没事别改：改成不合适的会一直刷屏） ----------------
ANGRY_PARTICLE_NAME = "minecraft:villager_angry"   # 头顶火气
HIT_PARTICLE_NAME = "minecraft:villager_angry"     # 咬中那一下

# ---------------- 表现 ----------------
ANGRY_PARTICLE = True           # 头顶冒火气
PARTICLE_INTERVAL = 0.8
PARTICLE_HEIGHT = 1.0
HIT_PARTICLE = True             # 咬中时冒火花
SOUND_ENABLED = True            # 愤怒的叫声
SOUND_INTERVAL = 1.5
SOUND_VOLUME = 1.0
TIP = True                      # 聊天栏提示
ANNOUNCE = True                 # 有生物发狂时，提醒附近的玩家
ANNOUNCE_DIST = 24.0

# ---------------- 自己的伙伴不参战 ----------------
# 已驯服的宠物（狗 / 猫 / 狐狸…）不会被激怒，也不会被发狂的生物当成目标。
SKIP_TAMED = True
# 这些生物一律不参战（不管有没有被驯服）。想多保护几种就往后面加。
SKIP_TYPES = ("minecraft:fox",)

# ---------------- 叫声：什么生物就叫它自己的声音 ----------------
# 靠生物名字里的关键词配对，从上往下第一个命中的赢。
# 比如 minecraft:zombie → zombie，minecraft:cow → cow。
SOUND_BY_TYPE = (
    (u"zombie_villager", "zombie"),
    (u"zombie_pigman", "zombie"),
    (u"zombie", "zombie"),
    (u"husk", "zombie"),
    (u"drowned", "zombie"),
    (u"wither_skeleton", "skeleton"),
    (u"skeleton", "skeleton"),
    (u"stray", "skeleton"),
    (u"bogged", "skeleton"),
    (u"cave_spider", "spider"),
    (u"spider", "spider"),
    (u"creeper", "creeper"),
    (u"piglin_brute", "piglin"),
    (u"piglin", "piglin"),
    (u"zoglin", "zoglin"),
    (u"hoglin", "hoglin"),
    (u"pig", "pig"),
    (u"mooshroom", "cow"),
    (u"cow", "cow"),
    (u"sheep", "sheep"),
    (u"chicken", "chicken"),
    (u"parrot", "chicken"),
    (u"wandering_trader", "villager"),
    (u"villager", "villager"),
    (u"magma_cube", "magmacube"),
    (u"magmacube", "magmacube"),
    (u"slime", "slime"),
    (u"blaze", "blaze"),
    (u"ghast", "ghast"),
    (u"ender_dragon", "dragon"),
    (u"enderman", "endermen"),
    (u"endermen", "endermen"),
    (u"iron_golem", "irongolem"),
    (u"snow_golem", "snowgolem"),
    (u"snowgolem", "snowgolem"),
    (u"polar_bear", "polarbear"),
    (u"polarbear", "polarbear"),
    (u"llama", "llama"),
    (u"ravager", "ravager"),
    (u"witch", "witch"),
    (u"silverfish", "silverfish"),
    (u"fox", "fox"),
    (u"panda", "panda"),
    (u"bee", "bee"),
    (u"wither", "wither"),
    (u"phantom", "phantom"),
    (u"pillager", "illager"),
    (u"vindicator", "illager"),
    (u"evocation", "illager"),
    (u"evoker", "illager"),
    (u"illusion", "illager"),
    (u"vex", "illager"),
    (u"turtle", "turtle"),
    (u"cat", "cat"),
    (u"ocelot", "cat"),
    (u"wolf", "wolf"),
    (u"dog", "wolf"),
)
SOUND_FALLBACK = "angry"      # 配不上的生物用这个（一声低吼）


def soundFamilyOf(entityType):
    # 这只生物该叫哪一组声音
    low = str(entityType or u"").lower()
    for key, fam in SOUND_BY_TYPE:
        if key in low:
            return fam
    return SOUND_FALLBACK
