# -*- coding: utf-8 -*-
# ============================================================
#  好斗生物 - 服务端
#  一句话：战斗药水扔出去，被砸到的生物当场发狂，随机盯上附近的
#          任意生物（玩家也算）扑上去咬，时间一到自己冷静下来。
#
#  负责：
#    1. 认出玩家手里的战斗药水 -> 改成"扔出去"（不是喝掉）
#    2. 瓶子落地 -> 把附近的生物全部激怒
#    3. 发狂期间：随机挑目标 / 下仇恨 / 扑过去 / 咬一口 / 冒火气 / 愤怒叫声
#    4. 时间到 / 生物死了 / 跑太远 -> 清仇恨、恢复原样
# ============================================================
import math
import random
import time
import mod.server.extraServerApi as serverApi
from BattleBrewScripts import modConfig
from BattleBrewScripts import battleBrewConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()


class BattleBrewServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(BattleBrewServerSystem, self).__init__(namespace, systemName)
        self._on = bool(getattr(cfg, "ENABLED", True))
        self._angry = {}        # 生物id -> 发狂记录
        self._splash = {}       # 扔出去的药水id -> 谁扔的 / 飞到哪了
        self._throwAt = {}      # playerId -> 上次扔的时间（一次点击只扔一瓶）
        self._giveAt = {}       # playerId -> 什么时候把进游戏送的药水放进背包
        self._welcomed = set()  # 已经送过药水的玩家
        self._dead = {}         # 刚死掉的实体id -> 时间
        self._lastTick = 0.0
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        def _L(_ns, _sn, _name, _obj, _handler):
            # 个别平台上某个事件名可能不存在：这一条注册失败就跳过。
            # 不能让整个系统因为一个不认识的事件名挂掉（手机端最容易踩）。
            try:
                self.ListenForEvent(_ns, _sn, _name, _obj, _handler)
            except Exception:
                pass
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        _L(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        _L(ns, sn, "ServerChatEvent", self, self.OnChat)
        _L(ns, sn, "OnScriptTickServer", self, self.OnTick)
        _L(ns, sn, "MobDieEvent", self, self.OnMobDie)
        # 手里拿着药水按下使用键（电脑右键 / 手机点屏幕）
        _L(ns, sn, "ServerItemTryUseEvent", self, self.OnItemTryUse)
        # 瓶子落地
        _L(ns, sn, "ProjectileDoHitEffectEvent", self, self.OnProjectileHit)

    # ==================== 取引擎数据的小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _rotOf(self, entityId):
        try:
            rot = serverApi.GetEngineCompFactory().CreateRot(entityId).GetRot()
            return float(rot[0]), float(rot[1])
        except Exception:
            return 0.0, 0.0

    def _dimOf(self, entityId):
        try:
            return int(serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId())
        except Exception:
            return 0

    def _typeOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateEngineType(
                entityId).GetEngineTypeStr()
        except Exception:
            return None

    def _alive(self, entityId):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateGame(
                serverApi.GetLevelId()).IsEntityAlive(entityId))
        except Exception:
            return True

    def _health(self, entityId):
        try:
            return float(serverApi.GetEngineCompFactory().CreateAttr(
                entityId).GetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH))
        except Exception:
            return -1.0

    def _dist(self, a, b):
        return math.sqrt((float(a[0]) - float(b[0])) ** 2 +
                         (float(a[1]) - float(b[1])) ** 2 +
                         (float(a[2]) - float(b[2])) ** 2)

    def _isPlayer(self, entityId):
        if not entityId:
            return False
        try:
            if entityId in (serverApi.GetPlayerList() or []):
                return True
        except Exception:
            pass
        t = self._typeOf(entityId)
        return bool(t) and str(t).endswith(u":player")

    def _isTamed(self, entityId):
        # 已驯服的宠物
        try:
            return bool(serverApi.GetEngineCompFactory().CreateEntityDefinitions(
                entityId).IsTamed())
        except Exception:
            return False

    def _isProtected(self, entityId):
        # 自己的伙伴：不激怒，也不当目标
        if not entityId:
            return True
        t = str(self._typeOf(entityId) or u"").lower()
        for skip in (getattr(cfg, "SKIP_TYPES", None) or ()):
            if str(skip).lower() in t:
                return True
        if getattr(cfg, "SKIP_TAMED", True) and self._isTamed(entityId):
            return True
        return False

    def _tip(self, playerId, text, color="AQUA"):
        if not getattr(cfg, "TIP", True) or not playerId:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    def _chat(self, playerId, text):
        # 往聊天栏里发一条（诊断 / 测试用）
        if not playerId or not text:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateMsg(playerId)
            comp.NotifyOneMessage(playerId, text, "")
            return
        except Exception:
            pass
        self._tip(playerId, text)

    def _announce(self, text, pos, dim, color="GOLD"):
        # 只提醒附近的玩家，远处的人别被刷屏
        if not getattr(cfg, "ANNOUNCE", True) or not pos:
            return
        r = float(getattr(cfg, "ANNOUNCE_DIST", 24.0))
        for pid in list(serverApi.GetPlayerList() or []):
            if self._dimOf(pid) != dim:
                continue
            p = self._posOf(pid)
            if not p:
                continue
            if self._dist(p, pos) <= r:
                self._tip(pid, text, color)

    # ==================== 对生物下命令 ====================
    def _setTarget(self, entityId, targetId):
        # 让这只生物把仇恨挂到目标身上（原版 AI 就会自己冲上去）
        try:
            return bool(serverApi.GetEngineCompFactory().CreateAction(
                entityId).SetAttackTarget(targetId))
        except Exception:
            return False

    def _clearTarget(self, entityId):
        try:
            serverApi.GetEngineCompFactory().CreateAction(
                entityId).ResetAttackTarget()
        except Exception:
            pass

    def _motion(self, entityId, vec):
        try:
            serverApi.GetEngineCompFactory().CreateActorMotion(
                entityId).SetMotion((float(vec[0]), float(vec[1]), float(vec[2])))
            return True
        except Exception:
            return False

    def _hurt(self, victimId, attackerId, damage):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateHurt(
                victimId).Hurt(float(damage),
                               serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                               attackerId, None, True))
        except Exception:
            return False

    # ==================== 表现：声音 / 粒子（广播给所有客户端） ====================
    def _broadcast(self, data):
        try:
            self.BroadcastToAllClient(modConfig.EventFx, data)
        except Exception:
            pass

    def _fxAt(self, kind, pos, dim, pitch=1.0):
        if pos is None:
            return
        self._broadcast({"t": kind,
                         "x": float(pos[0]), "y": float(pos[1]),
                         "z": float(pos[2]),
                         "p": float(pitch), "dim": int(dim)})

    def _voice(self, entityId):
        # 发狂时的叫声
        if not getattr(cfg, "SOUND_ENABLED", True) or not entityId:
            return
        pos = self._posOf(entityId)
        if pos is None:
            return
        try:
            fam = cfg.soundFamilyOf(self._typeOf(entityId))
        except Exception:
            fam = "angry"
        pitch = 0.9 + random.random() * 0.3
        self._fxAt("battlebrew." + str(fam), (pos[0], pos[1] + 0.7, pos[2]),
                   self._dimOf(entityId), pitch)

    def _angryFx(self, entityId):
        # 头顶冒火气
        if not getattr(cfg, "ANGRY_PARTICLE", True) or not entityId:
            return
        pos = self._posOf(entityId)
        if pos is None:
            return
        h = float(getattr(cfg, "PARTICLE_HEIGHT", 1.0))
        self._fxAt("angry", (pos[0], pos[1] + h, pos[2]),
                   self._dimOf(entityId))

    def _hitFx(self, entityId, pos=None):
        # 咬中时的小火花
        if not getattr(cfg, "HIT_PARTICLE", True) or not entityId:
            return
        if pos is None:
            pos = self._posOf(entityId)
        if pos is None:
            return
        self._fxAt("hit", (pos[0], pos[1] + 0.8, pos[2]),
                   self._dimOf(entityId))

    def _consumeOne(self, playerId):
        # 取消"使用"之后物品不会自己变少，这里手动扣掉一个
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
            slot = int(comp.GetSelectSlotId())
            item = comp.GetPlayerItem(ItemPosType.INVENTORY, slot, True)
            if not item:
                return
            num = int(item.get("count", 1))
            if num <= 1:
                comp.SetInvItemNum(slot, 0)
            else:
                comp.SetInvItemNum(slot, num - 1)
        except Exception:
            pass

    def _giveItem(self, playerId, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            itemName = str(getattr(cfg, "ITEM", ""))
            ok = comp.SpawnItemToPlayerInv(
                {"itemName": itemName, "count": int(num), "auxValue": 0}, playerId)
            if ok:
                self._tip(playerId, u"已获得 %s ×%d：拿在手里点一下屏幕就扔出去"
                          % (getattr(cfg, "ITEM_NAME", u"战斗药水"), int(num)),
                          "LIGHT_PURPLE")
            return bool(ok)
        except Exception:
            return False

    def _hasItem(self, playerId):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
            item = comp.GetPlayerItem(ItemPosType.INVENTORY, 0, False)
            name = ""
            if isinstance(item, dict):
                name = str(item.get("itemName") or item.get("newItemName") or "").lower()
            return name == str(getattr(cfg, "ITEM", "")).lower()
        except Exception:
            return False

    # ==================== 玩家进游戏 / 聊天指令 ====================
    def OnAddPlayer(self, args=None):
        try:
            playerId = self._actorIdOf(args)
            if not playerId:
                return
            self._giveAt[playerId] = time.time() + 3.0
        except Exception:
            pass

    def _tickGive(self, now):
        if not self._giveAt:
            return
        for playerId in list(self._giveAt.keys()):
            if now < float(self._giveAt.get(playerId, 0.0)):
                continue
            del self._giveAt[playerId]
            if playerId in self._welcomed:
                continue
            self._welcomed.add(playerId)
            n = int(getattr(cfg, "JOIN_GIVE", 1))
            if n > 0 and not self._hasItem(playerId):
                self._giveItem(playerId, n)

    def OnChat(self, args=None):
        # 聊天框输 #战斗药水 拿一瓶（手机端测试最方便）
        try:
            if not args or not getattr(cfg, "CHAT_COMMAND", True):
                return
            playerId = self._actorIdOf(args)
            msg = str(args.get("message") or "").strip()
            if not playerId or not msg:
                return
            low = msg.lower()
            if low in (u"#好斗测试", u"#battletest"):
                n = self._angerNearby(playerId)
                self._chat(playerId, u"[好斗生物] 附近 %d 只生物已经发狂，看它们打不打" % n)
                return
            if low in (u"#好斗诊断", u"#battledebug"):
                self._diag(playerId)
                return
            words = [str(w).lower() for w in (getattr(cfg, "CHAT_WORDS", None) or [])]
            hit = None
            for w in words:
                if low == w or low.startswith(w + " "):
                    hit = w
                    break
            if not hit:
                return
            num = 1
            tail = msg[len(hit):].strip()
            if tail:
                try:
                    num = max(1, min(16, int(tail)))
                except Exception:
                    num = 1
            self._giveItem(playerId, num)
        except Exception:
            pass

    def _angerNearby(self, playerId):
        # 不走药水，直接把附近的生物弄发狂（拿来验证"打架"这一环好不好使）
        pos = self._posOf(playerId)
        if not pos:
            return 0
        r = float(getattr(cfg, "SPLASH_RADIUS", 3.5)) * 3.0
        got = 0
        for eid in self._entitiesAround(pos, r, self._dimOf(playerId)):
            if self._isPlayer(eid):
                continue
            p = self._posOf(eid)
            if not p or not self._alive(eid):
                continue
            if self._dist(p, pos) > r:
                continue
            if self._anger(eid, playerId):
                got += 1
        return got

    def _diag(self, playerId):
        pos = self._posOf(playerId)
        dim = self._dimOf(playerId)
        r = float(getattr(cfg, "SPLASH_RADIUS", 3.5))
        near = 0
        prot = 0
        kinds = []
        ids = self._entitiesAround(pos, r, dim) if pos else []
        for eid in ids:
            if self._isPlayer(eid):
                continue
            p = self._posOf(eid)
            if not p or not self._alive(eid):
                continue
            near += 1
            if self._isProtected(eid):
                prot += 1
                continue
            if len(kinds) < 3:
                kinds.append(str(self._typeOf(eid)))
        self._chat(playerId, u"[好斗] 身边 %d 格内生物：%d 只（其中 %d 只是伙伴，不参战）"
                   % (int(r), near, prot))
        self._chat(playerId, u"[好斗] 会被激怒的：%s"
                   % (u" / ".join(kinds) if kinds else u"没有"))
        lines = []
        for eid in list(self._angry.keys())[:4]:
            rec = self._angry.get(eid) or {}
            lines.append(u"%s→%s" % (eid, rec.get("target")))
        self._chat(playerId, u"[好斗] 正在发狂：%d 只  %s"
                   % (len(self._angry), u"  ".join(lines)))

    def _actorIdOf(self, args):
        # 不同事件给的键不一样：playerId / entityId / id 都认一遍
        if not isinstance(args, dict):
            return None
        for k in ("playerId", "entityId", "id"):
            v = args.get(k)
            if v:
                return v
        return None

    def _itemIdOf(self, itemDict):
        # 有的版本给 newItemName，有的给 itemName，两个都认
        if not isinstance(itemDict, dict):
            return u""
        for k in ("newItemName", "itemName"):
            v = itemDict.get(k)
            if v:
                return str(v).lower()
        return u""

    # ==================== 扔药水 ====================
    def OnItemTryUse(self, args=None):
        # 手里拿着战斗药水按下使用键：原地喝掉 -> 改成扔出去
        try:
            if not args or not self._on:
                return
            playerId = self._actorIdOf(args)
            if not playerId:
                return
            name = self._itemIdOf(args.get("itemDict"))
            if not name or name != str(getattr(cfg, "ITEM", "")).lower():
                return
            if self._throwSplash(playerId):
                try:
                    args["cancel"] = True     # 别把瓶子喝掉
                except Exception:
                    pass
                self._consumeOne(playerId)
        except Exception:
            pass

    def _eyePosOf(self, playerId):
        feet = self._posOf(playerId)
        if not feet:
            return None
        try:
            return (float(feet[0]), float(feet[1]) + 1.62, float(feet[2]))
        except Exception:
            return None

    def _lookDirOf(self, playerId):
        pitch, yaw = self._rotOf(playerId)
        try:
            d = serverApi.GetDirFromRot((pitch, yaw))
        except Exception:
            return None
        try:
            dx = float(d[0])
            dy = float(d[1]) + float(getattr(cfg, "SPLASH_THROW_UP", 0.18))
            dz = float(d[2])
            n = math.sqrt(dx * dx + dy * dy + dz * dz)
            if n < 1e-4:
                return None
            return (dx / n, dy / n, dz / n)
        except Exception:
            return None

    def _landingOf(self, origin, direction, dim):
        # 从眼睛顺着视线往前摸，第一块挡路的方块就是药水大概会砸到的地方。
        # 这只是"万一没收到落地事件"时的保险，平时用不到它。
        if not origin or not direction:
            return None
        try:
            comp = serverApi.GetEngineCompFactory().CreateBlockInfo(
                serverApi.GetLevelId())
        except Exception:
            return None
        step = 0.25
        t = 1.0
        limit = float(getattr(cfg, "AIM_RANGE", 24.0))
        last = None
        while t <= limit:
            x = float(origin[0]) + float(direction[0]) * t
            y = float(origin[1]) + float(direction[1]) * t
            z = float(origin[2]) + float(direction[2]) * t
            t += step
            last = (x, y, z)
            try:
                blk = comp.GetBlockNew((int(math.floor(x)),
                                        int(math.floor(y)),
                                        int(math.floor(z))), dim)
            except Exception:
                return None
            name = u""
            if isinstance(blk, dict):
                name = str(blk.get("name") or blk.get("newBlockName") or u"")
            low = name.lower()
            if (not name) or low.endswith(u":air") or (u"water" in low):
                continue
            return (x, y, z)
        return last

    def _spawnSplash(self, playerId, origin, direction):
        # 让引擎发一个原版喷溅药水出去（落地自带碎裂动画和音效）
        try:
            comp = serverApi.GetEngineCompFactory().CreateProjectile(
                serverApi.GetLevelId())
            param = {"position": (float(origin[0]), float(origin[1]), float(origin[2])),
                     "direction": (float(direction[0]), float(direction[1]),
                                   float(direction[2])),
                     "power": float(getattr(cfg, "SPLASH_POWER", 1.25)),
                     "gravity": float(getattr(cfg, "SPLASH_GRAVITY", 0.06)),
                     "isDamageOwner": False,
                     "auxValue": 0}
            pid = comp.CreateProjectileEntity(
                playerId, str(getattr(cfg, "SPLASH_PROJECTILE",
                                      "minecraft:splash_potion")), param)
        except Exception:
            return None
        if not pid or str(pid) == "-1":
            return None
        return str(pid)

    def _throwSplash(self, playerId):
        if not self._on:
            return False
        now = time.time()
        gap = float(getattr(cfg, "SPLASH_COOLDOWN", 0.45))
        if now - float(self._throwAt.get(playerId, 0.0)) < gap:
            return False                # 一次点击只扔一瓶
        origin = self._eyePosOf(playerId)
        direction = self._lookDirOf(playerId)
        pid = None
        if origin and direction:
            pid = self._spawnSplash(playerId, origin, direction)
        self._throwAt[playerId] = now
        if not pid:
            # 极少数机器扔不出去：直接砸在脚边，效果不打折
            self._splashAtPos(origin, self._dimOf(playerId), playerId, None)
            return True
        dim = self._dimOf(playerId)
        self._splash[pid] = {"owner": playerId, "t": now, "pos": origin,
                             "live": False, "dim": dim,
                             "land": self._landingOf(origin, direction, dim),
                             "tLand": now + float(getattr(cfg, "SPLASH_FALLBACK", 1.2))}
        if getattr(cfg, "SPLASH_TIP", True):
            self._tip(playerId, u"%s 扔出去了：落地后 %d 格内的生物一起发狂"
                      % (getattr(cfg, "ITEM_NAME", u"战斗药水"),
                         int(getattr(cfg, "SPLASH_RADIUS", 3.5))), "LIGHT_PURPLE")
        return True

    def OnProjectileHit(self, args=None):
        # 自己扔的瓶子落地了（砸地上或者砸生物身上都算）
        try:
            if not args:
                return
            pid = args.get("id")
            rec = None
            for key in (str(pid), pid):
                if key is None:
                    continue
                rec = self._splash.pop(key, None)
                if rec:
                    break
            if not rec:
                return                  # 不是自己的瓶子，不管
            pos = self._splashPosOf(args)
            hitId = None
            if str(args.get("hitTargetType") or "").upper() == "ENTITY":
                hitId = args.get("targetId")
            self._splashAtPos(pos, rec.get("dim"), rec.get("owner"), hitId)
        except Exception:
            pass

    def _splashPosOf(self, args):
        # 砸在生物身上时，事件给回来的坐标不一定准，直接问那只生物在哪儿更稳
        try:
            if str(args.get("hitTargetType") or "").upper() == "ENTITY":
                target = args.get("targetId")
                if target:
                    p = self._posOf(target)
                    if p:
                        return (float(p[0]), float(p[1]) + 0.8, float(p[2]))
            return (float(args.get("x", 0.0)), float(args.get("y", 0.0)),
                    float(args.get("z", 0.0)))
        except Exception:
            return None

    # ==================== 瓶子炸开：让一片生物发狂 ====================
    def _splashAtPos(self, pos, dimensionId, owner=None, hitId=None):
        if not pos or not self._on:
            return []
        radius = float(getattr(cfg, "SPLASH_RADIUS", 3.5))
        got = []
        for eid in self._entitiesAround(pos, radius, dimensionId):
            if self._isPlayer(eid):
                continue               # 玩家不会被激怒（只有生物才会）
            p = self._posOf(eid)
            if not p or not self._alive(eid):
                continue
            if self._dist(p, pos) > radius:
                continue
            if self._anger(eid, owner):
                got.append(eid)
        # 直接被砸中的那只，哪怕离得远一点也算
        if hitId and not self._isPlayer(hitId) and hitId not in got:
            if self._anger(hitId, owner):
                got.append(hitId)
        if got:
            if owner:
                self._tip(owner, u"战斗药水炸开：%d 只生物当场发狂" % len(got), "RED")
            self._announce(u"有生物被战斗药水激怒了！", pos, dimensionId, "RED")
        return got

    def _entitiesAround(self, pos, r, dim):
        # 先问引擎这一片有哪些东西，再把玩家补进去（预防引擎没带上玩家）
        ids = []
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
            got = comp.GetEntitiesInSquareArea(
                None,
                (float(pos[0]) - r, float(pos[1]) - r, float(pos[2]) - r),
                (float(pos[0]) + r, float(pos[1]) + r, float(pos[2]) + r),
                dim)
            if got:
                ids = [str(x) for x in got]
        except Exception:
            ids = []
        for pid in list(serverApi.GetPlayerList() or []):
            if pid not in ids:
                ids.append(pid)
        return ids

    def _blastPosOf(self, rec):
        # 药水到底在哪儿炸：
        # 真的看到过它飞到哪就用那个，否则用推出来的落点
        if rec.get("live"):
            return rec.get("pos")
        return rec.get("land") or rec.get("pos")

    def _splashTick(self, now):
        # 兜底：万一没收到落地事件（少数机器），也得让药水生效
        if not self._splash:
            return
        for pid in list(self._splash.keys()):
            rec = self._splash.get(pid)
            if not rec:
                continue
            # 1) 到点了还没收到落地信号：直接按预判落点生效
            tLand = rec.get("tLand")
            if tLand and now >= float(tLand):
                self._splash.pop(pid, None)
                self._splashAtPos(self._blastPosOf(rec), rec.get("dim"),
                                  rec.get("owner"), None)
                continue
            # 2) 一边飞，一边记它飞到哪儿了
            if self._alive(pid):
                p = self._posOf(pid)
                if p:
                    rec["pos"] = p
                    rec["live"] = True
                if now - float(rec.get("t", now)) > float(
                        getattr(cfg, "SPLASH_TIMEOUT", 8.0)):
                    self._splash.pop(pid, None)
                    self._splashAtPos(self._blastPosOf(rec), rec.get("dim"),
                                      rec.get("owner"), None)
                continue
            if now - float(rec.get("t", now)) < 0.25:
                continue           # 刚出手，个别机器会短暂报"不存在"，先等一小会儿
            self._splash.pop(pid, None)
            self._splashAtPos(self._blastPosOf(rec), rec.get("dim"),
                              rec.get("owner"), None)

    # ==================== 发狂 ====================
    def _anger(self, entityId, owner=None):
        if not self._on or not entityId:
            return False
        if self._isPlayer(entityId) or not self._alive(entityId):
            return False
        if self._isProtected(entityId):
            return False            # 自己的伙伴不参战
        now = time.time()
        dur = float(getattr(cfg, "ANGRY_DURATION", 30.0))
        rec = self._angry.get(entityId)
        if rec:
            rec["until"] = max(float(rec.get("until", 0.0)), now + dur)
            return True                # 再砸一次就续时间
        limit = int(getattr(cfg, "MAX_ANGRY", 16))
        alive = 0
        for eid in list(self._angry.keys()):
            if self._alive(eid):
                alive += 1
        if alive >= limit:
            return False               # 太多只在打架了，先歇歇
        self._angry[entityId] = {"until": now + dur, "target": None, "owner": owner,
                                 "tFind": now,
                                 "tTarget": now,
                                 "tLunge": now + random.random() * 0.5,
                                 "tBite": now + 0.6 + random.random() * 0.4,
                                 "tSound": now,
                                 "tPart": now}
        self._voice(entityId)
        self._angryFx(entityId)
        return True

    def _calm(self, entityId):
        rec = self._angry.pop(entityId, None)
        if not rec:
            return
        self._clearTarget(entityId)

    def _pickTarget(self, entityId):
        # 在附近挑一只。附近有生物就先挑生物，没有生物才挑玩家。
        pos = self._posOf(entityId)
        if not pos:
            return None
        dim = self._dimOf(entityId)
        r = float(getattr(cfg, "TARGET_RANGE", 12.0))
        wantPlayer = bool(getattr(cfg, "TARGET_INCLUDE_PLAYER", True))
        wantMob = bool(getattr(cfg, "TARGET_INCLUDE_CREATURE", True))
        preferMob = bool(getattr(cfg, "PREFER_CREATURE", True))
        mobs = []
        players = []
        for eid in self._entitiesAround(pos, r, dim):
            if not eid or eid == entityId:
                continue
            if self._dimOf(eid) != dim:
                continue
            p = self._posOf(eid)
            if not p or self._dist(p, pos) > r:
                continue
            if not self._alive(eid):
                continue
            if self._isPlayer(eid):
                if wantPlayer:
                    players.append(eid)
                continue
            if self._isProtected(eid):
                continue            # 伙伴不打
            if wantMob:
                mobs.append(eid)
        if preferMob:
            # 优先打非玩家生物，附近没有生物才回头打玩家
            if mobs:
                return random.choice(mobs)
            if players:
                return random.choice(players)
            return None
        pool = mobs + players
        if not pool:
            return None
        return random.choice(pool)

    def _faceTo(self, entityId, tgt):
        # 转身面对着对手（直到打完都要对着）
        pos = self._posOf(entityId)
        if not pos or not tgt:
            return
        try:
            dx = float(tgt[0]) - float(pos[0])
            dy = float(tgt[1]) - (float(pos[1]) + 1.4)
            dz = float(tgt[2]) - float(pos[2])
            n = math.sqrt(dx * dx + dy * dy + dz * dz)
            if n < 1e-4:
                return
            rot = serverApi.GetRotFromDir((dx / n, dy / n, dz / n))
            serverApi.GetEngineCompFactory().CreateRot(entityId).SetRot(
                (float(rot[0]), float(rot[1])))
        except Exception:
            pass

    def _lunge(self, entityId, pa, pb, d):
        # 朝目标扑过去：原版 AI 走不走，自己也得冲上去（不然只会在原地吼）
        if not getattr(cfg, "LUNGE", True):
            return False
        if d < float(getattr(cfg, "LUNGE_MIN_DIST", 2.0)):
            return False
        dx = float(pb[0]) - float(pa[0])
        dz = float(pb[2]) - float(pa[2])
        h = math.sqrt(dx * dx + dz * dz)
        if h < 1e-4:
            dx, dz, h = 0.0, 1.0, 1.0
        speed = float(getattr(cfg, "LUNGE_SPEED", 0.5))
        up = float(getattr(cfg, "LUNGE_UP", 0.28))
        dy = float(pb[1]) - float(pa[1])
        if dy > 0.5:
            up = min(0.6, up + dy * 0.35)   # 对方在高处就跳高一点
        return self._motion(entityId, (dx / h * speed, up, dz / h * speed))

    def _tickAngry(self, now):
        if not self._angry:
            return
        for entityId in list(self._angry.keys()):
            rec = self._angry.get(entityId)
            if not rec:
                continue
            if now >= float(rec.get("until", 0.0)):
                self._calm(entityId)
                continue
            if not self._alive(entityId) or not self._typeOf(entityId):
                self._angry.pop(entityId, None)
                continue
            target = rec.get("target")
            if target and (not self._alive(target) or not self._typeOf(target)):
                target = None
                rec["target"] = None
            if now >= float(rec.get("tFind", 0.0)):
                rec["tFind"] = now + float(getattr(cfg, "TARGET_REFRESH", 1.0))
                fresh = self._pickTarget(entityId)
                # 换目标的两种情况：
                #   1) 现在没目标
                #   2) 现在盯着玩家，但旁边有生物了 -> 优先打生物
                if fresh and (not target or (
                        self._isPlayer(target) and not self._isPlayer(fresh))):
                    target = fresh
                    rec["target"] = target
                    rec["tTarget"] = now
                    self._setTarget(entityId, target)
            if now >= float(rec.get("tSound", 0.0)):
                rec["tSound"] = now + float(getattr(cfg, "SOUND_INTERVAL", 1.5)) *                     (0.75 + random.random() * 0.5)
                self._voice(entityId)
            if now >= float(rec.get("tPart", 0.0)):
                rec["tPart"] = now + float(getattr(cfg, "PARTICLE_INTERVAL", 0.8))
                self._angryFx(entityId)
            if not target:
                continue
            pa = self._posOf(entityId)
            pb = self._posOf(target)
            if not pa or not pb:
                rec["target"] = None
                continue
            d = self._dist(pa, pb)
            if d > float(getattr(cfg, "TARGET_RANGE", 12.0)):
                rec["target"] = None       # 追丢了，重新挑一个
                continue
            if getattr(cfg, "FACE_TARGET", True) and now >= float(
                    rec.get("tFace", 0.0)):
                rec["tFace"] = now + float(getattr(cfg, "FACE_INTERVAL", 0.1))
                self._faceTo(entityId, (pb[0], pb[1] + 1.4, pb[2]))
            if now >= float(rec.get("tTarget", 0.0)):
                rec["tTarget"] = now + float(getattr(cfg, "TARGET_REFRESH", 1.0))
                self._setTarget(entityId, target)
            if now >= float(rec.get("tLunge", 0.0)):
                rec["tLunge"] = now + float(getattr(cfg, "LUNGE_INTERVAL", 0.8))
                self._lunge(entityId, pa, pb, d)
            if d > float(getattr(cfg, "BITE_DIST", 2.6)):
                continue
            if now < float(rec.get("tBite", 0.0)):
                continue
            rec["tBite"] = now + float(getattr(cfg, "BITE_INTERVAL", 1.2))
            self._hitFx(target, pb)
            self._hurt(target, entityId, float(getattr(cfg, "BITE_DAMAGE", 3.0)))

    def OnMobDie(self, args=None):
        try:
            if not args:
                return
            eid = args.get("id")
            if eid:
                self._dead[eid] = time.time()
                self._calm(eid)
        except Exception:
            pass

    # ==================== 主循环 ====================
    def OnTick(self, args=None):
        if not self._on:
            return
        now = time.time()
        if now - self._lastTick < 0.02:
            return                          # 一帧里最多跑一次
        self._lastTick = now
        try:
            self._tickGive(now)
        except Exception:
            pass
        try:
            self._splashTick(now)
        except Exception:
            pass
        try:
            self._tickAngry(now)
        except Exception:
            pass
        # 定期清一下死掉实体的记录，别让字典越涨越大
        if self._dead and len(self._dead) > 64:
            cut = now - 10.0
            for eid in [k for k, t in self._dead.items() if t < cut]:
                self._dead.pop(eid, None)
