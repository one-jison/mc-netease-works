# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from BattleBrewScripts import modConfig


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class BattleBrewMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def BattleBrewServerInit(self):
        serverApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def BattleBrewServerDestroy(self):
        pass

    @Mod.InitClient()
    def BattleBrewClientInit(self):
        clientApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def BattleBrewClientDestroy(self):
        pass
