# -*- coding: utf-8 -*-
# 好斗生物 - 公共配置（模组名 / 事件名 / 版本号）
ModName = "BattleBrewMod"
ModVersion = "1.0.0"

ServerSystemName = "BattleBrewServerSystem"
ClientSystemName = "BattleBrewClientSystem"
ServerSystemClsPath = "BattleBrewScripts.battleBrewServerSystem.BattleBrewServerSystem"
ClientSystemClsPath = "BattleBrewScripts.battleBrewClientSystem.BattleBrewClientSystem"

# 服务端 -> 所有客户端（愤怒的叫声 + 火气粒子 + 咬中的火花）
EventFx = "BattleBrewFx"
