# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi


@Mod.Binding(name="FlyAwayMod", version="0.0.1")
class FlyAwayMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def FlyAwayServerInit(self):
        serverApi.RegisterSystem("FlyAwayMod", "FlyAwayServerSystem",
                                 "FlyAwayScripts.flyAwayServerSystem.FlyAwayServerSystem")

    @Mod.DestroyServer()
    def FlyAwayServerDestroy(self):
        pass

    @Mod.InitClient()
    def FlyAwayClientInit(self):
        pass

    @Mod.DestroyClient()
    def FlyAwayClientDestroy(self):
        pass
