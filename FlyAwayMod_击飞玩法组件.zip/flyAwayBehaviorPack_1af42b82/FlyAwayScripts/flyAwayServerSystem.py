# -*- coding: utf-8 -*-
import time
import mod.server.extraServerApi as serverApi

ServerSystem = serverApi.GetServerSystemCls()

# ==================== 力度调节（改这三行即可） ====================
# POWER      水平击飞力度，越大飞得越远
#            （原版普通击退约 0.4~1.0，官方“大力击飞”演示为 10）
# HEIGHT     上抛初速度，越大飞得越高
# HEIGHT_CAP 竖直速度上限，越大允许飞得越高
# 想“轻推”调到 4/0.8/0.8；想“又高又远”用 12/2.2/2.4；想更夸张可加到 20/3/3
POWER = 12.0
HEIGHT = 2.2
HEIGHT_CAP = 2.4
# ================================================================
BOOST = 0.6          # 额外保险速度比例，一般不用改
RECORD_SECONDS = 2.0  # 攻击记录保留时长（秒），一般不用改


class FlyAwayServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(FlyAwayServerSystem, self).__init__(namespace, systemName)
        self._recentAttacks = {}  # victimId -> (方向x, 方向z, 时间)
        # 玩家攻击实体时触发（用来记住是谁、从哪个方向被打）
        self.ListenForEvent(serverApi.GetEngineNamespace(),
                            serverApi.GetEngineSystemName(),
                            "PlayerAttackEntityEvent",
                            self, self.OnPlayerAttack)
        # 生物受伤时触发（官方验证过的击飞触发点，确保效果真正生效）
        self.ListenForEvent(serverApi.GetEngineNamespace(),
                            serverApi.GetEngineSystemName(),
                            "ActorHurtServerEvent",
                            self, self.OnActorHurt)

    def _pruneRecords(self):
        now = time.time()
        self._recentAttacks = dict(
            (k, v) for k, v in self._recentAttacks.items()
            if now - v[2] <= RECORD_SECONDS)

    def _isPlayer(self, entityId):
        try:
            playerList = serverApi.GetPlayerList()
            return bool(playerList) and entityId in playerList
        except Exception:
            return False

    def OnPlayerAttack(self, args):
        playerId = args.get("playerId")
        victimId = args.get("victimId")
        if not playerId or not victimId or victimId == playerId:
            return
        if self._isPlayer(victimId):
            return  # 不打飞玩家
        self._pruneRecords()
        try:
            compFactory = serverApi.GetEngineCompFactory()
            playerPos = compFactory.CreatePos(playerId).GetFootPos()
            victimPos = compFactory.CreatePos(victimId).GetFootPos()
            if not playerPos or not victimPos:
                return
            dirX = victimPos[0] - playerPos[0]
            dirZ = victimPos[2] - playerPos[2]
            length = (dirX * dirX + dirZ * dirZ) ** 0.5
            if length <= 0.001:
                return
            dirX, dirZ = dirX / length, dirZ / length
            self._recentAttacks[victimId] = (dirX, dirZ, time.time())
            self._fly(victimId, dirX, dirZ)
        except Exception:
            pass

    def OnActorHurt(self, args):
        victimId = args.get("entityId")
        record = self._recentAttacks.pop(victimId, None)
        if not record:
            return  # 不是刚才被玩家打的，忽略（火焰/摔伤等不触发）
        self._fly(victimId, record[0], record[1])

    def _fly(self, victimId, dirX, dirZ):
        # 官方击退接口：xd/zd 控制方向，power/height/heightCap 控制速度
        try:
            comp = serverApi.GetEngineCompFactory().CreateAction(victimId)
            comp.SetMobKnockback(dirX, dirZ, POWER, HEIGHT, HEIGHT_CAP)
        except Exception:
            pass
        # 保险：额外直接施加一个初速度，保证即使击退被原版流程覆盖也能飞出去
        try:
            motionComp = serverApi.GetEngineCompFactory().CreateActorMotion(victimId)
            motionComp.SetMotion((dirX * POWER * BOOST, HEIGHT * BOOST,
                                  dirZ * POWER * BOOST))
        except Exception:
            pass