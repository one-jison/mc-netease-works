# -*- coding: utf-8 -*-
# ============================================================
#  野生狗奶 — 所有能调的数字都在这儿，改完重启就生效
# ============================================================

MODE_ON = True                    # 整个模组的总开关
MILK_NAME = u"野生狗奶"            # 药水名字（聊天提示、屏幕左上角都用它）
MILK_ITEM = "wilddogmilk:wild_dog_milk"   # 物品 ID（别乱改）
SHELF_LIFE = u"保质期：永久"        # 物品说明

# ---------------- 喝下去那一瞬间 ----------------
WARP_FOLLOW_MUSIC = False    # False = 画面扭曲固定 10 秒；True = 改成跟着整首音乐走
MOVIE_ON = True           # True = 喝下去的瞬间，全屏放一遍《野生狗奶》视频
MOVIE_FRAMES = 66         # 视频被拆成了多少张图（跟着 textures/ui/wilddogmilk/movie 里的张数走）
MOVIE_FPS = 12.0          # 视频播放帧率（12 = 每秒 12 张）
MOVIE_SECONDS = 5.5       # 视频多长（秒）

WARP_SECONDS = 10.0          # 画面扭曲（屏幕漩涡 + 视角晃动）持续几秒
MUSIC_SECONDS = 52.2         # 整首音乐有多长（秒）。这是实测出来的
MUSIC_START_DELAY = 0.0      # 音乐从按下播放到真正出声的延迟（只有跟着音乐走时才用）
WARP_END_TUNE = 0.0          # 微调：正数 = 扭曲多转几秒，负数 = 早停几秒
WARP_MAX_SECONDS = 60.0      # 安全上限：无论如何到点就收，绝不让画面卡着不散
WARP_FPS = 12.5              # 扭曲画面每秒至少换几张
WARP_MAX_STEPS = 125         # 整段扭曲一共换多少张画，10 秒 x 12.5 张 = 125
NAUSEA_FOLLOW_MUSIC = False  # True = 连原版那种“晕”也跟着音乐走
NAUSEA_SECONDS = 10.0        # 原版那种“晕”持续几秒（跟扭曲一起收）

# ---------------- 音乐 / 音效 ----------------
DRINK_GULP = True                        # 喝下的一瞬间先来一声游戏自带的喝药声（保证听得到）
DRINK_GULP_SOUND = "random.drink"        # 那一声用哪个音效
DRINK_MUSIC_FULL = True                  # True = 放整首（约 52 秒，放完为止）
DRINK_MUSIC = "wilddogmilk.music"        # 整首音乐在资源包里的名字
DRINK_SOUND_SHORT = "wilddogmilk.drink"  # 开头那 4 秒（备用）
DRINK_SOUND_VOLUME = 1.0                 # 音量
DRINK_SOUND_PITCH = 1.0                  # 音调
DRINK_SOUND_SERVER = False               # 客户端实在放不出来时改 True：让服务端来放
DRINK_SOUND_FALLBACK = "wilddogmilk.music"  # 服务端兜底放哪一条（连这个都没声就改成 random.drink）
DRINK_SOUND_RADIUS = 1.0                 # 兜底时声音能传多远，1 = 基本只自己听得到

# ---------------- 药效（默认 3 分钟） ----------------
BUFF_SECONDS = 180.0       # 药效持续几秒：180 秒 = 3 分钟（想改时长就改这个数）
SPEED_AMPLIFIER = 2        # 加速等级：0=速度I，2=速度III
JUMP_AMPLIFIER = 8         # 跳跃提升等级，8 = 跳得非常高
REGEN_AMPLIFIER = 4        # 生命恢复等级，4 = 挨打之后血飞快往回涨
AUTO_REFRESH = False       # False = 到点就过期；True = 每隔一会儿自动续（就变成永久了）
REFRESH_SECONDS = 60.0     # 只在上面那条改成 True 的时候才用
KEEP_ON_DEATH = False      # 死了之后药效留不留：False = 不留，重生要再喝一瓶

# ---------------- 其他 ----------------
JOIN_GIVE = False          # 进游戏不再白送（改成 True 又会在进游戏时送）
JOIN_GIVE_COUNT = 3        # 万一开了上面那条，送几瓶
TIP_ON_DRINK = True        # 喝下去时在聊天框里提示一句

# ---------------- 这瓶奶只能跟狗要（默认玩法） ----------------
DOG_MILK = True                # True = 拿着铁桶靠近狗，屏幕上出现"获取"按钮
DOG_ITEM = "minecraft:bucket"  # 手上要拿的东西（铁桶）
DOG_RANGE = 2.0                # 离狗多近才会出现按钮（格）
DOG_GET_COUNT = 1              # 点一次给几瓶
DOG_CHECK_TICKS = 4            # 每隔几个 tick 查一次（20 tick = 1 秒）
DOG_ANY_SLOT = False           # False = 必须把铁桶拿在手里举着，放背包里不算
DOG_LOOSE = True               # True = 不小心读不出实体类型时，旁边有活物就当是狗
DOG_HINT = True                # True = 拿着铁桶没找到狗时，屏幕上方给一句提示


# ============================================================
#  下面几个函数不用动，改上面的数字就行
# ============================================================
def warpSeconds():
    # 画面扭曲一共持续几秒（微调 WARP_END_TUNE 正数就多几秒）
    if WARP_FOLLOW_MUSIC:
        base = float(MUSIC_SECONDS)
    else:
        base = float(WARP_SECONDS)
    return max(0.5, base + float(WARP_END_TUNE))


def nauseaSeconds():
    # 原版那种"晕"持续几秒
    if NAUSEA_FOLLOW_MUSIC:
        return warpSeconds()
    return max(0.0, float(NAUSEA_SECONDS))



def buffSeconds():
    # 药效持续几秒
    return max(1.0, float(BUFF_SECONDS))


def movieOn():
    # 喝下去的瞬间要不要全屏放那段视频
    return bool(MOVIE_ON)


def movieFrames():
    # 视频被拆成了多少张图
    return max(1, int(MOVIE_FRAMES))


def movieFps():
    # 视频每秒换几张
    return max(1.0, float(MOVIE_FPS))


def movieSeconds():
    # 视频多长（秒）
    return max(0.2, float(MOVIE_SECONDS))
