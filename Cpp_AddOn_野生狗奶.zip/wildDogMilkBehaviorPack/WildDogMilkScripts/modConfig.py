# -*- coding: utf-8 -*-
# ============================================================
#  野生狗奶 — 公共配置（模组名 / 事件名 / 界面名）
# ============================================================
ModName = "WildDogMilkMod"
ModVersion = "1.0.0"

ServerSystemName = "WildDogMilkServerSystem"
ClientSystemName = "WildDogMilkClientSystem"
ServerSystemClsPath = "WildDogMilkScripts.wildDogMilkServerSystem.WildDogMilkServerSystem"
ClientSystemClsPath = "WildDogMilkScripts.wildDogMilkClientSystem.WildDogMilkClientSystem"

# 客户端 -> 服务端（自定义音效放不出来时，请服务端帮忙放一声）
EventSound = "WildDogMilkSound"

# 服务端 -> 这个玩家自己：刚喝下一瓶（开始 5 秒空间扭曲 + 放音效）
EventDrink = "WildDogMilkDrink"
# 服务端 -> 这个玩家自己：药效还在不在
EventState = "WildDogMilkState"
# 服务端 -> 这个玩家自己：时间到了，把屏幕漩涡收起来
EventWarpStop = "WildDogMilkWarpStop"
# 服务端 -> 这个玩家自己：手上拿着铁桶、旁边有狗，把"获取"按钮亮出来
EventDogBtn = "WildDogMilkDogBtn"
# 客户端 -> 服务端：点了"获取"按钮
EventGetMilk = "WildDogMilkGetMilk"

UiInitFinishedEvent = "UiInitFinished"
HudUIName = "wilddogmilkhud"
HudUIPyClsPath = "WildDogMilkScripts.wildDogMilkHudScreen.WildDogMilkHudScreen"
HudUIScreenDef = "wilddogmilkhud.main"
