# -*- coding: utf-8 -*-
# ============================================================
#  野生狗奶 - 屏幕界面（HUD）
#    · 左上角常驻：野生狗奶 · 保质期：永久
#    · 右上角：原版那种药水方框（方框里有图标，底下写倒计时）
#    · 右下角：手上拿着铁桶、旁边有狗时，亮出一个"获取"按钮
#    · 屏幕中央：12 张漩涡图轮着显示，就是那 10 秒画面扭曲
#    · 自带保险：到点自己收，绝不留一个漩涡在屏幕上
# ============================================================
import time
import mod.client.extraClientApi as clientApi
from WildDogMilkScripts import wildDogMilkConfig as cfg

ScreenNode = clientApi.GetScreenNodeCls()

WARP_FRAMES = 12
MOVIE_FRAMES = max(1, int(cfg.movieFrames()))


class WildDogMilkHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mLblName = self.mPanel + "/lblName"
        self.mLblBuff = self.mPanel + "/lblBuff"
        # 右上角那个药水方框
        self.mBuffPanel = "/buffPanel"
        self.mBuffTime = self.mBuffPanel + "/buffTime"
        # 右下角跟狗要奶的按钮
        self.mGetPanel = "/getPanel"
        self.mGetBtn = self.mGetPanel + "/getBtn"
        # 喝下去瞬间全屏放的那段视频
        self.mMoviePanel = "/moviePanel"
        self.mMovieFrames = [self.mMoviePanel + "/mv%03d" % i
                             for i in range(MOVIE_FRAMES)]
        self.mMovieCur = -2
        self.mMovieHideAt = 0.0
        self.mWarpPanel = "/warpPanel"
        self.mFrames = [self.mWarpPanel + "/warp%02d" % i
                        for i in range(WARP_FRAMES)]
        self.mFrame = -2
        self.mActive = None
        self.mHideAt = 0.0
        self.mBuffText = None
        self.mTimeText = None
        self.mGetShown = None
        self.mOnGet = None

    def Create(self):
        self._setLabel(self.mLblName,
                       u"%s · %s" % (cfg.MILK_NAME, cfg.SHELF_LIFE),
                       (1.0, 0.94, 0.55))
        self._setLabel(self.mLblBuff,
                       u"加速 / 超高跳跃 / 快速回血",
                       (0.62, 0.94, 1.0))
        self.mActive = None
        self.mBuffText = None
        self.mTimeText = None
        self.mGetShown = None
        self.mFrame = -2
        self.mHideAt = 0.0
        self._wireGetButton()
        self.SetActive(False)
        self.SetBuffTime(u"")
        self.SetGetVisible(False)
        self.SetWarpFrame(-1)
        self.SetMovieFrame(-1)

    def Update(self):
        # 每帧都会被游戏喊一次：只要没人来收，到点它就自己把画面扭曲收掉，
        # 绝不会一直留在屏幕上
        if self.mFrame >= 0 and self.mHideAt > 0.0 and time.time() >= self.mHideAt:
            self.SetWarpFrame(-1)
        # 视频也一样：到点自己收，绝不会卡在屏幕上
        if self.mMovieCur >= 0 and self.mMovieHideAt > 0.0 and time.time() >= self.mMovieHideAt:
            self.SetMovieFrame(-1)

    # ==================== 左上角那两行字 ====================
    def SetActive(self, on):
        v = bool(on)
        if self.mActive == v:
            return
        self.mActive = v
        self._setVisible(self.mLblName, v)
        self._setVisible(self.mLblBuff, v)

    def SetBuff(self, text):
        # 左上角第二行字（留着给老写法用，平时走 SetBuffTime 那条）
        if text is None:
            text = u""
        if self.mBuffText == text:
            return
        self.mBuffText = text
        self._setLabel(self.mLblBuff, text, (0.62, 0.94, 1.0))

    # ==================== 右上角：原版那种药水倒计时 ====================
    def SetBuffTime(self, text):
        # 一个方框 + 方框里一瓶狗奶 + 底下写还有多久；没药效就整个收掉
        if text is None:
            text = u""
        text = u"%s" % text
        self.mTimeText = text
        self._setLabel(self.mBuffTime, text)
        self._setVisible(self.mBuffPanel, bool(text))

    # ==================== 右下角：跟狗要奶的"获取"按钮 ====================
    def SetOnGet(self, callback):
        # 客户端把"玩家点了这个按钮要干什么"交进来
        self.mOnGet = callback

    def SetGetVisible(self, show):
        v = bool(show)
        self.mGetShown = v
        self._setVisible(self.mGetPanel, v)
        self._setButtonEnabled(v)

    def _wireGetButton(self):
        # 给按钮接上"点一下"的回调
        try:
            btn = self.GetBaseUIControl(self.mGetBtn).asButton()
            btn.AddTouchEventParams({"isSwallow": True})
            btn.SetButtonTouchUpCallback(self._onGetTouch)
        except Exception:
            pass

    def _onGetTouch(self, args=None):
        if self.mOnGet is None:
            return
        try:
            self.mOnGet(args)
        except Exception:
            pass

    def _setButtonEnabled(self, on):
        # 藏起来的时候把按钮一并关掉，免得看不见还能点到
        try:
            btn = self.GetBaseUIControl(self.mGetBtn).asButton()
            btn.SetButtonEnable(bool(on))
        except Exception:
            pass

    def _warpSeconds(self):
        func = getattr(cfg, "warpSeconds", None)
        if func is not None:
            try:
                return max(0.5, float(func()))
            except Exception:
                pass
        return max(0.5, float(getattr(cfg, "WARP_SECONDS", 10.0)))

    # ==================== 空间扭曲 ====================
    def SetWarpFrame(self, index):
        try:
            index = int(index)
        except Exception:
            index = -1
        if index < -1 or index >= WARP_FRAMES:
            index = -1
        if index >= 0:
            # 记下"最晚到什么时候必须自己收掉"
            self.mHideAt = time.time() + self._warpSeconds() + 1.0
        else:
            self.mHideAt = 0.0
        if index == self.mFrame:
            return
        self.mFrame = index
        # 整块面板一起开关：万一某一帧没藏住，面板一关就全没了
        self._setVisible(self.mWarpPanel, index >= 0)
        for i in range(WARP_FRAMES):
            self._setVisible(self.mFrames[i], i == index)

    # ==================== 全屏视频 ====================
    def SetMovieFrame(self, index):
        try:
            index = int(index)
        except Exception:
            index = -1
        if index < -1 or index >= MOVIE_FRAMES:
            index = -1
        if index >= 0:
            self.mMovieHideAt = time.time() + float(getattr(cfg, "MOVIE_SECONDS", 5.5)) + 1.0
        else:
            self.mMovieHideAt = 0.0
        if index == self.mMovieCur:
            return
        self.mMovieCur = index
        # 整块面板一起开关：万一某一帧没藏住，面板一关就全没了
        self._setVisible(self.mMoviePanel, index >= 0)
        for i in range(MOVIE_FRAMES):
            self._setVisible(self.mMovieFrames[i], i == index)

    # ==================== 底层小工具 ====================
    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass
