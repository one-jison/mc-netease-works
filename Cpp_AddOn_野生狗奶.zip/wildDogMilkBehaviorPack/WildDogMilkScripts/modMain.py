# -*- coding: utf-8 -*-
# ============================================================
#  野生狗奶 - 模组入口
#    喝下一瓶野生狗奶：
#      · 屏幕进入 5 秒空间扭曲，同时响起狗奶音效
#      · 之后永久获得：加速 / 超高跳跃 / 受伤飞快回血
# ============================================================
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi

from WildDogMilkScripts import modConfig

MOD_NAME = modConfig.ModName
MOD_VERSION = modConfig.ModVersion


@Mod.Binding(name=MOD_NAME, version=MOD_VERSION)
class WildDogMilkMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def InitServer(self):
        serverApi.RegisterSystem(MOD_NAME, modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def DestroyServer(self):
        pass

    @Mod.InitClient()
    def InitClient(self):
        clientApi.RegisterSystem(MOD_NAME, modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def DestroyClient(self):
        pass
