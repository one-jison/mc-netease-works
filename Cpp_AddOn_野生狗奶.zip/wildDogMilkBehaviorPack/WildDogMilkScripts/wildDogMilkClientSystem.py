# -*- coding: utf-8 -*-
# ============================================================
#  野生狗奶 — 客户端
#    · 喝下去的那一瞬间：响起狗奶音效 + 中央转起漩涡，整整 10 秒
#    · 药效期间（3 分钟）：左上角挂着“野生狗奶 · 保质期：永久”+ 剩余时间
# ============================================================
import time
import mod.client.extraClientApi as clientApi
from WildDogMilkScripts import modConfig
from WildDogMilkScripts import wildDogMilkConfig as cfg


ClientSystem = clientApi.GetClientSystemCls()

# 12 张漩涡图：0-1 淡入，2-9 一直转，10-11 淡出
WARP_IN = 2
WARP_LOOP = 8
WARP_TAIL = 0.44          # 头尾各用多久


class WildDogMilkClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(WildDogMilkClientSystem, self).__init__(namespace, systemName)
        self._hudNode = None
        self._hudTries = 0
        self._hudTryTime = 0.0
        self._active = False
        self._warpStart = 0.0
        self._warpEnd = 0.0
        self._musicStart = 0.0
        self._frame = -2
        self._buffEnd = 0.0     # 药效到几点结束（用来在左上角数倒计时）
        self._hideLeft = 0      # 漩涡收掉后再喊几声，防止画面留在屏幕上
        self._drinkId = 0       # 这是第几瓶，免得上一瓶的"收起"把新的一瓶收掉
        self._showGet = False   # 屏幕上的"获取"按钮要不要亮着
        self._movieStart = 0.0  # 全屏视频从哪一刻开始
        self._movieEnd = 0.0    # 全屏视频放到哪一刻
        self._movieFrame = -2
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "OnScriptTickClient", self, self.OnScriptTick)
        self.ListenForEvent(ns, sn, "OnLocalPlayerStopLoading", self, self.OnStopLoading)
        self.ListenForEvent(ns, sn, modConfig.UiInitFinishedEvent, self, self.OnUIInitFinished)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventDrink, self, self.OnDrink)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventState, self, self.OnState)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventWarpStop, self, self.OnWarpStop)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventDogBtn, self, self.OnDogBtn)

    def OnStopLoading(self, args=None):
        self._hudNode = None
        self._hudTries = 0
        self._ensureHud()

    def OnUIInitFinished(self, args=None):
        self._ensureHud()

    # ==================== 每帧 ====================
    def OnScriptTick(self, args=None):
        now = time.time()
        if self._hudNode is None:
            if now - self._hudTryTime >= 3.0:
                self._hudTryTime = now
                self._ensureHud()
            return
        if now - self._hudTryTime >= 1.0:
            self._hudTryTime = now
            self._applyState()
        self._tickWarp(now)
        self._tickMovie(now)

    def _tickWarp(self, now):
        if self._warpEnd <= 0.0:
            # 已经收过了，再多喊两声，保证画面绝对不留下来
            self._resendHide()
            return
        if now >= self._warpEnd:
            self._warpStart = 0.0
            self._warpEnd = 0.0
            self._musicStart = 0.0
            self._hideLeft = 3
            self._resendHide()
            return
        if now < self._warpStart:
            # 音乐还没出声，先别转
            self._setFrame(-1)
            return
        total = max(0.2, self._warpEnd - self._warpStart)
        self._setFrame(self._frameAt(now - self._warpStart, total))

    def _frameAt(self, t, total):
        # 头尾慢慢淡进来 / 淡出去，中间一直转
        tail = max(WARP_TAIL, min(1.2, total * 0.04))
        if t >= total - tail / 2.0:
            return 11
        if t >= total - tail:
            return 10
        if t < tail / 2.0:
            return 0
        if t < tail:
            return 1
        try:
            fps = float(getattr(cfg, "WARP_FPS", 12.5))
        except Exception:
            fps = 12.5
        try:
            steps = float(getattr(cfg, "WARP_MAX_STEPS", 72))
        except Exception:
            steps = 72.0
        step = max(1.0 / max(1.0, fps), total / max(8.0, steps))
        idx = int((t - tail) / max(0.02, step)) % WARP_LOOP
        return WARP_IN + idx

    def _resendHide(self):
        # 保险：把"收起漩涡"这条命令连喊几声
        if self._hideLeft <= 0:
            return
        self._hideLeft -= 1
        self._frame = -2
        self._setFrame(-1)

    def OnWarpStop(self, args=None):
        # 服务端到点喊了一声：立刻把漩涡收掉
        seq = 0
        if args:
            try:
                seq = int(args.get("id", 0))
            except Exception:
                seq = 0
        if seq and seq != self._drinkId:
            # 这是上一瓶的"收起"，别把新喝的那瓶一起收掉
            return
        self._warpStart = 0.0
        self._warpEnd = 0.0
        self._hideLeft = 3
        self._resendHide()

    def _setFrame(self, index):
        if index == self._frame:
            return
        self._frame = index
        node = self._hudNode
        if node is None:
            return
        try:
            node.SetWarpFrame(index)
        except Exception:
            pass

    # ==================== 服务端来的消息 ====================
    def OnDrink(self, args=None):
        ms = 5000
        if args:
            try:
                ms = int(args.get("ms", 5000))
            except Exception:
                ms = 5000
        try:
            self._drinkId = int(args.get("id", 0)) if args else 0
        except Exception:
            self._drinkId = 0
        self._frame = -2
        self._musicStart = 0.0
        self._ensureHud()
        # 先把音乐放出去，这样才知道音乐是从哪一秒开始响的
        self._playDrinkSound()
        if self._musicStart > 0.0:
            # 音乐真的响了：漩涡就贴着这条声音走，声音停它就停
            start = self._musicStart + self._musicDelay()
            total = self._musicSpan()
        else:
            # 音乐没放出来（改由服务端兜底）：退回服务端给的时长
            start = time.time()
            total = max(0.2, ms / 1000.0)
        self._warpStart = start
        self._warpEnd = start + total
        self._tickWarp(time.time())
        # 同一瞬间，全屏再放一遍视频
        self._startMovie()

    # ==================== 全屏视频 ====================
    def _movieSeconds(self):
        try:
            return float(cfg.movieSeconds())
        except Exception:
            return 5.5

    def _movieFrames(self):
        try:
            return int(cfg.movieFrames())
        except Exception:
            return 66

    def _movieFps(self):
        try:
            return float(cfg.movieFps())
        except Exception:
            return 12.0

    def _movieOn(self):
        try:
            return bool(cfg.movieOn())
        except Exception:
            return True

    def _startMovie(self):
        if not self._movieOn():
            return
        now = time.time()
        self._movieStart = now
        self._movieEnd = now + self._movieSeconds()
        self._movieFrame = -2
        self._ensureHud()
        self._tickMovie(now)

    def _tickMovie(self, now):
        if self._movieEnd <= 0.0:
            return
        if now >= self._movieEnd:
            self._movieStart = 0.0
            self._movieEnd = 0.0
            self._setMovieFrame(-1)
            return
        frames = self._movieFrames()
        fps = self._movieFps()
        idx = int((now - self._movieStart) * fps)
        if idx >= frames:
            idx = frames - 1
        self._setMovieFrame(idx)

    def _setMovieFrame(self, index):
        if index == self._movieFrame:
            return
        self._movieFrame = index
        node = self._hudNode
        if node is None:
            return
        try:
            node.SetMovieFrame(index)
        except Exception:
            pass

    def _musicDelay(self):
        # 音乐从“按下播放”到真正出声的那点延迟
        try:
            return max(0.0, float(getattr(cfg, "MUSIC_START_DELAY", 0.0)))
        except Exception:
            return 0.0

    def _musicSpan(self):
        # 音乐到底有多长
        func = getattr(cfg, "warpSeconds", None)
        if func is not None:
            try:
                total = float(func())
            except Exception:
                total = float(getattr(cfg, "MUSIC_SECONDS", 52.0))
        else:
            total = float(getattr(cfg, "MUSIC_SECONDS", 52.0))
        try:
            cap = float(getattr(cfg, "WARP_MAX_SECONDS", 180.0))
        except Exception:
            cap = 180.0
        return max(0.2, min(total, max(1.0, cap)))

    def OnState(self, args=None):
        if not args:
            return
        try:
            if args.get("playerId") and args.get("playerId") != clientApi.GetLocalPlayerId():
                return
        except Exception:
            pass
        self._active = int(args.get("active", 0)) == 1
        try:
            left = float(args.get("left", 0))
        except Exception:
            left = 0.0
        if self._active and left > 0.0:
            self._buffEnd = time.time() + left
        elif not self._active:
            self._buffEnd = 0.0
        self._applyState()

    # ==================== 界面 ====================
    def _ensureHud(self):
        if self._hudNode is not None or self._hudTries >= 40:
            return
        self._hudTries += 1
        try:
            node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            if node is None:
                clientApi.RegisterUI(modConfig.ModName, modConfig.HudUIName,
                                     modConfig.HudUIPyClsPath, modConfig.HudUIScreenDef)
                node = clientApi.CreateUI(modConfig.ModName, modConfig.HudUIName,
                                          {"isHud": 1})
                if node is None:
                    node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            self._hudNode = node
            try:
                node.SetOnGet(self.OnGetButton)
            except Exception:
                pass
            self._applyState()
            self._applyGet()
        except Exception:
            self._hudNode = None

    def _applyState(self):
        node = self._hudNode
        if node is None:
            return
        try:
            node.SetActive(bool(self._active))
        except Exception:
            pass
        try:
            node.SetBuffTime(self._buffTimeText())
        except Exception:
            pass

    def _buffTimeText(self):
        # 右上角那个药水方框下面的倒计时
        if not self._active or self._buffEnd <= 0.0:
            return u""
        left = int(max(0, round(self._buffEnd - time.time())))
        return u"%d:%02d" % (left // 60, left % 60)

    # ==================== 跟狗要奶的"获取"按钮 ====================
    def _mobile(self):
        # 手机端还是电脑端（0 = 电脑）
        try:
            return int(clientApi.GetPlatform()) != 0
        except Exception:
            return True

    def OnDogBtn(self, args=None):
        show = 0
        if args:
            try:
                show = int(args.get("show", 0))
            except Exception:
                show = 0
        # 手机端点按钮、电脑端也能点（不再只限手机）
        self._showGet = bool(show)
        self._applyGet()

    def _applyGet(self):
        node = self._hudNode
        if node is None:
            return
        try:
            node.SetGetVisible(bool(self._showGet))
        except Exception:
            pass

    def OnGetButton(self, args=None):
        # 玩家点了屏幕上的"获取"
        try:
            self.NotifyToServer(modConfig.EventGetMilk,
                                {"playerId": clientApi.GetLocalPlayerId()})
        except Exception:
            pass

    # ==================== 狗奶音乐 / 音效 ====================
    def _playDrinkSound(self):
        # 先来一声游戏自带的喝药声：不管后面成不成，至少听得到动静
        if getattr(cfg, "DRINK_GULP", True):
            self._playByName(str(getattr(cfg, "DRINK_GULP_SOUND", "random.drink")),
                             self._audioVolume(), self._audioPitch())
        if getattr(cfg, "DRINK_SOUND_SERVER", False):
            self._askServerSound()
            return
        if self._playMusic():
            return
        self._askServerSound()

    def _soundName(self):
        # 默认放整首，一直放到放完为止
        if bool(getattr(cfg, "DRINK_MUSIC_FULL", True)):
            name = str(getattr(cfg, "DRINK_MUSIC", u""))
            if name:
                return name
        return str(getattr(cfg, "DRINK_SOUND_SHORT", u""))

    def _playMusic(self):
        ok = self._playByName(self._soundName(),
                              self._audioVolume(), self._audioPitch())
        if ok:
            # 记下音乐真正开始响的时刻
            self._musicStart = time.time()
        return ok

    def _playByName(self, name, vol, pit):
        if not name:
            return False
        pos = self._myPos()
        try:
            local = clientApi.GetLocalPlayerId()
        except Exception:
            local = None
        for owner in (local, clientApi.GetLevelId()):
            comp = self._audioComp(owner)
            if comp is None:
                continue
            if self._callPlay(comp, name, pos, vol, pit, local):
                return True
        return False

    def _callPlay(self, comp, name, pos, vol, pit, local):
        # 官方示例里两种写法都有：
        #   PlayCustomMusic(名字, 坐标, 音量, 音调)                 <- 最常见
        #   PlayCustomMusic(名字, 坐标, 音量, 音调, False, 玩家id)   <- 另一种
        func = getattr(comp, "PlayCustomMusic", None)
        if func is not None:
            calls = [(name, pos, vol, pit)]
            if local:
                calls.append((name, pos, vol, pit, False, local))
            for args in calls:
                try:
                    ret = func(*args)
                except Exception:
                    continue
                if ret is None or bool(ret):
                    return True
        # 万一这个版本另有 PlayCustomSound
        func = getattr(comp, "PlayCustomSound", None)
        if func is not None:
            for args in ((name, pos, vol, pit), (name, pos, vol, pit, False)):
                try:
                    ret = func(*args)
                except Exception:
                    continue
                if ret is None or bool(ret):
                    return True
        return False

    def _audioVolume(self):
        try:
            return float(getattr(cfg, "DRINK_SOUND_VOLUME", 1.0))
        except Exception:
            return 1.0

    def _audioPitch(self):
        try:
            return float(getattr(cfg, "DRINK_SOUND_PITCH", 1.0))
        except Exception:
            return 1.0

    def _audioComp(self, owner):
        try:
            return clientApi.GetEngineCompFactory().CreateCustomAudio(owner)
        except Exception:
            return None

    def _myPos(self):
        try:
            comp = clientApi.GetEngineCompFactory().CreatePos(
                clientApi.GetLocalPlayerId())
            return comp.GetFootPos()
        except Exception:
            return (0.0, 0.0, 0.0)

    def _askServerSound(self):
        try:
            self.NotifyToServer(modConfig.EventSound,
                                {"playerId": clientApi.GetLocalPlayerId()})
        except Exception:
            pass
