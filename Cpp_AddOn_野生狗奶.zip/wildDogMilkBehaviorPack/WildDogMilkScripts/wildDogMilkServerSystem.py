# -*- coding: utf-8 -*-
# ============================================================
#  野生狗奶 — 服务端
#    · 喝下一瓶：先 10 秒画面扭曲，再挂上 加速 / 超高跳跃 / 快速回血
#    · 药效持续 3 分钟，到点自动过期（想改时长就改 BUFF_SECONDS）
# ============================================================
import time
import mod.server.extraServerApi as serverApi
from WildDogMilkScripts import modConfig
from WildDogMilkScripts import wildDogMilkConfig as cfg


ServerSystem = serverApi.GetServerSystemCls()


class WildDogMilkServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(WildDogMilkServerSystem, self).__init__(namespace, systemName)
        self._active = {}       # playerId -> True：谁身上挂着狗奶
        self._lastApply = {}    # playerId -> 上一次续药效的时间
        self._giftAt = {}       # playerId -> 什么时候把进游戏送的狗奶放进背包
        self._lastDrink = {}    # playerId -> 上一次喝下去的时间（防止一瓶被算两次）
        self._buffEnd = {}      # playerId -> 药效到什么时候结束
        self._warpStop = {}     # playerId -> 什么时候喊客户端把漩涡收掉
        self._drinkSeq = {}     # playerId -> 这是第几瓶（免得上一瓶的"收起"把新的一瓶收掉）
        self._dogNear = {}      # playerId -> 上一次告诉客户端的"旁边有没有狗"
        self._lastGet = {}      # playerId -> 上一次挤奶的时间（防抖，一次别给两瓶）
        self._dogNearAt = {}    # playerId -> 上一次发按钮消息的时间（没变也隔几秒补发）
        self._dogHintAt = {}    # playerId -> 上一次给"附近没狗"提示的时间
        self._dogTimer = 0      # 数 tick 用，隔一会儿查一次
        self._nauseaStop = {}   # playerId -> 什么时候把原版那种"晕"摘掉
        self._listenEvents()

    # ==================== 事件 ====================
    def _listenEvents(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        self.ListenForEvent(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        # 喝药水：两个事件都听着，哪个先来都认
        self.ListenForEvent(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        self.ListenForEvent(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)
        # 死了就把药效一起收掉（不然重生还挂着）
        for evt in ("PlayerDieServerEvent", "PlayerDieEvent"):
            try:
                self.ListenForEvent(ns, sn, evt, self, self.OnPlayerDie)
            except Exception:
                pass
        # 客户端那边自定义音效放不出来时，会请这边帮忙放一声
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventSound, self, self.OnSoundAsk)
        # 客户端点了屏幕上的"获取"按钮
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventGetMilk, self, self.OnGetMilk)
        # 电脑端拿着铁桶按右键（手机端点屏幕也一样会来）：只认这一个"真的用了东西"的事件。
        # 之前那个 PlayerInteractServerEvent 是引擎在问"哪些实体能交互"，视角一落到狗身上
        # 就会来一下，结果就是没点也在挤奶 —— 不能再挂它。
        try:
            self.ListenForEvent(ns, sn, "ServerItemTryUseEvent", self,
                                self.OnItemTryUse)
        except Exception:
            pass

    def OnAddPlayer(self, args=None):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId:
            return
        now = time.time()
        self._giftAt[playerId] = now + 3.0
        if playerId in self._active:
            # 掉线又回来的：还剩多久就接着挂多久，没剩了就算了
            left = float(self._buffEnd.get(playerId, 0.0)) - now
            if left > 1.0:
                self._applyBuff(playerId, left)
            else:
                self._lose(playerId)
                return
        self._syncState(playerId)

    def OnPlayerDie(self, args=None):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId:
            return
        if getattr(cfg, "KEEP_ON_DEATH", False):
            return
        self._lose(playerId)

    # ==================== 每个 tick ====================
    def OnServerTick(self, args=None):
        if not self._on():
            return
        now = time.time()
        # 1) 进游戏送几瓶
        if self._giftAt:
            for pid in list(self._giftAt.keys()):
                if now < self._giftAt[pid]:
                    continue
                del self._giftAt[pid]
                self._giveJoinMilk(pid)
        # 2) 药效到点就收（默认 3 分钟）
        if self._active:
            players = serverApi.GetPlayerList() or []
            gap = float(getattr(cfg, "REFRESH_SECONDS", 60.0))
            for pid in list(self._active.keys()):
                if pid not in players:
                    continue
                end = float(self._buffEnd.get(pid, 0.0))
                if end > 0.0 and now >= end:
                    # 时间到了：药效连同左上角那行字一起收掉
                    self._lose(pid)
                    continue
                if getattr(cfg, "AUTO_REFRESH", False):
                    if now - float(self._lastApply.get(pid, 0.0)) >= gap:
                        self._lastApply[pid] = now
                        self._applyBuff(pid, self._buffSeconds())
        # 2b) 原版那种"晕"到点单独摘掉（不等三分钟的药效一起走）
        for pid in list(self._nauseaStop.keys()):
            if now < float(self._nauseaStop[pid]):
                continue
            self._nauseaStop.pop(pid, None)
            self._removeEffect(pid, "nausea")
        # 3) 画面扭曲到点：喊一声让客户端把漩涡收掉（客户端自己也会收，这是双保险）
        for pid in list(self._warpStop.keys()):
            if now < self._warpStop[pid]:
                continue
            seq = self._warpStop.pop(pid)
            self._toPlayer(pid, modConfig.EventWarpStop, {"id": seq})
        # 4) 手里拿着铁桶靠近狗 -> 亮出屏幕上的"获取"按钮
        if self._dogOn():
            self._dogTimer += 1
            if self._dogTimer >= max(1, int(getattr(cfg, "DOG_CHECK_TICKS", 4))):
                self._dogTimer = 0
                self._refreshDogButton()

    # ==================== 喝药水 ====================
    def OnEatFood(self, args=None):
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))
        self._checkGet(args.get("playerId"), args.get("itemDict"))

    def OnUseItem(self, args=None):
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))
        self._checkGet(args.get("playerId"), args.get("itemDict"))

    def OnGetMilk(self, args=None):
        # 客户端点了屏幕上的"获取"按钮
        playerId = None
        if args:
            playerId = args.get("playerId")
        if not playerId:
            return
        self._tryGet(playerId)

    def OnItemTryUse(self, args=None):
        # 拿着铁桶按右键（或手机端点屏幕）：旁边有狗就挤一瓶
        if not args:
            return
        playerId = args.get("playerId") or args.get("id")
        if not playerId:
            return
        if self._itemNameOf(args.get("itemDict")) != str(
                getattr(cfg, "DOG_ITEM", u"")).lower():
            return
        self._tryGet(playerId)

    def _itemNameOf(self, itemDict):
        if not isinstance(itemDict, dict):
            return u""
        name = itemDict.get("newItemName") or itemDict.get("itemName") or u""
        return str(name).lower()

    def _checkPotion(self, playerId, itemDict):
        if not playerId or not self._on():
            return
        if self._itemNameOf(itemDict) != str(getattr(cfg, "MILK_ITEM", u"")).lower():
            return
        # 喝药水会同时触发两个事件，前后相差不到一秒的只算一次（不然音乐会重叠着放两遍）
        now = time.time()
        if now - float(self._lastDrink.get(playerId, -999.0)) < 1.0:
            return
        self._lastDrink[playerId] = now
        self._drink(playerId)

    def _drink(self, playerId):
        now = time.time()
        # 1) 画面扭曲：先是屏幕漩涡（客户端画），再叠上原版那种"晕"
        #    这里给大（两种单位都够 10 秒），到点再由服务端自己摘掉，
        #    这样不管引擎把时长当秒还是当 tick，屏幕都不会一直算扭着
        nap = self._nauseaSeconds()
        if nap > 0:
            self._addEffect(playerId, "nausea",
                            int(max(1, round(nap * 20.0))), 0)
            self._nauseaStop[playerId] = now + nap
        # 2) 药效当场挂上，默认 3 分钟
        left = self._buffSeconds()
        self._active[playerId] = True
        self._lastApply[playerId] = now
        self._buffEnd[playerId] = now + left
        self._applyBuff(playerId, left)
        # 3) 告诉这个玩家的客户端：放狗奶音效 + 开始转漩涡
        seq = int(self._drinkSeq.get(playerId, 0)) + 1
        self._drinkSeq[playerId] = seq
        self._toPlayer(playerId, modConfig.EventDrink,
                       {"ms": int(round(self._warpSeconds() * 1000.0)),
                        "id": seq})
        # 4) 到点了再喊一声，让客户端把漩涡收掉
        self._warpStop[playerId] = now + self._warpSeconds() + 0.5
        self._syncState(playerId)
        if getattr(cfg, "TIP_ON_DRINK", True):
            self._tip(playerId,
                      u"喝下 %s：加速 / 超高跳跃 / 快速回血，持续 %s"
                      % (cfg.MILK_NAME, self._buffText()), "LIGHT_PURPLE")

    def _warpSeconds(self):
        # 扭曲一共持续多久（默认跟着整首音乐走）
        func = getattr(cfg, "warpSeconds", None)
        if func is not None:
            try:
                return float(func())
            except Exception:
                pass
        return max(0.5, float(getattr(cfg, "WARP_SECONDS", 5.0)))

    def _nauseaSeconds(self):
        func = getattr(cfg, "nauseaSeconds", None)
        if func is not None:
            try:
                return float(func())
            except Exception:
                pass
        return max(0.0, float(getattr(cfg, "NAUSEA_SECONDS", 5.0)))

    def _applyBuff(self, playerId, seconds):
        # 三种药效一起挂。
        # 这个接口在不同版本里，时长有的按秒算、有的按 tick 算（差 20 倍），
        # 所以故意按 20 倍给：不管按哪种算，都够三分钟；
        # 真正的三分钟由服务端自己掐表收掉（见 _lose），玩家看到的时长是准的。
        secs = int(max(1, round(float(seconds) * 20.0)))
        self._addEffect(playerId, "speed", secs, int(cfg.SPEED_AMPLIFIER))
        self._addEffect(playerId, "jump_boost", secs, int(cfg.JUMP_AMPLIFIER))
        self._addEffect(playerId, "regeneration", secs, int(cfg.REGEN_AMPLIFIER))

    def _buffSeconds(self):
        # 药效一共多少秒
        func = getattr(cfg, "buffSeconds", None)
        if func is not None:
            try:
                return max(1.0, float(func()))
            except Exception:
                pass
        return max(1.0, float(getattr(cfg, "BUFF_SECONDS", 180.0)))

    def _buffText(self):
        # 3 分钟 -> "3 分钟"
        total = int(round(self._buffSeconds()))
        if total % 60 == 0:
            return u"%d 分钟" % (total // 60)
        return u"%d 分 %d 秒" % (total // 60, total % 60)

    def _lose(self, playerId):
        self._active.pop(playerId, None)
        self._lastApply.pop(playerId, None)
        self._buffEnd.pop(playerId, None)
        self._warpStop.pop(playerId, None)
        self._nauseaStop.pop(playerId, None)
        for name in ("speed", "jump_boost", "regeneration", "nausea"):
            self._removeEffect(playerId, name)
        # 顺手让客户端把漩涡也收掉
        self._toPlayer(playerId, modConfig.EventWarpStop,
                       {"id": int(self._drinkSeq.get(playerId, 0))})
        self._syncState(playerId)

    # ==================== 药水效果 ====================
    def _effectComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreateEffect(playerId)
        except Exception:
            return None

    def _addEffect(self, playerId, name, seconds, amplifier, particles=False):
        # seconds：时长。不同版本单位不一样（秒 / tick），调用处故意给大一点，
        #          反正真正的时长由我们自己掐表控制
        comp = self._effectComp(playerId)
        if comp is None:
            return False
        names = [name] if ":" in str(name) else [str(name), "minecraft:" + str(name)]
        for one in names:
            for args in ((one, int(seconds), int(amplifier), bool(particles)),
                         (one, int(seconds), int(amplifier))):
                try:
                    comp.AddEffectToEntity(*args)
                    return True
                except Exception:
                    continue
        return False

    def _removeEffect(self, playerId, name):
        comp = self._effectComp(playerId)
        if comp is None:
            return
        names = [name] if ":" in str(name) else [str(name), "minecraft:" + str(name)]
        for one in names:
            for fn in ("RemoveEffectFromEntity", "RemoveEffect"):
                func = getattr(comp, fn, None)
                if func is None:
                    continue
                try:
                    func(one)
                    return
                except Exception:
                    continue

    # ==================== 背包 / 提示 / 通知 ====================
    def _giveJoinMilk(self, playerId):
        if not getattr(cfg, "JOIN_GIVE", True):
            return
        num = int(getattr(cfg, "JOIN_GIVE_COUNT", 3))
        if num <= 0 or self._hasItem(playerId, cfg.MILK_ITEM):
            return
        if self._giveItem(playerId, cfg.MILK_ITEM, num):
            self._tip(playerId,
                      u"已获得 %s ×%d（%s），拿在手里点一下屏幕就能喝"
                      % (cfg.MILK_NAME, num, cfg.SHELF_LIFE), "GOLD")

    def _hasItem(self, playerId, itemName):
        want = str(itemName).lower()
        if not want:
            return False
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            posType = serverApi.GetMinecraftEnum().ItemPosType
            for item in comp.GetPlayerAllItems(posType.INVENTORY):
                if not item:
                    continue
                name = item.get("newItemName") or item.get("itemName") or u""
                if str(name).lower() == want:
                    return True
        except Exception:
            return False
        return False

    def _giveItem(self, playerId, itemName, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            return bool(comp.SpawnItemToPlayerInv(
                {"itemName": itemName, "count": int(num), "auxValue": 0}, playerId))
        except Exception:
            return False

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    def _toPlayer(self, playerId, eventName, data):
        try:
            self.NotifyToClient(playerId, eventName, data)
        except Exception:
            pass

    def _syncState(self, playerId):
        left = 0.0
        if playerId in self._active:
            left = max(0.0, float(self._buffEnd.get(playerId, 0.0)) - time.time())
        self._toPlayer(playerId, modConfig.EventState,
                       {"active": 1 if playerId in self._active else 0,
                        "left": int(round(left)),
                        "name": cfg.MILK_NAME, "note": cfg.SHELF_LIFE})

    def _playSound(self, entityId, name, volume=1.0, pitch=1.0, radius=32.0):
        if not name:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateCommand(serverApi.GetLevelId())
            comp.SetCommand("/playsound %s @a[r=%s] ~ ~ ~ %s %s"
                            % (str(name), float(radius), float(volume), float(pitch)),
                            entityId)
        except Exception:
            pass

    def OnSoundAsk(self, args=None):
        playerId = None
        if args:
            playerId = args.get("playerId")
        if not playerId:
            return
        self._playSound(playerId,
                        str(getattr(cfg, "DRINK_SOUND_FALLBACK", "wilddogmilk.music")),
                        float(getattr(cfg, "DRINK_SOUND_VOLUME", 1.0)), 1.0,
                        float(getattr(cfg, "DRINK_SOUND_RADIUS", 1.0)))

    # ==================== 跟狗要奶 ====================
    def _dogOn(self):
        return bool(getattr(cfg, "DOG_MILK", True)) and self._on()

    def _refreshDogButton(self):
        # 状态变了就通知；没变也每隔几秒补发一次，免得客户端漏收之后按钮再也不出来
        now = time.time()
        for pid in (serverApi.GetPlayerList() or []):
            near = bool(self._dogNearPlayer(pid))
            if self._dogNear.get(pid) == near:
                if not near:
                    self._dogHint(pid, now)
                    continue
                if now - float(self._dogNearAt.get(pid, 0.0)) < 3.0:
                    continue
            self._dogNear[pid] = near
            self._dogNearAt[pid] = now
            self._toPlayer(pid, modConfig.EventDogBtn,
                           {"show": 1 if near else 0})
            if not near:
                self._dogHint(pid, now)

    def _dogHint(self, playerId, now):
        # 手里拿着铁桶却没找到狗：给一句话，顺便报一下附近都是些啥（方便定位）
        if not bool(getattr(cfg, "DOG_HINT", True)):
            return
        if not self._holdingDogItem(playerId):
            return
        if now - float(self._dogHintAt.get(playerId, 0.0)) < 4.0:
            return
        self._dogHintAt[playerId] = now
        names = self._nearbyTypes(playerId)
        rng = int(float(getattr(cfg, "DOG_RANGE", 8.0)))
        if names:
            self._tip(playerId, u"%s：%d 格内没找到狗，看到的是 %s"
                      % (cfg.MILK_NAME, rng, u"、".join(names[:4])), "GOLD")
        else:
            self._tip(playerId, u"%s：%d 格内没扫到生物，再走近狗一点试试"
                      % (cfg.MILK_NAME, rng), "GOLD")

    def _nearbyTypes(self, playerId):
        out = []
        for eid in self._nearby(playerId):
            t = self._typeStrOf(eid)
            if t and t not in out:
                out.append(t)
        return out

    def _dogNearPlayer(self, playerId):
        if not self._holdingDogItem(playerId):
            return False
        return self._findDog(playerId) is not None

    def _holdingDogItem(self, playerId):
        # 手上（或背包里）拿的是不是铁桶
        want = str(getattr(cfg, "DOG_ITEM", "minecraft:bucket")).lower()
        if not want:
            return False
        for item in self._carriedItems(playerId):
            if not item:
                continue
            name = item.get("newItemName") or item.get("itemName") or u""
            if str(name).lower() == want:
                return True
        return False

    def _carriedItems(self, playerId):
        # 主手 -> 当前快捷栏那一格 -> 整个背包（哪个接口能用就用哪个）
        out = []
        try:
            itemComp = serverApi.GetEngineCompFactory().CreateItem(playerId)
        except Exception:
            return out
        try:
            posType = serverApi.GetMinecraftEnum().ItemPosType
        except Exception:
            return out
        try:
            out.append(itemComp.GetPlayerItem(posType.CARRIED, 0))
        except Exception:
            pass
        try:
            slot = itemComp.GetSelectSlotId()
            out.append(itemComp.GetPlayerItem(posType.INVENTORY, slot))
        except Exception:
            pass
        if bool(getattr(cfg, "DOG_ANY_SLOT", True)):
            try:
                for it in itemComp.GetPlayerAllItems(posType.INVENTORY):
                    out.append(it)
            except Exception:
                pass
        return out

    def _nearby(self, playerId):
        # 附近有哪些实体
        # 先用跑通过的写法：以玩家脚下为中心画一个方框，把里面的实体全捞出来
        radius = max(1.0, float(getattr(cfg, "DOG_RANGE", 2.0)))
        out = []
        pos = self._posOf(playerId)
        if pos is not None:
            dim = self._dimOf(playerId)
            try:
                ids = serverApi.GetEngineCompFactory().CreateGame(
                    serverApi.GetLevelId()).GetEntitiesInSquareArea(
                        None,
                        (pos[0] - radius, pos[1] - radius, pos[2] - radius),
                        (pos[0] + radius, pos[1] + radius, pos[2] + radius),
                        dim)
            except Exception:
                ids = None
            for e in (ids or []):
                if e and e != playerId and e not in out:
                    out.append(e)
        if out:
            return out
        # 这个版本万一没有上面那个接口，再退回老写法
        return self._nearbyAround(playerId, radius)

    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _dimOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _nearbyAround(self, playerId, radius):
        # 老写法：GetEntitiesAround（有的版本好用，有的版本一直返回空）
        factory = serverApi.GetEngineCompFactory()
        owners = [serverApi.GetLevelId(), playerId]
        filters = (
            {"filters": {"all_of": [
                {"test": "is_family", "subject": "other", "value": "mob"}]}},
            {},
        )
        for owner in owners:
            try:
                comp = factory.CreateGame(owner)
            except Exception:
                continue
            for one in filters:
                try:
                    ids = comp.GetEntitiesAround(playerId, radius, one)
                except Exception:
                    continue
                if not ids:
                    continue
                out = [e for e in ids if e != playerId]
                if out:
                    return out
        return []

    def _findDog(self, playerId):
        # 附近有没有狗（狼），有就返回它的 id
        ids = self._nearby(playerId)
        if not ids:
            return None
        unknown = 0
        for eid in ids:
            t = str(self._typeStrOf(eid) or "").lower()
            if not t:
                unknown += 1
                continue
            if "wolf" in t or "dog" in t:
                return eid
        # 万一这个版本读不出实体类型：
        # 旁边有活物就当是狗，总比按钮永远不出现强
        if unknown == len(ids) and bool(getattr(cfg, "DOG_LOOSE", True)):
            return ids[0]
        return None

    def _typeStrOf(self, entityId):
        # 拿实体的类型名（不同版本的接口名不太一样，挨个试）
        factory = serverApi.GetEngineCompFactory()
        for maker in ("CreateEngineType", "CreateEntityType"):
            try:
                comp = factory.__getattribute__(maker)(entityId)
                if comp is not None:
                    return comp.GetEngineTypeStr()
            except Exception:
                continue
        try:
            return serverApi.CreateComponent(entityId, "Minecraft", "engineType").GetEngineTypeStr()
        except Exception:
            return u""

    def _checkGet(self, playerId, itemDict):
        # 电脑端右击鼠标：手里拿着铁桶、旁边有狗，就挤一瓶
        if not self._dogOn() or not playerId:
            return
        if self._itemNameOf(itemDict) != str(getattr(cfg, "DOG_ITEM", u"")).lower():
            return
        self._tryGet(playerId)

    def _tryGet(self, playerId):
        if not self._dogOn() or not playerId:
            return False
        now = time.time()
        if now - float(self._lastGet.get(playerId, -999.0)) < 0.8:
            return False
        if not self._holdingDogItem(playerId):
            return False
        if self._findDog(playerId) is None:
            return False
        self._lastGet[playerId] = now
        num = int(getattr(cfg, "DOG_GET_COUNT", 1))
        if self._giveItem(playerId, cfg.MILK_ITEM, num):
            self._tip(playerId,
                      u"挤到 %s ×%d（%s）"
                      % (cfg.MILK_NAME, num, cfg.SHELF_LIFE), "GOLD")
        return True

    # ==================== 开关 ====================
    def _on(self):
        return bool(getattr(cfg, "MODE_ON", True))
