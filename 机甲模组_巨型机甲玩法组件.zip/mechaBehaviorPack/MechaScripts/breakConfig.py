# -*- coding: utf-8 -*-
# ============================================================
#  机甲模组 - 破坏方块配置
#  想改机甲能打碎什么、一拳打多大一片，改这个文件就够了
# ============================================================

# ---------- 总开关 ----------
BREAK_ENABLED = True        # 机甲能不能破坏方块（False = 打下去方块不掉）
BREAK_DROP_ITEMS = False    # 打碎的方块是否掉落物品（False = 直接蒸发，不爆一地垃圾）
BREAK_MAX_PER_PUNCH = 240   # 一次最多打碎多少方块（性能保护，卡的话调小）
BREAK_MAX_RADIUS = 8        # 单个坑的最大半径，防止手滑炸掉一座山

# ---------- 重拳（F 键 / 鼠标中键）----------
PUNCH_KEY = "70"            # 触发重拳的键码：70 = F 键（键码表见官方 KeyBoardType 枚举）
PUNCH_COOLDOWN = 1.1        # 重拳冷却（秒），越小出拳越快
PUNCH_RANGE = 7             # 拳头能伸多远（格）
PUNCH_HEIGHT = 3.4          # 拳头从多高挥出去（相对机甲脚底，格）
PUNCH_FORWARD = 2.0         # 拳头起点向前偏移（格）
PUNCH_RADIUS = 2.8          # ★ 一拳打出的坑半径（格），想更猛就调大
PUNCH_DAMAGE = 45.0         # 重拳对生物的伤害
PUNCH_ENTITY_RADIUS = 5.0   # 拳风能掀到多远的生物（格）
PUNCH_KNOCK = 2.6           # 拳风掀飞力度，越大飞得越远
PUNCH_KNOCK_LIFT = 1.0      # 拳风上抬，越大飞得越高

# ---------- 激光炮破块 ----------
LASER_BREAK = True          # 激光打到方块时是否把方块打掉
LASER_BREAK_RADIUS = 1.6    # 激光炸出的坑半径（格）
LASER_BREAK_MAX = 30        # 激光一次最多打碎多少方块

# ---------- 冲刺撞碎 ----------
DASH_BREAK = True           # 冲刺时是否撞碎挡路的方块
DASH_BREAK_RADIUS = 1.7     # 撞出的洞半径（格）
DASH_BREAK_FORWARD = 3.2    # 撞击点向前偏移（格）
DASH_BREAK_HEIGHT = 1.8     # 撞击点高度（格）
DASH_BREAK_MAX = 70         # 冲刺一次最多打碎多少方块

# ---------- 保护名单：这些方块永远不会被机甲打碎 ----------
UNBREAKABLE_BLOCKS = [
    "minecraft:air",
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:light_block",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:end_portal",
    "minecraft:end_portal_frame",
    "minecraft:end_gateway",
    "minecraft:nether_portal",
    "minecraft:portal",
    "minecraft:moving_block",
    "minecraft:allow",
    "minecraft:deny",
    "minecraft:border_block",
    "minecraft:client_request_placeholder_block",
    "minecraft:reinforced_deepslate",
    "minecraft:unknown",
    "minecraft:water",
    "minecraft:flowing_water",
    "minecraft:lava",
    "minecraft:flowing_lava",
    "minecraft:fire",
    "minecraft:soul_fire",
    "minecraft:powder_snow",
]