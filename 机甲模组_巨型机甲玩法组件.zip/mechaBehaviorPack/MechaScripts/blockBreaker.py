# -*- coding: utf-8 -*-
# ============================================================
#  机甲模组 - 方块破坏器
#  机甲打出的所有坑都由这个类负责生成。
#  想调整力度 / 保护名单，请改同目录的 breakConfig.py，不用动这里。
# ============================================================
import mod.server.extraServerApi as serverApi
from MechaScripts import breakConfig as bc

AIR_BLOCK = {"name": "minecraft:air", "aux": 0}

MIN_Y = -64
MAX_Y = 320


class BlockBreaker(object):
    """把一片方块打成空气，自带保护名单、数量上限和性能保护"""

    def __init__(self, levelId):
        self._levelId = levelId
        self._blockInfo = serverApi.GetEngineCompFactory().CreateBlockInfo(levelId)

    # ---------- 基础查询 ----------
    def _blockAt(self, pos, dimensionId):
        """返回 (方块名, 附加值)；取不到就返回 (None, 0)"""
        info = None
        try:
            info = self._blockInfo.GetBlockNew(pos, dimensionId)
        except Exception:
            info = None
        if not info or not isinstance(info, dict):
            return None, 0
        return info.get("name"), info.get("aux", 0)

    def isProtected(self, blockName):
        """这个方块是否在保护名单里（空气、基岩、命令方块等一律不动）"""
        if not blockName:
            return True
        return blockName in bc.UNBREAKABLE_BLOCKS

    # ---------- 打碎单个方块 ----------
    def breakOne(self, pos, dimensionId, dropItems=None):
        if pos[1] < MIN_Y or pos[1] > MAX_Y:
            return False
        name, aux = self._blockAt(pos, dimensionId)
        if self.isProtected(name):
            return False
        if dropItems is None:
            dropItems = bc.BREAK_DROP_ITEMS
        if dropItems:
            try:
                self._blockInfo.SpawnResources(name, pos, aux, 1.0, 0, dimensionId)
            except Exception:
                pass
        try:
            self._blockInfo.SetBlockNew(pos, AIR_BLOCK, 0, dimensionId, True, False)
            return True
        except Exception:
            return False

    # ---------- 打碎球形一片 ----------
    def breakSphere(self, center, radius, dimensionId, maxCount=None):
        """把 center 周围 radius 格内的方块打成空气，返回实际打碎的数量"""
        if not bc.BREAK_ENABLED:
            return 0
        if maxCount is None:
            maxCount = bc.BREAK_MAX_PER_PUNCH
        if radius > bc.BREAK_MAX_RADIUS:
            radius = bc.BREAK_MAX_RADIUS
        if radius <= 0:
            return 0

        cx, cy, cz = int(center[0]), int(center[1]), int(center[2])
        r = int(radius) + 1
        limit = radius * radius
        candidates = []
        for dx in range(-r, r + 1):
            for dy in range(-r, r + 1):
                for dz in range(-r, r + 1):
                    dist2 = dx * dx + dy * dy + dz * dz
                    if dist2 > limit:
                        continue
                    candidates.append((dist2, (cx + dx, cy + dy, cz + dz)))
        # 从坑心往外打，先把最中心那几块打掉，剩下的即使被上限截断，坑也是圆的
        candidates.sort(key=lambda item: item[0])

        broken = 0
        for _dist2, pos in candidates:
            if broken >= maxCount:
                break
            if self.breakOne(pos, dimensionId):
                broken += 1
        return broken

    # ---------- 打碎方盒一片（备用：想挖方形坑时调用）----------
    def breakBox(self, center, halfSize, dimensionId, maxCount=None):
        if not bc.BREAK_ENABLED:
            return 0
        if maxCount is None:
            maxCount = bc.BREAK_MAX_PER_PUNCH
        cx, cy, cz = int(center[0]), int(center[1]), int(center[2])
        h = int(halfSize)
        broken = 0
        for dx in range(-h, h + 1):
            for dy in range(-h, h + 1):
                for dz in range(-h, h + 1):
                    if broken >= maxCount:
                        return broken
                    if self.breakOne((cx + dx, cy + dy, cz + dz), dimensionId):
                        broken += 1
        return broken