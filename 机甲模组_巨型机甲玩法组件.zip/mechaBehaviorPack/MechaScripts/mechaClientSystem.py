# -*- coding: utf-8 -*-
# 机甲模组 - 客户端：按键输入、激光光束表现、重拳特效、音效
import time
import mod.client.extraClientApi as clientApi
from MechaScripts import modConfig
from MechaScripts import laserConfig as cfg
from MechaScripts import breakConfig as bc

ClientSystem = clientApi.GetClientSystemCls()

BEAM_PARTICLE = "mecha:laser_beam"
MUZZLE_PARTICLE = "mecha:muzzle_flash"
IMPACT_PARTICLE = "mecha:laser_impact"
PUNCH_PARTICLE = "mecha:punch_blast"

MIDDLE_MOUSE_KEY = "-97"   # 鼠标中键（KeyBoardType.KEY_MOUSE_Middle）


class MechaClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(MechaClientSystem, self).__init__(namespace, systemName)
        self._lastSend = 0.0
        self._hiddenRiders = set()   # 正在驾驶机甲的玩家（他们的模型要藏起来）
        self._lastHold = 0.0         # 上次长按屏幕的时间
        self._tipTime = 0.0          # 上次弹操作提示的时间
        self._wasRiding = False      # 上一轮检查时自己是否在开机甲
        self._setupTouch()
        self._listenEvents()
        self._startRiderWatcher()

    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        # PC：鼠标左键 / 右键
        self.ListenForEvent(ns, sn, "LeftClickBeforeClientEvent", self, self.OnLeftClick)
        self.ListenForEvent(ns, sn, "RightClickBeforeClientEvent", self, self.OnRightClick)
        # 移动端 / F11：点击屏幕
        self.ListenForEvent(ns, sn, "TapBeforeClientEvent", self, self.OnTap)
        # 移动端 / F11：长按屏幕（重拳）
        self.ListenForEvent(ns, sn, "HoldBeforeClientEvent", self, self.OnHold)
        # 移动端：屏幕上的跳跃按钮（冲刺）
        self.ListenForEvent(ns, sn, "ClientJumpButtonPressDownEvent", self, self.OnJumpButton)
        # PC：键盘（重拳）与鼠标中键
        self.ListenForEvent(ns, sn, "OnKeyPressInGame", self, self.OnKeyPress)
        self.ListenForEvent(ns, sn, "OnMouseMiddleDownClientEvent", self, self.OnMouseMiddle)
        # 服务端下发表现
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventBeamFx, self, self.OnBeamFx)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventDashFx, self, self.OnDashFx)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventPunchFx, self, self.OnPunchFx)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventRiderState, self, self.OnRiderState)

    # ==================== 触屏手势设置 ====================
    def _setupTouch(self):
        """把长按判定时间调短一点，手机上更容易搓出重拳"""
        if not cfg.MOBILE_CONTROLS:
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateOperation(clientApi.GetLevelId())
            comp.SetHoldTimeThreshold(int(cfg.MOBILE_HOLD_MS))
        except Exception:
            pass

    # ==================== 骑乘时藏起玩家模型 ====================
    def _startRiderWatcher(self):
        """定时重新套用一次隐藏状态，避免死亡、换维度后被系统还原"""
        try:
            comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
            comp.AddRepeatedTimer(1.0, self._applyRiderState)
        except Exception:
            pass

    def OnRiderState(self, args):
        hidden = []
        try:
            if args:
                hidden = args.get("hidden") or []
        except Exception:
            hidden = []
        self._hiddenRiders = set(hidden)
        self._applyRiderState()

    def _applyRiderState(self):
        """把"谁在开机甲"套用到渲染上：自己用 SetRenderLocalPlayer，别人用 SetNotRenderAtAll"""
        try:
            localId = clientApi.GetLocalPlayerId()
        except Exception:
            return
        hideLocal = localId in self._hiddenRiders
        self._maybeTip(hideLocal)
        if not cfg.HIDE_RIDER:
            return
        factory = clientApi.GetEngineCompFactory()
        try:
            factory.CreateGame(clientApi.GetLevelId()).SetRenderLocalPlayer(not hideLocal)
        except Exception:
            pass
        if cfg.HIDE_RIDER_NAME:
            try:
                factory.CreateName(localId).SetShowName(not hideLocal)
            except Exception:
                pass
        try:
            players = clientApi.GetPlayerList()
        except Exception:
            players = None
        if not players:
            return
        for playerId in players:
            if playerId == localId:
                continue
            hide = playerId in self._hiddenRiders
            try:
                factory.CreateActorRender(playerId).SetNotRenderAtAll(bool(hide))
            except Exception:
                pass
            if cfg.HIDE_RIDER_NAME:
                try:
                    factory.CreateName(playerId).SetShowName(not hide)
                except Exception:
                    pass

    def _maybeTip(self, riding):
        """刚骑上机甲时在屏幕上弹一行操作说明（手机上尤其需要）"""
        now = time.time()
        if cfg.SHOW_MOBILE_TIP:
            if riding and not self._wasRiding:
                self._tipTime = now
                self._showTip()
            elif riding and cfg.MOBILE_TIP_REPEAT > 0 and now - self._tipTime >= cfg.MOBILE_TIP_REPEAT:
                self._tipTime = now
                self._showTip()
        self._wasRiding = riding

    def _showTip(self):
        msg = cfg.MOBILE_TIP
        try:
            msg = clientApi.GenerateColor("AQUA") + cfg.MOBILE_TIP
        except Exception:
            pass
        factory = clientApi.GetEngineCompFactory()
        for target in (clientApi.GetLocalPlayerId(), clientApi.GetLevelId()):
            try:
                factory.CreateGame(target).SetTipMessage(msg)
                return
            except Exception:
                continue

    # ==================== 输入 ====================
    def OnLeftClick(self, args=None):
        self._send(modConfig.EventFireLaser)

    def OnTap(self, args=None):
        """轻点屏幕 = 激光炮"""
        if not cfg.MOBILE_CONTROLS or not cfg.MOBILE_TAP_LASER:
            return
        if time.time() - self._lastHold < cfg.MOBILE_HOLD_GUARD:
            return   # 刚出完重拳，这次松手不算开炮
        self._send(modConfig.EventFireLaser)

    def OnHold(self, args=None):
        """长按屏幕 = 重拳（按住不动约 0.26 秒触发）"""
        if not cfg.MOBILE_CONTROLS or not cfg.MOBILE_HOLD_PUNCH:
            return
        if not self._isRiding(default=False):
            return   # 没在开机甲，长按还是原版的挖方块
        self._lastHold = time.time()
        self._send(modConfig.EventPunch)
        try:
            if isinstance(args, dict):
                args["cancel"] = True   # 拦掉原版的挖方块 / 与实体交互
        except Exception:
            pass

    def OnJumpButton(self, args=None):
        """点跳跃按钮 = 推进冲刺（跳跃本身保留，看起来就是跳起来往前冲）"""
        if not cfg.MOBILE_CONTROLS or not cfg.MOBILE_JUMP_DASH:
            return
        self._send(modConfig.EventDash)

    def OnRightClick(self, args=None):
        self._send(modConfig.EventDash)

    def OnKeyPress(self, args=None):
        """键盘按下：F 键 = 重拳碎方块"""
        try:
            if not args:
                return
            if str(args.get("key", "")) != str(bc.PUNCH_KEY):
                return
            if str(args.get("isDown", "0")) != "1":
                return
            self._send(modConfig.EventPunch)
        except Exception:
            pass

    def OnMouseMiddle(self, args=None):
        try:
            if args and int(args.get("isDown", 0)) == 1:
                self._send(modConfig.EventPunch)
        except Exception:
            pass

    def _send(self, eventName):
        if not self._isRiding():
            return  # 没在驾驶机甲，直接把按键交还给原版
        now = time.time()
        if now - self._lastSend < 0.08:
            return
        self._lastSend = now
        try:
            self.NotifyToServer(eventName, {"playerId": clientApi.GetLocalPlayerId()})
        except Exception:
            pass

    def _isRiding(self, default=True):
        """本地快速判断：玩家是否骑在某个坐骑上（具体是不是机甲交给服务端判定）"""
        try:
            comp = clientApi.GetEngineCompFactory().CreateRide(clientApi.GetLocalPlayerId())
            rideId = comp.GetEntityRider()
            return bool(rideId) and rideId != "-1"
        except Exception:
            return default

    # ==================== 表现 ====================
    def OnBeamFx(self, args):
        try:
            self._drawBeam(args)
        except Exception:
            pass
        try:
            self._playSound(args.get("ox"), args.get("oy"), args.get("oz"),
                            "beacon.power", 0.9, 1.7)
        except Exception:
            pass

    def OnDashFx(self, args):
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
            comp.Create(IMPACT_PARTICLE, (args.get("ox"), args.get("oy"), args.get("oz")), (0, 0, 0))
        except Exception:
            pass
        try:
            self._playSound(args.get("ox"), args.get("oy"), args.get("oz"),
                            "mob.ghast.fireball", 0.8, 0.9)
        except Exception:
            pass

    def OnPunchFx(self, args):
        """重拳落地：爆开的碎石粒子 + 低音冲击"""
        x = float(args.get("x", 0.0))
        y = float(args.get("y", 0.0))
        z = float(args.get("z", 0.0))
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
            for offset in ((0.0, 0.0, 0.0), (1.2, 0.0, 0.0), (-1.2, 0.0, 0.0),
                           (0.0, 0.0, 1.2), (0.0, 0.0, -1.2), (0.0, 1.1, 0.0)):
                comp.Create(PUNCH_PARTICLE,
                            (x + offset[0], y + offset[1], z + offset[2]), (0, 0, 0))
        except Exception:
            pass
        try:
            self._playSound(x, y, z, "random.explode", 1.0, 0.7)
        except Exception:
            pass

    def _drawBeam(self, args):
        comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
        ox = float(args.get("ox", 0.0))
        oy = float(args.get("oy", 0.0))
        oz = float(args.get("oz", 0.0))
        dx = float(args.get("dx", 0.0))
        dy = float(args.get("dy", 0.0))
        dz = float(args.get("dz", 0.0))
        length = float(args.get("length", 0.0))
        comp.Create(MUZZLE_PARTICLE, (ox, oy, oz), (0, 0, 0))
        dist = 0.0
        guard = 0
        while dist < length and guard < 60:
            guard += 1
            dist += cfg.BEAM_STEP_NEAR + cfg.BEAM_STEP_GROW * dist
            if dist > length:
                dist = length
            comp.Create(BEAM_PARTICLE,
                        (ox + dx * dist, oy + dy * dist, oz + dz * dist),
                        (0, 0, 0))
        if args.get("impact"):
            comp.Create(IMPACT_PARTICLE,
                        (float(args.get("ex", 0.0)),
                         float(args.get("ey", 0.0)),
                         float(args.get("ez", 0.0))),
                        (0, 0, 0))

    def _playSound(self, x, y, z, name, volume, pitch):
        try:
            comp = clientApi.GetEngineCompFactory().CreateCustomAudio(clientApi.GetLevelId())
            result = comp.PlayCustomMusic(name, (float(x), float(y), float(z)), volume, pitch, False, None)
            if result is None or str(result).startswith("-"):
                comp.PlayCustomMusic("random.explode", (float(x), float(y), float(z)),
                                     0.8, 1.8, False, None)
        except Exception:
            pass