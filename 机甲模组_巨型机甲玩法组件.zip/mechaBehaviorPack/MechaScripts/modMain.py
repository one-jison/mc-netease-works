# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from MechaScripts import modConfig


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class MechaMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def MechaServerInit(self):
        serverApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def MechaServerDestroy(self):
        pass

    @Mod.InitClient()
    def MechaClientInit(self):
        clientApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def MechaClientDestroy(self):
        pass
