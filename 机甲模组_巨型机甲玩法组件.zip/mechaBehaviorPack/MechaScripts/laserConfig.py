# -*- coding: utf-8 -*-
# ============================================================
#  机甲模组 - 数值配置（想改手感，改这里就够了）
# ============================================================

# ---------- 机体 ----------
MECHA_IDENTIFIER = "mecha:mecha"        # 机甲实体标识
CONTROLLER_ITEM = "mecha:mecha_controller"   # 机甲召唤器物品

# ---------- 激光 ----------
LASER_DAMAGE = 26.0        # 单发激光伤害
LASER_RANGE = 48           # 激光最远射程（格）
LASER_COOLDOWN = 0.45      # 激光冷却（秒），越小射得越快
MUZZLE_HEIGHT = 4.8        # 炮口高度（相对机甲脚底，单位：格）
MUZZLE_FORWARD = 1.9       # 炮口向前偏移（格）
BEAM_STEP_NEAR = 0.9       # 光束粒子间距（近处，格）
BEAM_STEP_GROW = 0.09      # 光束粒子间距随距离增大（越大远处越稀疏）

# ---------- 冲刺 ----------
DASH_COOLDOWN = 2.5        # 冲刺冷却（秒）
DASH_POWER = 2.6           # 冲刺初速度，越大冲得越远
DASH_LIFT = 0.55           # 冲刺上抬，越大跳得越高

# ---------- 召唤 ----------
SPAWN_DISTANCE = 4.5       # 召唤机甲时在玩家前方多少格生成
MAX_MECHA_COUNT = 8        # 同时存在的机甲上限，防止卡顿
JOIN_GIVE_CONTROLLER = True   # 玩家进服是否自动发放一个机甲召唤器

# ---------- 骑乘表现 ----------
HIDE_RIDER = True          # 驾驶时隐藏玩家模型，第三视角不会看到史蒂夫站在机甲头上
HIDE_RIDER_NAME = True     # 同时隐藏驾驶员的头顶名字
RIDER_CHECK_INTERVAL = 0.5 # 服务端检查"谁在开机甲"的间隔（秒），一般不用改

# ---------- 手机（触屏）操作 ----------
# 手机上没有鼠标和键盘，这里把三个动作绑到触屏手势上
MOBILE_CONTROLS = True      # 手机手势总开关，改成 False 手机端只剩原版操作
MOBILE_TAP_LASER = True     # 轻点屏幕           = 激光炮
MOBILE_HOLD_PUNCH = True    # 长按屏幕           = 重拳碎方块
MOBILE_JUMP_DASH = True     # 点屏幕上的跳跃按钮 = 推进冲刺（同时还是会跳一下）
MOBILE_HOLD_MS = 260        # 长按判定时间（毫秒，原版默认 400）。越小越容易搓出重拳
MOBILE_HOLD_GUARD = 0.5     # 长按之后这段时间内忽略松手带来的轻点，避免重拳完又打一炮
SHOW_MOBILE_TIP = True      # 骑上机甲时在屏幕上方弹一行操作提示
MOBILE_TIP = u"轻点=激光  长按=重拳  跳跃键=冲刺  输入#下机甲可下机"
MOBILE_TIP_REPEAT = 8.0     # 提示重复弹出的间隔（秒），改成 0 就只提示一次
