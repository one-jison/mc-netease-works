# -*- coding: utf-8 -*-
# 机甲模组 - 公共配置

ModName = "MechaMod"
ModVersion = "0.0.4"

ServerSystemName = "MechaServerSystem"
ClientSystemName = "MechaClientSystem"

ServerSystemClsPath = "MechaScripts.mechaServerSystem.MechaServerSystem"
ClientSystemClsPath = "MechaScripts.mechaClientSystem.MechaClientSystem"

# 客户端 -> 服务端
EventFireLaser = "MechaFireLaser"
EventDash = "MechaDash"
EventPunch = "MechaPunch"

# 服务端 -> 客户端
EventBeamFx = "MechaBeamFx"
EventDashFx = "MechaDashFx"
EventPunchFx = "MechaPunchFx"
EventRiderState = "MechaRiderState"