# -*- coding: utf-8 -*-
# 机甲模组 - 服务端：召唤机甲、激光炮、重拳碎方块、推进冲刺
import time
import mod.server.extraServerApi as serverApi
from MechaScripts import modConfig
from MechaScripts import laserConfig as cfg
from MechaScripts import breakConfig as bc
from MechaScripts import blockBreaker

ServerSystem = serverApi.GetServerSystemCls()

NO_RIDER = "-1"


class MechaServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(MechaServerSystem, self).__init__(namespace, systemName)
        self._lastLaser = {}      # playerId -> 上次开火时间
        self._lastDash = {}       # playerId -> 上次冲刺时间
        self._lastPunch = {}      # playerId -> 上次出拳时间
        self._welcomed = set()
        self._mechas = []         # 记录本模组召唤出的机甲
        self._tipShown = set()
        self._blockBreaker = None
        self._lastRiderKey = None   # 上一次广播出去的骑乘状态
        self._listenEvents()
        self._startRiderWatcher()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        self.ListenForEvent(ns, sn, "ServerItemTryUseEvent", self, self.OnItemTryUse)
        self.ListenForEvent(ns, sn, "ServerChatEvent", self, self.OnChat)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventFireLaser, self, self.OnFireLaser)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventDash, self, self.OnDash)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventPunch, self, self.OnPunch)

    # ==================== 小工具 ====================
    def _riddenMecha(self, playerId):
        """玩家正在驾驶机甲时返回机甲 entityId，否则返回 None"""
        try:
            comp = serverApi.GetEngineCompFactory().CreateRide(playerId)
            rideId = comp.GetEntityRider()
            if not rideId or rideId == NO_RIDER:
                return None
            identifier = None
            try:
                identifier = serverApi.GetEngineCompFactory().CreateEngineType(rideId).GetEngineTypeStr()
            except Exception:
                identifier = None
            if identifier is not None and identifier != cfg.MECHA_IDENTIFIER:
                return None
            return rideId
        except Exception:
            return None

    def _lookDir(self, entityId):
        try:
            rot = serverApi.GetEngineCompFactory().CreateRot(entityId).GetRot()
            return serverApi.GetDirFromRot(rot)
        except Exception:
            return (0.0, 0.0, 1.0)

    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _dimensionOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _breaker(self):
        """方块破坏器（整个模组共用一个实例）"""
        if self._blockBreaker is None:
            self._blockBreaker = blockBreaker.BlockBreaker(serverApi.GetLevelId())
        return self._blockBreaker

    def _rayHit(self, dimensionId, origin, direction, distance):
        """打一条射线。返回 (命中实体id, 命中方块坐标, 命中点坐标)，打空的部分为 None"""
        results = None
        try:
            results = serverApi.getEntitiesOrBlockFromRay(
                dimensionId, origin, direction, distance, False,
                serverApi.GetMinecraftEnum().RayFilterType.BothEntitiesAndBlock)
        except Exception:
            results = None
        if not results:
            return None, None, None
        first = results[0]
        if not isinstance(first, dict):
            return None, None, None
        hitPos = first.get("hitPos")
        if first.get("type") == "Entity":
            return first.get("entityId"), None, hitPos
        blockPos = first.get("pos")
        if blockPos:
            blockPos = (int(blockPos[0]), int(blockPos[1]), int(blockPos[2]))
        return None, blockPos, hitPos

    def _tip(self, playerId, text, color="BLUE"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    def _pruneMechas(self):
        alive = []
        for entityId in self._mechas:
            try:
                if self.IsEntityAlive(entityId):
                    alive.append(entityId)
            except Exception:
                pass
        self._mechas = alive

    # ==================== 骑乘状态广播 ====================
    def _startRiderWatcher(self):
        """定时检查谁在开机甲，状态变了就通知所有客户端隐藏/恢复他的模型"""
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
            comp.AddRepeatedTimer(cfg.RIDER_CHECK_INTERVAL, self._checkRiders)
        except Exception:
            pass

    def _checkRiders(self):
        try:
            players = serverApi.GetPlayerList()
        except Exception:
            players = None
        hidden = []
        if players:
            for playerId in players:
                try:
                    if self._riddenMecha(playerId):
                        hidden.append(playerId)
                except Exception:
                    pass
        hidden.sort()
        key = tuple(hidden)
        if key == self._lastRiderKey:
            return
        self._lastRiderKey = key
        self._broadcastRiders(hidden)

    def _broadcastRiders(self, hidden):
        data = {"hidden": list(hidden)}
        try:
            self.NotifyToAllClients(modConfig.EventRiderState, data)
            return
        except Exception:
            pass
        # 兜底：逐个通知
        try:
            players = serverApi.GetPlayerList()
        except Exception:
            players = None
        if not players:
            return
        for playerId in players:
            try:
                self.NotifyToClient(playerId, modConfig.EventRiderState, data)
            except Exception:
                pass

    # ==================== 玩家进入 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        self._lastRiderKey = None   # 有玩家进来，下一轮重新广播骑乘状态
        if not cfg.JOIN_GIVE_CONTROLLER:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
            comp.AddTimer(2.0, self._giveController, playerId)
        except Exception:
            pass

    def _giveController(self, playerId):
        try:
            itemDict = {"itemName": cfg.CONTROLLER_ITEM, "count": 1, "auxValue": 0}
            serverApi.GetEngineCompFactory().CreateItem(playerId).SpawnItemToPlayerInv(itemDict, playerId, 0)
            self._tip(playerId, u"获得【机甲召唤器】：对着地面点右键即可部署巨型机甲", "AQUA")
        except Exception:
            pass

    # ==================== 召唤机甲 ====================
    def _summonMecha(self, playerId):
        self._pruneMechas()
        if len(self._mechas) >= cfg.MAX_MECHA_COUNT:
            self._tip(playerId, u"机甲数量已达上限（%d 台），先清掉一些吧" % cfg.MAX_MECHA_COUNT, "RED")
            return None
        if self._riddenMecha(playerId):
            return None
        cf = serverApi.GetEngineCompFactory()
        pos = self._posOf(playerId)
        if not pos:
            return None
        dirX, dirY, dirZ = self._lookDir(playerId)
        rot = cf.CreateRot(playerId).GetRot()
        spawnPos = (pos[0] + dirX * cfg.SPAWN_DISTANCE,
                    pos[1] + 0.2,
                    pos[2] + dirZ * cfg.SPAWN_DISTANCE)
        dimensionId = self._dimensionOf(playerId)
        entityId = self.CreateEngineEntityByTypeStr(cfg.MECHA_IDENTIFIER, spawnPos, (0.0, rot[1]), dimensionId)
        if entityId:
            self._mechas.append(entityId)
            self._tip(playerId, u"机甲部署完毕！对准机甲按右键即可驾驶", "GREEN")
        else:
            self._tip(playerId, u"这里放不下机甲，换个空旷的地方试试", "RED")
        return entityId

    def OnItemTryUse(self, args):
        try:
            if not args:
                return
            itemDict = args.get("itemDict") or {}
            if itemDict.get("itemName") != cfg.CONTROLLER_ITEM:
                return
            playerId = args.get("playerId")
            if playerId:
                self._summonMecha(playerId)
        except Exception:
            pass

    def OnChat(self, args):
        try:
            if not args:
                return
            message = (args.get("message") or "").strip().lower()
            playerId = args.get("playerId")
            if not playerId:
                return
            if message in (u"#mecha", u"#机甲"):
                self._summonMecha(playerId)
            elif message in (u"#下机甲", u"#下机", u"#下车", u"#mecha off"):
                self._dismount(playerId)
            else:
                return
            args["cancel"] = True   # 指令本身不用发到聊天框里刷屏
        except Exception:
            pass

    def _dismount(self, playerId):
        """让玩家从机甲上下来（手机上没有 Shift 键，用聊天指令代替）"""
        try:
            if serverApi.GetEngineCompFactory().CreateRide(playerId).StopEntityRiding():
                self._tip(playerId, u"已下机甲", "AQUA")
                return
        except Exception:
            pass
        self._tip(playerId, u"你现在没有在驾驶机甲", "RED")

    # ==================== 激光炮 ====================
    def OnFireLaser(self, args):
        playerId = None
        if args:
            playerId = args.get("playerId")
        if not playerId:
            return
        now = time.time()
        if now - self._lastLaser.get(playerId, 0.0) < cfg.LASER_COOLDOWN:
            return
        mechaId = self._riddenMecha(playerId)
        if not mechaId:
            return
        self._lastLaser[playerId] = now
        if playerId not in self._tipShown:
            self._tipShown.add(playerId)
            self._tip(playerId, u"机甲系统：左键=激光炮  F=重拳碎方块  右键=推进冲刺", "AQUA")
        try:
            self._fireLaser(playerId, mechaId)
        except Exception:
            pass

    def _fireLaser(self, playerId, mechaId):
        dirX, dirY, dirZ = self._lookDir(playerId)
        mechaPos = self._posOf(mechaId)
        if not mechaPos:
            return
        origin = (mechaPos[0] + dirX * cfg.MUZZLE_FORWARD,
                  mechaPos[1] + cfg.MUZZLE_HEIGHT + dirY * cfg.MUZZLE_FORWARD,
                  mechaPos[2] + dirZ * cfg.MUZZLE_FORWARD)
        dimensionId = self._dimensionOf(mechaId)

        targetId, blockPos, hitPos = self._rayHit(
            dimensionId, origin, (dirX, dirY, dirZ), cfg.LASER_RANGE)
        # 射线打到自己身上时当作没打中
        if targetId and (targetId == mechaId or targetId == playerId):
            targetId = None
            hitPos = None

        if hitPos:
            endPos = (float(hitPos[0]), float(hitPos[1]), float(hitPos[2]))
            distance = ((endPos[0] - origin[0]) ** 2 +
                        (endPos[1] - origin[1]) ** 2 +
                        (endPos[2] - origin[2]) ** 2) ** 0.5
        else:
            distance = float(cfg.LASER_RANGE)
            endPos = (origin[0] + dirX * distance,
                      origin[1] + dirY * distance,
                      origin[2] + dirZ * distance)
        if distance > cfg.LASER_RANGE:
            distance = float(cfg.LASER_RANGE)
        if distance < 0.8:
            distance = 0.8

        if targetId:
            self._hurtTarget(targetId, cfg.LASER_DAMAGE, playerId)
        elif blockPos and bc.LASER_BREAK:
            # 激光炮可以打穿地形：在命中处炸出一个小坑
            self._breaker().breakSphere(blockPos, bc.LASER_BREAK_RADIUS,
                                        dimensionId, bc.LASER_BREAK_MAX)

        self.NotifyToClient(playerId, modConfig.EventBeamFx, {
            "ox": origin[0], "oy": origin[1], "oz": origin[2],
            "dx": dirX, "dy": dirY, "dz": dirZ,
            "length": distance,
            "impact": bool(hitPos),
            "ex": endPos[0], "ey": endPos[1], "ez": endPos[2]
        })

    def _hurtTarget(self, targetId, damage, playerId):
        try:
            comp = serverApi.GetEngineCompFactory().CreateHurt(targetId)
            comp.Hurt(damage,
                      serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                      playerId, None, True)
            return True
        except Exception:
            return False

    # ==================== 重拳：一拳打碎一大片方块 ====================
    def OnPunch(self, args):
        playerId = None
        if args:
            playerId = args.get("playerId")
        if not playerId:
            return
        now = time.time()
        if now - self._lastPunch.get(playerId, 0.0) < bc.PUNCH_COOLDOWN:
            return
        mechaId = self._riddenMecha(playerId)
        if not mechaId:
            return
        self._lastPunch[playerId] = now
        try:
            self._punch(playerId, mechaId)
        except Exception:
            pass

    def _punch(self, playerId, mechaId):
        dirX, dirY, dirZ = self._lookDir(playerId)
        mechaPos = self._posOf(mechaId)
        if not mechaPos:
            return
        dimensionId = self._dimensionOf(mechaId)
        origin = (mechaPos[0] + dirX * bc.PUNCH_FORWARD,
                  mechaPos[1] + bc.PUNCH_HEIGHT + dirY * bc.PUNCH_FORWARD,
                  mechaPos[2] + dirZ * bc.PUNCH_FORWARD)
        fallback = (int(origin[0] + dirX * bc.PUNCH_RANGE),
                    int(origin[1] + dirY * bc.PUNCH_RANGE),
                    int(origin[2] + dirZ * bc.PUNCH_RANGE))

        targetId, blockPos, hitPos = self._rayHit(
            dimensionId, origin, (dirX, dirY, dirZ), bc.PUNCH_RANGE)
        if targetId and (targetId == mechaId or targetId == playerId):
            targetId = None

        # 拳头落点：优先打中谁就砸谁脚下，否则砸正前方
        if blockPos:
            center = blockPos
        elif targetId:
            targetPos = self._posOf(targetId)
            if targetPos:
                center = (int(targetPos[0]), int(targetPos[1]), int(targetPos[2]))
            else:
                center = fallback
        else:
            center = fallback

        # 1) 一拳打碎一片方块
        broken = self._breaker().breakSphere(center, bc.PUNCH_RADIUS,
                                             dimensionId, bc.BREAK_MAX_PER_PUNCH)
        # 2) 拳风把周围的生物掀飞
        hitCount = self._punchEntities(playerId, mechaId, center, dimensionId)
        if targetId:
            self._hurtTarget(targetId, bc.PUNCH_DAMAGE, playerId)

        self.NotifyToClient(playerId, modConfig.EventPunchFx, {
            "x": float(center[0]) + 0.5,
            "y": float(center[1]) + 0.5,
            "z": float(center[2]) + 0.5,
            "broken": int(broken),
            "hit": int(hitCount),
        })
        return broken

    def _punchEntities(self, playerId, mechaId, center, dimensionId):
        """把拳头落点周围的生物掀飞（机甲自己和驾驶员不受影响）"""
        r = int(bc.PUNCH_ENTITY_RADIUS) + 1
        startPos = (int(center[0] - r), int(center[1] - r), int(center[2] - r))
        endPos = (int(center[0] + r), int(center[1] + r), int(center[2] + r))
        cf = serverApi.GetEngineCompFactory()
        try:
            entityIds = cf.CreateGame(serverApi.GetLevelId()).GetEntitiesInSquareArea(
                None, startPos, endPos, dimensionId)
        except Exception:
            entityIds = None
        if not entityIds:
            return 0

        hitCount = 0
        for entityId in entityIds:
            if not entityId or entityId == mechaId or entityId == playerId:
                continue
            pos = None
            try:
                pos = cf.CreatePos(entityId).GetFootPos()
            except Exception:
                pos = None
            if not pos:
                continue
            dx, dy, dz = pos[0] - center[0], pos[1] - center[1], pos[2] - center[2]
            dist = (dx * dx + dy * dy + dz * dz) ** 0.5
            if dist > bc.PUNCH_ENTITY_RADIUS:
                continue
            if self._hurtTarget(entityId, bc.PUNCH_DAMAGE, playerId):
                hitCount += 1
            # 以落点为圆心向外抛出
            if dist < 0.01:
                dx, dy, dz, dist = 0.0, 1.0, 0.0, 1.0
            power = bc.PUNCH_KNOCK
            try:
                motion = cf.CreateActorMotion(entityId)
                motion.SetMotion((dx / dist * power,
                                  dy / dist * power + bc.PUNCH_KNOCK_LIFT,
                                  dz / dist * power))
            except Exception:
                pass
        return hitCount

    # ==================== 推进冲刺 ====================
    def OnDash(self, args):
        playerId = None
        if args:
            playerId = args.get("playerId")
        if not playerId:
            return
        now = time.time()
        if now - self._lastDash.get(playerId, 0.0) < cfg.DASH_COOLDOWN:
            return
        mechaId = self._riddenMecha(playerId)
        if not mechaId:
            return
        self._lastDash[playerId] = now
        try:
            dirX, dirY, dirZ = self._lookDir(playerId)
            lift = dirY * cfg.DASH_POWER
            if lift < 0.15:
                lift = 0.15
            motionComp = serverApi.GetEngineCompFactory().CreateActorMotion(mechaId)
            motionComp.SetMotion((dirX * cfg.DASH_POWER,
                                  lift + cfg.DASH_LIFT,
                                  dirZ * cfg.DASH_POWER))
            pos = self._posOf(mechaId)
            if pos:
                self.NotifyToClient(playerId, modConfig.EventDashFx, {
                    "ox": pos[0], "oy": pos[1] + 0.4, "oz": pos[2]
                })
                # 冲刺撞碎挡路的方块，冲出一条路来
                if bc.DASH_BREAK:
                    center = (int(pos[0] + dirX * bc.DASH_BREAK_FORWARD),
                              int(pos[1] + bc.DASH_BREAK_HEIGHT),
                              int(pos[2] + dirZ * bc.DASH_BREAK_FORWARD))
                    self._breaker().breakSphere(center, bc.DASH_BREAK_RADIUS,
                                                self._dimensionOf(mechaId),
                                                bc.DASH_BREAK_MAX)
        except Exception:
            pass