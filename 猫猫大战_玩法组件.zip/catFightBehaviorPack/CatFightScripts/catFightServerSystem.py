# -*- coding: utf-8 -*-
# ============================================================
#  猫猫大战 - 服务端
#  负责：盯着玩家附近的猫，发现两只凑到一起就让它们互相仇视、当场开打，
#        打架过程中不停发出愤怒的叫声、头顶冒火气，
#        有一只倒下（或者跑散）就分胜负、清仇恨。
# ============================================================
import math
import random
import time
import mod.server.extraServerApi as serverApi
from CatFightScripts import modConfig
from CatFightScripts import catFightConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()

CAT_TYPE = u"minecraft:cat"


class CatFightServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(CatFightServerSystem, self).__init__(namespace, systemName)
        self._on = bool(getattr(cfg, "ENABLED", True))
        self._scanT = 0.0           # 上次扫描的时间
        self._fights = {}           # 猫id -> 对手id（正在打架）
        self._fightT = {}           # 猫id -> 这场架开始的时间
        self._soundT = {}           # 猫id -> 下次叫的时间
        self._partT = {}            # 猫id -> 下次冒火气的时间
        self._dmgT = {}             # 猫id -> 下次补刀的时间
        self._targetT = {}          # 猫id -> 下次重新确认对手的时间
        self._lungeT = {}           # 猫id -> 下次扑过去的时间
        self._coolT = {}            # 猫id -> 上一场架结束的时间
        self._calmUntil = 0.0       # #停战 之后冷静到什么时候
        self._cleanT = 0.0          # 上次清理记录的时间
        self._hpLock = {}           # 猫id -> 开打时的血量（打闹模式用来保持不掉血）
        self._dead = {}             # 刚刚死掉的实体id -> 时间
        self._welcomed = set()
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        self.ListenForEvent(ns, sn, "ServerChatEvent", self, self.OnChat)
        self.ListenForEvent(ns, sn, "OnScriptTickServer", self, self.OnTick)
        # 打闹模式：拦下两只猫之间的伤害，让它们怎么打都不掉血
        self.ListenForEvent(ns, sn, "DamageEvent", self, self.OnDamage)
        self.ListenForEvent(ns, sn, "ActuallyHurtServerEvent", self, self.OnActuallyHurt)
        self.ListenForEvent(ns, sn, "MobDieEvent", self, self.OnMobDie)

    # ==================== 小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _dimOf(self, entityId):
        try:
            return int(serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId())
        except Exception:
            return 0

    def _typeOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateEngineType(
                entityId).GetEngineTypeStr()
        except Exception:
            return None

    def _isCat(self, entityId):
        if not entityId:
            return False
        t = self._typeOf(entityId)
        if not t:
            return False
        t = str(t)
        return t == CAT_TYPE or t.endswith(u":cat")

    def _isBaby(self, entityId):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateEntityDefinitions(
                entityId).IsBaby())
        except Exception:
            return False

    def _health(self, entityId):
        try:
            return float(serverApi.GetEngineCompFactory().CreateAttr(
                entityId).GetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH))
        except Exception:
            return -1.0

    def _dist(self, a, b):
        return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 +
                         (a[2] - b[2]) ** 2)

    def _noDamage(self):
        # 打闹模式开关：打得热闹，但不掉血
        return bool(getattr(cfg, "NO_DAMAGE", True))

    def _fighting(self, a, b):
        return bool(a) and bool(b) and self._fights.get(a) == b

    def _lockHp(self, entityId):
        hp = self._health(entityId)
        if hp > 0.0:
            self._hpLock[entityId] = hp

    def _setHealth(self, entityId, value):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateAttr(
                entityId).SetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH, float(value), 0))
        except Exception:
            return False

    def _keepHp(self, entityId):
        # 打闹模式的保险：万一还是掉了血，立刻补回开打时的量
        lock = self._hpLock.get(entityId)
        if not lock:
            return
        hp = self._health(entityId)
        if 0.0 <= hp < float(lock) - 0.01:
            self._setHealth(entityId, lock)

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    # ==================== 给猫下命令 ====================
    def _setTarget(self, entityId, targetId):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateAction(
                entityId).SetAttackTarget(targetId))
        except Exception:
            return False

    def _clearTarget(self, entityId):
        try:
            serverApi.GetEngineCompFactory().CreateAction(entityId).ResetAttackTarget()
        except Exception:
            pass

    def _standUp(self, entityId):
        # 坐着的猫先站起来，不然它只会坐在原地挨打
        try:
            comp = serverApi.GetEngineCompFactory().CreateEntityDefinitions(entityId)
            if comp.IsSitting():
                try:
                    comp.SetSitting(False)
                except Exception:
                    comp.SetSitting()
        except Exception:
            pass

    def _hurt(self, entityId, attackerId, damage):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateHurt(entityId).Hurt(
                float(damage),
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                attackerId, None, True))
        except Exception:
            return False

    # ==================== 表现：叫声 / 粒子 ====================
    def _broadcast(self, data):
        try:
            self.BroadcastToAllClient(modConfig.EventCatFx, data)
        except Exception:
            pass

    def _fxAt(self, kind, pos, pitch=1.0, dim=0):
        if pos is None:
            return
        self._broadcast({"t": kind,
                         "x": float(pos[0]), "y": float(pos[1]), "z": float(pos[2]),
                         "p": float(pitch), "dim": int(dim)})

    def _voice(self, entityId, pos=None):
        # 愤怒的叫声：多数是炸毛的嘶嘶声，偶尔改成一长声嚎叫
        if not getattr(cfg, "SOUND_ENABLED", True):
            return
        if pos is None:
            pos = self._posOf(entityId)
        if pos is None:
            return
        yowl = random.random() < float(getattr(cfg, "YOWL_CHANCE", 0.35))
        name = "catfight.yowl" if yowl else "catfight.hiss"
        pmin = float(getattr(cfg, "HISS_PITCH_MIN", 0.9))
        pmax = float(getattr(cfg, "HISS_PITCH_MAX", 1.15))
        if pmax < pmin:
            pmax = pmin
        pitch = pmin + random.random() * (pmax - pmin)
        self._fxAt(name, (pos[0], pos[1] + 0.6, pos[2]), pitch, self._dimOf(entityId))

    def _angry(self, entityId, pos=None):
        if not getattr(cfg, "ANGRY_PARTICLE", True):
            return
        if pos is None:
            pos = self._posOf(entityId)
        if pos is None:
            return
        h = float(getattr(cfg, "PARTICLE_HEIGHT", 0.9))
        self._fxAt("angry", (pos[0], pos[1] + h, pos[2]), 1.0, self._dimOf(entityId))

    def _announce(self, text, pos, dim, color="GOLD"):
        if not getattr(cfg, "ANNOUNCE", True) or pos is None:
            return
        r = float(getattr(cfg, "ANNOUNCE_DIST", 24.0))
        for pid in (serverApi.GetPlayerList() or []):
            p = self._posOf(pid)
            if p is None:
                continue
            if self._dimOf(pid) != dim:
                continue
            if self._dist(p, pos) <= r:
                self._tip(pid, text, color)

    # ==================== 打闹模式：不许掉血 ====================
    def OnDamage(self, args):
        try:
            if not args or not self._noDamage():
                return
            victim = args.get("entityId")
            src = args.get("srcId")
            if self._fighting(victim, src) or self._fighting(src, victim):
                args["damage"] = 0        # 伤害改成 0，这一下就不会掉血
                args["knock"] = False     # 也不要被打飞
        except Exception:
            pass

    def OnActuallyHurt(self, args):
        try:
            if not args or not self._noDamage():
                return
            victim = args.get("entityId")
            src = args.get("srcId")
            if self._fighting(victim, src) or self._fighting(src, victim):
                args["damage"] = 0
        except Exception:
            pass

    def OnMobDie(self, args):
        try:
            if not args:
                return
            eid = args.get("id")
            if eid:
                self._dead[eid] = time.time()
        except Exception:
            pass

    # ==================== 开打 / 收场 ====================
    def _startFight(self, a, b, now, force=False):
        if not a or not b or a == b:
            return False
        if self._fights.get(a) or self._fights.get(b):
            return False
        cd = float(getattr(cfg, "REMATCH_COOLDOWN", 12.0))
        if not force:
            if now - self._coolT.get(a, 0.0) < cd:
                return False
            if now - self._coolT.get(b, 0.0) < cd:
                return False
        # 两只猫互相仇视
        self._fights[a] = b
        self._fights[b] = a
        self._fightT[a] = now
        self._fightT[b] = now
        self._targetT[a] = now + float(getattr(cfg, "TARGET_REFRESH", 0.75))
        self._targetT[b] = now + float(getattr(cfg, "TARGET_REFRESH", 0.75))
        self._setTarget(a, b)
        self._setTarget(b, a)
        self._standUp(a)
        self._standUp(b)
        if self._noDamage():
            self._lockHp(a)
            self._lockHp(b)
        # 一见面先炸毛
        self._soundT[a] = now + random.random() * 0.2
        self._soundT[b] = now + 0.35 + random.random() * 0.2
        self._partT[a] = now
        self._partT[b] = now
        interval = float(getattr(cfg, "OWN_DAMAGE_INTERVAL", 1.5))
        self._dmgT[a] = now + interval * 0.6
        self._dmgT[b] = now + interval
        pa = self._posOf(a)
        self._voice(a, pa)
        self._angry(a, pa)
        pb = self._posOf(b)
        self._voice(b, pb)
        self._angry(b, pb)
        dim = self._dimOf(a)
        self._announce(u"两只猫对上了眼，马上就要打起来！", pa, dim)
        return True

    def _endFight(self, a, b, now, win=False):
        if a not in self._fights and b not in self._fights:
            return
        self._fights.pop(a, None)
        self._fights.pop(b, None)
        self._clearTarget(a)
        self._clearTarget(b)
        self._coolT[a] = now
        self._coolT[b] = now
        self._forget(a)
        self._forget(b)
        if win:
            pos = self._posOf(a)
            if pos is not None and getattr(cfg, "WIN_SOUND", True):
                self._fxAt("catfight.win", (pos[0], pos[1] + 0.6, pos[2]), 1.05,
                           self._dimOf(a))
            self._announce(u"胜负已分：赢的那只猫得意地喵了一声！", pos, self._dimOf(a))

    def _forget(self, entityId):
        # 这只猫的临时记录清掉（打架计时之类）
        for box in (self._soundT, self._partT, self._dmgT, self._targetT,
                    self._lungeT, self._fightT, self._hpLock):
            box.pop(entityId, None)

    def _stopAll(self, now):
        for cat in list(self._fights.keys()):
            tgt = self._fights.get(cat)
            if tgt:
                self._endFight(cat, tgt, now, win=False)
            else:
                self._fights.pop(cat, None)
                self._forget(cat)

    def _hitFx(self, tgt, pb):
        # 咬到对方时的小火花（真打时被咬的叫声引擎自己会放）
        if pb is None or not getattr(cfg, "HIT_PARTICLE", True):
            return
        self._fxAt("hit", (pb[0], pb[1] + 0.5, pb[2]), 1.0, self._dimOf(tgt))

    def _fakeBite(self, cat, tgt, pb, now):
        # 打闹模式专用：不造成伤害，但看上去、听上去就像真咬了一口
        if pb is None:
            return
        dim = self._dimOf(tgt)
        pos = (pb[0], pb[1] + 0.5, pb[2])
        if getattr(cfg, "PLAY_HIT_SOUND", True):
            self._fxAt("catfight.hit", pos, 1.0, dim)
        if getattr(cfg, "HIT_PARTICLE", True):
            self._fxAt("hit", pos, 1.0, dim)

    # ==================== 扑咬 ====================
    def _lunge(self, cat, pa, pb, d, now):
        # 向对方冲过去（世界坐标系里的瞬时速度），看起来就是猫扑上去咬一口
        if not getattr(cfg, "LUNGE", True):
            return False
        if d < float(getattr(cfg, "LUNGE_MIN_DIST", 1.6)):
            return False
        if now < self._lungeT.get(cat, 0.0):
            return False
        self._lungeT[cat] = now + float(getattr(cfg, "LUNGE_INTERVAL", 0.9))
        dx = float(pb[0]) - float(pa[0])
        dz = float(pb[2]) - float(pa[2])
        h = math.sqrt(dx * dx + dz * dz)
        if h < 1e-4:
            dx, dz, h = 0.0, 1.0, 1.0
        speed = float(getattr(cfg, "LUNGE_SPEED", 0.55))
        up = float(getattr(cfg, "LUNGE_UP", 0.30))
        dy = float(pb[1]) - float(pa[1])
        if dy > 0.5:
            up = min(0.6, up + dy * 0.35)     # 对方在高处就跳高一点
        try:
            serverApi.GetEngineCompFactory().CreateActorMotion(cat).SetMotion(
                (dx / h * speed, up, dz / h * speed))
            return True
        except Exception:
            return False

    # ==================== 打架中 ====================
    def _keepFight(self, cat, tgt, pa, pb, d, now):
        # 0）打闹模式：不管怎么打都不掉血
        if self._noDamage():
            self._keepHp(cat)
        # 1）重新确认对手（原版的扑咬行为靠这个仇恨目标工作）
        if now >= self._targetT.get(cat, 0.0):
            self._targetT[cat] = now + float(getattr(cfg, "TARGET_REFRESH", 0.75))
            self._setTarget(cat, tgt)
            if getattr(cfg, "STAND_UP", True):
                self._standUp(cat)
        # 2）扑过去：不管原版 AI 走不走，自己也要冲上去
        self._lunge(cat, pa, pb, d, now)
        # 3）愤怒的叫声
        if now >= self._soundT.get(cat, 0.0):
            self._soundT[cat] = now + float(getattr(cfg, "HISS_INTERVAL", 1.4)) * \
                (0.75 + random.random() * 0.5)
            self._voice(cat, pa)
        # 4）头顶冒火气
        if now >= self._partT.get(cat, 0.0):
            self._partT[cat] = now + float(getattr(cfg, "PARTICLE_INTERVAL", 0.9))
            self._angry(cat, pa)
        # 5）咬一口：打闹模式只演不伤，真打模式才掉血
        if d > float(getattr(cfg, "OWN_DAMAGE_DIST", 2.2)):
            return
        if now < self._dmgT.get(cat, 0.0):
            return
        self._dmgT[cat] = now + float(getattr(cfg, "OWN_DAMAGE_INTERVAL", 1.5))
        # 打闹模式：只演不伤——叫一声被咬到 + 冒一点火花
        if self._noDamage():
            self._fakeBite(cat, tgt, pb, now)
            return
        # 点到为止模式：血不多了就收手，猫不会被打死
        if getattr(cfg, "MERCY_MODE", False):
            hp = self._health(tgt)
            if 0.0 <= hp <= float(getattr(cfg, "MERCY_HP", 4.0)):
                self._endFight(cat, tgt, now, win=False)
                return
        if not getattr(cfg, "OWN_DAMAGE", True):
            return
        self._hitFx(tgt, pb)
        self._hurt(tgt, cat, float(getattr(cfg, "OWN_DAMAGE_VALUE", 2.0)))

    def _tickFights(self, now):
        for cat in list(self._fights.keys()):
            tgt = self._fights.get(cat)
            if not tgt:
                self._fights.pop(cat, None)
                self._forget(cat)
                continue
            aliveA = self._isCat(cat)
            aliveB = self._isCat(tgt)
            if not aliveA or not aliveB:
                # 有一方真的倒下了，活着的那只算赢
                tgtDied = bool(self._dead.pop(tgt, None))
                catDied = bool(self._dead.pop(cat, None))
                self._endFight(cat, tgt, now,
                               win=(tgtDied and not catDied and aliveA))
                continue
            pa = self._posOf(cat)
            pb = self._posOf(tgt)
            if pa is None or pb is None:
                self._endFight(cat, tgt, now, win=False)
                continue
            d = self._dist(pa, pb)
            if d > float(getattr(cfg, "LOSE_DIST", 24.0)):
                self._endFight(cat, tgt, now, win=False)
                continue
            timeout = float(getattr(cfg, "FIGHT_TIMEOUT", 0.0))
            if timeout > 0.0 and now - self._fightT.get(cat, now) > timeout:
                self._endFight(cat, tgt, now, win=False)
                continue
            self._keepFight(cat, tgt, pa, pb, d, now)

    # ==================== 找新的架 ====================
    def _catsNearPlayers(self):
        found = {}
        r = float(getattr(cfg, "SCAN_RADIUS", 32))
        for pid in (serverApi.GetPlayerList() or []):
            pos = self._posOf(pid)
            if pos is None:
                continue
            dim = self._dimOf(pid)
            try:
                comp = serverApi.GetEngineCompFactory().CreateGame(pid)
                ids = comp.GetEntitiesInSquareArea(
                    None,
                    (pos[0] - r, pos[1] - r, pos[2] - r),
                    (pos[0] + r, pos[1] + r, pos[2] + r),
                    dim)
            except Exception:
                ids = None
            for eid in (ids or []):
                if self._isCat(eid):
                    found[eid] = True
        return list(found.keys())

    def _canJoin(self, eid, now):
        if self._fights.get(eid):
            return False
        if eid in self._coolT and now - self._coolT.get(eid, 0.0) < \
                float(getattr(cfg, "REMATCH_COOLDOWN", 12.0)):
            return False
        if getattr(cfg, "BABY_ONLY", False) and not self._isBaby(eid):
            return False
        if not getattr(cfg, "AFFECT_TAMED", True) and self._isTamed(eid):
            return False
        return True

    def _isTamed(self, entityId):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateEntityDefinitions(
                entityId).IsTamed())
        except Exception:
            return False

    def _tickStart(self, now):
        cats = self._catsNearPlayers()
        if not cats:
            return
        pos = {}
        for c in cats:
            p = self._posOf(c)
            if p is not None:
                pos[c] = p
        ids = [c for c in pos.keys() if self._canJoin(c, now)]
        trig = float(getattr(cfg, "TRIGGER_DIST", 8.0))
        limit = int(getattr(cfg, "MAX_FIGHT_CATS", 12))
        for a in ids:
            if len(self._fights) >= limit * 2:
                return
            if not self._canJoin(a, now):
                continue
            best = None
            bd = trig
            for b in ids:
                if b == a or not self._canJoin(b, now):
                    continue
                if self._dimOf(b) != self._dimOf(a):
                    continue
                d = self._dist(pos[a], pos[b])
                if d <= bd:
                    best = b
                    bd = d
            if best:
                self._startFight(a, best, now)

    # ==================== 每帧 ====================
    def OnTick(self, args=None):
        now = time.time()
        if self._fights:
            self._tickFights(now)
        if now - self._scanT < float(getattr(cfg, "SCAN_INTERVAL", 0.5)):
            return
        self._scanT = now
        if now - self._cleanT > 60.0:
            self._cleanT = now
            for eid in list(self._coolT.keys()):
                if now - self._coolT.get(eid, 0.0) > 120.0:
                    self._coolT.pop(eid, None)
            for eid in list(self._dead.keys()):
                if now - self._dead.get(eid, 0.0) > 10.0:
                    self._dead.pop(eid, None)
        if not self._on or now < self._calmUntil:
            if self._fights:
                self._stopAll(now)
            return
        self._tickStart(now)

    # ==================== 召唤几只猫来做示范 ====================
    def _spawnCats(self, playerId, num):
        feet = self._posOf(playerId)
        if feet is None:
            return []
        dim = self._dimOf(playerId)
        try:
            rot = serverApi.GetEngineCompFactory().CreateRot(playerId).GetRot()
            yaw = float(rot[1])
        except Exception:
            yaw = 0.0
        r = float(getattr(cfg, "SPAWN_DIST", 3.5))
        spread = float(getattr(cfg, "SPAWN_SPREAD", 40.0))
        made = []
        for i in range(num):
            y = yaw + spread * (i - (num - 1) / 2.0)
            try:
                d = serverApi.GetDirFromRot((0.0, y))
                dx, dz = float(d[0]), float(d[2])
            except Exception:
                dx, dz = 0.0, 1.0
            px = feet[0] + dx * r
            pz = feet[2] + dz * r
            eid = None
            try:
                eid = self.CreateEngineEntityByTypeStr(
                    CAT_TYPE, (px, feet[1], pz), (0.0, yaw), dim)
            except Exception:
                eid = None
            if eid:
                made.append(eid)
                try:
                    serverApi.GetEngineCompFactory().CreateAttr(
                        eid).SetPersistent(True)
                except Exception:
                    pass
        return made

    def _spawnAndFight(self, playerId, num):
        made = self._spawnCats(playerId, num)
        if len(made) < 2:
            self._tip(playerId, u"没召唤出来，站到空旷一点的地方再试一次", "RED")
            return
        now = time.time()
        for eid in made:
            self._coolT.pop(eid, None)
        if not self._on:
            self._on = True
        self._calmUntil = 0.0
        self._startFight(made[0], made[1], now, force=True)
        self._tip(playerId, u"%d 只猫已经就位，看好戏吧（想收场就输入 #停战）" % len(made),
                  "GREEN")

    # ==================== 玩家进来 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        if not self._on:
            self._tip(playerId, u"猫猫大战：已关闭（聊天输 #猫猫大战 打开）", "AQUA")
            return
        self._tip(playerId, u"猫猫大战已就绪：让两只猫走到一起，它们就会当场打起来"
                           u"（召唤两只来试：聊天输 #猫猫）", "GOLD")

    # ==================== 聊天指令 ====================
    def _showHelp(self, playerId):
        self._tip(playerId, u"猫猫大战指令：#猫猫 召唤两只猫打架 ／ #猫猫 4 召唤4只 "
                           u"／ #停战 全场冷静 ／ #猫猫大战 开关玩法", "GOLD")

    def OnChat(self, args):
        try:
            if not args:
                return
            message = (args.get("message") or "").strip().lower()
            playerId = args.get("playerId")
            if not playerId:
                return
            if message in (u"#猫猫帮助", u"#猫咪帮助", u"#cathelp"):
                self._showHelp(playerId)
            elif message in (u"#猫猫大战", u"#猫猫打架", u"#catfight"):
                self._on = not self._on
                if self._on:
                    self._calmUntil = 0.0
                    self._tip(playerId, u"猫猫大战已开启：两只猫一见面就会打起来", "GREEN")
                else:
                    self._stopAll(time.time())
                    self._tip(playerId, u"猫猫大战已关闭：猫咪们恢复和平", "AQUA")
            elif message in (u"#停战", u"#calm"):
                now = time.time()
                self._stopAll(now)
                self._calmUntil = now + float(getattr(cfg, "CALM_TIME", 20.0))
                self._tip(playerId, u"全场停战：猫咪们冷静 %d 秒"
                          % int(getattr(cfg, "CALM_TIME", 20.0)), "AQUA")
            elif message.startswith(u"#猫猫") or message.startswith(u"#cat"):
                num = 2
                parts = message.split(u" ")
                if len(parts) > 1:
                    try:
                        num = int(float(parts[1]))
                    except Exception:
                        num = 2
                num = max(2, min(num, 8))
                self._spawnAndFight(playerId, num)
            else:
                return
        except Exception:
            pass