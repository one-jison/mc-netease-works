# -*- coding: utf-8 -*-
# 猫猫大战 - 公共配置（模组名 / 事件名 / 版本号）
ModName = "CatFightMod"
ModVersion = "1.2.0"

ServerSystemName = "CatFightServerSystem"
ClientSystemName = "CatFightClientSystem"
ServerSystemClsPath = "CatFightScripts.catFightServerSystem.CatFightServerSystem"
ClientSystemClsPath = "CatFightScripts.catFightClientSystem.CatFightClientSystem"

# 服务端 -> 所有客户端（愤怒的叫声 + 头顶火气粒子）
EventCatFx = "CatFightFx"