# -*- coding: utf-8 -*-
# ============================================================
#  猫猫大战 - 客户端
#  负责：收到服务端的广播后，在本地放出猫的叫声、在猫头顶冒火气粒子。
#        声音和粒子是所有客户端各自播放的，所以房间里的玩家都能看到、听到。
# ============================================================
import mod.client.extraClientApi as clientApi
from CatFightScripts import modConfig
from CatFightScripts import catFightConfig as cfg

ClientSystem = clientApi.GetClientSystemCls()

ANGRY_PARTICLE = "minecraft:villager_angry"   # 头顶愤怒粒子
HIT_PARTICLE = "minecraft:basic_crit_particle"  # 咬到时的小火花

# 打架用的音效名 -> 原版音效名（自定义音效万一加载不出来，就用原版的顶上）
SOUND_FALLBACK = {
    "catfight.hiss": "mob.cat.hiss",
    "catfight.yowl": "mob.cat.straymeow",
    "catfight.win": "mob.cat.meow",
    "catfight.hit": "mob.cat.hit",
}


class CatFightClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(CatFightClientSystem, self).__init__(namespace, systemName)
        self._listenEvents()

    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventCatFx, self, self.OnCatFx)

    # ==================== 小工具 ====================
    def _sameDimension(self, dim):
        if dim is None:
            return True
        try:
            mine = clientApi.GetEngineCompFactory().CreateDimension(
                clientApi.GetLocalPlayerId()).GetEntityDimensionId()
            return int(mine) == int(dim)
        except Exception:
            return True

    def _failed(self, musicId):
        # 播放失败时接口会返回负数（-1 ~ -6），成功则返回一个字符串 id
        if musicId is None:
            return True
        if isinstance(musicId, int):
            return musicId < 0
        try:
            return str(musicId).strip().startswith("-")
        except Exception:
            return False

    # ==================== 收到广播 ====================
    def OnCatFx(self, args):
        if not args:
            return
        if not self._sameDimension(args.get("dim")):
            return
        try:
            pos = (float(args.get("x", 0.0)),
                   float(args.get("y", 0.0)),
                   float(args.get("z", 0.0)))
        except Exception:
            return
        kind = args.get("t") or ""
        if kind == "angry":
            self._spawnAngry(pos)
            return
        if kind == "hit":
            self._spawnHit(pos)
            return
        try:
            pitch = float(args.get("p", 1.0))
        except Exception:
            pitch = 1.0
        self._playSound(kind, pos, pitch)

    # ==================== 愤怒的叫声 ====================
    def _playSound(self, name, pos, pitch):
        if not getattr(cfg, "SOUND_ENABLED", True):
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateCustomAudio(
                clientApi.GetLevelId())
        except Exception:
            return
        volume = float(getattr(cfg, "HISS_VOLUME", 1.0))
        volume = max(0.0, min(1.0, volume))
        mid = None
        try:
            mid = comp.PlayCustomMusic(name, pos, volume, pitch, False, None)
        except Exception:
            mid = None
        if self._failed(mid):
            fb = SOUND_FALLBACK.get(name)
            if fb:
                try:
                    comp.PlayCustomMusic(fb, pos, volume, pitch, False, None)
                except Exception:
                    pass

    # ==================== 咬到时的小火花 ====================
    def _spawnHit(self, pos):
        if not getattr(cfg, "HIT_PARTICLE", True):
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
            comp.Create(HIT_PARTICLE, pos, (0.0, 0.0, 0.0))
        except Exception:
            pass

    # ==================== 头顶火气 ====================
    def _spawnAngry(self, pos):
        if not getattr(cfg, "ANGRY_PARTICLE", True):
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
            comp.Create(ANGRY_PARTICLE, pos, (0.0, 0.0, 0.0))
        except Exception:
            pass