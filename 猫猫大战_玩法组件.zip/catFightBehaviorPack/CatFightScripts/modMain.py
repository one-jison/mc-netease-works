# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from CatFightScripts import modConfig


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class CatFightMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def CatFightServerInit(self):
        serverApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def CatFightServerDestroy(self):
        pass

    @Mod.InitClient()
    def CatFightClientInit(self):
        clientApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def CatFightClientDestroy(self):
        pass