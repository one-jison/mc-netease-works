# -*- coding: utf-8 -*-
# 超级速度 - 公共配置（模块名 / 事件名 / 版本号）
ModName = "CompoundAllMod"
ModVersion = "1.2.2"

ServerSystemName = "SuperSpeedServerSystem"
ClientSystemName = "SuperSpeedClientSystem"
ServerSystemClsPath = "SuperSpeedScripts.superSpeedServerSystem.SuperSpeedServerSystem"
ClientSystemClsPath = "SuperSpeedScripts.superSpeedClientSystem.SuperSpeedClientSystem"

# 服务端 -> 这个玩家自己（药效还开着没有 / 还剩几秒 / 现在有没有在超速）
EventPowerState = "SuperSpeedPowerState"

# 客户端 -> 服务端（自己的疾跑状态：超级速度只在疾跑时生效，服务端读不到疾跑，要客户端报）
EventSprintState = "SuperSpeedSprintState"

# 手机 / 电脑屏幕上的倒计时（HUD）
UiInitFinishedEvent = "UiInitFinished"
HudUIName = "superSpeedHud"
HudUIPyClsPath = "SuperSpeedScripts.superSpeedHudScreen.SuperSpeedHudScreen"
HudUIScreenDef = "superspeedhud.main"
