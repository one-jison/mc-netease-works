# -*- coding: utf-8 -*-
# ============================================================
#  超级速度 - 左上角倒计时（HUD）
# ============================================================
import mod.client.extraClientApi as clientApi

ScreenNode = clientApi.GetScreenNodeCls()

# ★ 左上角倒计时预留几行：几瓶药水一起喝的时候一行一行往下排
TIMER_ROWS = 5


class SuperSpeedHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mLblTimers = [self.mPanel + "/lblTimer%d" % i
                           for i in range(TIMER_ROWS)]
        self.mTimerOn = None
        self.mTimerRow = -1

    # UI 建好后引擎会调用这里
    def Create(self):
        self.SetTimer(False, 0)          # 没喝药水的时候先藏起来

    def SetTimer(self, visible, seconds, sprint=False, row=0):
        # visible = 药效还在不在；seconds = 还剩几秒；sprint = 现在有没有在超速
        # row = 排在左上角第几行
        from SuperSpeedScripts import superSpeedConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            self._writeTimerText(int(seconds), bool(sprint), row)
        if self.mTimerOn == show and self.mTimerRow == row:
            return
        self.mTimerOn = show
        self.mTimerRow = row
        for i in range(TIMER_ROWS):
            self._setVisible(self.mLblTimers[i], show and i == row)

    def _fixRow(self, row):
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _writeTimerText(self, seconds, sprint=False, row=0):
        from SuperSpeedScripts import superSpeedConfig as cfg
        fmt = getattr(cfg, "MODE_HUD_TIMER_FMT", u"%s 剩余 %d 秒")
        try:
            text = fmt % (getattr(cfg, "MODE_NAME", u""), int(seconds))
        except Exception:
            text = u"%d" % int(seconds)
        if sprint:
            text += getattr(cfg, "MODE_HUD_TIMER_SPRINT_SUFFIX", u"（疾跑中）")
        warnAt = float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 10.0))
        if int(seconds) <= warnAt:
            color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
        elif sprint:
            color = getattr(cfg, "MODE_HUD_TIMER_SPRINT_COLOR", (0.55, 1.0, 0.8))
        else:
            color = getattr(cfg, "MODE_HUD_TIMER_COLOR", (0.35, 0.95, 1.0))
        try:
            lbl = self.GetBaseUIControl(self.mLblTimers[self._fixRow(row)]).asLabel()
            lbl.SetText(text)
            try:
                lbl.SetTextColor(color)
            except Exception:
                pass
            try:
                lbl.SetTextFontSize(float(getattr(cfg, "MODE_HUD_TIMER_SCALE", 1.0)))
            except Exception:
                pass
        except Exception:
            pass

    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

