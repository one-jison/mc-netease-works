# -*- coding: utf-8 -*-
# ============================================================
#  士兵男孩 - 数值配置（想改手感只改这个文件，不用动逻辑）
# ============================================================

# ---------- 药水 ----------
MODE_ENABLED = True                       # False = 不用喝药水，进游戏就是士兵男孩状态
MODE_ITEM = "soldierboy:compound_v"       # 药水物品的 id
MODE_NAME = u"V1化合物"                  # 屏幕上 / 提示里显示的名字
MODE_DURATION = 480.0                     # ★ 药效维持多久（秒）：480 = 8 分钟
MODE_TIP = True                           # 喝药 / 失效时在聊天框提示
MODE_JOIN_GIVE = True                     # 进游戏自动发药水（手机端不用打指令）
MODE_JOIN_GIVE_COUNT = 2                  # 进游戏发几瓶
MODE_REFILL_WHEN_EMPTY = True             # 药效结束、背包又空了，自动补一瓶
MODE_STACK = 16                           # 一瓶能叠几个
MODE_WARN_AT = [60.0, 30.0, 10.0]         # 还剩这些秒数时提醒一句

# ---------- 喝药水后的血量（100 颗心） ----------
MODE_MAX_HEALTH_ENABLED = True      # ★ 喝下药水后把生命上限拉高（关掉 = 保持原版 10 颗心）
MODE_MAX_HEALTH = 200.0             # ★ 生命上限改成多少点血：200 点 = 100 颗心
MODE_HEAL_ON_GAIN = True            # 喝下去时直接把血回满
MODE_BASE_MAX_HEALTH = 20.0         # 药效结束时还原成原版的 20 点（10 颗心）
MODE_RESTORE_HEALTH_ON_LOSE = True  # 药效结束时按比例换算血量（满血 -> 满血；一半 -> 一半）
MODE_HEALTH_RECHECK = 2.0           # 隔多少秒检查一次生命上限（死了复活后自动补回来）
MODE_REFILL_ON_DEATH = False        # 死亡后要不要再白送一瓶药水（False = 药效就这么没了）

# ---------- 左上角倒计时 ----------
MODE_HUD_TIMER = True                     # 药效期间在屏幕左上角显示剩余时间
MODE_HUD_TIMER_FMT = u"%s 剩余 %d 秒"      # 显示格式：%s = 药水名，%d = 剩余秒数
MODE_HUD_TIMER_COLOR = (1.0, 0.86, 0.28)    # 时间充裕时：金黄色
MODE_HUD_TIMER_WARN_COLOR = (1.0, 0.30, 0.25)   # 快没了：红色
MODE_HUD_TIMER_CHARGE_COLOR = (1.0, 1.0, 0.55)  # 蓄力中：亮黄
MODE_HUD_TIMER_WARN_AT = 30.0              # 剩余多少秒开始变红
MODE_HUD_TIMER_SCALE = 1.15                # 字号倍率
MODE_HUD_STATUS_FMT = u"蓄力中 %d%%"        # 蓄力进度（屏幕左上角第二行）
MODE_HUD_COOL_FMT = u"爆炸冷却 %d 秒"       # 冷却中（屏幕左上角第二行）

# ---------- 胸口爆炸 ----------
BLAST_ENABLED = True                      # 整个爆炸功能的总开关
BLAST_ICON = True                         # 药效期间在屏幕上显示【爆炸】图标按钮
BLAST_CHARGE_TIME = 5.0                   # ★ 长按蓄力多少秒
BLAST_COOLDOWN = 30.0                     # ★ 炸完之后冷却多少秒
BLAST_DIAMETER = 30                       # ★ 以自己为中心炸出的区域直径（格）
BLAST_RADIUS = 15.0                       # 半径 = 直径的一半（改上面那个就行）
BLAST_CENTER_UP = 1.0                     # 爆炸中心比脚底高多少格（1 = 胸口位置）

BLAST_BREAK_BLOCKS = True                 # 炸掉方块（关掉就只炸人，不破坏地形）
BLAST_BREAK_MAX = 16000                   # 一次最多炸掉多少块（性能保护；半径 15 的球约 1.4 万块）
BLAST_BREAK_BATCH = 400                   # ★ 每帧炸多少块：剩下的分几帧炸完，避免一次炸上万块卡住
BLAST_BREAK_DROP = False                  # 炸掉的方块要不要掉落物（False = 直接消失）

# ---------- 爆炸引火（炸完之后周围烧起来） ----------
BLAST_FIRE_ENABLED = True   # ★ 爆炸过后在坑里 / 坑边点起火
BLAST_FIRE_MAX = 320        # 一次最多点几把火（性能保护）
BLAST_FIRE_RING_ONLY = True # True = 只烧坑的最外圈（就是“周围”那一圈）
BLAST_FIRE_RIM = 1.5        # 外圈的宽度（格）：坑边往里这个范围算“周围”
BLAST_FIRE_CHANCE = 0.75    # 每个位置着火的概率（1.0 = 必着）

BLAST_PLAYER_ENABLED = True               # 要不要处理范围内的其他玩家
BLAST_PLAYER_RADIUS = 0.0                 # 影响玩家的范围：0 = 自动（爆炸半径 + 边缘宽容）
BLAST_MOB_ENABLED = True                  # 炸死范围内的生物
BLAST_MOB_RADIUS = 0.0                    # 影响生物的范围：0 = 自动（爆炸半径 + 边缘宽容）
BLAST_SPREAD_MARGIN = 1.0                 # ★ 边缘宽容：站在坑边上那一圈的人也一起算（格）
BLAST_VIP_CLEAR = True                    # ★ 身上带药水的目标（含其他玩家）：不直接炸死
BLAST_VIP_CLEAR_VANILLA = True            # 顺便把原版药水效果也清掉
BLAST_VIP_HP_RATIO = 0.2                  # ★ 清完药水后只剩最大血量的百分之多少（0.2 = 20%）
BLAST_VIP_HP_MIN = 2.0                    # 最少也要留 2 点血（1 颗心），别直接归零
BLAST_VIP_DAMAGE = 10.0                   # 老配置：早期版本用的固定扣血，现在不用了（留着兼容）
BLAST_MOB_VIP_ENABLED = True              # ★ 身上带（原版）药水效果的生物：同样不直接炸死，只留残血
BLAST_MOB_VIP_HP_RATIO = 0.15             # 生物：清完药水后只剩最大血量的百分之多少
BLAST_MOB_VIP_HP_MIN = 1.0                # 生物最少留 1 点血

BLAST_SELF_HALF_HP = True                 # ★ 炸完扣自己一半血
BLAST_SELF_LETHAL = False                 # False = 自己不会被这一下炸死（至少留 1 点血）
BLAST_SELF_HURT_DELAY = 0.4               # 爆炸后多少秒扣自己那一半血
BLAST_FALLBACK_MAX_HEALTH = 20.0          # 取不到最大生命值时的兜底（原版玩家 20 点）

# ---------- 被喷溅型 V1 砸中的生物：它自己炸的那一下 ----------
#   （和玩家胸口爆炸是同一套效果：炸方块 + 轰生物 + TNT 动画 + 爆炸声）
MOB_BOOM_ENABLED = True                   # 开关
MOB_BOOM_RADIUS = 9.0                     # ★ 炸多大（半径，格）：9 = 直径 18 格
MOB_BOOM_SPREAD = 0.0                     # ★ 清除药水 / 波及范围：0 = 跟爆炸一样大（也是直径 18）
MOB_BOOM_BREAK = True                     # 生物的爆炸也炸方块（不想让它拆家就改 False）
MOB_BOOM_DAMAGE = 12.0                    # 没药水的玩家被炸到扣多少血（12 = 6 颗心）

# ---------- 电脑端快捷键 ----------
BLAST_KEY_ENABLED = True                  # ★ 电脑端：按住 G 键也能蓄力（和按图标一样）
BLAST_KEY = "71"                          # 键码：71 = G 键（70 = F 键，72 = H 键，74 = J 键）
BLAST_KEY_NAME = u"G"                      # 提示 / 文档里显示的名字

# ---------- 声音 / 特效 ----------
BLAST_SOUND = True                        # 爆炸声
BLAST_SOUND_NAME = "random.explode"       # 单层兜底用的原版音效名（最稳）
BLAST_SOUND_VOLUME = 1.6                  # 单层兜底音量
BLAST_SOUND_PITCH = 0.6                   # 单层兜底音调（越低越闷、越震撼）
# ★ 爆炸音效叠层：一层不够震撼，这里同时叠几层不同的声音
#   每一行 = (音效名, 延迟秒数, 音量, 音调)
BLAST_SOUND_LAYERS = [
    ("random.explode", 0.00, 2.0, 0.55),            # 主爆：低音轰
    ("ambient.weather.thunder", 0.00, 1.6, 0.85),   # 同时来一记炸雷
    ("mob.ghast.fireball", 0.05, 1.2, 0.70),        # 气浪破空的“刷”
    ("random.explode", 0.16, 1.8, 0.45),            # 0.16 秒后再补一记更闷的
]
CHARGE_SOUND = True                       # 开始蓄力时的滋滋声
CHARGE_SOUND_NAME = "random.fizz"
CHARGE_FX = True                          # 蓄力期间胸口冒黄光
CHARGE_FX_INTERVAL = 0.12                 # 黄光多久冒一次（秒）
BLAST_FX = True                           # 爆炸特效（黄色火光 + 火花）

# ---------- 畜力时只能潜行移动 ----------
CHARGE_SNEAK_ONLY = True    # ★ 畜力期间只能慢慢挪（关掉 = 畜力时不限制移动）
CHARGE_SLOW_MOVE = True     # 把移速压到潜行档
CHARGE_SPEED_RATE = 0.3     # ★ 移速变成原来的多少倍（0.3 = 原版潜行速度）
CHARGE_SPEED_BASE = 0.1     # 原版玩家走路移速（别改，用来兜底恢复）
CHARGE_NO_JUMP = True       # 畜力期间不能跳
CHARGE_FORCE_SNEAK = True   # 手机端：畜力时真的蹲下去（电脑端该接口无效，自动跳过）
CHARGE_SNEAK_RECHECK = 0.6  # 每隔多少秒再“按回”一次潜行

# ---------- 爆炸动画（原版 TNT 同款） ----------
BLAST_TNT_FX = True         # ★ 爆炸时放原版 TNT 那样的大爆炸动画
BLAST_TNT_PARTICLE = "minecraft:huge_explosion_emitter"   # 游戏自带的 TNT 大爆炸粒子
BLAST_TNT_FALLBACK = "soldierboy:tnt_blast"               # 上面那个播不出来时的备用（自己复刻的同款）
BLAST_TNT_SMOKE = "minecraft:explosion_particle"          # 中心那朵白烟
BLAST_TNT_SPREAD = True     # 直径大的时候周围再补几个，爆得更“开”

# ---------- 炸不掉的方块 ----------
BLAST_BLOCK_BLACKLIST = [
    "minecraft:air",
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:light_block",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:end_portal",
    "minecraft:end_portal_frame",
    "minecraft:end_gateway",
    "minecraft:portal",
    "minecraft:allow",
    "minecraft:deny",
    "minecraft:border_block",
    "minecraft:reinforced_deepslate",
    "minecraft:moving_block",
    "minecraft:water",
    "minecraft:flowing_water",
    "minecraft:lava",
    "minecraft:flowing_lava",
]
