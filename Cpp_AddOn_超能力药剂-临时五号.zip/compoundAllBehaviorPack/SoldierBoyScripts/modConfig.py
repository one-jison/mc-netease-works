# -*- coding: utf-8 -*-
# ============================================================
#  士兵男孩 - 公共配置（模组名 / 事件名 / 界面名 / 版本号）
# ============================================================
ModName = "CompoundAllMod"
ModVersion = "1.2.0"

ServerSystemName = "SoldierBoyServerSystem"
ClientSystemName = "SoldierBoyClientSystem"
ServerSystemClsPath = "SoldierBoyScripts.soldierBoyServerSystem.SoldierBoyServerSystem"
ClientSystemClsPath = "SoldierBoyScripts.soldierBoyClientSystem.SoldierBoyClientSystem"

# 客户端 -> 服务端
EventChargeStart = "SoldierBoyChargeStart"     # 屏幕上的【爆炸】按钮：手指按住
EventChargeCancel = "SoldierBoyChargeCancel"   # 松手 / 蓄力被打断

# 服务端 -> 客户端
EventState = "SoldierBoyState"   # 药效剩余时间 / 蓄力进度 / 冷却剩余
EventFx = "SoldierBoyFx"         # 胸口黄光 / 爆炸特效
EventSneak = "SoldierBoySneak"   # 畜力期间：让客户端真的蹲下去 / 站起来

# 屏幕上的【爆炸】按钮 + 左上角倒计时
UiInitFinishedEvent = "UiInitFinished"
HudUIName = "soldierBoyHud"
HudUIPyClsPath = "SoldierBoyScripts.soldierBoyHudScreen.SoldierBoyHudScreen"
HudUIScreenDef = "soldierboyhud.main"
