# -*- coding: utf-8 -*-
# ============================================================
#  士兵男孩 - 屏幕界面（HUD）
#    · 左上角：药效剩余时间 + 蓄力进度 / 冷却
#    · 屏幕上：一个【爆炸】形状的图标，长按蓄力
# ============================================================
import mod.client.extraClientApi as clientApi
from SoldierBoyScripts import modConfig

ScreenNode = clientApi.GetScreenNodeCls()

# ★ 左上角倒计时预留几行：几瓶药水一起喝的时候一行一行往下排
TIMER_ROWS = 5


class SoldierBoyHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mLblTimers = [self.mPanel + "/lblTimer%d" % i
                           for i in range(TIMER_ROWS)]
        self.mLblStatuses = [self.mPanel + "/lblStatus%d" % i
                             for i in range(TIMER_ROWS)]
        self.mBtnBlast = self.mPanel + "/btnBlast"
        self.mLblBtn = self.mBtnBlast + "/button_label"
        self.mBtnDown = False
        self.mTimerOn = None
        self.mTimerRow = -1
        self.mStatusOn = None
        self.mStatusRow = -1
        self.mBtnOn = None
        self.mTimerText = None
        self.mBtnText = None

    # UI 建好后引擎会调用这里
    def Create(self):
        try:
            self.AddTouchEventHandler(self.mBtnBlast, self.OnBlastTouch, {"isSwallow": True})
        except Exception:
            pass
        self.SetTimer(False, 0)
        self.SetStatus(u"", False)
        self.SetButtonVisible(False)

    # ==================== 手指按下 / 松开 ====================
    def OnBlastTouch(self, args):
        try:
            touchEvent = clientApi.GetMinecraftEnum().TouchEvent
            touchType = args.get("TouchEvent")
        except Exception:
            return
        cs = self._client()
        if cs is None:
            return
        if touchType == touchEvent.TouchDown:
            if not self.mBtnDown:
                self.mBtnDown = True
                cs.HudBlastDown()
        elif touchType == touchEvent.TouchUp or touchType == touchEvent.TouchCancel:
            if self.mBtnDown:
                self.mBtnDown = False
                cs.HudBlastUp()

    def _client(self):
        try:
            return clientApi.GetSystem(modConfig.ModName, modConfig.ClientSystemName)
        except Exception:
            return None

    # ==================== 左上角倒计时 ====================
    def SetTimer(self, visible, seconds, charging=False, row=0):
        # row = 排在左上角第几行
        from SoldierBoyScripts import soldierBoyConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            fmt = getattr(cfg, "MODE_HUD_TIMER_FMT", u"%s 剩余 %d 秒")
            try:
                text = fmt % (getattr(cfg, "MODE_NAME", u""), int(seconds))
            except Exception:
                text = u"%d" % int(seconds)
            if charging:
                color = getattr(cfg, "MODE_HUD_TIMER_CHARGE_COLOR", (1.0, 1.0, 0.55))
            elif int(seconds) <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 30.0)):
                color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
            else:
                color = getattr(cfg, "MODE_HUD_TIMER_COLOR", (1.0, 0.86, 0.28))
            self._setLabel(self.mLblTimers[row], text, color)
        if self.mTimerOn == show and self.mTimerRow == row:
            return
        self.mTimerOn = show
        self.mTimerRow = row
        self._hideTimerRows(self.mLblTimers, row if show else -1)

    def SetStatus(self, text, visible, color=None, row=0):
        # 第二行（蓄力进度 / 冷却），跟着倒计时那一行走
        show = bool(visible) and bool(text)
        row = self._fixRow(row)
        if show:
            self._setLabel(self.mLblStatuses[row], text, color)
        if self.mStatusOn == show and self.mStatusRow == row:
            return
        self.mStatusOn = show
        self.mStatusRow = row
        self._hideTimerRows(self.mLblStatuses, row if show else -1)

    def _fixRow(self, row):
        # 把行号限在 0 ~ TIMER_ROWS-1
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _hideTimerRows(self, paths, row):
        for i in range(TIMER_ROWS):
            self._setVisible(paths[i], i == row)

    # ==================== 【爆炸】图标 ====================
    def SetButtonVisible(self, visible):
        v = bool(visible)
        if self.mBtnOn == v:
            return
        self.mBtnOn = v
        self._setVisible(self.mBtnBlast, v)

    def SetButtonLabel(self, text):
        # 图标上显示冷却剩余秒数（没冷却就是空的）
        text = text or u""
        if self.mBtnText == text:
            return
        self.mBtnText = text
        self._setLabel(self.mLblBtn, text, (1.0, 0.85, 0.3))

    # ==================== 底层小工具 ====================
    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass
