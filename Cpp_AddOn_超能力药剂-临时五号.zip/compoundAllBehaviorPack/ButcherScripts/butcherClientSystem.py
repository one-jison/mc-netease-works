# -*- coding: utf-8 -*-
# ============================================================
#  超级触手 / 超级愈合 — 客户端
#   · 背上的五条黑色触手：从后背上方伸出去，所有玩家都看得见
#   · 屏幕上那个方形【攻击】按钮 + 左上角倒计时
#   · 电脑端按 F 键也能打
# ============================================================
import math
import time
import mod.client.extraClientApi as clientApi
from ButcherScripts import modConfig
from ButcherScripts import butcherConfig as cfg


ClientSystem = clientApi.GetClientSystemCls()

TENT_PARTICLE = "butcher:tentacle"
TENT_TIP_PARTICLE = "butcher:tentacle_tip"


class ButcherClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(ButcherClientSystem, self).__init__(namespace, systemName)
        self._hudNode = None
        self._hudTries = 0
        self._hudTryTime = 0.0
        self._tentIds = []          # 谁身上长着触手
        self._tentCount = 5
        self._tentSeg = 5
        self._tentRefresh = 0.12
        self._tentRange = 40.0
        self._tentT = 0.0
        self._swingAt = {}          # playerId -> 甩触手的时间
        self._swingLen = 0.35
        self._attackDown = False    # 屏幕按钮 / F 键还按着吗
        self._sentAt = 0.0
        self._butcherOn = False
        self._healOn = False
        self._butcherLeft = 0
        self._healLeft = 0
        self._cool = 0.0
        self._coolMax = 1.0
        self._keyDown = False
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "OnScriptTickClient", self, self.OnScriptTick)
        self.ListenForEvent(ns, sn, "OnLocalPlayerStopLoading", self, self.OnStopLoading)
        self.ListenForEvent(ns, sn, modConfig.UiInitFinishedEvent, self, self.OnUIInitFinished)
        # 电脑端键盘：按 F 键抽一下
        self.ListenForEvent(ns, sn, "OnKeyPressInGame", self, self.OnKeyPress)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventState, self, self.OnState)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventTentacle, self, self.OnTentacle)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventSwing, self, self.OnSwing)

    def OnStopLoading(self, args=None):
        self._hudNode = None
        self._hudTries = 0
        self._ensureHud()

    # ==================== 每帧 ====================
    def OnScriptTick(self, args=None):
        now = time.time()
        if self._hudNode is None and now - self._hudTryTime >= 3.0:
            self._hudTryTime = now
            self._ensureHud()
        if self._hudNode is not None and now - self._hudTryTime >= 1.0:
            self._hudTryTime = now
            self._applyHud()
        # 一直按着就自动接着打（服务端那边有冷却兜着）
        if self._attackDown and now - self._sentAt >= max(0.2, self._coolMax) + 0.05:
            self._sendAttack()
        self._drawTentacles(now)

    # ==================== 背上的触手 ====================
    def OnTentacle(self, args):
        if not args:
            return
        try:
            self._tentIds = [str(pid) for pid in (args.get("list") or [])]
            self._tentCount = int(args.get("count", 5))
            self._tentSeg = int(args.get("seg", 5))
            self._tentRefresh = max(0.03, float(args.get("refresh", 0.12)))
            self._tentRange = float(args.get("range", 40.0))
        except Exception:
            return

    def OnSwing(self, args):
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        try:
            self._swingLen = max(0.1, float(args.get("time", 0.35)))
        except Exception:
            self._swingLen = 0.35
        self._swingAt[playerId] = time.time()

    def _drawTentacles(self, now):
        if not self._tentIds:
            return
        if now - self._tentT < self._tentRefresh:
            return
        self._tentT = now
        try:
            factory = clientApi.GetEngineCompFactory()
            comp = factory.CreateParticleSystem(None)
        except Exception:
            return
        if comp is None:
            return
        try:
            myPos = factory.CreatePos(clientApi.GetLocalPlayerId()).GetPos()
        except Exception:
            myPos = None
        rng = float(self._tentRange)
        for playerId in list(self._tentIds):
            try:
                pos = factory.CreatePos(playerId).GetPos()
            except Exception:
                continue
            if not pos:
                continue
            if myPos is not None:
                dx = float(pos[0]) - float(myPos[0])
                dy = float(pos[1]) - float(myPos[1])
                dz = float(pos[2]) - float(myPos[2])
                if dx * dx + dy * dy + dz * dz > rng * rng:
                    continue
            yaw = 0.0
            try:
                rot = factory.CreateRot(playerId).GetRot()
                yaw = math.radians(float(rot[1]))
            except Exception:
                yaw = 0.0
            self._oneTentacleSet(comp, pos, yaw, now, playerId)

    def _oneTentacleSet(self, comp, pos, yaw, now, playerId):
        # 五条黑色触手：从后背上方长出来，往后、往两边、往上摊开
        sinY = math.sin(yaw)
        cosY = math.cos(yaw)
        # 玩家朝向 = (-sinY, 0, cosY)，所以"后背"就是 (sinY, 0, -cosY)
        backX = sinY
        backZ = -cosY
        # 左右方向（只用来左右对称地摊开，不影响外观）
        rightX = cosY
        rightZ = sinY
        px = float(pos[0])
        py = float(pos[1])
        pz = float(pos[2])
        count = max(1, min(9, int(self._tentCount)))
        seg = max(2, min(14, int(self._tentSeg)))
        body = str(getattr(cfg, "BUTCHER_TENTACLE_PARTICLE", TENT_PARTICLE) or TENT_PARTICLE)
        tipP = str(getattr(cfg, "BUTCHER_TENTACLE_TIP_PARTICLE", TENT_TIP_PARTICLE)
                   or TENT_TIP_PARTICLE)
        tipFrom = float(getattr(cfg, "BUTCHER_TENTACLE_TIP_FROM", 0.58))
        backOff = float(getattr(cfg, "BUTCHER_TENTACLE_BACK", 0.32))
        baseH = float(getattr(cfg, "BUTCHER_TENTACLE_HEIGHT", 1.16))
        swing = 0.0
        start = self._swingAt.get(playerId)
        if start is not None:
            swing = 1.0 - (now - float(start)) / max(0.1, self._swingLen)
            swing = max(0.0, min(1.0, swing))
            if swing <= 0.0:
                self._swingAt.pop(playerId, None)
        half = max(1.0, (count - 1) * 0.5)
        for i in range(count):
            side = (float(i) - half) / half          # -1 .. 1
            # 根部长在后背上方，左右稍微分开一点
            baseX = px + backX * (backOff * 0.65) + rightX * (side * 0.18)
            baseZ = pz + backZ * (backOff * 0.65) + rightZ * (side * 0.18)
            baseY = py + baseH
            # 每根触手摆动相位不一样，看起来才像活的
            phase = float(i) * 0.9
            for j in range(seg):
                t = float(j + 1) / float(seg)
                if swing > 0.01:
                    # 甩起来：往前、往两边摊开，像五条鞭子同时抽出去
                    reach = (0.5 + 2.3 * t) * (0.6 + 0.6 * swing)
                    out = 0.7 + 1.6 * t
                    tx = baseX - backX * reach + rightX * (side * out * (0.5 + 0.9 * swing))
                    tz = baseZ - backZ * reach + rightZ * (side * out * (0.5 + 0.9 * swing))
                    ty = baseY + math.sin(t * 2.6) * 0.28 * (1.0 - swing * 0.5)
                else:
                    # 平时：从后背往后上方张开一条弧线，指尖会轻轻摆动
                    wave = math.sin(now * 2.0 + phase + t * 2.2)
                    out = 0.20 + 0.72 * t
                    back = backOff + 1.05 * t
                    tx = baseX + backX * back + rightX * (side * out + wave * 0.10 * t)
                    tz = baseZ + backZ * back + rightZ * (side * out + wave * 0.10 * t)
                    ty = baseY + 0.42 * t + 0.62 * t * t + wave * 0.05
                # 根部用粗的粒子，越接近指尖越细，看起来才像整根触手
                name = body if t <= tipFrom else tipP
                self._spawn(comp, name, (tx, ty, tz))

    def _spawn(self, comp, name, pos):
        try:
            comp.Create(str(name),
                        (float(pos[0]), float(pos[1]), float(pos[2])),
                        (0.0, 0.0, 0.0))
        except Exception:
            pass

    # ==================== 攻击 ====================
    def HudAttackDown(self):
        if not self._butcherOn:
            return
        self._attackDown = True
        self._sendAttack()

    def HudAttackUp(self):
        self._attackDown = False

    def _sendAttack(self):
        self._sentAt = time.time()
        self._send(modConfig.EventAttack)

    def OnKeyPress(self, args=None):
        if not args:
            return
        if not getattr(cfg, "BUTCHER_ATTACK_KEY_ENABLED", True):
            return
        try:
            if str(args.get("key", "")) != str(getattr(cfg, "BUTCHER_ATTACK_KEY", "70")):
                return
        except Exception:
            return
        try:
            isDown = str(args.get("isDown", "0")) == "1"
        except Exception:
            isDown = False
        if isDown:
            if self._keyDown:
                return
            self._keyDown = True
            self.HudAttackDown()
        else:
            if not self._keyDown:
                return
            self._keyDown = False
            self.HudAttackUp()

    def _send(self, eventName, extra=None):
        data = {"playerId": clientApi.GetLocalPlayerId()}
        if extra:
            data.update(extra)
        try:
            self.NotifyToServer(eventName, data)
        except Exception:
            pass

    # ==================== 屏幕（HUD） ====================
    def OnUIInitFinished(self, args=None):
        self._ensureHud()

    def _ensureHud(self):
        if self._hudNode is not None or self._hudTries >= 8:
            return
        self._hudTries += 1
        try:
            node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            if node is None:
                clientApi.RegisterUI(modConfig.ModName, modConfig.HudUIName,
                                     modConfig.HudUIPyClsPath, modConfig.HudUIScreenDef)
                node = clientApi.CreateUI(modConfig.ModName,
                                          modConfig.HudUIName, {"isHud": 1})
                if node is None:
                    node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            self._hudNode = node
            self._applyHud()
        except Exception:
            self._hudNode = None

    def OnState(self, args):
        if not args:
            return
        try:
            if args.get("playerId") != clientApi.GetLocalPlayerId():
                return
            self._butcherOn = int(args.get("butcher", 0)) == 1
            self._butcherLeft = int(args.get("butcherLeft", 0))
            self._healOn = int(args.get("heal", 0)) == 1
            self._healLeft = int(args.get("healLeft", 0))
            self._cool = float(args.get("cool", 0.0))
            self._coolMax = float(args.get("coolMax", 1.0))
        except Exception:
            return
        if not self._butcherOn:
            self._attackDown = False
        self._applyHud()

    def _applyHud(self):
        node = self._hudNode
        if node is None:
            return
        base = self.HudTimerRow()
        butcherShow = bool(self._butcherOn) and self._butcherLeft > 0
        healShow = bool(self._healOn) and self._healLeft > 0
        # 触手排在前面，超级愈合跟着往下一行
        butcherRow = base
        healRow = base + (1 if butcherShow else 0)
        try:
            node.SetButcherTimer(butcherShow, self._butcherLeft,
                                 butcherRow if butcherShow else 0)
        except Exception:
            pass
        try:
            node.SetHealTimer(healShow, self._healLeft,
                              healRow if healShow else 1)
        except Exception:
            pass
        try:
            node.SetButton(bool(self._butcherOn), self._cool)
        except Exception:
            pass

    # ==================== 左上角倒计时排版 ====================
    #  ★ 几瓶药水一起喝的时候，左上角的倒计时一行一行往下排，不会叠在一起
    _TIMER_ORDER = ("EyeLaserClientSystem", "SuperSpeedClientSystem",
                    "SoldierBoyClientSystem", "ButcherClientSystem")

    def HudTimerRows(self):
        # 我这套系统现在占了左上角几行
        n = 0
        if bool(self._butcherOn) and int(self._butcherLeft) > 0:
            n += 1
        if bool(self._healOn) and int(self._healLeft) > 0:
            n += 1
        return n


    def HudTimerRow(self):
        # 我排第几行：排在我前面、现在正显示倒计时的系统一共占了几行
        me = getattr(modConfig, "ClientSystemName", u"")
        row = 0
        for name in self._TIMER_ORDER:
            if name == me:
                break
            row += self._peerTimerRows(name)
        return row

    def _peerTimerRows(self, name):
        # 问一下那个系统：你现在占了几行
        obj = None
        try:
            obj = clientApi.GetSystem(modConfig.ModName, name)
        except Exception:
            obj = None
        if obj is None:
            return 0
        try:
            return int(obj.HudTimerRows())
        except Exception:
            return 0
