# -*- coding: utf-8 -*-
# ============================================================
#  屠夫 — 屏幕界面（HUD）
#    · 左上角：屠夫 / 超级愈合的剩余时间
#    · 屏幕右下角：一个方形【攻击】按钮，按下去抽打身边的目标
# ============================================================
import mod.client.extraClientApi as clientApi
from ButcherScripts import modConfig

ScreenNode = clientApi.GetScreenNodeCls()

# ★ 左上角倒计时预留几行：几瓶药水一起喝的时候一行一行往下排
TIMER_ROWS = 5


class ButcherHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mLblButchers = [self.mPanel + "/lblButcher%d" % i
                             for i in range(TIMER_ROWS)]
        self.mLblHeals = [self.mPanel + "/lblHeal%d" % i
                          for i in range(TIMER_ROWS)]
        self.mBtnAttack = self.mPanel + "/btnAttack"
        self.mLblBtn = self.mBtnAttack + "/button_label"
        self.mDown = False
        self.mBtnOn = None
        self.mBtnText = None
        self.mButcherOn = None
        self.mButcherRow = -1
        self.mHealOn = None
        self.mHealRow = -2

    def Create(self):
        try:
            self.AddTouchEventHandler(self.mBtnAttack, self.OnAttackTouch,
                                      {"isSwallow": True})
        except Exception:
            pass
        self.SetButcherTimer(False, 0)
        self.SetHealTimer(False, 0)
        self.SetButton(False, 0.0)

    # ==================== 手指按下 / 松开 ====================
    def OnAttackTouch(self, args):
        try:
            touchEvent = clientApi.GetMinecraftEnum().TouchEvent
            touchType = args.get("TouchEvent")
        except Exception:
            return
        cs = self._client()
        if cs is None:
            return
        if touchType == touchEvent.TouchDown:
            if not self.mDown:
                self.mDown = True
                cs.HudAttackDown()
        elif touchType == touchEvent.TouchUp or touchType == touchEvent.TouchCancel:
            if self.mDown:
                self.mDown = False
                cs.HudAttackUp()

    def _client(self):
        try:
            return clientApi.GetSystem(modConfig.ModName, modConfig.ClientSystemName)
        except Exception:
            return None

    # ==================== 左上角倒计时 ====================
    def SetButcherTimer(self, visible, seconds, row=0):
        from ButcherScripts import butcherConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            text = self._text(cfg.BUTCHER_NAME, seconds, cfg)
            self._setLabel(self.mLblButchers[row], text, self._color(seconds, cfg))
        if self.mButcherOn == show and self.mButcherRow == row:
            return
        self.mButcherOn = show
        self.mButcherRow = row
        self._hideTimerRows(self.mLblButchers, row if show else -1)

    def SetHealTimer(self, visible, seconds, row=1):
        from ButcherScripts import butcherConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            text = self._text(cfg.HEAL_NAME, seconds, cfg)
            self._setLabel(self.mLblHeals[row], text, self._color(seconds, cfg))
        if self.mHealOn == show and self.mHealRow == row:
            return
        self.mHealOn = show
        self.mHealRow = row
        self._hideTimerRows(self.mLblHeals, row if show else -1)

    # ==================== 倒计时的文字 / 颜色 ====================
    def _text(self, name, seconds, cfg):
        fmt = getattr(cfg, "MODE_HUD_TIMER_FMT", u"%s 剩余 %d 秒")
        try:
            return fmt % (name, int(seconds))
        except Exception:
            return u"%s 剩余 %d 秒" % (name, int(seconds))

    def _color(self, seconds, cfg):
        try:
            if float(seconds) <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 5.0)):
                return getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
        except Exception:
            pass
        return getattr(cfg, "MODE_HUD_TIMER_COLOR", (1.0, 0.45, 0.55))

    def _fixRow(self, row):
        # 把行号限在 0 ~ TIMER_ROWS-1
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _hideTimerRows(self, paths, row):
        for i in range(TIMER_ROWS):
            self._setVisible(paths[i], i == row)

    # ==================== 方形【攻击】按钮 ====================
    def SetButton(self, visible, cool=0.0):
        v = bool(visible)
        if self.mBtnOn != v:
            self.mBtnOn = v
            self._setVisible(self.mBtnAttack, v)
        text = u""
        if v and float(cool) > 0.05:
            text = u"%.1f" % float(cool)
        if self.mBtnText != text:
            self.mBtnText = text
            self._setLabel(self.mLblBtn, text, (1.0, 0.95, 0.85))

    # ==================== 底层小工具 ====================
    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass
