# -*- coding: utf-8 -*-
# ============================================================
#  超级触手 / 超级愈合 / 透明人 / 深海 — 服务端
#   · 超级触手（30 秒）：背上长出五条黑色触手，屏幕上多一个方形【攻击】按钮，
#                    按下去抽打身边的生物和玩家
#   · 超级愈合（30 秒）：挨打之后血会飞快回满
#   · 透明人（原版隐身药水）：生命上限 +10 颗心
#   · 深海（原版水下呼吸药水）：水里游速 x5
# ============================================================
import math
import time
import mod.server.extraServerApi as serverApi
from CompoundAllScripts import butcherModConfig as modConfig
from CompoundAllScripts import butcherConfig as cfg


ServerSystem = serverApi.GetServerSystemCls()


class ButcherServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(ButcherServerSystem, self).__init__(namespace, systemName)
        self._butcherUntil = {}     # playerId -> 超级触手药效到点的时间
        self._healUntil = {}        # playerId -> 超级愈合到点的时间
        self._coolUntil = {}        # playerId -> 攻击冷却到点的时间
        self._warned = {}           # playerId -> 已经提醒过的剩余秒数
        self._stateSig = {}         # playerId -> 上次同步给屏幕的状态
        self._tentList = None       # 上次广播出去的"谁身上有触手"
        self._tentT = 0.0           # 上次广播触手名单的时间
        self._potionAt = {}         # playerId -> 什么时候把进游戏送的药水放进背包
        self._welcomed = set()      # 已经欢迎过的玩家
        self._invExtra = {}         # playerId -> 透明人已经加过多少点血上限
        self._invWas = {}           # playerId -> 加之前生命上限是多少
        self._deepBase = {}         # playerId -> 原本的水下移动速度
        self._invT = 0.0
        self._deepT = 0.0
        self._healT = 0.0
        self._lastStateT = 0.0
        self._noKill = set(["minecraft:armor_stand", "minecraft:item",
                            "minecraft:xp_orb"])
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        def _L(_ns, _sn, _name, _obj, _handler):
            # 单个事件名在某些平台上可能不存在：这一条注册失败就跳过。
            # 不能让整个系统因为一个不认识的事件名而挂掉（手机端最容易踩）。
            try:
                self.ListenForEvent(_ns, _sn, _name, _obj, _handler)
            except Exception:
                pass
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        _L(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        _L(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        # 喝药水：两个事件都听着，哪个先来都认
        _L(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        _L(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)
        _L(ns, sn, "ServerItemTryUseEvent", self, self.OnTryUse)
        _L(ns, sn, "ItemUseAfterServerEvent", self, self.OnAfterUse)
        # 死了就把药效一起收掉（不然重生还挂着）
        for evt in ("PlayerDieServerEvent", "PlayerDieEvent"):
            try:
                _L(ns, sn, evt, self, self.OnPlayerDie)
            except Exception:
                pass
        # 屏幕上那个方形【攻击】按钮
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventAttack, self, self.OnAttack)

    # ==================== 小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _dimOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    def _isPlayerId(self, entityId):
        try:
            return entityId in (serverApi.GetPlayerList() or [])
        except Exception:
            return False

    def _engineTypeOf(self, entityId):
        try:
            return str(serverApi.GetEngineCompFactory().CreateEngineType(
                entityId).GetEngineTypeStr())
        except Exception:
            return ""

    def _isLiving(self, entityId):
        # 有血量的才算生物；盔甲架 / 掉落物 / 经验球一律放过
        try:
            hp = serverApi.GetEngineCompFactory().CreateAttr(entityId).GetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH)
        except Exception:
            return False
        if hp is None:
            return False
        return self._engineTypeOf(entityId) not in self._noKill

    def _attrComp(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateAttr(entityId)
        except Exception:
            return None

    def _attrType(self):
        try:
            return serverApi.GetMinecraftEnum().AttrType
        except Exception:
            return None

    def _attrNum(self, attr, attrType, fallback, getter="GetAttrMaxValue"):
        try:
            value = float(getattr(attr, getter)(attrType))
        except Exception:
            return float(fallback)
        if value <= 0.0:
            return float(fallback)
        return float(value)

    def _setAttrMax(self, attr, attrType, value):
        for target in (float(value), int(value)):
            try:
                if attr.SetAttrMaxValue(attrType, target) is False:
                    continue
                return True
            except Exception:
                continue
        return False

    def _setAttrValue(self, attr, attrType, value):
        for args in ((attrType, float(value)), (attrType, float(value), 1)):
            try:
                attr.SetAttrValue(*args)
                return True
            except Exception:
                continue
        return False

    def _healthOf(self, entityId):
        # 返回 (当前血量, 生命上限)；读不到就返回 None
        attr = self._attrComp(entityId)
        AT = self._attrType()
        if attr is None or AT is None:
            return None
        base = float(getattr(cfg, "BASE_MAX_HEALTH", 20.0))
        cur = self._attrNum(attr, AT.HEALTH, base, "GetAttrValue")
        top = self._attrNum(attr, AT.HEALTH, base)
        return (cur, top)

    def _hurtEntity(self, entityId, damage, attackerId=None):
        try:
            serverApi.GetEngineCompFactory().CreateHurt(entityId).Hurt(
                float(damage),
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                attackerId, None, True)
            return True
        except Exception:
            return False

    def _knock(self, entityId, center, power, up):
        # 把被打到的东西推出去
        if power <= 0.0:
            return
        pos = self._posOf(entityId)
        if pos is None:
            return
        dx = float(pos[0]) - float(center[0])
        dz = float(pos[2]) - float(center[2])
        length = math.sqrt(dx * dx + dz * dz)
        if length < 0.01:
            dx, dz, length = 0.0, 1.0, 1.0
        vec = (dx / length * float(power), float(up), dz / length * float(power))
        try:
            comp = serverApi.GetEngineCompFactory().CreateActorMotion(entityId)
        except Exception:
            return
        order = ("SetPlayerMotion", "SetMotion") if self._isPlayerId(entityId) \
            else ("SetMotion", "SetPlayerMotion")
        for name in order:
            func = getattr(comp, name, None)
            if func is None:
                continue
            try:
                func(vec)
                return
            except Exception:
                continue

    def _playSound(self, entityId, name, volume=1.0, pitch=1.0, radius=24.0):
        if not name:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateCommand(
                serverApi.GetLevelId())
            comp.SetCommand("/playsound %s @a[r=%s] ~ ~ ~ %s %s" % (
                str(name), float(radius), float(volume), float(pitch)), entityId)
        except Exception:
            pass

    def _toAllClients(self, eventName, data):
        try:
            self.BroadcastToAllClient(eventName, data)
            return
        except Exception:
            pass
        for pid in (serverApi.GetPlayerList() or []):
            try:
                self.NotifyToClient(pid, eventName, data)
            except Exception:
                pass

    # ==================== 超级触手：药效时间 ====================
    def _butcherOn(self):
        return bool(getattr(cfg, "BUTCHER_ENABLED", True))

    def _butcherLeft(self, playerId):
        if not self._butcherOn():
            return 0.0
        return max(0.0, float(self._butcherUntil.get(playerId, 0.0)) - time.time())

    def _hasButcher(self, playerId):
        return self._butcherOn() and self._butcherLeft(playerId) > 0.0

    def _giveButcher(self, playerId):
        if not self._butcherOn():
            return
        dur = float(getattr(cfg, "BUTCHER_DURATION", 30.0))
        self._butcherUntil[playerId] = time.time() + dur
        self._warned.pop(playerId, None)
        self._syncState(playerId, force=True)
        self._broadcastTentacles(force=True)
        if getattr(cfg, "BUTCHER_TIP", True):
            self._tip(playerId, u"%s 生效：背上长出 %d 条触手，屏幕右下角多出"
                                u"一个【攻击】按钮，按下去抽打身边的生物和玩家，维持 %d 秒"
                      % (cfg.BUTCHER_NAME, int(getattr(cfg, "BUTCHER_TENTACLES", 5)),
                         int(dur)), "LIGHT_PURPLE")

    def _loseButcher(self, playerId, quiet=False):
        had = self._butcherUntil.pop(playerId, None) is not None
        self._coolUntil.pop(playerId, None)
        self._syncState(playerId, force=True)
        self._broadcastTentacles(force=True)
        if had and not quiet and getattr(cfg, "BUTCHER_TIP", True):
            self._tip(playerId, u"%s 已失效，触手收起来了" % cfg.BUTCHER_NAME, "GOLD")

    # ==================== 超级愈合：药效时间 ====================
    def _healOn(self):
        return bool(getattr(cfg, "HEAL_ENABLED", True))

    def _healLeft(self, playerId):
        if not self._healOn():
            return 0.0
        return max(0.0, float(self._healUntil.get(playerId, 0.0)) - time.time())

    def _hasHeal(self, playerId):
        return self._healOn() and self._healLeft(playerId) > 0.0

    def _giveHeal(self, playerId):
        if not self._healOn():
            return
        dur = float(getattr(cfg, "HEAL_DURATION", 30.0))
        self._healUntil[playerId] = time.time() + dur
        self._syncState(playerId, force=True)
        if getattr(cfg, "HEAL_TIP", True):
            self._tip(playerId, u"%s 生效：受伤后血会飞快回满，维持 %d 秒"
                      % (cfg.HEAL_NAME, int(dur)), "LIGHT_PURPLE")

    def _loseHeal(self, playerId, quiet=False):
        had = self._healUntil.pop(playerId, None) is not None
        self._syncState(playerId, force=True)
        if had and not quiet and getattr(cfg, "HEAL_TIP", True):
            self._tip(playerId, u"%s 已失效" % cfg.HEAL_NAME, "GOLD")

    # ==================== 给 V1 爆炸用：认能力 / 收能力 ====================
    # 注意：名字必须和别的系统一致（HasPower / DropPower），
    # 士兵男孩的爆炸靠这几个方法把超能力一起清掉
    def HasPower(self, playerId):
        # 身上是不是正开着 超级触手 / 超级愈合
        if not playerId:
            return False
        return self._hasButcher(playerId) or self._hasHeal(playerId)

    def DropPower(self, playerId, quiet=True):
        # 被 V1 爆炸波及：超级触手 / 超级愈合一起收掉
        if not playerId:
            return
        self._loseButcher(playerId, quiet=bool(quiet))
        self._loseHeal(playerId, quiet=bool(quiet))

    def HasMobPower(self, entityId):
        # 这两瓶药水只给玩家用，生物身上没有
        return False

    def DropMobPower(self, entityId):
        # 生物身上没有这两瓶的效果，什么都不用做
        return

    def _healFast(self, playerId):
        # 超级愈合：每次回 HEAL_PER_TICK 点血，最多回到满
        info = self._healthOf(playerId)
        if info is None:
            return
        cur, top = info
        if cur >= top:
            return
        attr = self._attrComp(playerId)
        AT = self._attrType()
        if attr is None or AT is None:
            return
        want = min(top, cur + float(getattr(cfg, "HEAL_PER_TICK", 2.0)))
        self._setAttrValue(attr, AT.HEALTH, want)

    # ==================== 屏幕状态（左上角倒计时 / 按钮） ====================
    def _syncState(self, playerId, force=False):
        now = time.time()
        bOn = self._hasButcher(playerId)
        hOn = self._hasHeal(playerId)
        cool = max(0.0, float(self._coolUntil.get(playerId, 0.0)) - now)
        sig = (1 if bOn else 0, int(math.ceil(self._butcherLeft(playerId))),
               1 if hOn else 0, int(math.ceil(self._healLeft(playerId))),
               round(cool, 1))
        if not force and self._stateSig.get(playerId) == sig:
            return
        try:
            self.NotifyToClient(playerId, modConfig.EventState, {
                "playerId": playerId,
                "butcher": sig[0], "butcherLeft": sig[1],
                "heal": sig[2], "healLeft": sig[3],
                "cool": sig[4],
                "coolMax": float(getattr(cfg, "BUTCHER_ATTACK_COOLDOWN", 1.0))})
        except Exception:
            return
        self._stateSig[playerId] = sig

    # ==================== 触手（画在所有客户端上） ====================
    def _broadcastTentacles(self, players=None, force=False):
        now = time.time()
        if not force and now - self._tentT < 5.0:
            return
        self._tentT = now
        if players is None:
            players = list(serverApi.GetPlayerList() or [])
        ids = sorted([pid for pid in players if self._hasButcher(pid)])
        if not force and ids == (self._tentList or []):
            return
        self._tentList = list(ids)
        self._toAllClients(modConfig.EventTentacle, {
            "list": ids,
            "count": int(getattr(cfg, "BUTCHER_TENTACLES", 5)),
            "seg": int(getattr(cfg, "BUTCHER_TENTACLE_SEGMENTS", 5)),
            "refresh": float(getattr(cfg, "BUTCHER_TENTACLE_REFRESH", 0.12)),
            "range": float(getattr(cfg, "BUTCHER_TENTACLE_RANGE", 40.0))})

    # ==================== 攻击 ====================
    def OnAttack(self, args):
        playerId = args.get("playerId") if args else None
        if not playerId:
            return
        self._attack(playerId)

    def _nearby(self, center, dimensionId, span):
        try:
            ids = serverApi.GetEngineCompFactory().CreateGame(
                serverApi.GetLevelId()).GetEntitiesInSquareArea(
                    None,
                    (int(center[0] - span), int(center[1] - span),
                     int(center[2] - span)),
                    (int(center[0] + span), int(center[1] + span),
                     int(center[2] + span)),
                    dimensionId)
        except Exception:
            return []
        return list(ids or [])

    def _attack(self, playerId):
        if not getattr(cfg, "BUTCHER_ATTACK_ENABLED", True):
            return False
        if not self._hasButcher(playerId):
            return False
        now = time.time()
        if float(self._coolUntil.get(playerId, 0.0)) > now:
            return False
        self._coolUntil[playerId] = now + float(
            getattr(cfg, "BUTCHER_ATTACK_COOLDOWN", 1.0))
        pos = self._posOf(playerId)
        if pos is None:
            return False
        dim = self._dimOf(playerId)
        radius = float(getattr(cfg, "BUTCHER_ATTACK_RADIUS", 5.0))
        center = (float(pos[0]), float(pos[1]) + 1.0, float(pos[2]))
        # 甩触手的动作：所有玩家都看得见
        self._toAllClients(modConfig.EventSwing, {
            "playerId": playerId,
            "x": center[0], "y": center[1], "z": center[2],
            "dim": dim,
            "time": float(getattr(cfg, "BUTCHER_ATTACK_SWING_TIME", 0.35))})
        if getattr(cfg, "BUTCHER_ATTACK_SOUND", True):
            self._playSound(playerId,
                            getattr(cfg, "BUTCHER_ATTACK_SOUND_NAME",
                                    "mob.enderdragon.flap"), 1.0, 1.2)
        damage = float(getattr(cfg, "BUTCHER_ATTACK_DAMAGE", 14.0))
        power = float(getattr(cfg, "BUTCHER_ATTACK_KNOCK", 1.15))
        up = float(getattr(cfg, "BUTCHER_ATTACK_UP", 0.35))
        limit = int(getattr(cfg, "BUTCHER_ATTACK_MOB_MAX", 8))
        hitMob = 0
        hitPlayer = 0
        for entityId in self._nearby(center, dim, int(radius) + 1):
            if not entityId or entityId == playerId:
                continue
            epos = self._posOf(entityId)
            if epos is None:
                continue
            dx = float(epos[0]) - center[0]
            dy = float(epos[1]) - center[1]
            dz = float(epos[2]) - center[2]
            if math.sqrt(dx * dx + dy * dy + dz * dz) > radius:
                continue
            if self._isPlayerId(entityId):
                if not getattr(cfg, "BUTCHER_ATTACK_PLAYERS", True):
                    continue
                if self._hurtEntity(entityId, damage, playerId):
                    hitPlayer += 1
                    self._knock(entityId, center, power, up)
                continue
            if hitMob >= limit:
                continue
            if not self._isLiving(entityId):
                continue
            if self._hurtEntity(entityId, damage, playerId):
                hitMob += 1
                self._knock(entityId, center, power, up)
        self._syncState(playerId, force=True)
        if getattr(cfg, "BUTCHER_ATTACK_TIP", True) and (hitMob or hitPlayer):
            self._tip(playerId, u"触手抽过去：打到 %d 只生物 / %d 名玩家"
                      % (hitMob, hitPlayer), "RED")
        return True

    # ==================== 喝药水 ====================
    def _itemNameOf(self, itemDict):
        if not isinstance(itemDict, dict):
            return ""
        name = itemDict.get("itemName") or itemDict.get("newItemName") or ""
        return str(name).lower()

    # ==================== 用药识别（手机端 / 电脑端都认） ====================
    def _actorIdOf(self, args):
        # 不同事件给的键不一样：playerId / entityId / id 都认一遍
        if not isinstance(args, dict):
            return None
        for k in ("playerId", "entityId", "id"):
            v = args.get(k)
            if v:
                return v
        return None

    def _itemIdOf(self, itemDict):
        # 有的版本给 newItemName，有的给 itemName，两个都认
        if not isinstance(itemDict, dict):
            return u""
        for k in ("newItemName", "itemName"):
            v = itemDict.get(k)
            if v:
                return str(v).lower()
        return u""

    def _debugIntake(self, playerId, itemDict, src):
        # 这里只是打日志，绝对不能让它的异常把喝药流程带崩
        try:
            self._debugIntakeInner(playerId, itemDict, src)
        except Exception:
            pass

    def _debugIntakeInner(self, playerId, itemDict, src):
        # 排查用：把用到的物品名打到开发者日志（cfg.INTAKE_DEBUG 控制）
        if not getattr(cfg, "INTAKE_DEBUG", False):
            return
        name = self._itemIdOf(itemDict)
        if name:
            if name.split(":")[0] in ("eyelaser", "superspeed", "soldierboy",
                                      "butcher"):
                print(u"[药剂自检] 玩家=%s 事件=%s 物品=%s" % (playerId, src, name))
        elif src in ("try", "eat") and isinstance(itemDict, dict) and itemDict:
            keys = sorted([str(k) for k in itemDict.keys()])
            print(u"[药剂自检] 玩家=%s 事件=%s 物品名没取到，可用键=%s"
                  % (playerId, src, u",".join(keys)))

    # ==================== "真的喝了"的判定 ====================
    # 老写法是"手一点到药水就立刻生效"，玩家还没喝就变身了。
    # 现在改成：按下使用键只记一笔，确认喝下去（吃完 / 药水真的少了一瓶）才给效果。
    _DRINK_HOLD_MIN = 0.45      # 使用键至少按住这么久才算喝下去（点一下不算）

    def _drinkTestMap(self):
        d = getattr(self, "_drinkTest", None)
        if d is None:
            d = {}
            self._drinkTest = d
        return d

    def _drinkPress(self, playerId, itemName, grant):
        # 玩家刚按下使用键：先记一笔，不马上给效果
        slot, cnt = -1, 1
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
            slot = int(comp.GetSelectSlotId())
            item = comp.GetPlayerItem(ItemPosType.INVENTORY, slot, True) or {}
            cnt = int(item.get("count", 1) or 1)
        except Exception:
            pass
        self._drinkTestMap()[playerId] = {"t": time.time(), "slot": slot,
                                          "count": cnt, "name": itemName,
                                          "grant": grant}

    def _drinkConfirm(self, playerId, grant):
        # 确认真的喝下去了：给效果（同一次喝药只给一遍，免得倒计时被刷两回）
        self._drinkTestMap().pop(playerId, None)
        done = getattr(self, "_drinkDoneAt", None)
        if done is None:
            done = {}
            self._drinkDoneAt = done
        now = time.time()
        if now - float(done.get(playerId, 0.0)) < 0.5:
            return
        done[playerId] = now
        if callable(grant):
            grant(playerId)

    def _drinkRoute(self, playerId, name, src, grant):
        # 按下（try / use）只记账；吃完（eat）或药水真的被消耗掉才算喝下去
        if src == u"try":
            self._drinkPress(playerId, name, grant)
            return
        if src == u"eat":
            self._drinkConfirm(playerId, grant)
            return
        rec = self._drinkTestMap().get(playerId)
        if not rec:
            if src == u"use":
                self._drinkPress(playerId, name, grant)   # 没见到按下事件，先记一笔
            else:
                self._drinkConfirm(playerId, grant)       # 没见到按下事件，只能信完成事件
            return
        if float(rec.get("t", 0.0)) + self._DRINK_HOLD_MIN <= time.time():
            self._drinkConfirm(playerId, grant)

    def _drinkWatchTick(self, now):
        # 兜底：药水真的从背包里少了一瓶 -> 就当喝下去了
        m = getattr(self, "_drinkTest", None)
        if not m:
            return
        for playerId in list(m.keys()):
            rec = m.get(playerId)
            if not rec:
                continue
            age = now - float(rec.get("t", 0.0))
            if age > 5.0:
                m.pop(playerId, None)
                continue
            if age < self._DRINK_HOLD_MIN:
                continue
            cnt, cur = -1, u""
            try:
                comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
                ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
                item = comp.GetPlayerItem(ItemPosType.INVENTORY,
                                          int(rec.get("slot", -1)), True) or {}
                cnt = int(item.get("count", 0) or 0)
                cur = self._itemIdOf(item)
            except Exception:
                continue
            if cnt < int(rec.get("count", 1)) or (cur and cur != rec.get("name")):
                self._drinkConfirm(playerId, rec.get("grant"))

    def _checkPotion(self, playerId, itemDict, src=u"eat"):
        # 判断刚才喝的是超级触手还是超级愈合
        if not playerId:
            return
        self._debugIntake(playerId, itemDict, src)
        name = self._itemIdOf(itemDict)
        if not name:
            return
        if name == str(getattr(cfg, "BUTCHER_ITEM", "")).lower():
            self._drinkRoute(playerId, name, src, self._giveButcher)
            return
        if name == str(getattr(cfg, "HEAL_ITEM", "")).lower():
            self._drinkRoute(playerId, name, src, self._giveHeal)

    def OnEatFood(self, args):
        # 玩家把东西喝下去了
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"eat")

    def OnUseItem(self, args):
        # 开始使用物品时触发：先记一笔，等确认真的喝下去
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"use")

    def OnTryUse(self, args):
        # 按下使用键：只记一笔，喝完了才给效果
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"try")

    def OnAfterUse(self, args):
        # 用完 / 松手时发的事件：按住了足够久才算喝下去
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"after")

    # ==================== 透明人 / 深海：看原版药水效果 ====================
    def _effectsOf(self, entityId):
        try:
            comp = serverApi.GetEngineCompFactory().CreateEffect(entityId)
        except Exception:
            return []
        if comp is None:
            return []
        try:
            raw = comp.GetAllEffects()
        except Exception:
            return []
        if not raw:
            return []
        if isinstance(raw, dict):
            out = []
            for key, info in raw.items():
                if isinstance(info, dict):
                    item = dict(info)
                    item.setdefault("effectName", key)
                    out.append(item)
                else:
                    out.append({"effectName": key})
            return out
        try:
            return [item for item in raw if item]
        except Exception:
            return []

    def _effectNameOf(self, info):
        if isinstance(info, dict):
            for key in ("effectName", "name", "effect"):
                value = info.get(key)
                if value:
                    return str(value)
            return ""
        if info is None:
            return ""
        return str(info)

    def _hasEffect(self, entityId, names):
        # 身上有没有这几种药水效果（名字只认关键部分，带不带 minecraft: 都行）
        want = [str(n).lower().replace("minecraft:", "") for n in (names or ())]
        if not want:
            return False
        for info in self._effectsOf(entityId):
            name = self._effectNameOf(info).lower().replace("minecraft:", "")
            if not name:
                continue
            for one in want:
                if one and one in name:
                    return True
        return False

    def _tickInvis(self, players, now):
        # 透明人：生命上限 +10 颗心
        if not getattr(cfg, "INVIS_ENABLED", True):
            return
        if now - self._invT < float(getattr(cfg, "POLL_INTERVAL", 0.25)):
            return
        self._invT = now
        amount = float(getattr(cfg, "INVIS_EXTRA_HEALTH", 20.0))
        names = getattr(cfg, "INVIS_NAMES", ("invisibility",))
        for playerId in players:
            has = self._hasEffect(playerId, names)
            extra = float(self._invExtra.get(playerId, 0.0))
            if has and extra <= 0.0:
                self._addInvisHealth(playerId, amount)
            elif (not has) and extra > 0.0:
                self._dropInvisHealth(playerId)

    def _addInvisHealth(self, playerId, amount):
        attr = self._attrComp(playerId)
        AT = self._attrType()
        if attr is None or AT is None:
            return
        top = self._attrNum(attr, AT.HEALTH, float(getattr(cfg, "BASE_MAX_HEALTH", 20.0)))
        self._invWas[playerId] = top
        self._invExtra[playerId] = float(amount)
        self._setAttrMax(attr, AT.HEALTH, top + float(amount))
        # 多出来的心直接补上，喝下去立刻看得到
        self._setAttrValue(attr, AT.HEALTH, top + float(amount))
        if getattr(cfg, "INVIS_TIP", True):
            self._tip(playerId, u"透明人：生命上限 +%d 颗心"
                      % int(round(float(amount) / 2.0)), "LIGHT_PURPLE")

    def _dropInvisHealth(self, playerId):
        amount = float(self._invExtra.pop(playerId, 0.0))
        was = self._invWas.pop(playerId, None)
        if amount <= 0.0:
            return
        attr = self._attrComp(playerId)
        AT = self._attrType()
        if attr is None or AT is None:
            return
        base = float(getattr(cfg, "BASE_MAX_HEALTH", 20.0))
        cur = self._attrNum(attr, AT.HEALTH, base)
        want = max(base, cur - amount)
        if was is not None and abs(cur - (float(was) + amount)) < 1.0:
            want = float(was)                 # 只有我们在管血量：原样还回去
        self._setAttrMax(attr, AT.HEALTH, want)
        hp = self._attrNum(attr, AT.HEALTH, base, "GetAttrValue")
        if hp > want:
            self._setAttrValue(attr, AT.HEALTH, want)
        if getattr(cfg, "INVIS_TIP", True):
            self._tip(playerId, u"透明人失效：生命上限恢复原样", "GOLD")

    def _swimAttrType(self):
        # 水下移动速度这个属性，不同版本名字可能不一样，多试几个
        AT = self._attrType()
        if AT is not None:
            for name in ("UNDERWATER_SPEED", "UNDERWATER_MOVEMENT_SPEED",
                         "WATER_SPEED", "SWIM_SPEED"):
                value = getattr(AT, name, None)
                if value is not None:
                    return value
        return "minecraft:underwater_movement_speed"

    def _tickDeep(self, players, now):
        # 深海：水里游速 x5
        if not getattr(cfg, "DEEP_ENABLED", True):
            return
        if now - self._deepT < float(getattr(cfg, "POLL_INTERVAL", 0.25)):
            return
        self._deepT = now
        mult = float(getattr(cfg, "DEEP_SWIM_MULTIPLIER", 5.0))
        names = getattr(cfg, "DEEP_NAMES", ("water_breathing",))
        at = self._swimAttrType()
        for playerId in players:
            attr = self._attrComp(playerId)
            if attr is None:
                continue
            has = self._hasEffect(playerId, names)
            base = self._deepBase.get(playerId)
            if has:
                if base is None:
                    cur = self._attrNum(attr, at, 0.0, "GetAttrValue")
                    if cur <= 0.0:
                        continue          # 读不到原版数值就先不动，等下一轮
                    base = cur
                    self._deepBase[playerId] = base
                    if getattr(cfg, "DEEP_TIP", True):
                        self._tip(playerId, u"深海：水里游速变成 %d 倍"
                                  % int(round(mult)), "AQUA")
                self._setAttrValue(attr, at, float(base) * mult)
            elif base is not None:
                self._setAttrValue(attr, at, float(base))
                self._deepBase.pop(playerId, None)
                if getattr(cfg, "DEEP_TIP", True):
                    self._tip(playerId, u"深海失效：游速恢复原样", "GOLD")

    # ==================== 进游戏发药水 ====================
    def _hasPotion(self, playerId, itemName):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            posType = serverApi.GetMinecraftEnum().ItemPosType
            want = str(itemName).lower()
            for item in comp.GetPlayerAllItems(posType.INVENTORY):
                if not item:
                    continue
                name = item.get("newItemName") or item.get("itemName") or ""
                if str(name).lower() == want:
                    return True
        except Exception:
            return False
        return False

    def _givePotionItem(self, playerId, itemName, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            comp.SpawnItemToPlayerInv(
                {"itemName": itemName, "count": int(num), "auxValue": 0}, playerId)
        except Exception:
            pass

    def _giveJoinPotion(self, playerId):
        if getattr(cfg, "BUTCHER_JOIN_GIVE", True) and self._butcherOn():
            if not self._hasPotion(playerId, getattr(cfg, "BUTCHER_ITEM", "")):
                self._givePotionItem(playerId, cfg.BUTCHER_ITEM,
                                     int(getattr(cfg, "BUTCHER_JOIN_GIVE_COUNT", 1)))
        if getattr(cfg, "HEAL_JOIN_GIVE", True) and self._healOn():
            if not self._hasPotion(playerId, getattr(cfg, "HEAL_ITEM", "")):
                self._givePotionItem(playerId, cfg.HEAL_ITEM,
                                     int(getattr(cfg, "HEAL_JOIN_GIVE_COUNT", 1)))

    # ==================== 每帧 ====================
    def OnServerTick(self, args=None):
        try:
            players = set(serverApi.GetPlayerList() or [])
        except Exception:
            players = set()
        if not players:
            return
        now = time.time()

        # 0) 喝药确认：按下不算，按住喝完（药水真的少了一瓶）才给效果
        self._drinkWatchTick(now)

        # 0) 刚进游戏的玩家：等背包准备好再把药水放进去
        if self._potionAt:
            for playerId in list(self._potionAt.keys()):
                if now < self._potionAt[playerId]:
                    continue
                del self._potionAt[playerId]
                if playerId in players:
                    self._giveJoinPotion(playerId)

        # 1) 药效到点收回 / 到点前提醒
        for pid in list(self._butcherUntil.keys()):
            if pid not in players:
                self._loseButcher(pid, quiet=True)
                continue
            left = self._butcherLeft(pid)
            if left <= 0.0:
                self._loseButcher(pid)
                continue
            warned = self._warned.setdefault("b" + pid, set())
            for mark in getattr(cfg, "BUTCHER_WARN_AT", []):
                mark = float(mark)
                if left <= mark and mark not in warned:
                    warned.add(mark)
                    if getattr(cfg, "BUTCHER_TIP", True):
                        self._tip(pid, u"%s 还剩 %d 秒" % (cfg.BUTCHER_NAME, int(left)),
                                  "GOLD")
                    break
        for pid in list(self._healUntil.keys()):
            if pid not in players:
                self._loseHeal(pid, quiet=True)
                continue
            left = self._healLeft(pid)
            if left <= 0.0:
                self._loseHeal(pid)
                continue
            warned = self._warned.setdefault("h" + pid, set())
            for mark in getattr(cfg, "HEAL_WARN_AT", []):
                mark = float(mark)
                if left <= mark and mark not in warned:
                    warned.add(mark)
                    if getattr(cfg, "HEAL_TIP", True):
                        self._tip(pid, u"%s 还剩 %d 秒" % (cfg.HEAL_NAME, int(left)),
                                  "GOLD")
                    break

        # 2) 超级愈合：受伤之后血飞快回满
        if self._healOn() and self._healUntil:
            if now - self._healT >= float(getattr(cfg, "HEAL_INTERVAL", 0.1)):
                self._healT = now
                for pid in players:
                    if self._hasHeal(pid):
                        self._healFast(pid)

        # 3) 透明人：生命上限 +10 颗心
        self._tickInvis(players, now)

        # 4) 深海：水里游速 x5
        self._tickDeep(players, now)

        # 5) 触手名单：谁身上有触手，隔一会儿补发一次给所有人
        self._broadcastTentacles(players)

        # 6) 屏幕上那些数字
        if now - self._lastStateT >= float(getattr(cfg, "STATE_SYNC", 0.25)):
            self._lastStateT = now
            for pid in players:
                self._syncState(pid)

    # ==================== 玩家进入 / 死亡 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        self._potionAt[playerId] = time.time() + 3.0
        self._syncState(playerId, force=True)

    def OnPlayerDie(self, args):
        try:
            playerId = None
            if args:
                playerId = args.get("id") or args.get("playerId")
            if not playerId:
                return
            # 药效期间死亡：药效当场作废，重生之后不会还挂着
            self._loseButcher(playerId, quiet=True)
            self._loseHeal(playerId, quiet=True)
            # 透明人加的血上限也一起还原（重生后本来也是原版数值）
            self._invExtra.pop(playerId, None)
            self._invWas.pop(playerId, None)
            self._deepBase.pop(playerId, None)
            self._warned.pop("b" + playerId, None)
            self._warned.pop("h" + playerId, None)
            self._syncState(playerId, force=True)
        except Exception:
            pass
