# -*- coding: utf-8 -*-
# ============================================================
#  超级速度 - 服务端
#  喝下五号化合物之后：
#    · 移速大幅提升，左上角显示剩余时间
#    · 撞到生物 -> 生物直接死亡
#    · 撞到方块 -> 方块被撞碎，一路撞出一条隧道
#  药效到点自动收回，速度回到原版
# ============================================================
import math
import time
import mod.server.extraServerApi as serverApi
from CompoundAllScripts import superSpeedModConfig as modConfig
from CompoundAllScripts import superSpeedConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()


class SuperSpeedServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(SuperSpeedServerSystem, self).__init__(namespace, systemName)
        self._powerUntil = {}      # playerId -> 药效失效的时间戳
        self._powerWarned = {}     # playerId -> 已经提醒过的剩余秒数
        self._powerState = {}      # playerId -> 上次同步给客户端的 (开关, 剩余秒)
        self._powerSyncT = 0.0     # 上次同步倒计时的时间
        self._potionAt = {}        # playerId -> 什么时候把进游戏送的药水放进背包
        self._welcomed = set()     # 已经欢迎过的玩家
        self._lastPos = {}         # playerId -> 上一次的位置（算速度和撞击路段用）
        self._lastPosT = {}        # playerId -> 上一次记位置的时间
        self._speedT = 0.0         # 上次刷新移速的时间
        self._protect = None       # 撞不动的方块名单（第一次用到时再建）
        self._hitAt = {}           # 生物 -> 上次被撞的时间（防止一秒撞好几次）
        self._tipAt = {}           # playerId -> 上次"撞飞了几只"的提示时间
        self._noKill = set([       # 有血量但不算"生物"的东西：不撞
            "minecraft:armor_stand",
            "minecraft:item",
            "minecraft:xp_orb",
        ])
        self._hungerT = 0.0         # 上次补饥饿值的时间
        self._sprint = {}           # playerId -> 客户端报上来的疾跑状态
        self._sprintT = {}          # playerId -> 上次收到疾跑状态的时间
        self._boosted = {}          # playerId -> 现在是不是正在超速（给 HUD 显示用）
        self._sprintReq = bool(getattr(cfg, "SPEED_SPRINT_ONLY", True))  # 要不要"疾跑才生效"
        self._mobOn = True         # 撞死生物开关（可以用聊天指令改）
        self._blockOn = True       # 撞碎方块开关
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        def _L(_ns, _sn, _name, _obj, _handler):
            # 单个事件名在某些平台上可能不存在：这一条注册失败就跳过。
            # 不能让整个系统因为一个不认识的事件名而挂掉（手机端最容易踩）。
            try:
                self.ListenForEvent(_ns, _sn, _name, _obj, _handler)
            except Exception:
                pass
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        _L(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        _L(ns, sn, "ServerChatEvent", self, self.OnChat)
        _L(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        # 喝药水：两个事件都听着，哪个先来都认
        _L(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        _L(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)
        _L(ns, sn, "ServerItemTryUseEvent", self, self.OnTryUse)
        _L(ns, sn, "ItemUseAfterServerEvent", self, self.OnAfterUse)
        # 药效期间不怕摔
        try:
            _L(ns, sn, "DamageEvent", self, self.OnDamage)
        except Exception:
            pass
        # 客户端报上来的疾跑状态（超级速度只在疾跑时生效）
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventSprintState, self, self.OnSprintState)

    # ==================== 小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _dimOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    # ==================== 五号化合物：药效时间 ====================
    def _powerOn(self):
        return bool(getattr(cfg, "MODE_ENABLED", True))

    def _powerLeftOf(self, playerId):
        if not self._powerOn():
            return 999999.0
        return max(0.0, float(self._powerUntil.get(playerId, 0.0)) - time.time())

    def _hasPower(self, playerId):
        if not playerId:
            return False
        if not self._powerOn():
            return True
        return self._powerLeftOf(playerId) > 0.0

    def _syncPowerState(self, playerId, force=False):
        # 把"药效还开着没有 + 还剩几秒"告诉这个玩家的客户端（屏幕左上角倒计时）
        on = 1 if self._hasPower(playerId) else 0
        left = int(math.ceil(self._powerLeftOf(playerId))) if on else 0
        sprint = 1 if (on and self._boosted.get(playerId)) else 0
        sig = (on, left, sprint)
        if not force and self._powerState.get(playerId) == sig:
            return
        try:
            self.NotifyToClient(playerId, modConfig.EventPowerState,
                                {"playerId": playerId, "on": on, "left": left,
                                 "sprint": sprint})
        except Exception:
            return          # 没发出去就先不记，等下一轮继续发
        self._powerState[playerId] = sig

    def _givePower(self, playerId):
        dur = float(getattr(cfg, "MODE_DURATION", 90.0))
        left = self._powerLeftOf(playerId)
        self._powerUntil[playerId] = time.time() + dur
        self._powerWarned[playerId] = set()
        self._boostSpeed(playerId)                    # 超速立刻生效
        self._applyHunger(playerId, True)             # 饥饿值锁住，跑多久都不饿
        self._syncPowerState(playerId, force=True)    # 倒计时立刻出现
        if not getattr(cfg, "MODE_TIP", True):
            return
        if left > dur - 1.0:
            return                                    # 刚提示过，不刷屏
        if left > 0.0:
            self._tip(playerId, u"%s 时间已刷新，再来 %d 秒" % (cfg.MODE_NAME, int(dur)),
                      "LIGHT_PURPLE")
        else:
            self._tip(playerId, u"%s 生效：疾跑就是移速 x%s，撞到生物直接撞死、"
                                u"撞到方块直接撞碎，维持 %d 秒"
                      % (cfg.MODE_NAME, int(cfg.SPEED_MULTIPLIER), int(dur)),
                      "LIGHT_PURPLE")
            if self._hungerOn():
                self._tip(playerId, u"药效期间不会饿（饥饿值锁住），放心一直跑", "GREEN")

    def _losePower(self, playerId, quiet=False):
        self._powerUntil.pop(playerId, None)
        self._powerWarned.pop(playerId, None)
        self._syncPowerState(playerId, force=True)    # 倒计时马上收起
        self._restoreSpeed(playerId)                  # 速度回到原版
        self._applyHunger(playerId, False)            # 饥饿值恢复成原版
        if not quiet and getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"%s 已失效，速度恢复原版" % cfg.MODE_NAME, "GOLD")
            self._refillIfEmpty(playerId)

    # ===== 给士兵男孩的爆炸用：认得 / 收掉超级速度 =====
    def HasPower(self, playerId):
        if not self._powerOn():
            return False
        return self._powerLeftOf(playerId) > 0.0

    def DropPower(self, playerId, quiet=True):
        if not self._powerOn():
            return False
        if self._powerLeftOf(playerId) <= 0.0:
            return False
        self._losePower(playerId, quiet=quiet)
        return True

    # ===== 给喷溅型药水用 =====
    def PowerDuration(self):
        return float(getattr(cfg, "MODE_DURATION", 90.0))

    def GivePowerFromSplash(self, playerId):
        # 被喷溅型超级速度溅到：直接拿到超级速度
        if not self._powerOn() or not playerId:
            return False
        if not self._isPlayerId(playerId):
            return False
        self._givePower(playerId)
        return True

    # ==================== 药效期间：不怕摔 ====================
    def OnDamage(self, args):
        # 超速跑起来掉下悬崖不该摔死，所以药效期间把摔落伤害抹平
        try:
            if not getattr(cfg, "MODE_NO_FALL_DAMAGE", True):
                return
            entityId = args.get("entityId")
            if not self._hasPower(entityId):
                return
            if not self._isFallCause(args.get("cause")):
                return
            args["damage"] = 0
            args["knock"] = False
        except Exception:
            pass

    def _isFallCause(self, cause):
        try:
            if cause == serverApi.GetMinecraftEnum().ActorDamageCause.Fall:
                return True
        except Exception:
            pass
        return str(cause or "").lower().find("fall") >= 0

    # ==================== 药水的获得 ====================
    def _hasPotion(self, playerId):
        # 背包里还有没有五号化合物
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            posType = serverApi.GetMinecraftEnum().ItemPosType
            want = str(getattr(cfg, "MODE_ITEM", "")).lower()
            for item in comp.GetPlayerAllItems(posType.INVENTORY):
                if not item:
                    continue
                name = item.get("newItemName") or item.get("itemName") or ""
                if str(name).lower() == want:
                    return True
        except Exception:
            return False
        return False

    def _giveJoinPotion(self, playerId):
        # 手机端不好打指令：进游戏先把药水放背包里
        if not getattr(cfg, "MODE_JOIN_GIVE", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, int(getattr(cfg, "MODE_JOIN_GIVE_COUNT", 2)))

    def _refillIfEmpty(self, playerId):
        # 药效到点、背包又空了：补一瓶，免得没法接着玩（可以关掉）
        if not getattr(cfg, "MODE_REFILL_WHEN_EMPTY", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, 1)
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"时间到，背包里补了一瓶 %s，喝掉就能接着飞" % cfg.MODE_NAME,
                      "LIGHT_PURPLE")

    def _givePotionItem(self, playerId, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            itemDict = {"itemName": cfg.MODE_ITEM, "count": int(num), "auxValue": 0}
            ok = comp.SpawnItemToPlayerInv(itemDict, playerId)
            if getattr(cfg, "MODE_TIP", True):
                if ok:
                    self._tip(playerId, u"已获得 %s ×%d，喝下去就能超速"
                              % (cfg.MODE_NAME, int(num)), "LIGHT_PURPLE")
                else:
                    self._tip(playerId, u"背包放不下，先清一格再试", "RED")
        except Exception:
            pass

    # ==================== 用药识别（手机端 / 电脑端都认） ====================
    def _actorIdOf(self, args):
        # 不同事件给的键不一样：playerId / entityId / id 都认一遍
        if not isinstance(args, dict):
            return None
        for k in ("playerId", "entityId", "id"):
            v = args.get(k)
            if v:
                return v
        return None

    def _itemIdOf(self, itemDict):
        # 有的版本给 newItemName，有的给 itemName，两个都认
        if not isinstance(itemDict, dict):
            return u""
        for k in ("newItemName", "itemName"):
            v = itemDict.get(k)
            if v:
                return str(v).lower()
        return u""

    def _debugIntake(self, playerId, itemDict, src):
        # 这里只是打日志，绝对不能让它的异常把喝药流程带崩
        try:
            self._debugIntakeInner(playerId, itemDict, src)
        except Exception:
            pass

    def _debugIntakeInner(self, playerId, itemDict, src):
        # 排查用：把用到的物品名打到开发者日志（cfg.INTAKE_DEBUG 控制）
        if not getattr(cfg, "INTAKE_DEBUG", False):
            return
        name = self._itemIdOf(itemDict)
        if name:
            if name.split(":")[0] in ("eyelaser", "superspeed", "soldierboy",
                                      "butcher"):
                print(u"[药剂自检] 玩家=%s 事件=%s 物品=%s" % (playerId, src, name))
        elif src in ("try", "eat") and isinstance(itemDict, dict) and itemDict:
            keys = sorted([str(k) for k in itemDict.keys()])
            print(u"[药剂自检] 玩家=%s 事件=%s 物品名没取到，可用键=%s"
                  % (playerId, src, u",".join(keys)))

    # ==================== "真的喝了"的判定 ====================
    # 老写法是"手一点到药水就立刻生效"，玩家还没喝就变身了。
    # 现在改成：按下使用键只记一笔，确认喝下去（吃完 / 药水真的少了一瓶）才给效果。
    _DRINK_HOLD_MIN = 0.45      # 使用键至少按住这么久才算喝下去（点一下不算）

    def _drinkTestMap(self):
        d = getattr(self, "_drinkTest", None)
        if d is None:
            d = {}
            self._drinkTest = d
        return d

    def _drinkPress(self, playerId, itemName, grant):
        # 玩家刚按下使用键：先记一笔，不马上给效果
        slot, cnt = -1, 1
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
            slot = int(comp.GetSelectSlotId())
            item = comp.GetPlayerItem(ItemPosType.INVENTORY, slot, True) or {}
            cnt = int(item.get("count", 1) or 1)
        except Exception:
            pass
        self._drinkTestMap()[playerId] = {"t": time.time(), "slot": slot,
                                          "count": cnt, "name": itemName,
                                          "grant": grant}

    def _drinkConfirm(self, playerId, grant):
        # 确认真的喝下去了：给效果（同一次喝药只给一遍，免得倒计时被刷两回）
        self._drinkTestMap().pop(playerId, None)
        done = getattr(self, "_drinkDoneAt", None)
        if done is None:
            done = {}
            self._drinkDoneAt = done
        now = time.time()
        if now - float(done.get(playerId, 0.0)) < 0.5:
            return
        done[playerId] = now
        if callable(grant):
            grant(playerId)

    def _drinkRoute(self, playerId, name, src, grant):
        # 按下（try / use）只记账；吃完（eat）或药水真的被消耗掉才算喝下去
        if src == u"try":
            self._drinkPress(playerId, name, grant)
            return
        if src == u"eat":
            self._drinkConfirm(playerId, grant)
            return
        rec = self._drinkTestMap().get(playerId)
        if not rec:
            if src == u"use":
                self._drinkPress(playerId, name, grant)   # 没见到按下事件，先记一笔
            else:
                self._drinkConfirm(playerId, grant)       # 没见到按下事件，只能信完成事件
            return
        if float(rec.get("t", 0.0)) + self._DRINK_HOLD_MIN <= time.time():
            self._drinkConfirm(playerId, grant)

    def _drinkWatchTick(self, now):
        # 兜底：药水真的从背包里少了一瓶 -> 就当喝下去了
        m = getattr(self, "_drinkTest", None)
        if not m:
            return
        for playerId in list(m.keys()):
            rec = m.get(playerId)
            if not rec:
                continue
            age = now - float(rec.get("t", 0.0))
            if age > 5.0:
                m.pop(playerId, None)
                continue
            if age < self._DRINK_HOLD_MIN:
                continue
            cnt, cur = -1, u""
            try:
                comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
                ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
                item = comp.GetPlayerItem(ItemPosType.INVENTORY,
                                          int(rec.get("slot", -1)), True) or {}
                cnt = int(item.get("count", 0) or 0)
                cur = self._itemIdOf(item)
            except Exception:
                continue
            if cnt < int(rec.get("count", 1)) or (cur and cur != rec.get("name")):
                self._drinkConfirm(playerId, rec.get("grant"))

    def _checkPotion(self, playerId, itemDict, src=u"eat"):
        # 判断刚才喝的是不是超级速度药水
        if not playerId or not self._powerOn():
            return
        self._debugIntake(playerId, itemDict, src)
        name = self._itemIdOf(itemDict)
        if not name:
            return
        if name == str(getattr(cfg, "MODE_ITEM", "")).lower():
            self._drinkRoute(playerId, name, src, self._givePower)

    def OnEatFood(self, args):
        # 玩家把东西喝下去了
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"eat")

    def OnUseItem(self, args):
        # 开始使用物品时触发：先记一笔，等确认真的喝下去
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"use")

    def OnTryUse(self, args):
        # 按下使用键：只记一笔，喝完了才给效果
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"try")

    def OnAfterUse(self, args):
        # 用完 / 松手时发的事件：按住了足够久才算喝下去
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"after")

    # ==================== 超级速度 ====================
    def _attrComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreateAttr(playerId)
        except Exception:
            return None

    def _setAttr(self, attr, attrType, value):
        try:
            cur = float(attr.GetAttrValue(attrType))
        except Exception:
            cur = None
        if cur is not None and abs(cur - value) < 1e-4:
            return True                       # 已经是这个值，不用重复设置
        try:
            attr.SetAttrMaxValue(attrType, value)   # 先把上限抬高，否则会被截断
        except Exception:
            pass
        try:
            attr.SetAttrValue(attrType, value, 1)
            return True
        except Exception:
            return False

    # ==================== 药效期间：饥饿值不掉 ====================
    def _hungerOn(self):
        return bool(getattr(cfg, "MODE_NO_HUNGER", True))

    def _applyHunger(self, playerId, on):
        # on = True  -> 饥饿值锁住（最大消耗度设得很大，怎么跑都不掉）
        # on = False -> 还原成原版的最大消耗度
        if not self._hungerOn():
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreatePlayer(playerId)
        except Exception:
            return
        if comp is None:
            return
        if on:
            try:
                comp.SetPlayerMaxExhaustionValue(
                    float(getattr(cfg, "MODE_HUNGER_EXHAUSTION", 999999999.9)))
            except Exception:
                pass
            try:
                comp.SetPlayerHunger(int(getattr(cfg, "MODE_HUNGER_MAX", 20)))
            except Exception:
                pass
        else:
            try:
                comp.SetPlayerMaxExhaustionValue(
                    float(getattr(cfg, "MODE_HUNGER_EXHAUSTION_BASE", 4.0)))
            except Exception:
                pass

    # ==================== 疾跑判定（超速的前提） ====================
    def OnSprintState(self, args):
        # 客户端告诉我们：它现在有没有在疾跑
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        try:
            self._sprint[playerId] = int(args.get("sprint", 0)) == 1
        except Exception:
            self._sprint[playerId] = False
        self._sprintT[playerId] = time.time()

    def _sprintOf(self, playerId):
        # True / False / None（None = 客户端还没报过，或者报得太久算过期）
        t = self._sprintT.get(playerId)
        if t is None:
            return None
        if time.time() - float(t) > float(getattr(cfg, "SPRINT_STALE", 2.0)):
            return None
        return bool(self._sprint.get(playerId, False))

    def _superSpeedOn(self, playerId, speed=0.0):
        # 超级速度生效条件：药效还在 + 现在正在疾跑
        if not self._hasPower(playerId):
            return False
        if not self._sprintReq:
            return True
        sprint = self._sprintOf(playerId)
        if sprint is None:
            # 收不到客户端的疾跑状态时用速度兜底：
            # 原版走路大约 4.3 格/秒，疾跑大约 5.6 格/秒
            return float(speed or 0.0) > float(
                getattr(cfg, "SPRINT_FALLBACK_SPEED", 4.6))
        return sprint

    def _boostSpeed(self, playerId):
        if not cfg.SPEED_ENABLED:
            return
        attr = self._attrComp(playerId)
        if attr is None:
            return
        AttrType = serverApi.GetMinecraftEnum().AttrType
        mul = float(cfg.SPEED_MULTIPLIER)
        self._setAttr(attr, AttrType.SPEED, cfg.SPEED_BASE_WALK * mul)
        if getattr(cfg, "SPEED_BOOST_FLYING", True):
            self._setAttr(attr, AttrType.FLYING_SPEED,
                          cfg.SPEED_BASE_FLY * float(getattr(cfg, "SPEED_FLY_MULTIPLIER", mul)))

    def _restoreSpeed(self, playerId):
        attr = self._attrComp(playerId)
        if attr is None:
            return
        AttrType = serverApi.GetMinecraftEnum().AttrType
        self._setAttr(attr, AttrType.SPEED, cfg.SPEED_BASE_WALK)
        if getattr(cfg, "SPEED_BOOST_FLYING", True):
            self._setAttr(attr, AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY)

    # ==================== 撞击：算速度 ====================
    def _moveSpeedOf(self, playerId, pos, now):
        # 用前后两次采样的位移算水平速度（格 / 秒）
        last = self._lastPos.get(playerId)
        lastT = float(self._lastPosT.get(playerId, 0.0))
        if pos is None:
            return 0.0
        self._lastPos[playerId] = (float(pos[0]), float(pos[1]), float(pos[2]))
        self._lastPosT[playerId] = now
        if last is None:
            return 0.0
        dt = now - lastT
        if dt <= 0.001 or dt > 2.0:
            return 0.0
        dx = float(pos[0]) - last[0]
        dz = float(pos[2]) - last[2]
        return math.sqrt(dx * dx + dz * dz) / dt

    # ==================== 撞击生物：直接撞死 ====================
    def _typeOf(self, entityId):
        try:
            return str(serverApi.GetEngineCompFactory().CreateEngineType(
                entityId).GetEngineTypeStr() or "").lower()
        except Exception:
            return ""

    def _isLiving(self, entityId):
        # 只处理"有血量的生物"：地上的掉落物、箭、经验球这些一律放过，
        # 不然跑过去会把玩家自己丢的东西也一起清掉
        try:
            hp = serverApi.GetEngineCompFactory().CreateAttr(entityId).GetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH)
        except Exception:
            return False
        if hp is None:
            return False
        if self._typeOf(entityId) in self._noKill:
            return False
        return True

    def _isPlayerId(self, entityId):
        try:
            return entityId in (serverApi.GetPlayerList() or [])
        except Exception:
            return False

    def _touch(self, entityId, pos, radius):
        # 生物离自己够近才算撞上
        ep = self._posOf(entityId)
        if ep is None:
            return True                 # 拿不到位置就按范围算
        dx = float(ep[0]) - float(pos[0])
        dy = float(ep[1]) - float(pos[1])
        dz = float(ep[2]) - float(pos[2])
        return math.sqrt(dx * dx + dy * dy + dz * dz) <= (radius + 0.9)

    def _killEntity(self, entityId, playerId):
        try:
            game = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
            if game.KillEntity(entityId):
                return True
        except Exception:
            pass
        try:
            serverApi.GetEngineCompFactory().CreateHurt(entityId).Hurt(
                1000.0,
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                playerId, None, True)
            return True
        except Exception:
            return False

    def _killNearbyMobs(self, playerId, pos, dimensionId, now):
        radius = float(getattr(cfg, "IMPACT_MOB_RADIUS", 2.2))
        try:
            ids = serverApi.GetEngineCompFactory().CreateGame(
                serverApi.GetLevelId()).GetEntitiesInSquareArea(
                    None,
                    (pos[0] - radius, pos[1] - radius, pos[2] - radius),
                    (pos[0] + radius, pos[1] + radius, pos[2] + radius),
                    dimensionId)
        except Exception:
            ids = None
        if not ids:
            return 0
        cd = float(getattr(cfg, "IMPACT_MOB_COOLDOWN", 0.25))
        limit = int(getattr(cfg, "IMPACT_MOB_MAX_PER_TICK", 6))
        hurtPlayers = bool(getattr(cfg, "IMPACT_MOB_HURT_PLAYERS", False))
        killed = 0
        for entityId in ids:
            if killed >= limit:
                break
            if not entityId or entityId == playerId:
                continue
            if self._isPlayerId(entityId) and not hurtPlayers:
                continue
            if not self._isLiving(entityId):
                continue
            if now - float(self._hitAt.get(entityId, 0.0)) < cd:
                continue
            if not self._touch(entityId, pos, radius):
                continue
            self._hitAt[entityId] = now
            if self._killEntity(entityId, playerId):
                killed += 1
        return killed

    # ==================== 撞击方块：直接撞碎 ====================
    def _blockComp(self):
        try:
            return serverApi.GetEngineCompFactory().CreateBlockInfo(
                serverApi.GetLevelId())
        except Exception:
            return None

    def _isProtected(self, name):
        # 打不动的方块：air / 基岩 / 命令方块 / 水 / 岩浆 ... 都会跳过
        if self._protect is None:
            try:
                self._protect = set(cfg.IMPACT_BLOCK_BLACKLIST or [])
            except Exception:
                self._protect = set()
        if not name:
            return True
        return name in self._protect

    def _breakBlock(self, comp, pos, dimensionId, cache):
        # 返回 "air"（本来就是空的）/"broken"（撞碎了）/"stop"（撞不动）
        name = None
        try:
            info = comp.GetBlockNew(pos, dimensionId)
            if info:
                name = info.get("name")
        except Exception:
            name = None
        if not name or name == "minecraft:air":
            cache[pos] = "air"
            return "air"
        if self._isProtected(name):
            cache[pos] = "stop"
            return "stop"
        ok = False
        try:
            ok = bool(comp.SetBlockNew(pos, {"name": "minecraft:air", "aux": 0},
                                       1, dimensionId, True, False))
        except Exception:
            ok = False
        cache[pos] = "broken" if ok else "air"
        return cache[pos]

    def _sampleSegment(self, prev, cur, step=0.4):
        # 把"上一帧的位置 -> 这一帧的位置"这一段切成若干个点
        px, py, pz = float(prev[0]), float(prev[1]), float(prev[2])
        cx, cy, cz = float(cur[0]), float(cur[1]), float(cur[2])
        dx = cx - px
        dy = cy - py
        dz = cz - pz
        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        if length <= 0.0:
            return [cur]
        n = int(length / step) + 1
        n = max(1, min(n, int(getattr(cfg, "IMPACT_BLOCK_TAIL", 40))))
        out = []
        for i in range(1, n + 1):
            t = float(i) / float(n)
            out.append((px + dx * t, py + dy * t, pz + dz * t))
        return out

    # ==================== 撞到方块：分清“墙”和“地面” ====================
    def _solidAt(self, comp, pos, dimensionId):
        # 这一格是不是真的挡路（空气 / 水 / 岩浆 / 屏障这些都不算）
        name = None
        try:
            info = comp.GetBlockNew(pos, dimensionId)
            if info:
                name = info.get("name")
        except Exception:
            name = None
        if not name or name == "minecraft:air":
            return False
        return not self._isProtected(name)

    def _groundRowY(self, comp, baseX, baseZ, baseY, dimensionId, scache):
        # 从脚那一格往下找“我站在哪一层”（最多往下找几格），
        #   找到的那一层就是地面：撞的时候必须放过它，
        #   不然跑在平地上也会把脚下挖出一条沟
        if not bool(getattr(cfg, "IMPACT_BLOCK_KEEP_GROUND", True)):
            return None
        span = max(1, int(getattr(cfg, "IMPACT_BLOCK_GROUND_SCAN", 4)))
        for dy in range(0, span + 1):
            yy = baseY - dy
            p = (baseX, yy, baseZ)
            state = scache.get(p)
            if state is None:
                state = "solid" if self._solidAt(comp, p, dimensionId) else "air"
                scache[p] = state
            if state == "solid":
                return yy
        return None

    def _smashAt(self, comp, pt, dimensionId, cache, scache, radius, budget):
        # 在某一个采样点上，把它周围那几格方块打碎
        #   关键：只打“身体这一层挡路的方块”，脚下那一层（地面）永远不打
        footY = float(pt[1])
        baseX = int(math.floor(float(pt[0])))
        baseZ = int(math.floor(float(pt[2])))
        baseY = int(math.floor(footY + 0.5))
        groundY = self._groundRowY(comp, baseX, baseZ, baseY, dimensionId, scache)
        if radius > 0:
            offs = [(ax, az) for ax in range(-radius, radius + 1)
                    for az in range(-radius, radius + 1)]
        else:
            offs = [(0, 0)]
        heights = max(1, int(getattr(cfg, "IMPACT_BLOCK_HEIGHT", 2)))
        broken = 0
        for (ax, az) in offs:
            for ay in range(-1, heights):
                if broken >= budget:
                    return broken
                by = baseY + ay
                if groundY is not None and by <= groundY:
                    continue            # 脚下那一层（含以下）不打，平地才不会留坑
                p = (baseX + ax, by, baseZ + az)
                state = cache.get(p)
                if state is None:
                    state = self._breakBlock(comp, p, dimensionId, cache)
                if state == "broken":
                    broken += 1
        return broken

    def _smashBlocks(self, prev, cur, dimensionId):
        comp = self._blockComp()
        if comp is None:
            return 0
        radius = int(getattr(cfg, "IMPACT_BLOCK_RADIUS", 0))
        budget = int(getattr(cfg, "IMPACT_BLOCK_MAX", 24))
        cache = {}
        scache = {}
        broken = 0
        for pt in self._sampleSegment(prev, cur):
            if broken >= budget:
                break
            broken += self._smashAt(comp, pt, dimensionId, cache, scache,
                                    radius, budget - broken)
        return broken

    # ==================== tick ====================
    def OnServerTick(self, args=None):
        try:
            players = set(serverApi.GetPlayerList() or [])
        except Exception:
            players = set()
        if not players:
            return
        now = time.time()

        # 0) 喝药确认：按下不算，按住喝完（药水真的少了一瓶）才给效果
        self._drinkWatchTick(now)

        # -1) 刚进游戏的玩家：等背包准备好，把药水放进去
        if self._potionAt:
            for playerId in list(self._potionAt.keys()):
                if now < self._potionAt[playerId]:
                    continue
                del self._potionAt[playerId]
                if playerId in players:
                    self._giveJoinPotion(playerId)

        # 0) 药效到点收回 / 到点前提醒
        if self._powerOn() and self._powerUntil:
            for playerId in players:
                if playerId not in self._powerUntil:
                    continue
                left = self._powerLeftOf(playerId)
                if left <= 0.0:
                    self._losePower(playerId)
                    continue
                warned = self._powerWarned.setdefault(playerId, set())
                fired = False
                for mark in getattr(cfg, "MODE_WARN_AT", []):
                    mark = float(mark)
                    if left <= mark and mark not in warned:
                        warned.add(mark)
                        fired = True          # 同一次只提醒一句，不刷屏
                if fired and getattr(cfg, "MODE_TIP", True):
                    self._tip(playerId, u"%s 还剩 %d 秒" % (cfg.MODE_NAME, int(left)), "GOLD")

        # 0.1) 先采样每个人的位置和速度（撞击判定、疾跑兜底都要用）
        moves = {}
        for playerId in players:
            cur = self._posOf(playerId)
            prev = self._lastPos.get(playerId)
            speed = self._moveSpeedOf(playerId, cur, now)
            if cur is None or prev is None:
                continue
            moves[playerId] = (prev, cur, speed)

        # 1) ★ 超级速度只在疾跑时生效：松开疾跑马上回到原版速度
        #    （重生 / 换维度会把属性重置，所以隔一小段时间就补一次）
        if cfg.SPEED_ENABLED:
            if self._sprintReq:
                gap = float(getattr(cfg, "SPEED_REFRESH_SPRINT", 0.1))
            else:
                gap = float(getattr(cfg, "SPEED_REFRESH", 1.0))
            if now - self._speedT >= gap:
                self._speedT = now
                for playerId in players:
                    if not self._hasPower(playerId):
                        self._boosted[playerId] = False
                        continue
                    speed = moves.get(playerId, (None, None, 0.0))[2]
                    on = self._superSpeedOn(playerId, speed)
                    self._boosted[playerId] = on
                    if on:
                        self._boostSpeed(playerId)
                    else:
                        self._restoreSpeed(playerId)

        # 1.05) 药效期间把饥饿值锁住（死亡重生 / 换维度后要补一次）
        if self._hungerOn() and now - self._hungerT >= float(
                getattr(cfg, "MODE_HUNGER_REFRESH", 0.5)):
            self._hungerT = now
            for playerId in players:
                if self._hasPower(playerId):
                    self._applyHunger(playerId, True)

        # 1.1) 左上角倒计时同步（顺便告诉客户端现在是不是正在超速）
        if now - self._powerSyncT >= float(getattr(cfg, "MODE_SYNC_INTERVAL", 0.25)):
            self._powerSyncT = now
            for playerId in players:
                self._syncPowerState(playerId)

        # 2) 撞击：只有"疾跑 + 超速"才撞得动，站着不动不会秒杀掉旁边的生物
        if not self._powerOn():
            return
        lowSpeed = float(getattr(cfg, "IMPACT_MIN_SPEED", 2.5))
        cap = float(getattr(cfg, "IMPACT_SPEED_CAP", 500.0))
        for playerId, (prev, cur, speed) in moves.items():
            if not self._hasPower(playerId):
                continue
            if not self._superSpeedOn(playerId, speed):
                continue          # 没在疾跑 / 没超速，就不撞
            if speed < lowSpeed or speed > cap:
                continue
            dimensionId = self._dimOf(playerId)
            killed = 0
            if self._mobOn and getattr(cfg, "IMPACT_MOB_ENABLED", True):
                killed = self._killNearbyMobs(playerId, cur, dimensionId, now)
            if self._blockOn and getattr(cfg, "IMPACT_BLOCK_ENABLED", True):
                self._smashBlocks(prev, cur, dimensionId)
            if killed and getattr(cfg, "IMPACT_MOB_TIP", True):
                if now - float(self._tipAt.get(playerId, 0.0)) >= 3.0:
                    self._tipAt[playerId] = now
                    self._tip(playerId, u"撞飞了 %d 只生物" % killed, "GREEN")

    # ==================== 进游戏 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        if self._powerOn():
            self._tip(playerId, u"药水马上放进背包：喝掉之后一路疾跑就是移速 x%s，"
                                u"撞到什么拆什么，维持 %d 秒"
                      % (int(cfg.SPEED_MULTIPLIER), int(cfg.MODE_DURATION)),
                      "LIGHT_PURPLE")
            self._potionAt[playerId] = time.time() + 2.0
        self._syncPowerState(playerId, force=True)

    # ==================== 聊天指令 ====================
    def OnChat(self, args):
        try:
            if not args:
                return
            message = (args.get("message") or "").strip().lower()
            playerId = args.get("playerId")
            if not playerId:
                return
            if message in (u"#五号化合物", u"#化合物", u"#药水", u"#speedpotion"):
                self._givePotionItem(playerId, 1)
            elif (message.startswith(u"#五号化合物 ")
                  or message.startswith(u"#化合物 ")
                  or message.startswith(u"#药水 ")):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    num = int(raw)
                except Exception:
                    num = 1
                num = max(1, min(num, int(getattr(cfg, "MODE_STACK", 16))))
                self._givePotionItem(playerId, num)
            elif message.startswith(u"#速度倍率 ") or message.startswith(u"#speed "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    mul = float(raw)
                except Exception:
                    mul = None
                if mul is None:
                    self._tip(playerId, u"格式：#速度倍率 15", "RED")
                else:
                    mul = max(float(cfg.SPEED_MIN), min(float(cfg.SPEED_MAX), mul))
                    cfg.SPEED_MULTIPLIER = mul
                    self._tip(playerId, u"移速倍数改成 x%s（药效期间生效）" % mul, "AQUA")
                    if self._hasPower(playerId):
                        self._boostSpeed(playerId)
            elif message in (u"#撞击生物", u"#mob"):
                self._mobOn = not self._mobOn
                self._tip(playerId, u"撞击生物：%s" % (u"开" if self._mobOn else u"关"),
                          "GREEN" if self._mobOn else "AQUA")
            elif message in (u"#撞击方块", u"#block"):
                self._blockOn = not self._blockOn
                self._tip(playerId, u"撞击方块：%s" % (u"开" if self._blockOn else u"关"),
                          "GREEN" if self._blockOn else "AQUA")
            elif message in (u"#疾跑限制", u"#sprint"):
                self._sprintReq = not self._sprintReq
                if not self._sprintReq:
                    for pid in (serverApi.GetPlayerList() or []):
                        self._boosted[pid] = False
                self._tip(playerId, u"超级速度：%s" % (
                    u"必须疾跑才生效" if self._sprintReq else u"随时生效（不用疾跑）"),
                    "GREEN" if self._sprintReq else "AQUA")
            elif message in (u"#极速帮助", u"#superspeed"):
                self._tip(playerId, u"喝超级速度，然后一路疾跑就是超速；"
                                    u"撞到生物直接撞死、撞到方块直接撞碎；"
                                    u"指令：#化合物 #速度倍率 15 #撞击生物 #撞击方块 #疾跑限制", "GOLD")
            else:
                return
            args["cancel"] = True
        except Exception:
            pass
