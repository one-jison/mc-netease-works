# -*- coding: utf-8 -*-
# ============================================================
#  超级速度 - 屏幕右侧的药水框（上面图标，下面剩余时间）
# ============================================================
import mod.client.extraClientApi as clientApi

ScreenNode = clientApi.GetScreenNodeCls()

TIMER_ROWS = 5


def _fmtTime(seconds):
    # 药水剩余时间，跟原版一样写成 分:秒
    try:
        s = int(seconds)
    except Exception:
        s = 0
    if s < 0:
        s = 0
    if s >= 3600:
        return u"%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)
    return u"%d:%02d" % (s // 60, s % 60)


class SuperSpeedHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mChips = [self.mPanel + "/chip%d" % i
                       for i in range(TIMER_ROWS)]
        self.mTimerOn = None
        self.mTimerRow = -1
        self.mTimerText = None

    # UI 建好后引擎会调用这里
    def Create(self):
        self.SetTimer(False, 0)          # 没喝药水的时候先藏起来

    def SetTimer(self, visible, seconds, sprint=False, row=0):
        # visible = 药效还在不在；seconds = 还剩几秒；sprint = 有没有在超速
        from CompoundAllScripts import superSpeedConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            self._writeChip(row, seconds, bool(sprint))
        if self.mTimerOn == show and self.mTimerRow == row:
            return
        self.mTimerOn = show
        self.mTimerRow = row
        for i in range(TIMER_ROWS):
            self._setVisible(self.mChips[i], show and i == row)

    def _writeChip(self, row, seconds, sprint=False):
        from CompoundAllScripts import superSpeedConfig as cfg
        try:
            left = int(seconds)
        except Exception:
            left = 0
        text = _fmtTime(left)
        if self.mTimerText == text and self.mTimerRow == self._fixRow(row):
            return
        self.mTimerText = text
        if left <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 10.0)):
            color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
        elif sprint:
            color = getattr(cfg, "MODE_HUD_TIMER_SPRINT_COLOR", (0.55, 1.0, 0.8))
        else:
            color = (1.0, 1.0, 1.0)
        self._setLabel(self.mChips[self._fixRow(row)] + "/num", text, color)

    def _fixRow(self, row):
        # 把行号限在 0 ~ TIMER_ROWS-1
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass

