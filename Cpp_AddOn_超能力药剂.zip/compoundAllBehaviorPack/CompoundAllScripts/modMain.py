# -*- coding: utf-8 -*-
# ============================================================
#  超能力药剂-临时五号 - 模组入口
#  一个模组里同时装着三种能力药水：
#    飞行热射线   （眼球激光 / 飞行 / 提速）
#    超级速度   （疾跑时超级速度）
#    V1化合物 （胸口爆炸）
#  另外还有：超级触手（背上长触手 + 抽打攻击）、超级愈合（飞快回血）、
#  以及给原版 透明人 / 深海 药水加的新效果。
#  三个能力各自一个服务端系统 + 一个客户端系统，
#  统一注册在同一个模组名下，彼此互不干扰。
# ============================================================
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi

from CompoundAllScripts import soldierBoyModConfig as soldierBoyModConfig
from CompoundAllScripts import eyeLaserModConfig as eyeLaserModConfig
from CompoundAllScripts import superSpeedModConfig as superSpeedModConfig
from CompoundAllScripts import butcherModConfig as butcherModConfig

MOD_NAME = soldierBoyModConfig.ModName
MOD_VERSION = "1.5.9"

# 三个子系统（服务端 / 客户端）
MOD_CONFIGS = (soldierBoyModConfig, eyeLaserModConfig,
               superSpeedModConfig, butcherModConfig)


@Mod.Binding(name=MOD_NAME, version=MOD_VERSION)
class CompoundAllMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def InitServer(self):
        register = serverApi.RegisterSystem
        for one in MOD_CONFIGS:
            register(one.ModName, one.ServerSystemName, one.ServerSystemClsPath)

    @Mod.DestroyServer()
    def DestroyServer(self):
        pass

    @Mod.InitClient()
    def InitClient(self):
        register = clientApi.RegisterSystem
        for one in MOD_CONFIGS:
            register(one.ModName, one.ClientSystemName, one.ClientSystemClsPath)

    @Mod.DestroyClient()
    def DestroyClient(self):
        pass
