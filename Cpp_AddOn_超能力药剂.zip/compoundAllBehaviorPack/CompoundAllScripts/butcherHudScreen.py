# -*- coding: utf-8 -*-
# ============================================================
#  屠夫 — 屏幕界面（HUD）
#    · 屏幕右侧：两个药水框（触手一瓶、超级愈合一瓶），
#      框里上面是药水图标、下面是剩余时间
#    · 屏幕上：一个 MC 原生风格的方形【攻击】按钮
# ============================================================
import mod.client.extraClientApi as clientApi
from CompoundAllScripts import butcherModConfig as modConfig

ScreenNode = clientApi.GetScreenNodeCls()

TIMER_ROWS = 5


def _fmtTime(seconds):
    # 药水剩余时间，跟原版一样写成 分:秒
    try:
        s = int(seconds)
    except Exception:
        s = 0
    if s < 0:
        s = 0
    if s >= 3600:
        return u"%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)
    return u"%d:%02d" % (s // 60, s % 60)


class ButcherHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mChipsA = [self.mPanel + "/chipA%d" % i
                        for i in range(TIMER_ROWS)]
        self.mChipsB = [self.mPanel + "/chipB%d" % i
                        for i in range(TIMER_ROWS)]
        self.mBtnAttack = self.mPanel + "/btnAttack"
        self.mLblBtn = self.mBtnAttack + "/button_label"
        self.mDown = False
        self.mBtnOn = None
        self.mBtnText = None
        self.mAOn = None
        self.mARow = -1
        self.mAText = None
        self.mBOn = None
        self.mBRow = -2
        self.mBText = None

    def Create(self):
        try:
            self.AddTouchEventHandler(self.mBtnAttack, self.OnAttackTouch,
                                      {"isSwallow": True})
        except Exception:
            pass
        self.SetButcherTimer(False, 0)
        self.SetHealTimer(False, 0)
        self.SetButton(False, 0.0)

    # ==================== 手指按下 / 松开 ====================
    def OnAttackTouch(self, args):
        try:
            touchEvent = clientApi.GetMinecraftEnum().TouchEvent
            touchType = args.get("TouchEvent")
        except Exception:
            return
        cs = self._client()
        if cs is None:
            return
        if touchType == touchEvent.TouchDown:
            if not self.mDown:
                self.mDown = True
                cs.HudAttackDown()
        elif touchType == touchEvent.TouchUp or touchType == touchEvent.TouchCancel:
            if self.mDown:
                self.mDown = False
                cs.HudAttackUp()

    def _client(self):
        try:
            return clientApi.GetSystem(modConfig.ModName, modConfig.ClientSystemName)
        except Exception:
            return None

    # ==================== 右侧药水框 ====================
    def SetButcherTimer(self, visible, seconds, row=0):
        from CompoundAllScripts import butcherConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            try:
                left = int(seconds)
            except Exception:
                left = 0
            text = _fmtTime(left)
            if self.mAText != text or self.mARow != row:
                self.mAText = text
                if left <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 5.0)):
                    color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR",
                                    (1.0, 0.30, 0.25))
                else:
                    color = (1.0, 1.0, 1.0)
                self._setLabel(self.mChipsA[row] + "/num", text, color)
        if self.mAOn == show and self.mARow == row:
            return
        self.mAOn = show
        self.mARow = row
        for i in range(TIMER_ROWS):
            self._setVisible(self.mChipsA[i], show and i == row)

    def SetHealTimer(self, visible, seconds, row=1):
        from CompoundAllScripts import butcherConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            try:
                left = int(seconds)
            except Exception:
                left = 0
            text = _fmtTime(left)
            if self.mBText != text or self.mBRow != row:
                self.mBText = text
                if left <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 5.0)):
                    color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR",
                                    (1.0, 0.30, 0.25))
                else:
                    color = (1.0, 1.0, 1.0)
                self._setLabel(self.mChipsB[row] + "/num", text, color)
        if self.mBOn == show and self.mBRow == row:
            return
        self.mBOn = show
        self.mBRow = row
        for i in range(TIMER_ROWS):
            self._setVisible(self.mChipsB[i], show and i == row)

    def _fixRow(self, row):
        # 把行号限在 0 ~ TIMER_ROWS-1
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass

    # ==================== 方形【攻击】按钮 ====================
    def SetButton(self, visible, cool=0.0):
        v = bool(visible)
        if self.mBtnOn != v:
            self.mBtnOn = v
            self._setVisible(self.mBtnAttack, v)
        text = u""
        if v and float(cool) > 0.05:
            text = u"%.1f" % float(cool)
        if self.mBtnText != text:
            self.mBtnText = text
            self._setLabel(self.mLblBtn, text, (1.0, 0.95, 0.85))
