# -*- coding: utf-8 -*-
# ============================================================
#  士兵男孩 - 屏幕界面（HUD）
#    · 屏幕右侧：药水框（上面图标，下面剩余时间）
#    · 屏幕上：一个 MC 原生风格的【爆炸】按钮，长按蓄力
# ============================================================
import mod.client.extraClientApi as clientApi
from CompoundAllScripts import soldierBoyModConfig as modConfig

ScreenNode = clientApi.GetScreenNodeCls()

TIMER_ROWS = 5


def _fmtTime(seconds):
    # 药水剩余时间，跟原版一样写成 分:秒
    try:
        s = int(seconds)
    except Exception:
        s = 0
    if s < 0:
        s = 0
    if s >= 3600:
        return u"%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)
    return u"%d:%02d" % (s // 60, s % 60)


class SoldierBoyHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mChips = [self.mPanel + "/chip%d" % i
                       for i in range(TIMER_ROWS)]
        self.mBtnBlast = self.mPanel + "/btnBlast"
        self.mLblBtn = self.mBtnBlast + "/button_label"
        self.mBtnDown = False
        self.mTimerOn = None
        self.mTimerRow = -1
        self.mTimerText = None
        self.mBtnOn = None
        self.mBtnText = None

    # UI 建好后引擎会调用这里
    def Create(self):
        try:
            self.AddTouchEventHandler(self.mBtnBlast, self.OnBlastTouch,
                                      {"isSwallow": True})
        except Exception:
            pass
        self.SetTimer(False, 0)
        self.SetButtonVisible(False)

    # ==================== 手指按下 / 松开 ====================
    def OnBlastTouch(self, args):
        try:
            touchEvent = clientApi.GetMinecraftEnum().TouchEvent
            touchType = args.get("TouchEvent")
        except Exception:
            return
        cs = self._client()
        if cs is None:
            return
        if touchType == touchEvent.TouchDown:
            if not self.mBtnDown:
                self.mBtnDown = True
                cs.HudBlastDown()
        elif touchType == touchEvent.TouchUp or touchType == touchEvent.TouchCancel:
            if self.mBtnDown:
                self.mBtnDown = False
                cs.HudBlastUp()

    def _client(self):
        try:
            return clientApi.GetSystem(modConfig.ModName, modConfig.ClientSystemName)
        except Exception:
            return None

    # ==================== 右侧药水框 ====================
    def SetTimer(self, visible, seconds, charging=False, row=0):
        from CompoundAllScripts import soldierBoyConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            try:
                left = int(seconds)
            except Exception:
                left = 0
            text = _fmtTime(left)
            if self.mTimerText != text or self.mTimerRow != row:
                self.mTimerText = text
                if charging:
                    color = getattr(cfg, "MODE_HUD_TIMER_CHARGE_COLOR",
                                    (1.0, 1.0, 0.55))
                elif left <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 30.0)):
                    color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR",
                                    (1.0, 0.30, 0.25))
                else:
                    color = (1.0, 1.0, 1.0)
                self._setLabel(self.mChips[row] + "/num", text, color)
        if self.mTimerOn == show and self.mTimerRow == row:
            return
        self.mTimerOn = show
        self.mTimerRow = row
        for i in range(TIMER_ROWS):
            self._setVisible(self.mChips[i], show and i == row)

    def SetStatus(self, text, visible, color=None, row=0):
        # 蓄力进度 / 冷却现在显示在【爆炸】按钮上，屏幕上不再重复写一行
        return

    def _fixRow(self, row):
        # 把行号限在 0 ~ TIMER_ROWS-1
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass

    # ==================== MC 原生风格的【爆炸】按钮 ====================
    def SetButtonVisible(self, visible):
        v = bool(visible)
        if self.mBtnOn == v:
            return
        self.mBtnOn = v
        self._setVisible(self.mBtnBlast, v)

    def SetButtonLabel(self, text):
        # 按钮中间：蓄力百分比 / 冷却剩余秒数（没有就空着）
        text = text or u""
        if self.mBtnText == text:
            return
        self.mBtnText = text
        self._setLabel(self.mLblBtn, text, (1.0, 0.85, 0.3))
