# -*- coding: utf-8 -*-
# ============================================================
#  屠夫 / 超级愈合 / 透明人 / 深海 — 数值配置
#  想改手感，改这个文件就够了，逻辑代码不用动。
# ============================================================

# ---------- 屠夫（背上长触手 + 抽打攻击） ----------
BUTCHER_ENABLED = True               # 整个屠夫玩法的开关
BUTCHER_ITEM = "butcher:the_butcher" # 屠夫药水的物品 id（别改）
INTAKE_DEBUG = False   # 把"用了哪瓶药水"打到开发者日志，排查手机端不生效用；不想看日志就改 False
BUTCHER_NAME = u"超级触手"           # 屏幕上显示的名字
BUTCHER_DURATION = 30.0              # ★ 药效维持多少秒
BUTCHER_STACK = 16                   # 一瓶能叠几个
BUTCHER_TIP = True                   # 喝药 / 失效时提示一句
BUTCHER_JOIN_GIVE = True             # 进游戏自动发一瓶（手机端不用打指令）
BUTCHER_JOIN_GIVE_COUNT = 1          # 进游戏发几瓶
BUTCHER_WARN_AT = [10.0, 5.0]        # 还剩这些秒时提醒一句

# 背上的触手（纯外观，画给所有玩家看）
BUTCHER_TENTACLES = 5                # ★ 背上几条触手
BUTCHER_TENTACLE_SEGMENTS = 8        # 每条触手画几节（越大越顺滑，越费性能）
BUTCHER_TENTACLE_REFRESH = 0.10      # 多久画一次（秒），越小越顺滑
BUTCHER_TENTACLE_RANGE = 40.0        # 多远之内的玩家能看见
BUTCHER_TENTACLE_PARTICLE = "butcher:tentacle"   # 触手根部（粗）
BUTCHER_TENTACLE_TIP_PARTICLE = "butcher:tentacle_tip"  # 触手尖（细）
BUTCHER_TENTACLE_TIP_FROM = 0.58     # 从第几节开始换成细的（0~1）
BUTCHER_TENTACLE_BACK = 0.32         # 从后背往后偏多少格伸出（越大越靠后）
BUTCHER_TENTACLE_HEIGHT = 1.16       # 从离地多高的地方长出来（1.16 ≈ 后背）

# 抽打攻击
BUTCHER_ATTACK_ENABLED = True        # 攻击功能开关
BUTCHER_ATTACK_RADIUS = 5.0          # ★ 打多远（格）
BUTCHER_ATTACK_DAMAGE = 14.0         # ★ 打一下多少伤害（14 点 = 7 颗心）
BUTCHER_ATTACK_COOLDOWN = 1.0        # ★ 打完之后冷却多少秒
BUTCHER_ATTACK_KNOCK = 1.15          # 打飞力度（0 = 只掉血不推）
BUTCHER_ATTACK_UP = 0.35             # 打飞时往上抬多少
BUTCHER_ATTACK_PLAYERS = True        # ★ 也打身边的玩家
BUTCHER_ATTACK_MOB_MAX = 8           # 一次最多打到几只（性能保护）
BUTCHER_ATTACK_SWING_TIME = 0.35     # 甩触手的动作持续多少秒（纯外观）
BUTCHER_ATTACK_TIP = True            # 打中之后提示打到了几个
BUTCHER_ATTACK_SOUND = True          # 甩触手的声音
BUTCHER_ATTACK_SOUND_NAME = "mob.enderdragon.flap"   # 用的是游戏自带音效
BUTCHER_ATTACK_KEY_ENABLED = True    # 电脑端：按 F 键也能打
BUTCHER_ATTACK_KEY = "70"            # 键码：70 = F 键
BUTCHER_ATTACK_KEY_NAME = u"F"       # 文档里显示的名字

# ---------- 超级愈合（受伤飞快回血） ----------
HEAL_ENABLED = True
HEAL_ITEM = "butcher:heal_potion"    # 超级愈合药水的物品 id
HEAL_NAME = u"超级愈合"
HEAL_DURATION = 30.0                 # ★ 药效维持多少秒
HEAL_PER_TICK = 2.0                  # ★ 每次回多少血（2 点 = 1 颗心）
HEAL_INTERVAL = 0.1                  # ★ 多久回一次（0.1 秒 -> 一秒回 10 次）
HEAL_STACK = 16
HEAL_TIP = True
HEAL_JOIN_GIVE = True
HEAL_JOIN_GIVE_COUNT = 1
HEAL_WARN_AT = [10.0, 5.0]

# ---------- 透明人（原版隐身药水）：生命 +10 颗心 ----------
INVIS_ENABLED = True                 # 开关
INVIS_EXTRA_HEALTH = 20.0            # ★ 额外加多少点血（20 点 = 10 颗心）
INVIS_NAMES = ("invisibility",)      # 原版隐身效果的名字（别改）
INVIS_TIP = True                     # 生效 / 结束时提示一句

# ---------- 深海（原版水下呼吸药水）：游速 x5 ----------
DEEP_ENABLED = True                  # 开关
DEEP_SWIM_MULTIPLIER = 5.0           # ★ 水里游速乘几倍
DEEP_NAMES = ("water_breathing",)    # 原版水下呼吸效果的名字（别改）
DEEP_TIP = True

# ---------- 左上角倒计时 / 通用 ----------
MODE_HUD_TIMER = True                # 药效期间在屏幕左上角显示剩余秒数
MODE_HUD_TIMER_FMT = u"%s 剩余 %d 秒"
MODE_HUD_TIMER_COLOR = (1.0, 0.45, 0.55)         # 时间充裕：粉红
MODE_HUD_TIMER_WARN_COLOR = (1.0, 0.30, 0.25)    # 快没了：红
MODE_HUD_TIMER_WARN_AT = 5.0
STATE_SYNC = 0.25                    # 多久同步一次屏幕状态（秒）
POLL_INTERVAL = 0.25                 # 多久检查一次药水效果（秒）
BASE_MAX_HEALTH = 20.0               # 原版生命上限（10 颗心），兜底用
