# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 手机屏幕按钮（HUD）
#  屏幕左上角两个按钮（MC 原生风格，按钮上写着技能名）：
#    【激光】 按住不放 = 连着放，松手 = 停
#    【起飞】 点一下 = 开 / 关飞行（就在【激光】正下方）
#  另外连着跳两下也能起飞
#  屏幕右侧：药水框，框里上面是药水图标、下面是剩余时间
#  写法参考网易官方示例组件 AwesomeMod 的 fpsBattle 按钮
# ============================================================
import mod.client.extraClientApi as clientApi
from CompoundAllScripts import eyeLaserModConfig as modConfig
from CompoundAllScripts import eyeLaserConfig as cfg

ScreenNode = clientApi.GetScreenNodeCls()

# ★ 右侧药水框预留几个：几瓶药水一起喝的时候一框一框往下排
TIMER_ROWS = 5


def _fmtTime(seconds):
    # 药水剩余时间，跟原版一样写成 分:秒
    try:
        s = int(seconds)
    except Exception:
        s = 0
    if s < 0:
        s = 0
    if s >= 3600:
        return u"%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)
    return u"%d:%02d" % (s // 60, s % 60)


class EyeLaserHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mBtnLaser = self.mPanel + "/btnLaser"
        self.mBtnFly = self.mPanel + "/btnFly"
        self.mChips = [self.mPanel + "/chip%d" % i
                       for i in range(TIMER_ROWS)]
        self.mTimerOn = None
        self.mTimerRow = -1
        self.mTimerText = None
        self.mLaserDown = False

    # UI 建好后引擎会调用这里
    def Create(self):
        self._addTouch(self.mBtnLaser, self.OnLaserTouch)
        self._addTouch(self.mBtnFly, self.OnFlyTouch)
        self.SetButtonsVisible(False)   # 先藏起来，等客户端确认药水生效再露出来
        self.SetTimer(False, 0)         # 右侧药水框也先藏起来

    def SetButtonsVisible(self, visible):
        # 没喝飞行热射线的时候，屏幕上不该出现这两个按钮
        v = bool(visible)
        for path in (self.mBtnLaser, self.mBtnFly):
            self._setVisible(path, v)

    def SetTimer(self, visible, seconds, row=0):
        # 屏幕右侧的药水框：上面图标、下面剩余时间（row = 排在第几框）
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        row = self._fixRow(row)
        if show:
            self._writeChip(row, seconds)
        if self.mTimerOn == show and self.mTimerRow == row:
            return
        self.mTimerOn = show
        self.mTimerRow = row
        for i in range(TIMER_ROWS):
            self._setVisible(self.mChips[i], show and i == row)

    def _writeChip(self, row, seconds):
        try:
            left = int(seconds)
        except Exception:
            left = 0
        text = _fmtTime(left)
        if self.mTimerText == text and self.mTimerRow == self._fixRow(row):
            return
        self.mTimerText = text
        if left <= float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 10.0)):
            color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
        else:
            color = (1.0, 1.0, 1.0)
        self._setLabel(self.mChips[self._fixRow(row)] + "/num", text, color)

    def _fixRow(self, row):
        # 把行号限在 0 ~ TIMER_ROWS-1
        try:
            row = int(row)
        except Exception:
            row = 0
        if row < 0:
            row = 0
        if row > TIMER_ROWS - 1:
            row = TIMER_ROWS - 1
        return row

    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text, color=None):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            if color is not None:
                try:
                    lbl.SetTextColor(color)
                except Exception:
                    pass
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass

    def _addTouch(self, path, callback):
        try:
            self.AddTouchEventHandler(path, callback, {"isSwallow": True})
        except Exception:
            pass

    def _client(self):
        try:
            return clientApi.GetSystem(modConfig.ModName, modConfig.ClientSystemName)
        except Exception:
            return None

    def _event(self, args):
        try:
            return args.get("TouchEvent")
        except Exception:
            return None

    # 【激光】按钮：按住连发，松手停
    def OnLaserTouch(self, args):
        try:
            ev = clientApi.GetMinecraftEnum().TouchEvent
        except Exception:
            return
        t = self._event(args)
        cs = self._client()
        if not cs:
            return
        if t == ev.TouchDown:
            self.mLaserDown = True
            cs.HudLaserHold(True)
        elif t == ev.TouchUp or t == ev.TouchCancel:
            if self.mLaserDown:
                self.mLaserDown = False
                cs.HudLaserHold(False)

    # 【起飞】按钮：点一下开关飞行
    def OnFlyTouch(self, args):
        try:
            ev = clientApi.GetMinecraftEnum().TouchEvent
        except Exception:
            return
        if self._event(args) != ev.TouchUp:
            return
        cs = self._client()
        if cs:
            cs.HudFlyToggle()
