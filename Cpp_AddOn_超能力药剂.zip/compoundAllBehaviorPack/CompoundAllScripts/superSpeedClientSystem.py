# -*- coding: utf-8 -*-
# ============================================================
#  超级速度 - 客户端
#  只干一件事：药效期间在屏幕左上角显示剩余时间
# ============================================================
import time
import mod.client.extraClientApi as clientApi
from CompoundAllScripts import superSpeedModConfig as modConfig
from CompoundAllScripts import superSpeedConfig as cfg

ClientSystem = clientApi.GetClientSystemCls()


class SuperSpeedClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(SuperSpeedClientSystem, self).__init__(namespace, systemName)
        self._hudNode = None       # 左上角倒计时（HUD）
        self._hudTries = 0
        self._hudTryTime = 0.0
        self._powerOn = None       # 药效还开着吗（None = 还没收到服务端消息）
        self._powerLeft = 0        # 还剩几秒
        self._sprintOn = False     # 现在有没有在超速（服务端算的）
        self._sprintT = 0.0        # 上次检查自己疾跑状态的时间
        self._sprintSent = None    # 上次报给服务端的疾跑状态
        self._sprintSentT = 0.0    # 上次上报的时间
        self._fovDone = False
        self._fovTryTime = 0.0
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        def _L(_ns, _sn, _name, _obj, _handler):
            # 单个事件名在某些平台上可能不存在：这一条注册失败就跳过。
            # 不能让整个系统因为一个不认识的事件名而挂掉（手机端最容易踩）。
            try:
                self.ListenForEvent(_ns, _sn, _name, _obj, _handler)
            except Exception:
                pass
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        _L(ns, sn, "OnScriptTickClient", self, self.OnScriptTick)
        _L(ns, sn, modConfig.UiInitFinishedEvent, self, self.OnUIInitFinished)
        _L(ns, sn, "OnLocalPlayerStopLoading", self, self.OnStopLoading)
        # 服务端告诉我们：药效还开着没有、还剩几秒
        _L(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventPowerState, self, self.OnPowerState)

    def OnStopLoading(self, args=None):
        # 进存档：重新建一次倒计时、重新锁一次视野
        self._hudNode = None
        self._hudTries = 0
        self._fovDone = False
        self._sprintSent = None
        self._sprintT = 0.0
        self._lockFov()
        self._ensureHud()

    def OnScriptTick(self, args=None):
        now = time.time()
        self._reportSprint()       # 把自己的疾跑状态报给服务端（超速要用）
        if not self._fovDone and now - self._fovTryTime >= 1.0:
            self._fovTryTime = now
            self._lockFov()
        if self._hudNode is None and now - self._hudTryTime >= 3.0:
            self._hudTryTime = now
            self._ensureHud()          # 建失败就隔几秒再试
        self._applyHudTimer()

    def OnUIInitFinished(self, args=None):
        self._ensureHud()

    # ==================== 左上角倒计时 ====================
    def _ensureHud(self):
        if self._hudNode is not None or self._hudTries >= 300:
            return
        self._hudTries += 1
        try:
            node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            if node is None:
                clientApi.RegisterUI(modConfig.ModName, modConfig.HudUIName,
                                     modConfig.HudUIPyClsPath, modConfig.HudUIScreenDef)
                node = clientApi.CreateUI(modConfig.ModName, modConfig.HudUIName, {"isHud": 1})
                if node is None:
                    node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            self._hudNode = node
            self._applyHudTimer()
        except Exception:
            self._hudNode = None

    def OnPowerState(self, args):
        if not args:
            return
        try:
            if args.get("playerId") != clientApi.GetLocalPlayerId():
                return
            self._powerOn = int(args.get("on", 0)) == 1
            self._powerLeft = int(args.get("left", 0))
            self._sprintOn = int(args.get("sprint", 0)) == 1
        except Exception:
            return
        self._applyHudTimer()

    def _applyHudTimer(self):
        if not getattr(cfg, "MODE_HUD_TIMER", True):
            return
        node = self._hudNode
        if node is None:
            return
        left = int(self._powerLeft) if self._powerOn else 0
        show = bool(self._powerOn) and left > 0
        try:
            node.SetTimer(show, left, bool(self._sprintOn),
                          self.HudTimerRow() if show else 0)
        except Exception:
            pass

    # ==================== 左上角倒计时排版 ====================
    #  ★ 几瓶药水一起喝的时候，左上角的倒计时一行一行往下排，不会叠在一起
    _TIMER_ORDER = ("EyeLaserClientSystem", "SuperSpeedClientSystem",
                    "SoldierBoyClientSystem", "ButcherClientSystem")

    def HudTimerRows(self):
        # 我这套系统现在占了左上角几行
        if bool(self._powerOn) and int(self._powerLeft) > 0:
            return 1
        return 0


    def HudTimerRow(self):
        # 我排第几行：排在我前面、现在正显示倒计时的系统一共占了几行
        me = getattr(modConfig, "ClientSystemName", u"")
        row = 0
        for name in self._TIMER_ORDER:
            if name == me:
                break
            row += self._peerTimerRows(name)
        return row

    def _peerTimerRows(self, name):
        # 问一下那个系统：你现在占了几行
        obj = None
        try:
            obj = clientApi.GetSystem(modConfig.ModName, name)
        except Exception:
            obj = None
        if obj is None:
            return 0
        try:
            return int(obj.HudTimerRows())
        except Exception:
            return 0


    # ==================== 疾跑状态上报 ====================
    def _reportSprint(self):
        # 服务端读不到玩家的疾跑状态，只能由客户端报上去；
        # 没变化就 2 秒报一次心跳，不刷流量
        now = time.time()
        if now - self._sprintT < float(getattr(cfg, "SPRINT_REPORT", 0.12)):
            return
        self._sprintT = now
        try:
            me = clientApi.GetLocalPlayerId()
            comp = clientApi.GetEngineCompFactory().CreatePlayer(me)
            if comp is None:
                return
            sprint = bool(comp.isSprinting())
        except Exception:
            return
        if sprint == self._sprintSent and now - self._sprintSentT < 2.0:
            return
        self._sprintSent = sprint
        self._sprintSentT = now
        self._send(modConfig.EventSprintState, {"sprint": 1 if sprint else 0})

    def _send(self, eventName, extra=None):
        data = {}
        try:
            data["playerId"] = clientApi.GetLocalPlayerId()
        except Exception:
            pass
        if extra:
            data.update(extra)
        try:
            self.NotifyToServer(eventName, data)
        except Exception:
            pass

    def _lockFov(self):
        # 提速之后画面会随速度拉伸，锁住视野看着更舒服
        if self._fovDone or not getattr(cfg, "SPEED_FOV_LOCK", True):
            self._fovDone = True
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateCamera(clientApi.GetLevelId())
            comp.SetSpeedFovLock(True)
            self._fovDone = True
        except Exception:
            pass
