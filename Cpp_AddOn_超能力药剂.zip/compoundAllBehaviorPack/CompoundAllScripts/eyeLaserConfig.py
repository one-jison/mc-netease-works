# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 数值配置（想改手感，改这个文件就够了）
# ============================================================

# ---------- 自定义按键 ----------
# 这两个按键会出现在 游戏设置 -> 键盘 里，玩家可以自己改成别的键
FLY_KEY_NAME = "eye_fly"          # 按键名（内部标识）
FLY_KEY_CODE = 82                 # 默认键：R 键
FLY_KEY_CATEGORY = "movement"     # 设置里归到"移动"分类
LASER_KEY_NAME = "eye_laser"
LASER_KEY_CODE = 86               # 默认键：V 键（按住 = 连发）
LASER_KEY_CATEGORY = "gameplay"   # 设置里归到"游戏"分类

# ---------- 五号化合物（变身药水） ----------
# 只有喝下它，下面所有能力（飞行 / 眼睛激光 / 提速 / 趴着飞）才会开启，
# 维持 MODE_DURATION 秒，时间一到全部收回去。
MODE_ENABLED = True                          # False = 不喝药水也能用（回到老玩法）
MODE_ITEM = "eyelaser:compound_five"         # 药水的物品名（别改）
INTAKE_DEBUG = False   # 把"用了哪瓶药水"打到开发者日志，排查手机端不生效用；不想看日志就改 False
MODE_NAME = "飞行热射线"                      # 显示名字
MODE_DURATION = 90.0                         # ★ 喝下后维持多少秒（90 = 一分半）
MODE_WARN_AT = [30.0, 10.0, 5.0]             # 剩这些秒时各提醒一次
MODE_TIP = True                              # 药水相关提示
MODE_GIVE_COMMAND = True                     # 允许用 #化合物 拿一瓶（方便测试）
MODE_STACK = 16                              # 一次最多拿几瓶
MODE_JOIN_GIVE = True                        # 进游戏自动发药水（手机端不用打指令）
MODE_JOIN_GIVE_COUNT = 2                     # 进游戏发几瓶
MODE_REFILL_WHEN_EMPTY = False               # 药效结束后不自动补药（想让系统补一瓶就改成 True）

MODE_SYNC_INTERVAL = 0.25                   # 服务端多久检查一次药效并同步给屏幕（秒）

# ---------- 药效期间的屏幕倒计时（左上角） ----------
MODE_HUD_TIMER = True                       # ★ 喝下药水后，屏幕左上角显示剩余秒数
MODE_HUD_TIMER_FMT = u"%s 剩余 %d 秒"       # 显示格式（%s = 药水名，%d = 剩余秒数）
MODE_HUD_TIMER_COLOR = (1.0, 0.85, 0.30)    # 文字颜色（金色）
MODE_HUD_TIMER_WARN_COLOR = (1.0, 0.30, 0.25)  # 快没时间时的颜色（红）
MODE_HUD_TIMER_WARN_AT = 10.0               # 剩多少秒开始变红
MODE_HUD_TIMER_SCALE = 1.15                 # 字号缩放（1.0 = 默认大小）

# ---------- 药效期间：锁血无敌 ----------
MODE_INVINCIBLE = True                      # ★ 药效期间打不死：锁血 + 免疫所有伤害
MODE_INVINCIBLE_SURVIVAL_ONLY = True        # True = 只保护生存 / 冒险模式（创造本来就不会死）
MODE_INVINCIBLE_FULL_HP = True              # 顺便一直把血条顶满（更直观）
MODE_INVINCIBLE_REFRESH = 0.25              # 多久检查一次血条（秒）
MODE_INVINCIBLE_TIP = True                  # 变身 / 药效结束各提示一句

# ---------- 飞行 ----------
FLY_ENTER_ON_GIVE = True          # 给飞行能力时直接起飞
FLY_TIP = True                    # 开关飞行时给玩家一句提示
FLY_TAKEOFF_LIFT = True           # 开启飞行时往上抬一段，直接离地起飞
FLY_TAKEOFF_SPEED = 1.5           # 起飞抬升力度（越大飞得越高）
FLY_SPEED_MULTIPLIER = 55.0       # ★ 飞行时，飞行速度的倍数（越大飞得越快，55 = 原版的 55 倍）
FLY_SPEED_WALK_BOOST = 9.0        # ★ 飞起来时，普通移速也一起乘这么多（落地自动回到 SPEED_MULTIPLIER）
FLY_SPEED_DEFAULT = 55.0         # #飞速重置 回到的默认倍数（一般跟上面一致）
FLY_SPEED_ENABLED = True          # 飞行加速总开关
FLY_SPEED_REFRESH = 0.25          # 多久检查一次飞行状态（秒），越小反应越快
FLY_SPEED_MIN = 5.0               # 聊天指令 #飞速 x 允许的最小倍数
FLY_SPEED_MAX = 120.0              # 聊天指令 #飞速 x 允许的最大倍数

# ---- 双击跳跃起飞（手机上不占屏幕，比按钮好用）----
FLY_DOUBLE_JUMP = True        # 连着跳两下 = 起飞
FLY_DOUBLE_WINDOW = 1.0       # 两次跳跃间隔小于这么多秒，算双击
FLY_LAND_WINDOW = 0.8         # 落地后这么久内再跳一下，也算双击
FLY_TAKEOFF_GRACE = 0.7       # 刚起飞这么久内，助推顶起来的速度不算"按键"
FLY_JUMP_RISE = 0.35          # 竖直速度超过这个数，算"正在起跳"
FLY_GROUND_V = 0.06           # 竖直速度小于这个数，算"落在地上"

# ---------- 飞行姿态（趴着飞，像超人那样） ----------
FLY_POSE_FREEZE_LEGS = True     # 飞行时把原版走路动画整个停掉（腿就不会摆动了）
FLY_ROOT_ANIM_KEY = "root"      # 原版走路动画在 scripts/animate 里的键名（别改）

FLY_POSE_ENABLED = True           # 飞行时把玩家摆成趴着的姿势
#   "sprint" = 只有“飞行 + 疾跑”才趴（电脑双击 W / 手机奔跑按钮）—— 默认
#   "speed"  = 按速度判断（飞得够快 + 在天上 + 持续一小会儿）
#   "both"   = 上面任一条满足就趴
FLY_POSE_MODE = "sprint"
FLY_POSE_SPRINT_REPORT = 0.2     # 客户端多久把自己疾跑状态报给服务端一次（秒）
FLY_POSE_KEY = "eyelaser_prone"   # 动画短名（内部用）
FLY_POSE_ANIM = "animation.eyelaser.prone"
FLY_POSE_VAR = "query.mod.eyelaserfly"      # 1 = 正在飞（用来冻结走路动画，腿不动）
FLY_POSE_PRONE_VAR = "query.mod.eyelaserprone"  # 1 = 趴下

# 以下几行只在 FLY_POSE_MODE 为 "speed" 或 "both" 时生效：
# 一边飞一边往前冲就趴；悬停、慢慢漂、站着都是站姿
FLY_POSE_MIN_SPEED = 3.0     # ★ 飞多快才趴下（格/秒），比这快才算奔跑飞行
FLY_POSE_STOP_SPEED = 1.5    # ★ 掉到多慢就站起来（比上面小，形成迟滞，不会一快一慢乱抖）
FLY_POSE_HOLD_TIME = 0.0     # ★ 冲多久才趴（0 = 一动就趴；想加起手延迟就调大）
FLY_POSE_SPEED_CAP = 3000.0  # ★ 速度采样的传送过滤线（格/秒）
                              #   飞行提速后速度会远超 500，这条线太低的话
                              #   会把正常飞行误判成传送，飞得越快反而越不趴
FLY_POSE_NEED_AIRBORNE = True  # ★ 必须真的在天上：贴地跑 / 站在地上不算飞行奔跑，不趴
FLY_POSE_REFRESH = 0.25      # 多久检查一次速度（秒），越小切换越跟手

# 只有真趴下（冲刺飞行）时，眼睛的位置才变（不然激光会从身体里冒出来）；
# 站着飞 / 悬停 / 站在地面都用下面那两个原版高度
LASER_EYE_HEIGHT_FLYING = 0.45
LASER_ORIGIN_FORWARD_FLYING = 1.15

# ---------- 眼睛激光 ----------
LASER_ENABLED = True              # 激光总开关
LASER_DAMAGE = 8.0                # ★ 单道激光命中伤害（两只眼睛都打中 = 双倍）
LASER_COOLDOWN = 0.35             # ★ 单点一下的冷却（秒）
LASER_COOLDOWN_HOLD = 0.10        # ★ 长按时的间隔（秒），越小越连贯，看起来就像一直不断
LASER_RANGE = 40                  # ★ 射程（格）
LASER_EYE_HEIGHT = 1.62           # 眼睛离脚底多高（原版是 1.62）
LASER_EYE_GAP = 0.22              # 两只眼睛左右各偏多少格（这就是"两道激光"的来源）
LASER_ORIGIN_FORWARD = 0.35       # 射线起点往前推一点，免得打到自己
HURT_SELF = False                 # 会不会被自己的激光打到（False = 不会）
HURT_CREATIVE = False             # 会不会打到创造模式的玩家（False = 不会）

# ---------- 移速提升 ----------
SPEED_ENABLED = True              # 进存档就自动给玩家提速
SPEED_MULTIPLIER = 3.0            # ★ 速度倍数（3.0 = 原版的 3 倍，想更快要更大）
SPEED_BASE_WALK = 0.1             # 原版玩家走路移速（别改）
SPEED_BASE_FLY = 0.05             # 原版玩家飞行速度（别改）
SPEED_BOOST_FLYING = True         # 飞行速度要不要一起变快
SPEED_REFRESH = 1.0               # 每隔几秒重新套用一次（重生/换维度后自动补回来）
SPEED_FOV_LOCK = True             # 锁住镜头视野，高速跑动时画面不会拉变形
SPEED_TIP = True                  # 开关提速时给一句提示
SPEED_MIN = 0.5                   # 聊天指令 #速度 x 允许的最小倍数
SPEED_MAX = 10.0                  # 聊天指令 #速度 x 允许的最大倍数

# ---------- 激光打方块（破坏力） ----------
LASER_BREAK_ENABLED = True        # 激光能不能打掉方块
LASER_BREAK_MAX_BLOCKS = 48       # ★ 一道激光每次最多打掉多少个方块（性能保护）
LASER_BREAK_RADIUS = 0            # 0 = 只打穿 1 格宽的隧道；1 = 3x3 粗隧道；2 = 5x5
LASER_BREAK_BLACKLIST = [         # 这些方块打不动，而且会把激光挡住
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:light_block",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:end_portal",
    "minecraft:end_portal_frame",
    "minecraft:end_gateway",
    "minecraft:portal",
    "minecraft:allow",
    "minecraft:deny",
    "minecraft:border_block",
    "minecraft:reinforced_deepslate",
    "minecraft:moving_block",
    "minecraft:water",
    "minecraft:flowing_water",
    "minecraft:lava",
    "minecraft:flowing_lava",
]

# ---------- 激光引火（打到哪烧到哪） ----------
LASER_FIRE_ENABLED = True         # ★ 激光打中的地方会不会烧起来
LASER_FIRE_SPREAD = 0             # ★ 着火点往四周蔓延几格（0 = 只烧命中的那一格）
LASER_FIRE_MAX = 1                # ★ 一次开枪（两只眼睛合起来）最多点几处火
LASER_FIRE_CHANCE = 1.0           # 着火的概率（1.0 = 必着）
LASER_FIRE_PER_SHOT = True        # ★ 每一枪都点火：长按扫射时，火跟着光束一路烧过去
                                  #   False = 一次开火（按住不放）只点第一枪那一格
LASER_FIRE_MIN_GAP = 0.0          # 两次点火之间至少隔几秒（0 = 不隔；嫌火烧得密可以改 0.4）
LASER_FIRE_MIN_DIST = 2.0         # ★ 离自己多近之内不点火（安全兜底，不会烧到自己脚下）
LASER_FIRE_AHEAD = 3              # ★ 打中的那一格已经烧着了的话，往光束里再试几格
LASER_FIRE_BLACKLIST = [          # 站在这些方块上面点不着火（水 / 岩浆 / 基岩之类）
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:light_block",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:reinforced_deepslate",
    "minecraft:moving_block",
]

# ---------- 光束表现（一体化连续光束） ----------
# ★ 每只眼睛只画一条连续的红线：从眼睛一直连到命中点，
#   中间不断开，也不是粒子拼出来的。
#   “粗一点”的那圈光是靠下面的外发光做出来的。
FX_ON = True                      # ★ 光束总开关
FX_BEAM_LINE = True               # ★ 用渲染组件画线段（主力光束，必须开）
FX_BEAM_LINE_COLOR = (1.0, 0.70, 0.64)   # 光束正中间那一条线（发白的亮芯）
# 加粗：中心一条线，外面套几圈同方向的线。
# 圈越往外颜色越暗，所以看起来是一条有亮芯、
# 边缘发暗的粗线（全部是线，没有粒子）。
# 每一圈：(半径格, 线条数, 颜色)
FX_BEAM_LINE_HALO = [
    (0.025, 6, (0.92, 0.18, 0.13)),
    (0.055, 8, (0.45, 0.06, 0.05)),
]
FX_BEAM_LINE_PRIORITY = 10        # 渲染优先级，调高免得被地形盖住

# 再试一个更加粗的办法：引擎自带的“箭头”形状自带半径，
# 如果能吃住，激光就是一根实心的粗线。头部故意留得很短，不像箭。
FX_BEAM_ARROW = True              # 关掉就只剩下面那束细线
FX_BEAM_ARROW_RADIUS = 0.055      # 激光半径（格），0.055 ≈ 眼睛粗细
FX_BEAM_ARROW_HEAD = 0.10         # 箭头尖那一小截的长度

# 备用画法（把整束光切成几段拉长的光条）：只在渲染组件用不了时自动顶上
FX_BEAM_ROD = False               # 手动开关，正常不用开
FX_BEAM_ROD_WIDTH = 0.13          # 每段光条的粗细（格）
FX_BEAM_ROD_SEG = 3.6             # 每段光条多长（格）
FX_BEAM_ROD_STEP = 3.1            # 相邻两段的间距（格），比段长小，所以首尾相接
FX_BEAM_ROD_MAX = 4               # 每道激光画几段

# 光束外面那圈红光：就是中间那条亮线外面裹着的红色光圈。
# 沿光束铺一串平头的红光，间距只有它们尺寸的一大半，
# 完全重叠在一起就是一整条光圈，看不出一个个点。
FX_BEAM_GLOW = False              # ★ 外面那圈光（一串粒子）：关掉，激光只用线画，一个小球都没有
FX_BEAM_GLOW_STEP = 0.15          # 内部密度（越小越实，太小会卡）
FX_BEAM_GLOW_SIZE = 0.28          # ★ 粗细（格）：0.16≈眼睛粗细 / 0.28 现在这个 / 0.45 粗
FX_BEAM_GLOW_SPAN = 6.0           # 粗线画到眼前多远（格）
FX_BEAM_GLOW_START = 0.45         # 从眼前多远开始铺
FX_BEAM_GLOW_TAPER = 0.0          # 0 = 粗细一直不变（像一条粗线）
FX_BEAM_GLOW_MAX = 40             # 每道激光最多铺多少个（性能保护）

# 自己开火时避开镜头，不糊视线
FX_SELF_FORWARD = 0.70            # 第三人称：表现从眼前多远开始画
FX_FP_FORWARD = 1.20              # 第一人称：再往前挪一点
FX_SELF_HALO_START = 1.00         # 自己开火时，粗线从眼前多远才开始画
FX_SELF_NO_MUZZLE = True          # 自己开火时不画眼睛处的闪光

# 只有“点”上的特效（一个光点，不会串成一串，也不影响光束形态）
FX_MUZZLE_PARTICLE = True         # 眼睛处闪一下
FX_IMPACT_PARTICLE = True         # 命中点爆一下

FX_SOUND_ENABLED = True           # 是否播放音效
LASER_SOUND = "random.fizz"       # ★ 激光的“滋滋”声（像滋滋电流）
LASER_SOUND_FALLBACK = "fire.ignite"
LASER_SOUND_VOLUME = 0.55       # 音量
LASER_SOUND_PITCH = 1.35        # 音调（越高越尖、越像激光）

# ============================================================
#  喷溅型飞行热射线（扔出去，一片人一起变身）
#  喝下去的那瓶 = 自己变身；
#  这瓶是"喷溅型"，扔出去落地后，附近的人一起变身。
# ============================================================
SPLASH_ENABLED = True                            # 喷溅型总开关
SPLASH_ITEM = "eyelaser:compound_five_splash"    # 喷溅型药水的物品名（别改）
SPLASH_NAME = u"喷溅型飞行热射线"                     # 提示里显示的名字
SPLASH_PROJECTILE = "minecraft:splash_potion"    # 扔出去的是原版喷溅药水（别改）

SPLASH_RADIUS = 5.0            # ★ 落地后多少格内的玩家一起中招（想大一点就调这个）
SPLASH_AFFECT_SELF = True      # True = 砸在自己脚下，自己也变身
SPLASH_DURATION = 90.0         # 中招后维持多少秒（和喝下去的一样：一分半）

SPLASH_POWER = 1.25            # 扔出去的力量（越大扔得越远）
SPLASH_GRAVITY = 0.06          # 重力因子（越小飞得越平、越远）
SPLASH_THROW_UP = 0.18         # 出手时稍微往上抬一点，扔得更远
SPLASH_TIMEOUT = 8.0           # 扔出去多久还没落地就放弃等待（秒）

SPLASH_COOLDOWN = 0.45         # 两次投掷之间最短间隔（秒），防止一次点击扔出两瓶
SPLASH_JOIN_GIVE = 1           # 进游戏送几瓶喷溅型（0 = 不送）
SPLASH_TIP = True              # 扔出去 / 中招时提示一句
SPLASH_GET_COMMAND = True      # 允许聊天输 #喷溅 拿一瓶（电脑端测试方便）

# ============================================================
#  喷溅型砸到生物：那只生物也变身，自己乱飞 + 随机放激光
#  只有"被砸中的那一只"会变身，旁边的生物不会跟着变。
# ============================================================
MOB_POWER_ENABLED = True        # ★ 砸中非玩家生物时，那只生物也获得能力
MOB_POWER_DURATION = 90.0       # 生物维持多少秒（默认和玩家一样：一分半）
MOB_POWER_MAX = 6               # 同时最多几只能变身（性能保护）
MOB_POWER_TIP = True            # 变身时提醒附近玩家一句

# ---- 生物飞行（随机乱飘，像喝醉了在飞）----
MOB_FLY_ENABLED = True
MOB_FLY_SPEED = 0.42            # ★ 每一次推动的力度（越大飞得越快）
MOB_FLY_HEIGHT = 7.0            # ★ 最多飘到变身点上方多高（格）
MOB_FLY_RANGE = 16.0            # 以变身点为中心，最多飘出去多远（格）
MOB_FLY_RETARGET_MIN = 1.2      # 多久换一次飞行目标（秒）
MOB_FLY_RETARGET_MAX = 3.0

# ---- 生物激光（随机时机开火）----
MOB_LASER_ENABLED = True
MOB_LASER_INTERVAL_MIN = 1.6    # ★ 两次开火之间最少隔多少秒
MOB_LASER_INTERVAL_MAX = 3.8    # ★ 最多隔多少秒
MOB_LASER_RANGE = 32            # 射程（格）
MOB_LASER_AIM = "nearest"       # "nearest" = 打最近的玩家 / "random" = 完全随机方向
MOB_LASER_BREAK = True          # ★ 生物的激光也能打穿方块（不想让它拆家就改 False）
MOB_LASER_HURT = True           # 生物的激光能伤到玩家 / 生物


# ============================================================
#  三种喷溅型药水：扔出去，落地后附近的人一起变身
#  左边是物品名，右边是"哪一瓶"。想再加新药水，在这里加一行就行。
# ============================================================
SPLASH_KINDS = {
    "eyelaser:compound_five_splash": "eyelaser",
    "superspeed:potion_splash": "superspeed",
    "soldierboy:compound_v_splash": "soldierboy",
}

# 提示里显示的名字
SPLASH_DISPLAY = {
    "eyelaser": u"喷溅型飞行热射线",
    "superspeed": u"喷溅型超级速度",
    "soldierboy": u"喷溅型V1化合物",
}

# 进游戏每种送几瓶（0 = 不送）
SPLASH_JOIN_ITEMS = [
    "eyelaser:compound_five_splash",
    "superspeed:potion_splash",
    "soldierboy:compound_v_splash",
]

# ============================================================
#   喷溅型砸到非玩家生物：每一瓶对应它自己的能力
#     飞行热射线    -> 飞起来 + 随机打激光
#     超级速度    -> 随机到处乱跑
#     V1化合物  -> 随机在附近某个地方爆炸
# ============================================================
MOB_SPLASH_POWER = {
    "eyelaser": "laser",
    "superspeed": "speed",
    "soldierboy": "explode",
}
MOB_SPLASH_RANDOM = False      # True = 不看哪一瓶，统一在下面这两种里随机挑
MOB_SPLASH_RANDOM_POOL = ("speed", "explode")
MOB_SPLASH_REROLL = False      # True = 变身期间随机换成另一种能力
MOB_SPLASH_REROLL_MIN = 6.0
MOB_SPLASH_REROLL_MAX = 13.0

# ---- 生物的 “超级速度”：随机挑方向，一路乱跑 ----
MOB_SPEED_ENABLED = True
MOB_SPEED_POWER = 1.35         # ★ 跑得多快（越大越猛）
MOB_SPEED_UP = 0.18            # 带一点向上，看起来像连蹦带跑
MOB_SPEED_GAP_MIN = 0.6        # ★ 多久换一次奔跑方向（秒）
MOB_SPEED_GAP_MAX = 1.5

# ---- 生物的 “爆炸”：随机时机在附近某个地方炸一下 ----
MOB_BOOM_ENABLED = True
MOB_BOOM_GAP_MIN = 6.0         # ★ 两次爆炸之间最少隔多少秒
MOB_BOOM_GAP_MAX = 12.0
MOB_BOOM_SCATTER = 3.0         # ★ 炸点在它周围多少格内随机挑（0 = 就在脚下）
# 注意：下面这三个真正的数值放在 CompoundAllScripts/soldierBoyConfig.py 里
#       （炸坑 / 清药水都归那边管），这里留着只是方便对照
MOB_BOOM_RADIUS = 9.0          # 炸多大（半径，格）：9 = 直径 18 格
MOB_BOOM_BREAK = True          # 生物的爆炸也炸方块（不想让它拆家就改 False）
MOB_BOOM_DAMAGE = 12.0         # 没药水的玩家被炸到扣多少血（12 = 6 颗心）
MOB_BOOM_TIP_RANGE = 40.0      # 多远之内的玩家能看到提醒
MOB_BOOM_CHARGE = True        # ★ 生物炸之前也要蓄力（身上亮起黄金光），蓄满才炸
MOB_BOOM_CHARGE_TIME = 5.0    # ★ 生物蓄力多久才炸开（秒）
MOB_BOOM_CHARGE_FX = True     # ★ 蓄力时身上冒黄金光
MOB_BOOM_CHARGE_FX_INTERVAL = 0.12   # 金光多久亮一次（秒）
MOB_BOOM_CHARGE_UP = 0.9      # ★ 金光的位置：脚底往上抬多少格（生物胸口高度）
