# -*- coding: utf-8 -*-
# ============================================================
#  屠夫 / 超级愈合 — 公共配置（模组名 / 事件名 / 界面名）
# ============================================================
ModName = "CompoundPotionMod"
ModVersion = "1.0.0"

ServerSystemName = "ButcherServerSystem"
ClientSystemName = "ButcherClientSystem"
ServerSystemClsPath = "CompoundAllScripts.butcherServerSystem.ButcherServerSystem"
ClientSystemClsPath = "CompoundAllScripts.butcherClientSystem.ButcherClientSystem"

# 客户端 -> 服务端
EventAttack = "ButcherAttack"        # 屏幕上那个方形【攻击】按钮被按下了

# 服务端 -> 这个玩家自己（药效剩余时间 / 攻击冷却 / 按钮显不显示）
EventState = "ButcherState"
# 服务端 -> 所有客户端（谁背上长着触手：一张名单）
EventTentacle = "ButcherTentacle"
# 服务端 -> 所有客户端（谁刚甩了一下触手）
EventSwing = "ButcherSwing"

# 手机屏幕按钮 + 左上角倒计时
UiInitFinishedEvent = "UiInitFinished"
HudUIName = "butcherHud"
HudUIPyClsPath = "CompoundAllScripts.butcherHudScreen.ButcherHudScreen"
HudUIScreenDef = "butcherhud.main"
