# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 服务端
#  负责：飞行开关 / 眼睛激光判定 / 把光束广播给所有客户端
# ============================================================
import math
import random
import time
import mod.server.extraServerApi as serverApi
from CompoundAllScripts import eyeLaserModConfig as modConfig
from CompoundAllScripts import eyeLaserConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()

# 这些方块不算“踩着地”（站在水里 / 岩浆上也不算飞行贴地）
_NO_GROUND_BLOCKS = (u"minecraft:air", u"minecraft:water",
                     u"minecraft:flowing_water", u"minecraft:lava",
                     u"minecraft:flowing_lava")

# ★ 激光引火：火方块
FIRE_BLOCK = {"name": "minecraft:fire", "aux": 0}
# 激光不会打掉的东西（直接穿过去）
_NO_BREAK_THROUGH = (u"minecraft:fire", u"minecraft:soul_fire")
# 底下是这些东西就点不着火
_NO_FIRE_UNDER = (u"minecraft:air", u"minecraft:water", u"minecraft:flowing_water",
                  u"minecraft:lava", u"minecraft:flowing_lava",
                  u"minecraft:fire", u"minecraft:soul_fire")


class EyeLaserServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(EyeLaserServerSystem, self).__init__(namespace, systemName)
        self._lastFire = {}        # playerId -> 上次开火时间
        self._fireArmed = {}       # playerId -> 这一次开火还能不能点火（松手后重新给名额）
        self._lastBeamFire = {}    # playerId -> 上次真的点着火的时间
        self._holding = set()      # 正按住激光键的玩家
        self._autoFire = set()     # 开了"激光连发"的玩家
        self._welcomed = set()
        self._protect = None       # 打不动的方块名单（第一次用到时再建）
        self._speedOff = set()     # 主动关掉提速的玩家
        self._speedT = 0.0         # 上次检查移速的时间
        self._flyTaken = {}        # playerId -> 上一次套用的是不是“飞行加速”
        self._powerUntil = {}      # playerId -> 五号化合物失效的时间戳
        self._potionAt = {}         # playerId -> 什么时候把进游戏送的药水放进背包
        self._powerWarned = {}     # playerId -> 已经提醒过的秒数
        self._powerTipT = {}       # playerId -> 上次“没药水”提示的时间
        self._flyT = 0.0           # 上次检查飞行状态的时间
        self._powerState = {}      # playerId -> 上次同步给客户端的药水开关（0 / 1）
        self._powerSyncT = 0.0     # 上次同步"药水开关"的时间
        self._gmCache = {}         # playerId -> (游戏模式, 采样时间)：判断是不是生存模式
        self._fxWarned = set()     # 已经提醒过"画不出光束线"的玩家
        self._hpT = 0.0            # 上次把血条顶满的时间
        self._lastPos = {}         # playerId -> 上次记下的位置（用来算移动速度）
        self._lastPosT = {}        # playerId -> 上次记位置的时间
        self._flySent = {}         # playerId -> 上次发出去的（飞行, 趴姿）
        self._poseSyncT = 0.0      # 上次同步飞行 / 趴姿的时间
        self._poseForceT = 0.0     # 上次强制重发飞行状态的时间
        self._poseOn = bool(cfg.FLY_POSE_ENABLED)   # 趴着飞的开关
        self._proneNow = {}        # playerId -> 现在到底趴不趴（给开火时取眼睛高度用）
        self._proneSpeed = {}      # playerId -> 上一次量到的水平速度（排查用）
        self._fastSince = {}       # playerId -> 什么时候开始持续冲刺（判定“起趴”）
        self._sprint = {}          # playerId -> 客户端报上来的疾跑状态
        self._sprintT = {}         # playerId -> 上次收到疾跑状态的时间
        self._splash = {}          # 喷溅药水id -> 谁扔的 / 什么时候扔的 / 飞到哪了
        self._splashAt = {}        # playerId -> 上次扔喷溅药水的时间
        self._mobPower = {}        # 生物id -> 变身到什么时候结束
        self._mobFly = {}          # 生物id -> 飞行状态（家在哪儿 / 现在往哪飘 / 下次换目标）
        self._mobFire = {}         # 生物id -> 下次开火时间
        self._mobState = {}        # 生物id -> 这次变身是哪种能力（速度 / 爆炸 / 激光）
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        def _L(_ns, _sn, _name, _obj, _handler):
            # 单个事件名在某些平台上可能不存在：这一条注册失败就跳过。
            # 不能让整个系统因为一个不认识的事件名而挂掉（手机端最容易踩）。
            try:
                self.ListenForEvent(_ns, _sn, _name, _obj, _handler)
            except Exception:
                pass
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        _L(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        _L(ns, sn, "ServerChatEvent", self, self.OnChat)
        # 服务端 tick：负责"按住不放 = 连发"
        _L(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventFlyToggle, self, self.OnFlyToggle)
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventLaserHold, self, self.OnLaserHold)
        # 五号化合物：喝下去的时候认一下
        _L(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        _L(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)
        _L(ns, sn, "ItemUseAfterServerEvent", self, self.OnAfterUse)
        # 药效期间锁血无敌：三层拦截，任何掉血路径都挡住
        for evtName, handler in ((u"DamageEvent", self.OnDamage),
                                 (u"ActuallyHurtServerEvent", self.OnActuallyHurt),
                                 (u"HealthChangeBeforeServerEvent",
                                  self.OnHealthChangeBefore)):
            try:
                _L(ns, sn, evtName, self, handler)
            except Exception:
                pass
        # 客户端报上来的疾跑状态（趴姿 + 激光起点都要用）
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventSprintState, self, self.OnSprintState)
        # 客户端画不出线段时喊一声（渲染组件不可用）
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventFxWarn, self, self.OnFxWarn)
        # 聊天指令 #光束测试 的回执
        _L(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventBeamTestResult, self,
                            self.OnBeamTestResult)
        # 喷溅型飞行热射线：点一下就是"扔出去"
        try:
            _L(ns, sn, "ServerItemTryUseEvent", self,
                                self.OnItemTryUse)
        except Exception:
            pass
        # 喷溅型飞行热射线：瓶子落地
        try:
            _L(ns, sn, "ProjectileDoHitEffectEvent", self,
                                self.OnProjectileHit)
        except Exception:
            pass

    # ==================== 小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _rotOf(self, entityId):
        try:
            rot = serverApi.GetEngineCompFactory().CreateRot(entityId).GetRot()
            return float(rot[0]), float(rot[1])
        except Exception:
            return 0.0, 0.0

    def _dimensionOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    # ==================== 五号化合物（变身能力） ====================
    def _powerOn(self):
        return bool(getattr(cfg, "MODE_ENABLED", True))

    def _powerLeftOf(self, playerId):
        if not self._powerOn():
            return 999999.0
        return max(0.0, float(self._powerUntil.get(playerId, 0.0)) - time.time())

    def _hasPower(self, playerId):
        # 没开这个玩法就当作一直有能力
        if not self._powerOn():
            return True
        return self._powerLeftOf(playerId) > 0.0

    def _syncPowerState(self, playerId, force=False):
        # 把"五号化合物还开着没有 + 还剩几秒"告诉这个玩家的客户端；
        # 客户端拿它决定手机按钮显不显示、屏幕左上角倒计时写什么
        on = 1 if self._hasPower(playerId) else 0
        left = int(math.ceil(self._powerLeftOf(playerId))) if on else 0
        sig = (on, left)
        if not force and self._powerState.get(playerId) == sig:
            return
        try:
            self.NotifyToClient(playerId, modConfig.EventPowerState,
                                {"playerId": playerId, "on": on, "left": left})
        except Exception:
            return          # 没发出去就先不记，等下一轮继续发
        self._powerState[playerId] = sig

    def _givePower(self, playerId, reason=u"", dur=None):
        if dur is None:
            dur = float(getattr(cfg, "MODE_DURATION", 90.0))
        dur = float(dur)
        left = self._powerLeftOf(playerId)
        self._powerUntil[playerId] = time.time() + dur
        self._powerWarned[playerId] = set()
        self._boostSpeed(playerId)          # 提速立刻生效
        self._syncPowerState(playerId, force=True)   # 按钮立刻出现
        if not getattr(cfg, "MODE_TIP", True):
            return
        if left > dur - 1.0:
            return                          # 刚刚已经提醒过，不重复刷屏
        if left > 0.0:
            self._tip(playerId, u"%s 时间已刷新，再来 %d 秒" % (cfg.MODE_NAME, int(dur)), "LIGHT_PURPLE")
        else:
            self._tip(playerId, u"%s 生效：飞行 + 眼睛激光 + 提速 全部开启，维持 %d 秒，屏幕按钮已出现" % (cfg.MODE_NAME, int(dur)), "LIGHT_PURPLE")
        if getattr(cfg, "MODE_INVINCIBLE_TIP", True) and self._invincibleOn():
            if self._isPowerProtected(playerId):
                self._tip(playerId, u"药效期间你是无敌的：打不死、血条不掉、也不会被击退",
                          "GREEN")

    def _losePower(self, playerId, quiet=False):
        self._powerUntil.pop(playerId, None)
        self._powerWarned.pop(playerId, None)
        # 药效没了：正在连发的激光也一起停掉，屏幕按钮马上收起
        self._holding.discard(playerId)
        self._autoFire.discard(playerId)
        self._fireArmed.pop(playerId, None)        # 点火名额一并清掉
        self._lastBeamFire.pop(playerId, None)
        self._syncPowerState(playerId, force=True)
        # 飞行收回去
        try:
            comp = self._flyComp(playerId)
            if comp is not None and bool(comp.IsPlayerFlying()):
                comp.ChangePlayerFlyState(False)
        except Exception:
            pass
        self._flyTaken[playerId] = False
        self._restoreSpeed(playerId)        # 速度回到原版
        self._syncFlyState(playerId)
        if quiet:
            return
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"%s 已失效，能力全部收回，屏幕按钮已收起" % cfg.MODE_NAME, "GOLD")
        # 默认不补药；MODE_REFILL_WHEN_EMPTY 打开时才会自动补一瓶
        self._refillIfEmpty(playerId)

    # ==================== 药效期间：锁血无敌 ====================
    def _invincibleOn(self):
        return bool(getattr(cfg, "MODE_INVINCIBLE", True)) and self._powerOn()

    def _gameTypeOf(self, playerId):
        # 玩家的游戏模式（0 生存 / 1 创造 / 2 冒险 / 6 旁观）
        # 拿不到就返回 None，调用方按"要保护"处理
        now = time.time()
        hit = self._gmCache.get(playerId)
        if hit and now - hit[1] < 2.0:
            return hit[0]
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(
                serverApi.GetLevelId())
            gt = int(comp.GetPlayerGameType(playerId))
        except Exception:
            return None
        self._gmCache[playerId] = (gt, now)
        return gt

    def _isPowerProtected(self, playerId):
        # 这个玩家现在要不要保护（药效还在 + 是生存 / 冒险模式）
        if not self._invincibleOn() or not playerId:
            return False
        try:
            if playerId not in (serverApi.GetPlayerList() or []):
                return False
        except Exception:
            return False
        if not self._hasPower(playerId):
            return False
        if not getattr(cfg, "MODE_INVINCIBLE_SURVIVAL_ONLY", True):
            return True
        gt = self._gameTypeOf(playerId)
        if gt is None:
            return True              # 问不到游戏模式，宁可多保护一层
        gameType = serverApi.GetMinecraftEnum().GameType
        return gt in (int(gameType.Survival), int(gameType.Adventure))

    def _keepFullHp(self, playerId):
        # 兜底：就算有伤害绕过了前面几层，也把血条顶回去
        if not getattr(cfg, "MODE_INVINCIBLE_FULL_HP", True):
            return
        attr = self._attrComp(playerId)
        if attr is None:
            return
        AttrType = serverApi.GetMinecraftEnum().AttrType
        try:
            mx = float(attr.GetAttrMaxValue(AttrType.HEALTH))
            cur = float(attr.GetAttrValue(AttrType.HEALTH))
        except Exception:
            return
        if mx <= 0.0 or cur >= mx - 0.01:
            return
        try:
            attr.SetAttrValue(AttrType.HEALTH, mx, 0)
        except Exception:
            pass

    def OnDamage(self, args):
        # 将要受伤：药效期间把伤害抹平，连击退、点燃一起免掉
        try:
            entityId = args.get("entityId")
            if not self._isPowerProtected(entityId):
                return
            args["damage"] = 0
            args["knock"] = False
            args["ignite"] = False
        except Exception:
            pass

    def OnActuallyHurt(self, args):
        # 护甲 / buff 算完之后的真实伤害：再抹一次
        try:
            entityId = args.get("entityId")
            if not self._isPowerProtected(entityId):
                return
            args["damage"] = 0
        except Exception:
            pass

    def OnHealthChangeBefore(self, args):
        # 生命值变化之前：只要是往下掉就取消（火焰、中毒、掉虚空都算）
        try:
            entityId = args.get("entityId")
            if not entityId or args.get("byScript"):
                return
            if not self._isPowerProtected(entityId):
                return
            try:
                frm = float(args.get("from", 0.0))
                to = float(args.get("to", 0.0))
            except Exception:
                return
            if to < frm:
                args["cancel"] = True
        except Exception:
            pass


    def _warnNoPower(self, playerId):
        if not getattr(cfg, "MODE_TIP", True):
            return
        now = time.time()
        if now - float(self._powerTipT.get(playerId, 0.0)) < 3.0:
            return                          # 别一直刷屏
        self._powerTipT[playerId] = now
        self._tip(playerId, u"还没有能力：先喝一瓶 %s（聊天输 #化合物 可以拿一瓶）" % cfg.MODE_NAME, "RED")

    def _hasItem(self, playerId, itemName):
        # 背包里有没有这个物品
        want = str(itemName or "").lower()
        if not want:
            return False
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            posType = serverApi.GetMinecraftEnum().ItemPosType
            for item in comp.GetPlayerAllItems(posType.INVENTORY):
                if not item:
                    continue
                name = item.get("newItemName") or item.get("itemName") or ""
                if str(name).lower() == want:
                    return True
        except Exception:
            return False
        return False

    def _hasPotion(self, playerId):
        # 背包里还有没有五号化合物
        return self._hasItem(playerId, getattr(cfg, "MODE_ITEM", ""))

    def _giveJoinPotion(self, playerId):
        # 手机端不好打指令：进游戏先把药水放背包里，点按钮就能玩
        if not getattr(cfg, "MODE_JOIN_GIVE", True) or not self._powerOn():
            return
        # 喷溅型也顺手发，手机端直接点屏幕就能扔
        splashNum = int(getattr(cfg, "SPLASH_JOIN_GIVE", 0) or 0)
        if splashNum > 0 and self._splashOn():
            for iid in (getattr(cfg, "SPLASH_JOIN_ITEMS", None)
                        or [getattr(cfg, "SPLASH_ITEM", "")]):
                if not iid or self._hasItem(playerId, iid):
                    continue
                self._giveSplashItem(playerId, splashNum, iid)
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, int(getattr(cfg, "MODE_JOIN_GIVE_COUNT", 2)))

    def _refillIfEmpty(self, playerId):
        # 变身时间到：按配置决定要不要补一瓶（MODE_REFILL_WHEN_EMPTY，默认关）
        if not getattr(cfg, "MODE_REFILL_WHEN_EMPTY", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, 1)
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"变身时间到，背包里补了一瓶 %s，喝掉就能接着玩" % cfg.MODE_NAME,
                      "LIGHT_PURPLE")

    def _givePotionItem(self, playerId, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            itemDict = {"itemName": cfg.MODE_ITEM, "count": int(num), "auxValue": 0}
            ok = comp.SpawnItemToPlayerInv(itemDict, playerId)
            if getattr(cfg, "MODE_TIP", True):
                if ok:
                    self._tip(playerId, u"已获得 %s ×%d，喝下去就能变身" % (cfg.MODE_NAME, int(num)), "LIGHT_PURPLE")
                else:
                    self._tip(playerId, u"背包放不下，先清一格再试", "RED")
        except Exception:
            pass

    # ==================== 用药识别（手机端 / 电脑端都认） ====================
    def _actorIdOf(self, args):
        # 不同事件给的键不一样：playerId / entityId / id 都认一遍
        if not isinstance(args, dict):
            return None
        for k in ("playerId", "entityId", "id"):
            v = args.get(k)
            if v:
                return v
        return None

    def _itemIdOf(self, itemDict):
        # 有的版本给 newItemName，有的给 itemName，两个都认
        if not isinstance(itemDict, dict):
            return u""
        for k in ("newItemName", "itemName"):
            v = itemDict.get(k)
            if v:
                return str(v).lower()
        return u""

    def _debugIntake(self, playerId, itemDict, src):
        # 这里只是打日志，绝对不能让它的异常把喝药流程带崩
        try:
            self._debugIntakeInner(playerId, itemDict, src)
        except Exception:
            pass

    def _debugIntakeInner(self, playerId, itemDict, src):
        # 排查用：把用到的物品名打到开发者日志（cfg.INTAKE_DEBUG 控制）
        if not getattr(cfg, "INTAKE_DEBUG", False):
            return
        name = self._itemIdOf(itemDict)
        if name:
            if name.split(":")[0] in ("eyelaser", "superspeed", "soldierboy",
                                      "butcher"):
                print(u"[药剂自检] 玩家=%s 事件=%s 物品=%s" % (playerId, src, name))
        elif src in ("try", "eat") and isinstance(itemDict, dict) and itemDict:
            keys = sorted([str(k) for k in itemDict.keys()])
            print(u"[药剂自检] 玩家=%s 事件=%s 物品名没取到，可用键=%s"
                  % (playerId, src, u",".join(keys)))

    # ==================== "真的喝了"的判定 ====================
    # 老写法是"手一点到药水就立刻生效"，玩家还没喝就变身了。
    # 现在改成：按下使用键只记一笔，确认喝下去（吃完 / 药水真的少了一瓶）才给效果。
    _DRINK_HOLD_MIN = 0.45      # 使用键至少按住这么久才算喝下去（点一下不算）

    def _drinkTestMap(self):
        d = getattr(self, "_drinkTest", None)
        if d is None:
            d = {}
            self._drinkTest = d
        return d

    def _drinkPress(self, playerId, itemName, grant):
        # 玩家刚按下使用键：先记一笔，不马上给效果
        slot, cnt = -1, 1
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
            slot = int(comp.GetSelectSlotId())
            item = comp.GetPlayerItem(ItemPosType.INVENTORY, slot, True) or {}
            cnt = int(item.get("count", 1) or 1)
        except Exception:
            pass
        self._drinkTestMap()[playerId] = {"t": time.time(), "slot": slot,
                                          "count": cnt, "name": itemName,
                                          "grant": grant}

    def _drinkConfirm(self, playerId, grant):
        # 确认真的喝下去了：给效果（同一次喝药只给一遍，免得倒计时被刷两回）
        self._drinkTestMap().pop(playerId, None)
        done = getattr(self, "_drinkDoneAt", None)
        if done is None:
            done = {}
            self._drinkDoneAt = done
        now = time.time()
        if now - float(done.get(playerId, 0.0)) < 0.5:
            return
        done[playerId] = now
        if callable(grant):
            grant(playerId)

    def _drinkRoute(self, playerId, name, src, grant):
        # 按下（try / use）只记账；吃完（eat）或药水真的被消耗掉才算喝下去
        if src == u"try":
            self._drinkPress(playerId, name, grant)
            return
        if src == u"eat":
            self._drinkConfirm(playerId, grant)
            return
        rec = self._drinkTestMap().get(playerId)
        if not rec:
            if src == u"use":
                self._drinkPress(playerId, name, grant)   # 没见到按下事件，先记一笔
            else:
                self._drinkConfirm(playerId, grant)       # 没见到按下事件，只能信完成事件
            return
        if float(rec.get("t", 0.0)) + self._DRINK_HOLD_MIN <= time.time():
            self._drinkConfirm(playerId, grant)

    def _drinkWatchTick(self, now):
        # 兜底：药水真的从背包里少了一瓶 -> 就当喝下去了
        m = getattr(self, "_drinkTest", None)
        if not m:
            return
        for playerId in list(m.keys()):
            rec = m.get(playerId)
            if not rec:
                continue
            age = now - float(rec.get("t", 0.0))
            if age > 5.0:
                m.pop(playerId, None)
                continue
            if age < self._DRINK_HOLD_MIN:
                continue
            cnt, cur = -1, u""
            try:
                comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
                ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
                item = comp.GetPlayerItem(ItemPosType.INVENTORY,
                                          int(rec.get("slot", -1)), True) or {}
                cnt = int(item.get("count", 0) or 0)
                cur = self._itemIdOf(item)
            except Exception:
                continue
            if cnt < int(rec.get("count", 1)) or (cur and cur != rec.get("name")):
                self._drinkConfirm(playerId, rec.get("grant"))

    def _checkPotion(self, playerId, itemDict, src=u"eat"):
        # 判断刚才用到的是不是本模组的药水
        if not playerId or not self._powerOn():
            return
        self._debugIntake(playerId, itemDict, src)
        name = self._itemIdOf(itemDict)
        if not name:
            return
        if name == str(getattr(cfg, "SPLASH_ITEM", "")).lower():
            self._throwSplash(playerId)      # 手里的是喷溅型：改成扔出去
            return
        if name == str(getattr(cfg, "MODE_ITEM", "")).lower():
            self._drinkRoute(playerId, name, src, self._givePower)

    def OnEatFood(self, args):
        # 玩家把东西喝下去了
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"eat")

    def OnUseItem(self, args):
        # 开始使用物品时触发：先记一笔，等确认真的喝下去
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"use")

    def OnAfterUse(self, args):
        # 用完 / 松手时发的事件：按住了足够久才算喝下去
        if not args:
            return
        self._checkPotion(self._actorIdOf(args), args.get("itemDict"), u"after")

    # ==================== 喷溅型飞行热射线（扔出去，一片人一起变身） ====================
    def _splashOn(self):
        # 喷溅型开没开
        return bool(getattr(cfg, "SPLASH_ENABLED", True)) and self._powerOn()

    def _isSplashItem(self, itemDict):
        # 手里拿的是不是喷溅型（飞行热射线 / 超级速度 / V1 都算）
        return self._splashKindOf(itemDict) is not None

    def _splashKindOf(self, itemDict):
        # 手里这瓶是哪一种喷溅型
        if not isinstance(itemDict, dict):
            return None
        name = self._itemIdOf(itemDict)
        if not name:
            return None
        for iid, kind in (getattr(cfg, "SPLASH_KINDS", None) or {}).items():
            if name == str(iid).lower():
                return str(kind)
        if name == str(getattr(cfg, "SPLASH_ITEM", "")).lower():
            return "eyelaser"
        return None

    def _splashNameOf(self, kind):
        table = getattr(cfg, "SPLASH_DISPLAY", None) or {}
        return table.get(kind) or getattr(cfg, "SPLASH_NAME", u"喷溅型飞行热射线")

    def _peerSys(self, kind):
        # 拿同一模组里别的系统（超级速度 / 士兵男孩）
        name = {"superspeed": "SuperSpeedServerSystem",
                "soldierboy": "SoldierBoyServerSystem"}.get(kind)
        if not name:
            return None
        try:
            return serverApi.GetSystem(modConfig.ModName, name)
        except Exception:
            return None

    def _splashDurOf(self, kind, fallback):
        # 这瓶药维持多久（问一下对应的系统）
        sysObj = self._peerSys(kind)
        if sysObj is not None:
            try:
                d = float(sysObj.PowerDuration())
                if d > 0.0:
                    return d
            except Exception:
                pass
        return float(fallback)

    def _applySplashPower(self, playerId, kind, dur):
        # 按这一瓶药的类型，给对应的能力
        if kind in ("superspeed", "soldierboy"):
            sysObj = self._peerSys(kind)
            if sysObj is None:
                return False
            try:
                return bool(sysObj.GivePowerFromSplash(playerId))
            except Exception:
                return False
        self._givePower(playerId, dur=dur)
        return True

    def _eyePosOf(self, playerId):
        # 从眼睛高度扔出去
        feet = self._posOf(playerId)
        if not feet:
            return None
        try:
            eyeH = float(getattr(cfg, "LASER_EYE_HEIGHT", 1.62))
            return (float(feet[0]), float(feet[1]) + eyeH, float(feet[2]))
        except Exception:
            return None

    def _lookDirOf(self, playerId):
        # 玩家看哪儿就扔哪儿（稍微往上抬一点，扔得更远）
        pitch, yaw = self._rotOf(playerId)
        try:
            d = serverApi.GetDirFromRot((pitch, yaw))
        except Exception:
            return None
        dx = float(d[0])
        dy = float(d[1]) + float(getattr(cfg, "SPLASH_THROW_UP", 0.18))
        dz = float(d[2])
        n = math.sqrt(dx * dx + dy * dy + dz * dz)
        if n < 1e-4:
            return None
        return (dx / n, dy / n, dz / n)

    def _consumeOne(self, playerId):
        # 把"使用"取消之后，物品不会自己变少，这里手动扣掉一个
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ItemPosType = serverApi.GetMinecraftEnum().ItemPosType
            slot = int(comp.GetSelectSlotId())
            item = comp.GetPlayerItem(ItemPosType.INVENTORY, slot, True)
            if not item:
                return
            num = int(item.get("count", 1))
            if num <= 1:
                comp.SetInvItemNum(slot, 0)
            else:
                comp.SetInvItemNum(slot, num - 1)
        except Exception:
            pass

    def _giveSplashItem(self, playerId, num=1, itemName=None):
        # 给玩家一瓶喷溅型（不指定就给飞行热射线那瓶）
        if not itemName:
            itemName = str(getattr(cfg, "SPLASH_ITEM", ""))
        kind = self._splashKindOf({"itemName": itemName}) or "eyelaser"
        if not itemName:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            ok = comp.SpawnItemToPlayerInv(
                {"itemName": itemName, "count": int(num), "auxValue": 0},
                playerId)
            if ok and getattr(cfg, "SPLASH_TIP", True):
                self._tip(playerId, u"已获得 %s ×%d：拿在手里点一下屏幕就扔出去"
                          % (self._splashNameOf(kind), int(num)), "LIGHT_PURPLE")
        except Exception:
            pass

    def OnItemTryUse(self, args):
        # 手里拿着药水按下使用键（电脑右键 / 手机点屏幕）：
        #   喝的那瓶 -> 只记一笔，按住喝完了才生效（点一下不算）
        #   喷溅型   -> 直接扔出去
        if not args:
            return
        playerId = self._actorIdOf(args)
        if not playerId:
            return
        itemDict = args.get("itemDict")
        self._debugIntake(playerId, itemDict, u"try")
        name = self._itemIdOf(itemDict)
        if not name:
            return
        if name == str(getattr(cfg, "MODE_ITEM", "")).lower():
            if self._powerOn():
                self._drinkPress(playerId, name, self._givePower)
            return
        if not self._splashOn():
            return
        kind = self._splashKindOf(itemDict)
        if not kind:
            return
        if self._throwSplash(playerId, kind):
            try:
                args["cancel"] = True          # 别把瓶子喝掉
            except Exception:
                pass
            self._consumeOne(playerId)

    def _throwSplash(self, playerId, kind="eyelaser"):
        # 真的把瓶子扔出去
        if not self._splashOn():
            return False
        now = time.time()
        gap = float(getattr(cfg, "SPLASH_COOLDOWN", 0.45))
        if now - float(self._splashAt.get(playerId, 0.0)) < gap:
            return False                        # 一次点击只会扔一瓶
        origin = self._eyePosOf(playerId)
        direction = self._lookDirOf(playerId)
        pid = None
        if origin and direction:
            pid = self._spawnSplash(playerId, origin, direction)
        self._splashAt[playerId] = now
        if not pid:
            # 扔不出去（少数机器会失败）：直接砸在脚边，效果一样不打折
            self._splashAtPos(origin, self._dimensionOf(playerId), playerId,
                              None, kind)
            return True
        self._splash[pid] = {"owner": playerId, "t": now, "pos": origin,
                             "dim": self._dimensionOf(playerId), "kind": kind}
        if getattr(cfg, "SPLASH_TIP", True):
            self._tip(playerId, u"%s 扔出去了：落地后 %d 格内的玩家一起变身"
                      % (self._splashNameOf(kind),
                         int(getattr(cfg, "SPLASH_RADIUS", 5.0))),
                      "LIGHT_PURPLE")
        return True

    def _spawnSplash(self, playerId, origin, direction):
        # 让引擎发一个原版喷溅药水出去（落地自带碎裂动画和音效）
        try:
            comp = serverApi.GetEngineCompFactory().CreateProjectile(
                serverApi.GetLevelId())
            param = {
                "position": (float(origin[0]), float(origin[1]),
                             float(origin[2])),
                "direction": (float(direction[0]), float(direction[1]),
                              float(direction[2])),
                "power": float(getattr(cfg, "SPLASH_POWER", 1.25)),
                "gravity": float(getattr(cfg, "SPLASH_GRAVITY", 0.06)),
                "isDamageOwner": False,
                "auxValue": 0,
            }
            pid = comp.CreateProjectileEntity(
                playerId,
                str(getattr(cfg, "SPLASH_PROJECTILE", "minecraft:splash_potion")),
                param)
        except Exception:
            return None
        if not pid or str(pid) == "-1":
            return None
        return str(pid)

    def OnProjectileHit(self, args):
        # 自己扔的那瓶落地了（砸地上或者砸生物身上都算）
        try:
            if not args:
                return
            rec = self._splash.pop(args.get("id"), None)
            if not rec:
                return                        # 不是自己的瓶子，不管
            pos = self._splashPosOf(args)
            hitId = None
            if str(args.get("hitTargetType") or "").upper() == "ENTITY":
                hitId = args.get("targetId")
            self._splashAtPos(pos, rec.get("dim"), rec.get("owner"), hitId,
                              rec.get("kind"))
        except Exception:
            pass

    def _splashPosOf(self, args):
        # 算出瓶子到底在哪儿炸开。
        # 砸在生物身上时，事件给回来的坐标不一定准，直接问那只生物在哪儿更稳。
        hitType = str(args.get("hitTargetType") or "").upper()
        if hitType == "ENTITY":
            target = args.get("targetId")
            if target:
                p = self._posOf(target)
                if p:
                    try:
                        # 生物脚底往上抬一点，取身体中间
                        return (float(p[0]), float(p[1]) + 0.8, float(p[2]))
                    except Exception:
                        pass
        try:
            return (float(args.get("x", 0.0)), float(args.get("y", 0.0)),
                    float(args.get("z", 0.0)))
        except Exception:
            return None

    def _splashAtPos(self, pos, dimensionId, owner=None, hitId=None, kind=None):
        # 落地：把这一片的玩家全部变身
        if not pos:
            return []
        kind = kind or "eyelaser"
        x = float(pos[0])
        y = float(pos[1])
        z = float(pos[2])
        radius = float(getattr(cfg, "SPLASH_RADIUS", 5.0))
        dur = getattr(cfg, "SPLASH_DURATION", None)
        if not dur:
            dur = float(getattr(cfg, "MODE_DURATION", 90.0))
        selfAffect = bool(getattr(cfg, "SPLASH_AFFECT_SELF", True))
        hit = []
        for playerId in list(serverApi.GetPlayerList() or []):
            if dimensionId is not None and self._dimensionOf(
                    playerId) != dimensionId:
                continue
            if playerId == owner and not selfAffect:
                continue
            p = self._posOf(playerId)
            if not p:
                continue
            d = math.sqrt((float(p[0]) - x) ** 2 + (float(p[1]) - y) ** 2
                          + (float(p[2]) - z) ** 2)
            if d <= radius:
                hit.append(playerId)
        showDur = self._splashDurOf(kind, dur)
        for playerId in hit:
            self._applySplashPower(playerId, kind, dur)
            if getattr(cfg, "SPLASH_TIP", True):
                self._tip(playerId, u"被 %s 溅到：能力到手，维持 %d 秒"
                          % (self._splashNameOf(kind), int(showDur)), "GREEN")
        # 直接被砸中的如果是非玩家生物：那只生物也变身
        if hitId:
            self._giveMobPower(hitId, kind)
        return hit

    def _splashTick(self, now):
        # 兜底：万一没收到落地事件（少数机器），就按最后看到的位置生效
        if not self._splash:
            return
        for pid in list(self._splash.keys()):
            rec = self._splash.get(pid)
            if not rec:
                continue
            alive = True
            try:
                alive = bool(serverApi.GetEngineCompFactory().CreateGame(
                    serverApi.GetLevelId()).IsEntityAlive(pid))
            except Exception:
                alive = True
            if alive:
                p = self._posOf(pid)
                if p:
                    rec["pos"] = p
                if now - float(rec.get("t", now)) > float(
                        getattr(cfg, "SPLASH_TIMEOUT", 8.0)):
                    self._splash.pop(pid, None)
                    self._splashAtPos(rec.get("pos"), rec.get("dim"),
                                      rec.get("owner"), None, rec.get("kind"))
                continue
            self._splash.pop(pid, None)
            self._splashAtPos(rec.get("pos"), rec.get("dim"), rec.get("owner"),
                              None, rec.get("kind"))

    # ==================== 变身的生物（自己乱飞 + 随机放激光） ====================
    def _mobPowerOn(self):
        # 生物变身这个玩法开没开
        return bool(getattr(cfg, "MOB_POWER_ENABLED", True)) and self._powerOn()

    def _isPlayerId(self, entityId):
        try:
            return entityId in (serverApi.GetPlayerList() or [])
        except Exception:
            return False

    def _giveMobPower(self, mobId, splashKind="eyelaser"):
        # 砸中哪只生物，哪只就变身
        # 飞行热射线那瓶：乱飞 + 随机激光；超级速度 / V1 那两瓶：随机给“超级速度”或“爆炸”
        if not self._mobPowerOn() or not mobId:
            return False
        if self._isPlayerId(mobId):
            return False                    # 玩家走玩家那一套
        try:
            if not bool(serverApi.GetEngineCompFactory().CreateGame(
                    serverApi.GetLevelId()).IsEntityAlive(mobId)):
                return False
        except Exception:
            pass
        cap = int(getattr(cfg, "MOB_POWER_MAX", 6))
        if cap > 0 and mobId not in self._mobPower and len(self._mobPower) >= cap:
            return False                    # 变身的生物太多了，先保住性能
        now = time.time()
        dur = float(getattr(cfg, "MOB_POWER_DURATION", 0.0) or
                    getattr(cfg, "MODE_DURATION", 90.0))
        power = self._mobPowerKindFor(splashKind)
        self._mobPower[mobId] = now + dur
        self._mobState[mobId] = self._newMobState(power, now)
        if power == "laser":
            home = self._posOf(mobId)
            if home:
                self._mobFly[mobId] = {
                    "home": (float(home[0]), float(home[1]), float(home[2])),
                    "tgt": None, "next": now}
            self._mobFire[mobId] = now + self._mobFireGap()
        if getattr(cfg, "MOB_POWER_TIP", True):
            self._tipNearMob(mobId, self._mobTipOf(power))
        return True

    def _mobTipOf(self, power):
        # 变身时提醒附近玩家一句
        if power == "speed":
            return u"这只生物被溅到了：它会随机到处乱跑，追都追不上，躲远点！"
        if power == "explode":
            return u"这只生物被溅到了：它会先蓄力发光、然后随机在附近炸开，看到金光就躲远点！"
        return u"这只生物也被溅到了：它会自己飞起来、随机打激光，躲远点！"

    def _mobPowerKindFor(self, splashKind):
        # 这只生物拿到哪一种能力
        # 默认“哪一瓶就给哪一种”：超级速度 -> 乱跑，V1 -> 爆炸
        if getattr(cfg, "MOB_SPLASH_RANDOM", False):
            pool = [str(k) for k in
                    (getattr(cfg, "MOB_SPLASH_RANDOM_POOL", None) or ())
                    if str(k) in ("speed", "explode")]
            if pool:
                return random.choice(pool)
        table = getattr(cfg, "MOB_SPLASH_POWER", None) or {}
        kind = table.get(splashKind)
        if kind:
            return str(kind)
        return "laser"

    def _mobGap(self, lo, hi):
        lo = float(lo)
        hi = float(hi)
        if hi < lo:
            hi = lo
        return random.uniform(lo, hi)

    def _mobKindOf(self, mobId):
        st = self._mobState.get(mobId)
        if isinstance(st, dict) and st.get("kind"):
            return str(st["kind"])
        return "laser"

    def _newMobState(self, kind, now):
        # act = 下一次出手时间；roll = 下一次换能力时间
        st = {"kind": kind, "act": 0.0, "roll": 0.0}
        if kind == "speed":
            st["act"] = now + self._mobGap(getattr(cfg, "MOB_SPEED_GAP_MIN", 1.2),
                                           getattr(cfg, "MOB_SPEED_GAP_MAX", 2.6))
        elif kind == "explode":
            st["act"] = now + self._mobGap(getattr(cfg, "MOB_BOOM_GAP_MIN", 6.0),
                                           getattr(cfg, "MOB_BOOM_GAP_MAX", 12.0))
        if getattr(cfg, "MOB_SPLASH_REROLL", True):
            st["roll"] = now + self._mobGap(
                getattr(cfg, "MOB_SPLASH_REROLL_MIN", 6.0),
                getattr(cfg, "MOB_SPLASH_REROLL_MAX", 13.0))
        return st

    def _mobSpeedStep(self, mobId, now):
        # 超级速度：隔一小会儿就朝一个随机方向猛冲
        st = self._mobState.get(mobId)
        if not isinstance(st, dict):
            return
        if now < float(st.get("act", 0.0)):
            return
        st["act"] = now + self._mobGap(getattr(cfg, "MOB_SPEED_GAP_MIN", 1.2),
                                       getattr(cfg, "MOB_SPEED_GAP_MAX", 2.6))
        if not getattr(cfg, "MOB_SPEED_ENABLED", True):
            return
        ang = random.uniform(0.0, 2.0 * math.pi)
        sp = float(getattr(cfg, "MOB_SPEED_POWER", 1.55))
        vx = math.cos(ang) * sp
        vz = math.sin(ang) * sp
        vy = float(getattr(cfg, "MOB_SPEED_UP", 0.30))
        self._mobMotion(mobId, (vx, vy, vz))
        pos = self._posOf(mobId)
        if pos:
            self._mobFaceTo(mobId, (float(pos[0]) + vx, float(pos[1]) + vy,
                                    float(pos[2]) + vz))

    def _mobBoomCenter(self, mobId):
        # ★ 炸点：在它周围随机挑一个地方，而不是每次都在脚下
        pos = self._posOf(mobId)
        if not pos:
            return None
        scatter = float(getattr(cfg, "MOB_BOOM_SCATTER", 3.0))
        ox = 0.0
        oz = 0.0
        if scatter > 0.0:
            ang = random.uniform(0.0, 2.0 * math.pi)
            r = random.uniform(0.0, scatter)
            ox = math.cos(ang) * r
            oz = math.sin(ang) * r
        return (float(pos[0]) + ox, float(pos[1]) + 0.5, float(pos[2]) + oz)

    def _mobBoomFx(self, mobId, now, ratio):
        # 蓄力时的黄金光芒：和玩家胸口那道金光同一套
        # 位置抬到生物胸口高度，看起来就像它自己在蓄力
        if not getattr(cfg, "MOB_BOOM_CHARGE_FX", True):
            return
        sysObj = self._peerSys("soldierboy")
        if sysObj is None:
            return
        pos = self._posOf(mobId)
        if not pos:
            return
        up = float(getattr(cfg, "MOB_BOOM_CHARGE_UP", 0.9))
        try:
            sysObj.MobChargeFx((float(pos[0]), float(pos[1]) + up, float(pos[2])),
                               self._dimensionOf(mobId), ratio)
        except Exception:
            pass

    def _mobBlow(self, mobId, now):
        # 真的炸开
        center = self._mobBoomCenter(mobId)
        if center is None:
            return
        sysObj = self._peerSys("soldierboy")
        if sysObj is None:
            return
        try:
            sysObj.MobExplode(center, self._dimensionOf(mobId), mobId)
        except Exception:
            pass

    def _mobChargeStep(self, mobId, now):
        # 正在蓄力的生物：身上一直冒黄金光，蓄满才炸开
        st = self._mobState.get(mobId)
        if not isinstance(st, dict):
            return
        since = st.get("charge")
        if since is None:
            return
        chargeTime = max(0.1, float(getattr(cfg, "MOB_BOOM_CHARGE_TIME", 5.0)))
        done = now - float(since)
        if done >= chargeTime:
            st["charge"] = None
            st["chargeFx"] = 0.0
            self._mobBlow(mobId, now)
            return
        gap = float(getattr(cfg, "MOB_BOOM_CHARGE_FX_INTERVAL", 0.12))
        if now - float(st.get("chargeFx", 0.0)) < gap:
            return
        st["chargeFx"] = now
        self._mobBoomFx(mobId, now, done / chargeTime)

    def _mobBoomStep(self, mobId, now):
        # 爆炸：隔几秒就在自己周围随机一个地方炸开
        st = self._mobState.get(mobId)
        if not isinstance(st, dict):
            return
        if st.get("charge") is not None:
            return                      # 正在蓄力，交给 _mobChargeStep
        if now < float(st.get("act", 0.0)):
            return
        st["act"] = now + self._mobGap(getattr(cfg, "MOB_BOOM_GAP_MIN", 6.0),
                                       getattr(cfg, "MOB_BOOM_GAP_MAX", 12.0))
        if not getattr(cfg, "MOB_BOOM_ENABLED", True):
            return
        if not self._posOf(mobId):
            return
        # ★ 炸之前先蓄力：身上亮起黄金光芒，
        #   越蓄越亮，蓄满才炸开
        if getattr(cfg, "MOB_BOOM_CHARGE", True):
            st["charge"] = now
            st["chargeFx"] = 0.0
            self._mobBoomFx(mobId, now, 0.0)
            return
        self._mobBlow(mobId, now)

    def _mobRerollStep(self, mobId, now):
        # 变身期间随机换成另一种能力，看起来更“随机”
        st = self._mobState.get(mobId)
        if not isinstance(st, dict):
            return
        if str(st.get("kind")) not in ("speed", "explode"):
            return
        if not getattr(cfg, "MOB_SPLASH_REROLL", True):
            return
        if st.get("charge") is not None:
            return              # 正在蓄力的别换能力，不然蓄到一半就断了
        if now < float(st.get("roll", 0.0)):
            return
        other = "explode" if str(st.get("kind")) == "speed" else "speed"
        st.update(self._newMobState(other, now))

    def _tipNearMob(self, mobId, text):
        # 只提醒附近的玩家，远处的人别被刷屏
        pos = self._posOf(mobId)
        if not pos:
            return
        dim = self._dimensionOf(mobId)
        for playerId in list(serverApi.GetPlayerList() or []):
            if self._dimensionOf(playerId) != dim:
                continue
            p = self._posOf(playerId)
            if not p:
                continue
            d = math.sqrt((float(p[0]) - float(pos[0])) ** 2
                          + (float(p[1]) - float(pos[1])) ** 2
                          + (float(p[2]) - float(pos[2])) ** 2)
            if d <= 40.0:
                self._tip(playerId, text, "RED")

    def _loseMobPower(self, mobId):
        self._mobPower.pop(mobId, None)
        self._mobFly.pop(mobId, None)
        self._mobFire.pop(mobId, None)
        self._mobState.pop(mobId, None)
        self._fireArmed.pop(mobId, None)
        self._lastBeamFire.pop(mobId, None)

    # ===== 给士兵男孩的爆炸用：认得 / 收掉飞行热射线 =====
    def HasPower(self, playerId):
        # 别的小系统问：这个玩家现在是不是正开着飞行热射线
        if not self._powerOn():
            return False
        return self._powerLeftOf(playerId) > 0.0

    def DropPower(self, playerId, quiet=True):
        # 把飞行热射线收掉（被 V1 爆炸清药水时调用）；真的收了返回 True
        if not self._powerOn():
            return False
        if self._powerLeftOf(playerId) <= 0.0:
            return False
        self._losePower(playerId, quiet=quiet)
        return True

    def HasMobPower(self, entityId):
        # 这只生物是不是被喷溅型砸中变身的
        return bool(entityId) and entityId in self._mobPower

    def DropMobPower(self, entityId):
        if not self.HasMobPower(entityId):
            return False
        self._loseMobPower(entityId)
        return True

    def _mobFireGap(self):
        # 随机开火间隔
        lo = float(getattr(cfg, "MOB_LASER_INTERVAL_MIN", 1.6))
        hi = float(getattr(cfg, "MOB_LASER_INTERVAL_MAX", 3.8))
        if hi < lo:
            hi = lo
        return random.uniform(lo, hi)

    def _mobSizeH(self, mobId):
        # 这只生物多高（用来算眼睛在哪儿）
        try:
            size = serverApi.GetEngineCompFactory().CreateCollisionBox(
                mobId).GetSize()
            if size and len(size) >= 2:
                return max(0.45, float(size[1]) * 0.85)
        except Exception:
            pass
        return 1.35

    def _mobMotion(self, mobId, vec):
        try:
            return bool(serverApi.GetEngineCompFactory().CreateActorMotion(
                mobId).SetMotion((float(vec[0]), float(vec[1]),
                                  float(vec[2]))))
        except Exception:
            return False

    def _mobFaceTo(self, mobId, tgt):
        # 让生物的头朝着某个点
        pos = self._posOf(mobId)
        if not pos:
            return
        dx = float(tgt[0]) - float(pos[0])
        dy = float(tgt[1]) - float(pos[1])
        dz = float(tgt[2]) - float(pos[2])
        n = math.sqrt(dx * dx + dy * dy + dz * dz)
        if n < 1e-4:
            return
        try:
            rot = serverApi.GetRotFromDir((dx / n, dy / n, dz / n))
            serverApi.GetEngineCompFactory().CreateRot(mobId).SetRot(
                (float(rot[0]), float(rot[1])))
        except Exception:
            pass

    def _mobFlyStep(self, mobId, now):
        # 随机乱飘：每隔一两秒换一个目标点，然后一直朝它推
        rec = self._mobFly.get(mobId)
        if not rec:
            return
        pos = self._posOf(mobId)
        if not pos:
            return
        px = float(pos[0])
        py = float(pos[1])
        pz = float(pos[2])
        home = rec.get("home") or (px, py, pz)
        tgt = rec.get("tgt")
        if tgt is None or now >= float(rec.get("next", 0.0)):
            rng = float(getattr(cfg, "MOB_FLY_RANGE", 16.0))
            top = float(getattr(cfg, "MOB_FLY_HEIGHT", 7.0))
            tgt = (float(home[0]) + random.uniform(-rng, rng),
                   float(home[1]) + random.uniform(3.0, max(3.5, top)),
                   float(home[2]) + random.uniform(-rng, rng))
            rec["tgt"] = tgt
            rec["next"] = now + random.uniform(
                float(getattr(cfg, "MOB_FLY_RETARGET_MIN", 1.2)),
                float(getattr(cfg, "MOB_FLY_RETARGET_MAX", 3.0)))
            self._mobFaceTo(mobId, tgt)
        vx = float(tgt[0]) - px
        vy = float(tgt[1]) - py
        vz = float(tgt[2]) - pz
        n = math.sqrt(vx * vx + vy * vy + vz * vz)
        if n < 0.7:
            rec["tgt"] = None
            self._mobMotion(mobId, (0.0, 0.05, 0.0))    # 悬停一下，别掉下去
            return
        sp = float(getattr(cfg, "MOB_FLY_SPEED", 0.42))
        move = [vx / n * sp, vy / n * sp, vz / n * sp]
        if py < float(home[1]) + 1.5:
            move[1] = max(move[1], 0.07)                # 别贴着地面飞
        self._mobMotion(mobId, move)

    def _mobEyePos(self, mobId):
        pos = self._posOf(mobId)
        if not pos:
            return None
        return (float(pos[0]), float(pos[1]) + self._mobSizeH(mobId),
                float(pos[2]))

    def _nearestPlayerTo(self, mobId, origin):
        best = None
        bestD = None
        dim = self._dimensionOf(mobId)
        for playerId in list(serverApi.GetPlayerList() or []):
            if playerId == mobId or self._dimensionOf(playerId) != dim:
                continue
            p = self._posOf(playerId)
            if not p:
                continue
            d = math.sqrt((float(p[0]) - origin[0]) ** 2
                          + (float(p[1]) - origin[1]) ** 2
                          + (float(p[2]) - origin[2]) ** 2)
            if bestD is None or d < bestD:
                bestD = d
                best = playerId
        return best

    def _randomAim(self, origin):
        # 完全随机方向：随便找个点，稍微朝下，别一直往天上打
        a = random.uniform(0.0, math.pi * 2.0)
        pitch = random.uniform(-0.45, 0.10)
        ch = math.cos(pitch)
        return (origin[0] + math.sin(a) * ch,
                origin[1] + math.sin(pitch),
                origin[2] + math.cos(a) * ch)

    def _mobShoot(self, mobId):
        # 生物的激光：从它眼睛那儿打出去（一道就够，客户端只画得下两道）
        origin = self._mobEyePos(mobId)
        if not origin:
            return False
        aim = str(getattr(cfg, "MOB_LASER_AIM", "nearest")).strip().lower()
        aimAt = None
        if aim != "random":
            target = self._nearestPlayerTo(mobId, origin)
            if target:
                tp = self._posOf(target)
                if tp:
                    aimAt = (float(tp[0]), float(tp[1]) + 1.0, float(tp[2]))
        if aimAt is None:
            aimAt = self._randomAim(origin)
        dx = aimAt[0] - origin[0]
        dy = aimAt[1] - origin[1]
        dz = aimAt[2] - origin[2]
        n = math.sqrt(dx * dx + dy * dy + dz * dz)
        if n < 1e-4:
            return False
        dirVec = (dx / n, dy / n, dz / n)
        self._mobFaceTo(mobId, aimAt)
        dimensionId = self._dimensionOf(mobId)
        reach = float(getattr(cfg, "MOB_LASER_RANGE", 32))
        stopDist = reach
        if getattr(cfg, "MOB_LASER_BREAK", True) and cfg.LASER_BREAK_ENABLED:
            # 生物没有“松手”这个动作：每一枪都重新给一个点火名额，
            # 靠 LASER_FIRE_MIN_GAP 兜住，不会刷出一片火
            self._fireArmed[mobId] = True
            stopDist = self._pierce(
                dimensionId, origin, dirVec, reach, {},
                {"fire": 0, "pid": mobId,
                 "allow": self._fireAllowed(mobId)})
        endPos = (origin[0] + dirVec[0] * stopDist,
                  origin[1] + dirVec[1] * stopDist,
                  origin[2] + dirVec[2] * stopDist)
        if getattr(cfg, "MOB_LASER_HURT", True):
            hitId, hitDist, hitPos = self._findTarget(
                dimensionId, origin, dirVec, mobId, reach)
            if hitId and hitDist is not None and hitDist <= stopDist + 0.6:
                self._hurt(hitId, mobId)
                endPos = hitPos
        self._broadcastFx(dimensionId,
                          [(origin[0], origin[1], origin[2],
                            dirVec[0], dirVec[1], dirVec[2], endPos)], mobId)
        return True

    def _mobTick(self, now):
        # 每一帧都看一眼：还在变身期的生物要一直飞，到点就开火
        for mobId in list(self._mobPower.keys()):
            if now >= float(self._mobPower.get(mobId, 0.0)):
                self._loseMobPower(mobId)
                continue
            alive = True
            try:
                alive = bool(serverApi.GetEngineCompFactory().CreateGame(
                    serverApi.GetLevelId()).IsEntityAlive(mobId))
            except Exception:
                alive = True
            if not alive:
                self._loseMobPower(mobId)
                continue
            self._mobChargeStep(mobId, now)     # ★ 正在蓄力的：冒金光，蓄满就炸
            kind = self._mobKindOf(mobId)
            if kind == "speed":
                self._mobSpeedStep(mobId, now)      # 随机猛冲
            elif kind == "explode":
                self._mobBoomStep(mobId, now)       # 随机爆炸
            else:
                if getattr(cfg, "MOB_FLY_ENABLED", True):
                    self._mobFlyStep(mobId, now)
                if getattr(cfg, "MOB_LASER_ENABLED", True) and now >= float(
                        self._mobFire.get(mobId, 0.0)):
                    self._mobFire[mobId] = now + self._mobFireGap()
                    self._mobShoot(mobId)
            self._mobRerollStep(mobId, now)         # 随机换能力

    # ==================== 通用广播 ====================
    def _toAllClients(self, eventName, data):
        # 注意：官方接口叫 BroadcastToAllClient（不是 NotifyToAllClients）
        try:
            self.BroadcastToAllClient(eventName, data)
            return
        except Exception:
            pass
        try:
            for pid in (serverApi.GetPlayerList() or []):
                try:
                    self.NotifyToClient(pid, eventName, data)
                except Exception:
                    pass
        except Exception:
            pass

    # ==================== 飞行状态 ====================
    def _flyStateOf(self, playerId):
        comp = self._flyComp(playerId)
        if comp is None:
            return False
        try:
            return bool(comp.IsPlayerFlying())
        except Exception:
            return False

    def _moveSpeedOf(self, playerId):
        # 用两次采样之间的水平位移算速度（格 / 秒）
        pos = self._posOf(playerId)
        if pos is None:
            return 0.0
        now = time.time()
        last = self._lastPos.get(playerId)
        lastT = float(self._lastPosT.get(playerId, 0.0))
        self._lastPos[playerId] = (pos[0], pos[1], pos[2])
        self._lastPosT[playerId] = now
        if last is None:
            return 0.0
        dt = now - lastT
        if dt <= 0.001:
            return 0.0
        dx = float(pos[0]) - float(last[0])
        dz = float(pos[2]) - float(last[2])
        speed = math.sqrt(dx * dx + dz * dz) / dt
        # 跳得太离谱就当传送（换维度 / tp），不算移动。
        # 这条线必须高于正常飞行速度，否则飞得越快越会被误判成“没在动”。
        if speed > float(getattr(cfg, "FLY_POSE_SPEED_CAP", 3000.0)):
            return 0.0
        return speed

    def _isAirborne(self, playerId):
        # 脚底往下 0.12 格是不是空的：踩着地就不算"在天上飞"
        if not getattr(cfg, "FLY_POSE_NEED_AIRBORNE", True):
            return True
        pos = self._posOf(playerId)
        if not pos:
            return True            # 问不到位置就按原来的手感处理
        comp = self._blockComp()
        if comp is None:
            return True
        try:
            blockPos = (int(math.floor(float(pos[0]))),
                        int(math.floor(float(pos[1]) - 0.12)),
                        int(math.floor(float(pos[2]))))
            info = comp.GetBlockNew(blockPos, self._dimensionOf(playerId))
        except Exception:
            return True
        if not info or not hasattr(info, "get"):
            return True
        name = info.get("name")
        if not name:
            return True
        return str(name).lower() in _NO_GROUND_BLOCKS

    def OnSprintState(self, args):
        # 客户端上报：我正在疾跑 / 没在疾跑
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        try:
            self._sprint[playerId] = int(args.get("sprint", 0)) == 1
            self._sprintT[playerId] = time.time()
        except Exception:
            pass

    def _sprintOf(self, playerId):
        # 疾跑状态：True / False；超过 2 秒没收到就返回 None（当作不知道）
        t = float(self._sprintT.get(playerId, 0.0))
        if t <= 0.0 or time.time() - t > 2.0:
            return None
        return bool(self._sprint.get(playerId, False))

    def _updateProne(self, playerId, flying):
        # 趴不趴：默认“飞行 + 疾跑”才算（电脑双击 W / 手机奔跑按钮），
        # 悬停、慢慢飞、站着都不趴。判定方式可以在配置里选。
        if not flying or not getattr(cfg, "FLY_POSE_ENABLED", True) or not self._poseOn:
            self._proneNow[playerId] = False
            self._fastSince.pop(playerId, None)
            self._moveSpeedOf(playerId)          # 照样采样，保持间隔稳定
            return False
        mode = str(getattr(cfg, "FLY_POSE_MODE", "sprint")).strip().lower()
        sprint = self._sprintOf(playerId)
        if mode == "speed" or sprint is None:
            prone = self._speedProne(playerId)
        elif mode == "both":
            prone = bool(sprint) or self._speedProne(playerId)
        else:
            prone = bool(sprint)
        self._proneNow[playerId] = prone
        return prone

    def _speedProne(self, playerId):
        # 备选判定：飞得快 + 持续一小会儿 + 真的在天上
        speed = self._moveSpeedOf(playerId)
        self._proneSpeed[playerId] = speed
        was = bool(self._proneNow.get(playerId, False))
        hi = float(getattr(cfg, "FLY_POSE_MIN_SPEED", 3.0))
        lo = float(getattr(cfg, "FLY_POSE_STOP_SPEED", hi * 0.5))
        if speed < (lo if was else hi):
            self._fastSince.pop(playerId, None)
            return False                         # 慢下来就马上站起来
        now = time.time()
        since = self._fastSince.get(playerId)
        if since is None:
            since = now
            self._fastSince[playerId] = since
        if not was and (now - since) < float(getattr(cfg, "FLY_POSE_HOLD_TIME", 0.0)):
            return False                         # 刚起步还不够久，先站着
        if not self._isAirborne(playerId):
            return False                         # 脚踩着地，不算飞行奔跑
        return True


    def _isProne(self, playerId, flying=None):
        # 只读缓存：趴不趴由 _updateProne 每 0.25 秒算一次，
        # 开火时直接取结果，免得一次次重新采样把判定抖来抖去
        if flying is False:
            return False
        return bool(self._proneNow.get(playerId, False))

    def _syncFlyState(self, playerId, flying=None, force=False):
        if flying is None:
            flying = self._flyStateOf(playerId)
        # 飞行姿势只在飞行热射线药效还在的时候才让客户端改：
        # 没喝药的时候（创造模式飞行、别的模组给的飞行）保持原版姿势，腿照常摆动
        if not self._hasPower(playerId):
            flying = False
        prone = self._updateProne(playerId, flying)
        sig = (1 if flying else 0, 1 if prone else 0)
        if not force and self._flySent.get(playerId) == sig:
            return flying          # 没变化就不发，省带宽
        self._flySent[playerId] = sig
        self._toAllClients(modConfig.EventFlyState,
                           {"playerId": playerId,
                            "fly": sig[0], "prone": sig[1]})
        return flying

    def _broadcastPoseState(self):
        self._toAllClients(modConfig.EventPoseState,
                           {"on": 1 if self._poseOn else 0,
                            "mode": str(getattr(cfg, "FLY_POSE_MODE", "sprint"))})

    # ==================== 起飞抬升 ====================
    def _takeoffLift(self, playerId):
        if not cfg.FLY_TAKEOFF_LIFT:
            return
        try:
            motion = serverApi.GetEngineCompFactory().CreateActorMotion(playerId)
            motion.SetPlayerMotion((0.0, float(cfg.FLY_TAKEOFF_SPEED), 0.0))
        except Exception:
            pass

    # ==================== 玩家进入 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        if self._powerOn():
            self._tip(playerId, u"药水马上放进背包：喝掉变身 90 秒，屏幕左上角出现【激光】【起飞】两个按钮（电脑按 V 和 R）",
                      "LIGHT_PURPLE")
            self._potionAt[playerId] = time.time() + 2.0
        else:
            self._tip(playerId, u"眼球激光已就绪：手机点屏幕左上角的【激光】【起飞】；电脑按 V 和 R",
                      "GOLD")
        self._applySpeedState(playerId, True, tip=False)   # 不刷屏，安静地给上提速
        self._syncPowerState(playerId, force=True)

    # ==================== 飞行 ====================
    def _flyComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreateFly(playerId)
        except Exception:
            return None

    def _toggleFly(self, playerId, want=None):
        # want = True / False 表示"我要开 / 我要关"（客户端双击跳跃只会要"开"）；
        # want = None 就是老写法"切换一下"（电脑自定义按键走这条路）
        if not self._hasPower(playerId):
            self._warnNoPower(playerId)      # 没喝五号化合物，飞不起来
            return
        comp = self._flyComp(playerId)
        if comp is None:
            return
        canFly = False
        flying = False
        try:
            canFly = bool(comp.IsPlayerCanFly())
        except Exception:
            canFly = False
        try:
            flying = bool(comp.IsPlayerFlying())
        except Exception:
            flying = False
        on = (not (canFly and flying)) if want is None else bool(want)
        try:
            if on and not (canFly and flying):
                comp.ChangePlayerFlyState(True, cfg.FLY_ENTER_ON_GIVE)
                self._takeoffLift(playerId)               # 直接抬起来，不用自己按空格
                if cfg.FLY_TIP:
                    self._tip(playerId, u"飞行已开启：再点一次【起飞】/ 再按一次 R 可以关掉",
                              "GREEN")
            elif (not on) and canFly and flying:
                comp.ChangePlayerFlyState(False)          # 关掉飞行，并收回能力
                if cfg.FLY_TIP:
                    self._tip(playerId, u"飞行已关闭", "AQUA")
        except Exception:
            pass
        self._syncFlyState(playerId)
        self._applyFlySpeed(playerId)      # 飞行开/关，速度立刻跟着变

    def OnFlyToggle(self, args):
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        want = args.get("on")
        if want is None:
            want = None
        else:
            try:
                want = int(want) == 1
            except Exception:
                want = None
        self._toggleFly(playerId, want)

    # ==================== 激光 ====================
    def OnLaserHold(self, args):
        # 客户端按下 / 松开激光键
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        try:
            hold = int(args.get("hold", 0)) == 1
        except Exception:
            hold = False
        if hold:
            self._holding.add(playerId)
            self._fireArmed[playerId] = True     # 新的一次开火：重新给一个点火名额
            self._tryFire(playerId, time.time(), holding=True)   # 立刻开火，然后一直连着放
        else:
            self._holding.discard(playerId)
            self._fireArmed[playerId] = True     # 松手了：下次按下可以再点一格

    def OnServerTick(self, args=None):
        try:
            players = set(serverApi.GetPlayerList() or [])
        except Exception:
            players = set()
        if not players:
            return
        now = time.time()

        # 0) 喝药确认：按下不算，按住喝完（药水真的少了一瓶）才给效果
        self._drinkWatchTick(now)

        # -1) 刚进游戏的玩家：等背包准备好，把药水放进去（手机端不打指令也能玩）
        if self._potionAt:
            for playerId in list(self._potionAt.keys()):
                if now < self._potionAt[playerId]:
                    continue
                del self._potionAt[playerId]
                if playerId in players:
                    self._giveJoinPotion(playerId)

        # 0) 五号化合物：到点就收回能力，到点前提醒
        if self._powerOn() and self._powerUntil:
            for playerId in players:
                if playerId not in self._powerUntil:
                    continue
                left = self._powerLeftOf(playerId)
                if left <= 0.0:
                    self._losePower(playerId)
                    continue
                warned = self._powerWarned.setdefault(playerId, set())
                fired = False
                for mark in getattr(cfg, "MODE_WARN_AT", []):
                    mark = float(mark)
                    if left <= mark and mark not in warned:
                        warned.add(mark)
                        fired = True          # 同一次只提醒一句，不刷屏
                if fired and getattr(cfg, "MODE_TIP", True):
                    self._tip(playerId, u"%s 还剩 %d 秒" % (cfg.MODE_NAME, int(left)), "GOLD")

        # 0.1) 定期把"药水开着没有 / 还剩几秒"同步给客户端
        #      （屏幕按钮的显隐 + 左上角倒计时）
        if now - self._powerSyncT >= float(getattr(cfg, "MODE_SYNC_INTERVAL", 0.25)):
            self._powerSyncT = now
            for playerId in players:
                self._syncPowerState(playerId)

        # 0.2) 药效期间锁血无敌：兜底把血条顶满
        if self._invincibleOn() and now - self._hpT >= float(
                getattr(cfg, "MODE_INVINCIBLE_REFRESH", 0.25)):
            self._hpT = now
            for playerId in players:
                if self._isPowerProtected(playerId):
                    self._keepFullHp(playerId)

        # 0.3) 喷溅型：瓶子飞出去之后的兜底检查
        if self._splash:
            self._splashTick(now)

        # 0.4) 被溅到的生物：一直乱飞 + 随机开火
        if self._mobPower:
            self._mobTick(now)

        # 1) 维持移速：重生 / 换维度 / 重进都会把属性打回原样，所以定期补一次
        if cfg.SPEED_ENABLED and now - self._speedT >= cfg.SPEED_REFRESH:
            self._speedT = now
            for playerId in players:
                if playerId in self._speedOff:
                    continue
                self._boostSpeed(playerId)

        # 1.1) 飞行状态一变就换速度：飞起来就是大幅加速，落地自动回到平常速度
        if cfg.SPEED_ENABLED and now - self._flyT >= float(
                getattr(cfg, "FLY_SPEED_REFRESH", 0.25)):
            self._flyT = now
            self._refreshFlySpeed(players)

        # 1.2) 飞行状态 / 趴姿：每 0.25 秒看一眼速度
        #      （冲刺飞行才趴下；悬停和慢漂都是站姿）
        if now - self._poseSyncT >= float(getattr(cfg, "FLY_POSE_REFRESH", 0.25)):
            self._poseSyncT = now
            forceAll = (now - self._poseForceT >= 5.0)
            if forceAll:
                self._poseForceT = now     # 每 5 秒强制重发一次
            for playerId in players:
                self._syncFlyState(playerId, force=forceAll)

        # 2) 按住激光键 = 连发
        if not self._holding and not self._autoFire:
            return
        for playerId in list(self._holding) + list(self._autoFire):
            if playerId not in players:
                self._holding.discard(playerId)
                self._autoFire.discard(playerId)
                continue
            self._tryFire(playerId, now, holding=True)

    # ==================== 移速提升 ====================
    def _attrComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreateAttr(playerId)
        except Exception:
            return None

    def _speedJobs(self, flying=False, powered=True):
        # 要设置的属性：(AttrType, 目标值)
        # flying=True 时就是“飞行加速”：飞行速度和普通移速一起提上去
        AttrType = serverApi.GetMinecraftEnum().AttrType
        if not powered:
            # 没有五号化合物的时候，就是原版速度
            return [(AttrType.SPEED, cfg.SPEED_BASE_WALK),
                    (AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY)]
        walkMul = float(cfg.SPEED_MULTIPLIER)
        flyMul = float(getattr(cfg, "FLY_SPEED_MULTIPLIER", 10.0))
        if not self._flySpeedOn():
            flyMul = 1.0                       # 关掉飞行加速就回到原版飞行速度
        if flying and self._flySpeedOn():
            walkMul = max(walkMul, float(getattr(cfg, "FLY_SPEED_WALK_BOOST",
                                               cfg.SPEED_MULTIPLIER)))
        jobs = [(AttrType.SPEED, cfg.SPEED_BASE_WALK * walkMul)]
        if cfg.SPEED_BOOST_FLYING:
            jobs.append((AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY * flyMul))
        return jobs

    def _flySpeedOn(self):
        return bool(getattr(cfg, "FLY_SPEED_ENABLED", True))

    def _setAttr(self, attr, attrType, value):
        try:
            cur = float(attr.GetAttrValue(attrType))
        except Exception:
            cur = None
        if cur is not None and abs(cur - value) < 1e-4:
            return True                       # 已经是这个值，不用重复设置
        try:
            attr.SetAttrMaxValue(attrType, value)   # 先把上限抬高，否则会被截断
        except Exception:
            pass
        try:
            attr.SetAttrValue(attrType, value, 1)
            return True
        except Exception:
            return False

    def _boostSpeed(self, playerId, flying=None):
        attr = self._attrComp(playerId)
        if attr is None:
            return
        if flying is None:
            flying = self._flyStateOf(playerId)
        powered = self._hasPower(playerId)
        for attrType, want in self._speedJobs(flying, powered):
            self._setAttr(attr, attrType, want)

    def _applyFlySpeed(self, playerId):
        # 立刻按当前飞行状态换一套速度，不等下一次轮询
        if not cfg.SPEED_ENABLED or playerId in self._speedOff:
            return
        flying = bool(self._flyStateOf(playerId))
        self._flyTaken[playerId] = flying
        self._boostSpeed(playerId, flying)

    def _refreshFlySpeed(self, players):
        # 飞行状态一变（自己按键、双击跳跃、落地）就换速度
        for playerId in players:
            try:
                flying = bool(self._flyStateOf(playerId))
            except Exception:
                continue
            if self._flyTaken.get(playerId) == flying:
                continue
            self._flyTaken[playerId] = flying
            if playerId in self._speedOff:
                continue
            self._boostSpeed(playerId, flying)

    def _restoreSpeed(self, playerId):
        attr = self._attrComp(playerId)
        if attr is None:
            return
        AttrType = serverApi.GetMinecraftEnum().AttrType
        self._setAttr(attr, AttrType.SPEED, cfg.SPEED_BASE_WALK)
        if cfg.SPEED_BOOST_FLYING:
            self._setAttr(attr, AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY)

    def _applySpeedState(self, playerId, enabled, tip=None):
        if enabled:
            self._speedOff.discard(playerId)
            self._boostSpeed(playerId)
        else:
            self._speedOff.add(playerId)
            self._restoreSpeed(playerId)
        if tip is None:
            tip = cfg.SPEED_TIP
        if tip:
            if enabled:
                self._tip(playerId, u"提速已开启：移速 x%s" % cfg.SPEED_MULTIPLIER, "GREEN")
            else:
                self._tip(playerId, u"提速已关闭，恢复原版速度", "AQUA")

    def _tryFire(self, playerId, now, holding=False):
        if not cfg.LASER_ENABLED:
            return False
        if not self._hasPower(playerId):
            self._warnNoPower(playerId)      # 没喝五号化合物，眼睛射不出东西
            return False
        # 长按的时候用更短的间隔，看起来就是一条连续不断的光束
        if holding:
            cooldown = float(getattr(cfg, "LASER_COOLDOWN_HOLD",
                                     cfg.LASER_COOLDOWN))
        else:
            cooldown = float(cfg.LASER_COOLDOWN)
        if now - self._lastFire.get(playerId, 0.0) < cooldown:
            return False
        self._lastFire[playerId] = now
        self._shoot(playerId)
        return True

    def _shoot(self, playerId):
        # 从两只眼睛各打一道激光
        feet = self._posOf(playerId)
        if not feet:
            return
        pitch, yaw = self._rotOf(playerId)
        try:
            dirVec = serverApi.GetDirFromRot((pitch, yaw))
        except Exception:
            return
        dx, dy, dz = float(dirVec[0]), float(dirVec[1]), float(dirVec[2])

        # 玩家右手方向（用来把两只眼睛分开）
        hlen = math.sqrt(dx * dx + dz * dz)
        if hlen < 1e-4:
            rx, rz = 0.0, 0.0
        else:
            rx, rz = -dz / hlen, dx / hlen

        # 只有真的趴下（冲刺飞行）时头才在前面，激光才从前面出去；
        # 站着飞、悬停、站在地面，眼睛都还在原版高度
        if self._isProne(playerId):
            eyeY = feet[1] + cfg.LASER_EYE_HEIGHT_FLYING
            fwd = cfg.LASER_ORIGIN_FORWARD_FLYING
        else:
            eyeY = feet[1] + cfg.LASER_EYE_HEIGHT
            fwd = cfg.LASER_ORIGIN_FORWARD
        dimensionId = self._dimensionOf(playerId)

        beams = []
        targets = []
        cache = {}        # 本次开火里"这个方块查过/打过了"，两只眼睛共用，避免重复
        # ★ 这一枪两只眼睛合起来点了几处火；allow = 这次开火还能不能点
        shot = {"fire": 0, "pid": playerId,
                "allow": self._fireAllowed(playerId)}
        for side in (1.0, -1.0):
            ox = feet[0] + rx * cfg.LASER_EYE_GAP * side + dx * fwd
            oy = eyeY + dy * fwd
            oz = feet[2] + rz * cfg.LASER_EYE_GAP * side + dz * fwd
            origin = (ox, oy, oz)

            # 1) 先看这条线上有没有生物
            targetId, targetDist, targetPos = self._findTarget(
                dimensionId, origin, dirVec, playerId)
            reach = targetDist if targetId else float(cfg.LASER_RANGE)

            # 2) 再把路上的方块打穿；碰到基岩这种打不动的就停在它前面
            stopDist = reach
            if cfg.LASER_BREAK_ENABLED:
                stopDist = self._pierce(dimensionId, origin, dirVec, reach, cache, shot)

            if targetId and stopDist >= reach - 1e-3:
                endPos = targetPos                 # 打到了生物，光束停在生物身上
                targets.append(targetId)
            else:
                endPos = (origin[0] + dx * stopDist,
                          origin[1] + dy * stopDist,
                          origin[2] + dz * stopDist)
            beams.append((ox, oy, oz, dx, dy, dz, endPos))

        # 命中第一个生物 -> 造成伤害。两只眼睛都打中同一个目标就吃两次伤害
        for targetId in targets:
            self._hurt(targetId, playerId)

        # 广播给所有玩家（包括自己），所有人的客户端都会画出这两道红光
        self._broadcastFx(dimensionId, beams, playerId)

    def _findTarget(self, dimensionId, origin, dirVec, shooterId, maxDist=None):
        # 射线上的生物：取最近的那个（不包含自己）
        try:
            RayFilterType = serverApi.GetMinecraftEnum().RayFilterType
            onlyEntities = RayFilterType.OnlyEntities
        except Exception:
            onlyEntities = 1
        hits = None
        try:
            hits = serverApi.getEntitiesOrBlockFromRay(
                dimensionId, origin, dirVec,
                int(maxDist if maxDist else cfg.LASER_RANGE), True, onlyEntities)
        except Exception:
            hits = None
        bestId = None                # 最近的生物
        bestDist = 0.0               # 它离玩家多少格
        bestPos = (0.0, 0.0, 0.0)    # 打到它身上的位置
        for item in (hits or []):
            if item.get("type") != "Entity":
                continue
            entityId = item.get("entityId")
            if not entityId or entityId == shooterId:
                continue                  # 别把自己当成目标
            hitPos = item.get("hitPos")
            if not hitPos:
                continue
            ex = float(hitPos[0])
            ey = float(hitPos[1])
            ez = float(hitPos[2])
            dist = math.sqrt((ex - origin[0]) ** 2 + (ey - origin[1]) ** 2
                             + (ez - origin[2]) ** 2)
            if bestId is None or dist < bestDist:
                bestId = entityId
                bestDist = dist
                bestPos = (ex, ey, ez)
        if bestId is None:
            return None, None, None
        return bestId, bestDist, bestPos

    # ==================== 打穿方块 ====================
    def _blockComp(self):
        try:
            return serverApi.GetEngineCompFactory().CreateBlockInfo(
                serverApi.GetLevelId())
        except Exception:
            return None

    def _walkVoxels(self, origin, dirVec, maxDist):
        # 沿着射线一个格子一个格子地走（DDA），返回 [(方块坐标, 走到这里有多远), ...]
        dx = float(dirVec[0])
        dy = float(dirVec[1])
        dz = float(dirVec[2])
        bx = int(math.floor(origin[0]))
        by = int(math.floor(origin[1]))
        bz = int(math.floor(origin[2]))
        stepX = 1 if dx > 0 else (-1 if dx < 0 else 0)
        stepY = 1 if dy > 0 else (-1 if dy < 0 else 0)
        stepZ = 1 if dz > 0 else (-1 if dz < 0 else 0)
        INF = float("inf")
        tdx = abs(1.0 / dx) if dx else INF
        tdy = abs(1.0 / dy) if dy else INF
        tdz = abs(1.0 / dz) if dz else INF
        if dx > 0:
            tmx = (bx + 1 - origin[0]) / dx
        elif dx < 0:
            tmx = (bx - origin[0]) / dx
        else:
            tmx = INF
        if dy > 0:
            tmy = (by + 1 - origin[1]) / dy
        elif dy < 0:
            tmy = (by - origin[1]) / dy
        else:
            tmy = INF
        if dz > 0:
            tmz = (bz + 1 - origin[2]) / dz
        elif dz < 0:
            tmz = (bz - origin[2]) / dz
        else:
            tmz = INF
        out = []
        t = 0.0
        for _ in range(256):
            out.append(((bx, by, bz), t))
            if tmx < tmy and tmx < tmz:
                bx += stepX
                t = tmx
                tmx += tdx
            elif tmy < tmz:
                by += stepY
                t = tmy
                tmy += tdy
            else:
                bz += stepZ
                t = tmz
                tmz += tdz
            if t > maxDist:
                break
        return out

    def _isProtected(self, name):
        if not name:
            return False
        if self._protect is None:
            try:
                self._protect = set(cfg.LASER_BREAK_BLACKLIST or [])
            except Exception:
                self._protect = set()
        return name in self._protect

    def _breakBlock(self, comp, pos, dimensionId, cache):
        # 返回 "air"（空的/打掉了）、"stop"（打不动，挡住激光）
        name = None
        try:
            info = comp.GetBlockNew(pos, dimensionId)
            if info:
                name = info.get("name")
        except Exception:
            name = None
        if not name or name == "minecraft:air":
            cache[pos] = "air"
            return "air"
        if name in _NO_BREAK_THROUGH:
            # ★ 火 / 烟等不会被激光打掉：直接穿过去，
            #   光束路过自己点着的火时不会把火打灭
            cache[pos] = "air"
            return "air"
        if self._isProtected(name):
            cache[pos] = "stop"
            return "stop"
        ok = False
        try:
            ok = bool(comp.SetBlockNew(pos, {"name": "minecraft:air", "aux": 0},
                                       1, dimensionId, True, False))
        except Exception:
            ok = False
        cache[pos] = "broken" if ok else "air"
        return cache[pos]

    def _breakAround(self, comp, pos, dimensionId, radius, cache):
        # 把隧道拓宽成正方体（LASER_BREAK_RADIUS > 0 时才用）
        extra = 0
        for ax in range(-radius, radius + 1):
            for ay in range(-radius, radius + 1):
                for az in range(-radius, radius + 1):
                    if ax == 0 and ay == 0 and az == 0:
                        continue
                    np = (pos[0] + ax, pos[1] + ay, pos[2] + az)
                    if cache.get(np) is not None:
                        continue
                    if self._breakBlock(comp, np, dimensionId, cache) == "broken":
                        extra += 1
        return extra

    # ==================== 引火（打到哪烧到哪） ====================
    def _fireProtected(self, name):
        # 火不会点在这些方块上面
        if not name:
            return True
        if name in _NO_FIRE_UNDER:
            return True
        for one in getattr(cfg, "LASER_FIRE_BLACKLIST", []) or []:
            if name == one:
                return True
        return False

    def _fireAllowed(self, playerId):
        # ★ 这一枪能不能点火：默认每一枪都能点（长按扫射 = 火跟着光束走）
        if not getattr(cfg, "LASER_FIRE_ENABLED", True):
            return False
        if not getattr(cfg, "LASER_FIRE_PER_SHOT", True):
            # 关掉"每一枪都点"之后：一次开火（按住不放）只点第一枪那一格
            if not self._fireArmed.get(playerId, True):
                return False
        self._fireArmed[playerId] = False
        gap = float(getattr(cfg, "LASER_FIRE_MIN_GAP", 0.0))
        if gap > 0.0 and time.time() - float(self._lastBeamFire.get(playerId, 0.0)) < gap:
            return False
        return True

    def _fireUsed(self, playerId):
        # 真的点着了一格：这一次开火的名额用完
        self._fireArmed[playerId] = False
        self._lastBeamFire[playerId] = time.time()

    def _fireHere(self, comp, pos, dimensionId, tried):
        # 在某一格点一把火：这格得是空的，而且底下踩着实心方块
        if not getattr(cfg, "LASER_FIRE_ENABLED", True):
            return 0
        if pos[1] < -64 or pos[1] > 320:
            return 0
        if tried is not None:
            if pos in tried:
                return 0
            tried.add(pos)
        chance = float(getattr(cfg, "LASER_FIRE_CHANCE", 1.0))
        if chance < 1.0 and random.random() > chance:
            return 0
        info = None
        try:
            info = comp.GetBlockNew(pos, dimensionId)
        except Exception:
            info = None
        name = info.get("name") if info else None
        if name and name != "minecraft:air":
            return 0
        under = None
        try:
            info = comp.GetBlockNew((pos[0], pos[1] - 1, pos[2]), dimensionId)
            under = info.get("name") if info else None
        except Exception:
            under = None
        if self._fireProtected(under):
            return 0
        try:
            if comp.SetBlockNew(pos, FIRE_BLOCK, 0, dimensionId, True, False):
                return 1
        except Exception:
            pass
        return 0

    def _igniteArea(self, comp, pos, dimensionId, tried, radius, budget):
        # 以打中的那一格为中心，连周围一起点着（烧成一小片）
        if not getattr(cfg, "LASER_FIRE_ENABLED", True) or budget <= 0:
            return 0
        placed = 0
        for ax in range(-radius, radius + 1):
            for ay in range(-radius, radius + 1):
                for az in range(-radius, radius + 1):
                    if placed >= budget:
                        return placed
                    placed += self._fireHere(
                        comp, (pos[0] + ax, pos[1] + ay, pos[2] + az),
                        dimensionId, tried)
        return placed

    def _pierce(self, dimensionId, origin, dirVec, maxDist, cache, shot=None):
        # 打穿路上的方块，返回光束实际能前进的距离
        comp = self._blockComp()
        if comp is None:
            return maxDist
        radius = int(cfg.LASER_BREAK_RADIUS)
        broken = 0
        stopDist = maxDist
        path = []          # 先把光束路过的格子记下来，等方块全打完了再点火
        for pos, dist in self._walkVoxels(origin, dirVec, maxDist):
            if broken >= cfg.LASER_BREAK_MAX_BLOCKS:
                break
            state = cache.get(pos)
            if state is None:
                state = self._breakBlock(comp, pos, dimensionId, cache)
            if state == "stop":
                stopDist = max(0.0, dist - 0.02)      # 停在打不动的方块前面
                path.append((pos, u"impact", dist))
                break
            path.append((pos, u"broken" if state == "broken" else u"air", dist))
            if state == "broken":
                broken += 1
                if radius > 0:
                    broken += self._breakAround(comp, pos, dimensionId,
                                                radius, cache)
        # ★ 打到哪烧到哪：方块都打完了才点火，火才烧得稳
        self._ignitePath(comp, path, dimensionId, shot)
        return stopDist

    def _ignitePath(self, comp, path, dimensionId, shot=None):
        # ★ 只点着激光命中的那一格：一次开火就点一把火，
        #   之后让火自己慢慢向四周蔓延（游戏自带的火就会这么做）
        if not getattr(cfg, "LASER_FIRE_ENABLED", True) or not path:
            return 0
        limit = int(getattr(cfg, "LASER_FIRE_MAX", 1))
        if shot is None:
            shot = {"fire": 0}
        if not shot.get("allow", True):
            # ★ 这一次开火的点火名额已经用完：不再点火，
            #   让已经点着的那一格自己慢慢向四周蔓延
            return 0
        left = limit - int(shot.get("fire", 0))
        if left <= 0:
            return 0
        spread = int(getattr(cfg, "LASER_FIRE_SPREAD", 0))
        tried = set()
        # ★ 激光射到哪里，火就烧到哪里：
        #   沿着光束从头往前走，找到"光束打到的那一格"（打中地面的第一格），
        #   就在那一格点着火。扫射的时候火就一路跟着光束烧过去；
        #   对着同一格不动，那一格已经在烧了，就不会在上面反复堆火。
        minDist = float(getattr(cfg, "LASER_FIRE_MIN_DIST", 2.0))
        ahead = int(getattr(cfg, "LASER_FIRE_AHEAD", 3))
        hit = -1
        for i in range(len(path)):
            one = path[i]
            if one[1] not in (u"broken", u"impact"):
                continue
            try:
                dist = float(one[2])
            except Exception:
                dist = 0.0
            if dist < minDist:
                continue
            hit = i
            break
        if hit < 0:
            return 0          # 这一枪什么都没打到（比如朝天上打），不点火
        if ahead < 0:
            ahead = 0
        last = min(len(path) - 1, hit + ahead)
        for i in range(hit, last + 1):
            pos = path[i][0]
            if self._igniteArea(comp, pos, dimensionId, tried, spread, left) > 0:
                shot["fire"] = int(shot.get("fire", 0)) + 1
                owner = shot.get("pid")
                if owner:
                    self._fireUsed(owner)      # 记一下时间（LASER_FIRE_MIN_GAP 用）
                return 1
        return 0

    def _hurt(self, targetId, playerId):
        if not cfg.HURT_SELF and targetId == playerId:
            return
        if not cfg.HURT_CREATIVE and self._isPlayerId(targetId):
            # 只有目标是玩家时才看游戏模式：创造 / 旁观免伤。
            # 目标是生物的时候别去问游戏模式，免得被返回的怪数值挡住
            try:
                gameType = serverApi.GetEngineCompFactory().CreateGame(
                    playerId).GetPlayerGameType(targetId)
                if int(gameType) in (1, 6):      # 1 = 创造，6 = 旁观
                    return
            except Exception:
                pass
        try:
            serverApi.GetEngineCompFactory().CreateHurt(targetId).Hurt(
                float(cfg.LASER_DAMAGE),
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                playerId, None, True)
        except Exception:
            pass

    def _broadcastFx(self, dimensionId, beams, shooterId=None):
        data = {"dim": dimensionId, "pid": shooterId}
        index = 0
        for beam in beams:
            index += 1
            key = str(index)
            ox, oy, oz, dx, dy, dz, endPos = beam
            data["ox" + key] = ox
            data["oy" + key] = oy
            data["oz" + key] = oz
            data["dx" + key] = dx
            data["dy" + key] = dy
            data["dz" + key] = dz
            data["ex" + key] = endPos[0]
            data["ey" + key] = endPos[1]
            data["ez" + key] = endPos[2]
            data["ln" + key] = math.sqrt(
                (endPos[0] - ox) ** 2 + (endPos[1] - oy) ** 2 + (endPos[2] - oz) ** 2)
        self._toAllClients(modConfig.EventLaserFx, data)

    def OnFxWarn(self, args):
        # 客户端说：用来画光束的“渲染组件”用不了，光束只剩下备用画法
        playerId = args.get("playerId") if args else None
        if not playerId or playerId in self._fxWarned:
            return
        self._fxWarned.add(playerId)
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId,
                      u"提示：你这边的客户端不支持一体化光束，激光先用备用画法顶着（会像一串光点）。请把 MC Studio 和游戏客户端更新到最新版本",
                      "RED")

    def OnBeamTestResult(self, args):
        # 客户端回话：刚才那个线条测试到底画出几条
        playerId = args.get("playerId") if args else None
        if not playerId:
            return
        try:
            made = int(args.get("made", 0))
        except Exception:
            made = 0
        if made > 0:
            if getattr(cfg, "MODE_TIP", True):
                self._tip(playerId,
                          u"测试成功：你这台机器能画出一体化线条（刚画了 %d 条红线），激光会是一整束。" % made,
                          "GREEN")
        else:
            if getattr(cfg, "MODE_TIP", True):
                self._tip(playerId,
                          u"测试失败：你这台机器不支持画一体化线条，请把 MC Studio 和游戏客户端更新到最新版本。",
                          "RED")
    # ==================== 聊天指令 ====================
    def OnChat(self, args):
        try:
            if not args:
                return
            message = (args.get("message") or "").strip().lower()
            playerId = args.get("playerId")
            if not playerId:
                return
            if message in (u"#飞行", u"#fly"):
                self._toggleFly(playerId)
            elif message in (u"#激光", u"#laser"):
                self._tryFire(playerId, time.time())
            elif message in (u"#光束测试", u"#beamtest"):
                self.NotifyToClient(playerId, modConfig.EventBeamTest, {})
                self._tip(playerId, u"正在测试线条渲染，请看你眼前能不能看到三条长红线", "AQUA")

            elif message in (u"#激光连发", u"#laser auto"):
                if playerId in self._autoFire:
                    self._autoFire.discard(playerId)
                    self._tip(playerId, u"激光连发已关闭", "AQUA")
                else:
                    self._autoFire.add(playerId)
                    self._tip(playerId, u"激光连发已开启（手机端也能用），再输入一次关闭", "GREEN")
            elif message in (u"#速度", u"#speed"):
                if playerId in self._speedOff:
                    self._applySpeedState(playerId, True)
                else:
                    self._applySpeedState(playerId, False)
            elif message.startswith(u"#速度 ") or message.startswith(u"#speed "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = float(raw)
                except Exception:
                    value = None
                if value is None:
                    self._tip(playerId, u"用法： #速度 3    （数字是倍数，范围 %s ~ %s）"
                              % (cfg.SPEED_MIN, cfg.SPEED_MAX), "GOLD")
                else:
                    value = max(cfg.SPEED_MIN, min(cfg.SPEED_MAX, value))
                    cfg.SPEED_MULTIPLIER = value
                    self._applySpeedState(playerId, True, tip=False)
                    self._tip(playerId, u"移速倍数已设为 x%s" % value, "GREEN")
            elif message in (u"#速度重置", u"#speed reset"):
                cfg.SPEED_MULTIPLIER = 1.0
                self._applySpeedState(playerId, True, tip=False)
                self._tip(playerId, u"移速已恢复原版（x1.0）", "AQUA")
            elif message.startswith(u"#化合物") or message.startswith(u"#compound"):
                if not getattr(cfg, "MODE_GIVE_COMMAND", True):
                    return
                num = 1
                parts = message.split(u" ")
                if len(parts) > 1:
                    try:
                        num = int(float(parts[1]))
                    except Exception:
                        num = 1
                num = max(1, min(num, int(getattr(cfg, "MODE_STACK", 16))))
                self._givePotionItem(playerId, num)
            elif message in (u"#飞速", u"#flyspeed"):
                if self._flySpeedOn():
                    cfg.FLY_SPEED_ENABLED = False
                    self._applyFlySpeed(playerId)
                    self._tip(playerId, u"飞行加速已关闭（飞行恢复原版速度）", "AQUA")
                else:
                    cfg.FLY_SPEED_ENABLED = True
                    self._applyFlySpeed(playerId)
                    self._tip(playerId, u"飞行加速已开启：飞起来速度 x%s" % cfg.FLY_SPEED_MULTIPLIER, "GREEN")
            elif message.startswith(u"#飞速 ") or message.startswith(u"#flyspeed "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = float(raw)
                except Exception:
                    value = None
                if value is None:
                    self._tip(playerId, u"用法： #飞速 30    （数字是倍数，范围 %s ~ %s）"
                              % (cfg.FLY_SPEED_MIN, cfg.FLY_SPEED_MAX), "GOLD")
                else:
                    value = max(cfg.FLY_SPEED_MIN, min(cfg.FLY_SPEED_MAX, value))
                    cfg.FLY_SPEED_MULTIPLIER = value
                    cfg.FLY_SPEED_ENABLED = True
                    self._applyFlySpeed(playerId)
                    self._tip(playerId, u"飞行速度倍数已设为 x%s" % value, "GREEN")
            elif message in (u"#飞速重置", u"#flyspeed reset"):
                cfg.FLY_SPEED_MULTIPLIER = float(getattr(cfg, "FLY_SPEED_DEFAULT", 55.0))
                cfg.FLY_SPEED_ENABLED = True
                self._applyFlySpeed(playerId)
                self._tip(playerId, u"飞行速度已恢复默认（x%s）" % int(cfg.FLY_SPEED_MULTIPLIER), "AQUA")
            elif message in (u"#飞行姿态", u"#pose"):
                # 趴下条件，按一下换一种（不用改文件就能现场试）
                order = ["sprint", "both", "speed"]
                cur = str(getattr(cfg, "FLY_POSE_MODE", "sprint")).strip().lower()
                nxt = order[(order.index(cur) + 1) % len(order)] if cur in order else order[0]
                cfg.FLY_POSE_MODE = nxt
                self._poseOn = True
                self._broadcastPoseState()
                if nxt == "sprint":
                    self._tip(playerId, u"趴下条件：疾跑才趴（电脑双击 W / 手机奔跑键）", "GREEN")
                elif nxt == "both":
                    self._tip(playerId, u"趴下条件：疾跑或飞得快都会趴（兜底）", "GOLD")
                else:
                    self._tip(playerId, u"趴下条件：按飞行速度决定", "AQUA")
            elif message in (u"#喷溅", u"#splash"):
                if not getattr(cfg, "SPLASH_GET_COMMAND", True):
                    return
                num = 1
                parts = message.split(u" ")
                if len(parts) > 1:
                    try:
                        num = int(float(parts[1]))
                    except Exception:
                        num = 1
                num = max(1, min(num, int(getattr(cfg, "MODE_STACK", 16))))
                self._giveSplashItem(playerId, num)
            elif message in (u"#眼球激光帮助", u"#eyelaser"):
                self._tip(playerId, u"电脑：R 开关飞行，按住 V 发射激光；手机：#化合物（拿药水）#飞行 #激光 #激光连发 #速度 #飞速 #飞行姿态", "GOLD")
            else:
                return
            args["cancel"] = True
        except Exception:
            pass
