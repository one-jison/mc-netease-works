# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from EyeLaserScripts import modConfig


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class EyeLaserMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def EyeLaserServerInit(self):
        serverApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def EyeLaserServerDestroy(self):
        pass

    @Mod.InitClient()
    def EyeLaserClientInit(self):
        clientApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def EyeLaserClientDestroy(self):
        pass
