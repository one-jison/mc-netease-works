# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 数值配置（想改手感，改这个文件就够了）
# ============================================================

# ---------- 自定义按键 ----------
# 这两个按键会出现在 游戏设置 -> 键盘 里，玩家可以自己改成别的键
FLY_KEY_NAME = "eye_fly"          # 按键名（内部标识）
FLY_KEY_CODE = 82                 # 默认键：R 键
FLY_KEY_CATEGORY = "movement"     # 设置里归到"移动"分类
LASER_KEY_NAME = "eye_laser"
LASER_KEY_CODE = 86               # 默认键：V 键（按住 = 连发）
LASER_KEY_CATEGORY = "gameplay"   # 设置里归到"游戏"分类

# ---------- 五号化合物（变身药水） ----------
# 只有喝下它，下面所有能力（飞行 / 眼睛激光 / 提速 / 趴着飞）才会开启，
# 维持 MODE_DURATION 秒，时间一到全部收回去。
MODE_ENABLED = True                          # False = 不喝药水也能用（回到老玩法）
MODE_ITEM = "eyelaser:compound_five"         # 药水的物品名（别改）
MODE_NAME = "五号化合物"                      # 显示名字
MODE_DURATION = 90.0                         # ★ 喝下后维持多少秒（90 = 一分半）
MODE_WARN_AT = [30.0, 10.0, 5.0]             # 剩这些秒时各提醒一次
MODE_TIP = True                              # 药水相关提示
MODE_GIVE_COMMAND = True                     # 允许用 #化合物 拿一瓶（方便测试）
MODE_STACK = 16                              # 一次最多拿几瓶
MODE_JOIN_GIVE = True                        # 进游戏自动发药水（手机端不用打指令）
MODE_JOIN_GIVE_COUNT = 2                     # 进游戏发几瓶
MODE_REFILL_WHEN_EMPTY = False               # 药效结束后不自动补药（想让系统补一瓶就改成 True）

MODE_SYNC_INTERVAL = 0.25                   # 服务端多久检查一次药效并同步给屏幕（秒）

# ---------- 药效期间的屏幕倒计时（左上角） ----------
MODE_HUD_TIMER = True                       # ★ 喝下药水后，屏幕左上角显示剩余秒数
MODE_HUD_TIMER_FMT = u"%s 剩余 %d 秒"       # 显示格式（%s = 药水名，%d = 剩余秒数）
MODE_HUD_TIMER_COLOR = (1.0, 0.85, 0.30)    # 文字颜色（金色）
MODE_HUD_TIMER_WARN_COLOR = (1.0, 0.30, 0.25)  # 快没时间时的颜色（红）
MODE_HUD_TIMER_WARN_AT = 10.0               # 剩多少秒开始变红
MODE_HUD_TIMER_SCALE = 1.15                 # 字号缩放（1.0 = 默认大小）

# ---------- 药效期间：锁血无敌 ----------
MODE_INVINCIBLE = True                      # ★ 药效期间打不死：锁血 + 免疫所有伤害
MODE_INVINCIBLE_SURVIVAL_ONLY = True        # True = 只保护生存 / 冒险模式（创造本来就不会死）
MODE_INVINCIBLE_FULL_HP = True              # 顺便一直把血条顶满（更直观）
MODE_INVINCIBLE_REFRESH = 0.25              # 多久检查一次血条（秒）
MODE_INVINCIBLE_TIP = True                  # 变身 / 药效结束各提示一句

# ---------- 飞行 ----------
FLY_ENTER_ON_GIVE = True          # 给飞行能力时直接起飞
FLY_TIP = True                    # 开关飞行时给玩家一句提示
FLY_TAKEOFF_LIFT = True           # 开启飞行时往上抬一段，直接离地起飞
FLY_TAKEOFF_SPEED = 1.5           # 起飞抬升力度（越大飞得越高）
FLY_SPEED_MULTIPLIER = 55.0       # ★ 飞行时，飞行速度的倍数（越大飞得越快，55 = 原版的 55 倍）
FLY_SPEED_WALK_BOOST = 9.0        # ★ 飞起来时，普通移速也一起乘这么多（落地自动回到 SPEED_MULTIPLIER）
FLY_SPEED_DEFAULT = 55.0         # #飞速重置 回到的默认倍数（一般跟上面一致）
FLY_SPEED_ENABLED = True          # 飞行加速总开关
FLY_SPEED_REFRESH = 0.25          # 多久检查一次飞行状态（秒），越小反应越快
FLY_SPEED_MIN = 5.0               # 聊天指令 #飞速 x 允许的最小倍数
FLY_SPEED_MAX = 120.0              # 聊天指令 #飞速 x 允许的最大倍数

# ---------- 飞行姿态（趴着飞，像超人那样） ----------
FLY_POSE_FREEZE_LEGS = True     # 飞行时把原版走路动画整个停掉（腿就不会摆动了）
FLY_ROOT_ANIM_KEY = "root"      # 原版走路动画在 scripts/animate 里的键名（别改）

FLY_POSE_ENABLED = True           # 飞行时把玩家摆成趴着的姿势
#   "sprint" = 只有“飞行 + 疾跑”才趴（电脑双击 W / 手机奔跑按钮）—— 默认
#   "speed"  = 按速度判断（飞得够快 + 在天上 + 持续一小会儿）
#   "both"   = 上面任一条满足就趴
FLY_POSE_MODE = "sprint"
FLY_POSE_SPRINT_REPORT = 0.2     # 客户端多久把自己疾跑状态报给服务端一次（秒）
FLY_POSE_KEY = "eyelaser_prone"   # 动画短名（内部用）
FLY_POSE_ANIM = "animation.eyelaser.prone"
FLY_POSE_VAR = "query.mod.eyelaserfly"      # 1 = 正在飞（用来冻结走路动画，腿不动）
FLY_POSE_PRONE_VAR = "query.mod.eyelaserprone"  # 1 = 趴下

# 以下几行只在 FLY_POSE_MODE 为 "speed" 或 "both" 时生效：
# 一边飞一边往前冲就趴；悬停、慢慢漂、站着都是站姿
FLY_POSE_MIN_SPEED = 3.0     # ★ 飞多快才趴下（格/秒），比这快才算奔跑飞行
FLY_POSE_STOP_SPEED = 1.5    # ★ 掉到多慢就站起来（比上面小，形成迟滞，不会一快一慢乱抖）
FLY_POSE_HOLD_TIME = 0.0     # ★ 冲多久才趴（0 = 一动就趴；想加起手延迟就调大）
FLY_POSE_SPEED_CAP = 3000.0  # ★ 速度采样的传送过滤线（格/秒）
                              #   飞行提速后速度会远超 500，这条线太低的话
                              #   会把正常飞行误判成传送，飞得越快反而越不趴
FLY_POSE_NEED_AIRBORNE = True  # ★ 必须真的在天上：贴地跑 / 站在地上不算飞行奔跑，不趴
FLY_POSE_REFRESH = 0.25      # 多久检查一次速度（秒），越小切换越跟手

# 只有真趴下（冲刺飞行）时，眼睛的位置才变（不然激光会从身体里冒出来）；
# 站着飞 / 悬停 / 站在地面都用下面那两个原版高度
LASER_EYE_HEIGHT_FLYING = 0.45
LASER_ORIGIN_FORWARD_FLYING = 1.15

# ---------- 眼睛激光 ----------
LASER_ENABLED = True              # 激光总开关
LASER_DAMAGE = 8.0                # ★ 单道激光命中伤害（两只眼睛都打中 = 双倍）
LASER_COOLDOWN = 0.35             # ★ 单点一下的冷却（秒）
LASER_COOLDOWN_HOLD = 0.10        # ★ 长按时的间隔（秒），越小越连贯，看起来就像一直不断
LASER_RANGE = 40                  # ★ 射程（格）
LASER_EYE_HEIGHT = 1.62           # 眼睛离脚底多高（原版是 1.62）
LASER_EYE_GAP = 0.22              # 两只眼睛左右各偏多少格（这就是"两道激光"的来源）
LASER_ORIGIN_FORWARD = 0.35       # 射线起点往前推一点，免得打到自己
HURT_SELF = False                 # 会不会被自己的激光打到（False = 不会）
HURT_CREATIVE = False             # 会不会打到创造模式的玩家（False = 不会）

# ---------- 移速提升 ----------
SPEED_ENABLED = True              # 进存档就自动给玩家提速
SPEED_MULTIPLIER = 3.0            # ★ 速度倍数（3.0 = 原版的 3 倍，想更快要更大）
SPEED_BASE_WALK = 0.1             # 原版玩家走路移速（别改）
SPEED_BASE_FLY = 0.05             # 原版玩家飞行速度（别改）
SPEED_BOOST_FLYING = True         # 飞行速度要不要一起变快
SPEED_REFRESH = 1.0               # 每隔几秒重新套用一次（重生/换维度后自动补回来）
SPEED_FOV_LOCK = True             # 锁住镜头视野，高速跑动时画面不会拉变形
SPEED_TIP = True                  # 开关提速时给一句提示
SPEED_MIN = 0.5                   # 聊天指令 #速度 x 允许的最小倍数
SPEED_MAX = 10.0                  # 聊天指令 #速度 x 允许的最大倍数

# ---------- 激光打方块（破坏力） ----------
LASER_BREAK_ENABLED = True        # 激光能不能打掉方块
LASER_BREAK_MAX_BLOCKS = 48       # ★ 一道激光每次最多打掉多少个方块（性能保护）
LASER_BREAK_RADIUS = 0            # 0 = 只打穿 1 格宽的隧道；1 = 3x3 粗隧道；2 = 5x5
LASER_BREAK_BLACKLIST = [         # 这些方块打不动，而且会把激光挡住
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:light_block",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:end_portal",
    "minecraft:end_portal_frame",
    "minecraft:end_gateway",
    "minecraft:portal",
    "minecraft:allow",
    "minecraft:deny",
    "minecraft:border_block",
    "minecraft:reinforced_deepslate",
    "minecraft:moving_block",
    "minecraft:water",
    "minecraft:flowing_water",
    "minecraft:lava",
    "minecraft:flowing_lava",
]

# ---------- 光束表现（一体化连续光束） ----------
# ★ 每只眼睛只画一条连续的红线：从眼睛一直连到命中点，
#   中间不断开，也不是粒子拼出来的。
#   “粗一点”的那圈光是靠下面的外发光做出来的。
FX_ON = True                      # ★ 光束总开关
FX_BEAM_LINE = True               # ★ 用渲染组件画线段（主力光束，必须开）
FX_BEAM_LINE_COLOR = (1.0, 0.70, 0.64)   # 光束正中间那一条线（发白的亮芯）
# 加粗：中心一条线，外面套几圈同方向的线。
# 圈越往外颜色越暗，所以看起来是一条有亮芯、
# 边缘发暗的粗线（全部是线，没有粒子）。
# 每一圈：(半径格, 线条数, 颜色)
FX_BEAM_LINE_HALO = [
    (0.025, 6, (0.92, 0.18, 0.13)),
    (0.055, 8, (0.45, 0.06, 0.05)),
]
FX_BEAM_LINE_PRIORITY = 10        # 渲染优先级，调高免得被地形盖住

# 再试一个更加粗的办法：引擎自带的“箭头”形状自带半径，
# 如果能吃住，激光就是一根实心的粗线。头部故意留得很短，不像箭。
FX_BEAM_ARROW = True              # 关掉就只剩下面那束细线
FX_BEAM_ARROW_RADIUS = 0.055      # 激光半径（格），0.055 ≈ 眼睛粗细
FX_BEAM_ARROW_HEAD = 0.10         # 箭头尖那一小截的长度

# 备用画法（把整束光切成几段拉长的光条）：只在渲染组件用不了时自动顶上
FX_BEAM_ROD = False               # 手动开关，正常不用开
FX_BEAM_ROD_WIDTH = 0.13          # 每段光条的粗细（格）
FX_BEAM_ROD_SEG = 3.6             # 每段光条多长（格）
FX_BEAM_ROD_STEP = 3.1            # 相邻两段的间距（格），比段长小，所以首尾相接
FX_BEAM_ROD_MAX = 4               # 每道激光画几段

# 光束外面那圈红光：就是中间那条亮线外面裹着的红色光圈。
# 沿光束铺一串平头的红光，间距只有它们尺寸的一大半，
# 完全重叠在一起就是一整条光圈，看不出一个个点。
FX_BEAM_GLOW = False              # ★ 外面那圈光（一串粒子）：关掉，激光只用线画，一个小球都没有
FX_BEAM_GLOW_STEP = 0.15          # 内部密度（越小越实，太小会卡）
FX_BEAM_GLOW_SIZE = 0.28          # ★ 粗细（格）：0.16≈眼睛粗细 / 0.28 现在这个 / 0.45 粗
FX_BEAM_GLOW_SPAN = 6.0           # 粗线画到眼前多远（格）
FX_BEAM_GLOW_START = 0.45         # 从眼前多远开始铺
FX_BEAM_GLOW_TAPER = 0.0          # 0 = 粗细一直不变（像一条粗线）
FX_BEAM_GLOW_MAX = 40             # 每道激光最多铺多少个（性能保护）

# 自己开火时避开镜头，不糊视线
FX_SELF_FORWARD = 0.70            # 第三人称：表现从眼前多远开始画
FX_FP_FORWARD = 1.20              # 第一人称：再往前挪一点
FX_SELF_HALO_START = 1.00         # 自己开火时，粗线从眼前多远才开始画
FX_SELF_NO_MUZZLE = True          # 自己开火时不画眼睛处的闪光

# 只有“点”上的特效（一个光点，不会串成一串，也不影响光束形态）
FX_MUZZLE_PARTICLE = True         # 眼睛处闪一下
FX_IMPACT_PARTICLE = True         # 命中点爆一下

FX_SOUND_ENABLED = True           # 是否播放音效
LASER_SOUND = "random.fizz"       # ★ 激光的“滋滋”声（像滋滋电流）
LASER_SOUND_FALLBACK = "fire.ignite"
LASER_SOUND_VOLUME = 0.55       # 音量
LASER_SOUND_PITCH = 1.35        # 音调（越高越尖、越像激光）
