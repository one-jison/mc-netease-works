# -*- coding: utf-8 -*-
# 眼球激光 - 公共配置（模块名 / 事件名 / 版本号）
ModName = "EyeLaserMod"
ModVersion = "0.6.5"

ServerSystemName = "EyeLaserServerSystem"
ClientSystemName = "EyeLaserClientSystem"
ServerSystemClsPath = "EyeLaserScripts.eyeLaserServerSystem.EyeLaserServerSystem"
ClientSystemClsPath = "EyeLaserScripts.eyeLaserClientSystem.EyeLaserClientSystem"

# 客户端 -> 服务端
EventFlyToggle = "EyeLaserFlyToggle"     # 切换飞行
EventLaserHold = "EyeLaserHold"          # 按住 / 松开激光键

# 服务端 -> 所有客户端（光束要让所有玩家都看得见）
EventLaserFx = "EyeLaserFx"
# 服务端 -> 所有客户端（谁在飞 / 趴姿开关）
EventFlyState = "EyeLaserFlyState"
EventPoseState = "EyeLaserPoseState"
# 服务端 -> 这个玩家自己（五号化合物还开着没有：决定屏幕按钮显不显示）
EventPowerState = "EyeLaserPowerState"
# 客户端 -> 服务端（自己的疾跑状态，服务端算激光起点要用）
EventSprintState = "EyeLaserSprintState"
# 客户端 -> 服务端（客户端画不出线段时喊一声，服务端给玩家提个醒）
EventFxWarn = "EyeLaserFxWarn"

# 聊天指令 #光束测试：快速检查这台机器能不能画一体化光束
EventBeamTest = "EyeLaserBeamTest"
EventBeamTestResult = "EyeLaserBeamTestResult"

# 手机屏幕按钮（HUD）：【激光】【起飞】
UiInitFinishedEvent = "UiInitFinished"     # 界面初始化完成，收到这个事件后再建 HUD
HudUIName = "eyeLaserHud"
HudUIPyClsPath = "EyeLaserScripts.eyeLaserHudScreen.EyeLaserHudScreen"
HudUIScreenDef = "eyelaserhud.main"
