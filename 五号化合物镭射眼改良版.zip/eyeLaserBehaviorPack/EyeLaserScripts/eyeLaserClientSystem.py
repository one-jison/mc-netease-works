# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 客户端
#  负责：注册自定义按键、上报按键、画出所有人可见的红色激光束
# ============================================================
import math
import time
import mod.client.extraClientApi as clientApi
from EyeLaserScripts import modConfig
from EyeLaserScripts import eyeLaserConfig as cfg

ClientSystem = clientApi.GetClientSystemCls()

BEAM_PARTICLE = "eyelaser:beam"
MUZZLE_PARTICLE = "eyelaser:muzzle"
IMPACT_PARTICLE = "eyelaser:impact"
GLOW_PARTICLE = "eyelaser:glow"      # 激光外面那圈红光
ROD_PARTICLE = "eyelaser:rod"      # 一整根被拉长的光条


class EyeLaserClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(EyeLaserClientSystem, self).__init__(namespace, systemName)
        self._keysDone = False
        self._keyTryTime = 0.0
        self._hudNode = None        # 手机屏幕按钮（HUD）
        self._hudTries = 0
        self._hudTryTime = 0.0
        self._hudShown = None       # 按钮当前是否显示（None = 还没定下来）
        self._hudLaserDown = False  # 屏幕上的【激光】按钮是不是被按住了
        self._powerOn = None        # 五号化合物还开着吗（None = 还没收到服务端消息）
        self._powerLeft = 0         # 药效还剩几秒（服务端每 0.25 秒检查一次）
        self._fovDone = False
        self._fovTryTime = 0.0
        self._poseReady = set()     # 已经设好趴姿动画的玩家
        self._poseState = {}        # playerId -> (是否在飞, 服务端算的备选趴姿)
        self._sprintT = 0.0         # 上次检查自己疾跑状态的时间
        self._sprintSent = None     # 上次报给服务端的疾跑状态
        self._sprintSentT = 0.0     # 上次上报的时间
        self._poseOn = bool(cfg.FLY_POSE_ENABLED)
        self._poseMode = str(getattr(cfg, "FLY_POSE_MODE", "sprint")).strip().lower()
        self._poseT = 0.0
        self._shapes = []       # 画出来的光束线条（真正的'一束'）
        self._fxT = 0.0         # 上一次收到开火消息的时间
        self._lineWarned = False   # 渲染组件用不了只提醒一次
        self._comp = None         # 渲染组件（画光束线用）
        self._testHold = 0.0     # 光束测试画的线多留几秒

        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        # 自定义按键（会出现在 游戏设置 -> 键盘 里，玩家可以改键）
        self.ListenForEvent(ns, sn, "OnCustomKeyPressInGame", self, self.OnCustomKey)
        self.ListenForEvent(ns, sn, "OnScriptTickClient", self, self.OnScriptTick)
        # 手机屏幕按钮：界面初始化完成后把 HUD 建出来
        self.ListenForEvent(ns, sn, modConfig.UiInitFinishedEvent, self, self.OnUIInitFinished)
        # 进存档之后再登记一遍按键，保证一定注册上
        self.ListenForEvent(ns, sn, "OnLocalPlayerStopLoading", self, self.OnStopLoading)
        # 服务端广播的光束表现
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventLaserFx, self, self.OnLaserFx)
        # 谁在飞（用来摆趴着的姿势）
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventFlyState, self, self.OnFlyState)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventPoseState, self, self.OnPoseState)
        # 五号化合物还开着没有（决定手机两个按钮显不显示）
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventPowerState, self, self.OnPowerState)
        # 聊天指令 #光束测试：在眼前画三条大红线，看看能不能画出来
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventBeamTest, self, self.OnBeamTest)

    # ==================== 注册按键 ====================
    def OnStopLoading(self, args=None):
        # 玩家进入存档：重新登记一次自定义按键
        self._keysDone = False
        self._keyTryTime = 0.0
        self._fovDone = False
        self._poseReady = set()
        self._hudShown = None
        self._registerKeys()
        self._lockFov()
        try:
            me = clientApi.GetLocalPlayerId()
            self._applyPose(me)
        except Exception:
            pass

    def OnScriptTick(self, args=None):
        now = time.time()
        if cfg.FLY_POSE_ENABLED and now - self._poseT >= float(
                getattr(cfg, "FLY_POSE_REFRESH", 0.25)):
            self._poseT = now
            for pid in list(self._poseState.keys()):
                self._applyPose(pid)
        self._reportSprint()
        hold = 0.45
        if self._testHold > now:
            hold = self._testHold - now   # 测试画的线多留一会儿
        if self._shapes and now - self._fxT > hold:
            self._clearShapes()   # 不开火了就把光束线收掉
        if not self._fovDone and now - self._fovTryTime >= 1.0:
            self._fovTryTime = now
            self._lockFov()
        if self._hudNode is None and now - self._hudTryTime >= 3.0:
            self._hudTryTime = now
            self._ensureHud()       # 手机上的两个按钮，建失败就隔几秒再试
        self._applyHudVisible()     # 药效在不在 -> 按钮显不显示
        if self._keysDone:
            return
        if now - self._keyTryTime < 1.0:
            return          # 没注册成功就每 1 秒再试一次，别每帧都调
        self._keyTryTime = now
        self._registerKeys()

    def _lockFov(self):
        # 提速之后画面会随速度拉伸，锁住视野看着更舒服
        if self._fovDone or not cfg.SPEED_FOV_LOCK:
            self._fovDone = True
            return
        try:
            comp = clientApi.GetEngineCompFactory().CreateCamera(clientApi.GetLevelId())
            comp.SetSpeedFovLock(True)
            self._fovDone = True
        except Exception:
            pass

    def _registerKeys(self):
        view = None
        try:
            view = clientApi.GetEngineCompFactory().CreatePlayerView(clientApi.GetLevelId())
        except Exception:
            return
        ok = False
        try:
            if view.RegisterCustomKeyMapping(cfg.FLY_KEY_NAME,
                                             cfg.FLY_KEY_CODE,
                                             cfg.FLY_KEY_CATEGORY):
                ok = True
        except Exception:
            pass
        try:
            if view.RegisterCustomKeyMapping(cfg.LASER_KEY_NAME,
                                             cfg.LASER_KEY_CODE,
                                             cfg.LASER_KEY_CATEGORY):
                ok = True
        except Exception:
            pass
        if ok:
            self._keysDone = True

    # ==================== 手机屏幕按钮（HUD） ====================
    def OnUIInitFinished(self, args=None):
        self._ensureHud()

    def _ensureHud(self):
        # 建出手机上的【激光】【起飞】两个按钮，建过一次就不再建
        if self._hudNode is not None or self._hudTries >= 5:
            return
        self._hudTries += 1
        try:
            node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            if node is not None:
                self._hudNode = node
                self._hudShown = None
                self._applyHudTimer()
                return
            clientApi.RegisterUI(modConfig.ModName, modConfig.HudUIName,
                                 modConfig.HudUIPyClsPath, modConfig.HudUIScreenDef)
            node = clientApi.CreateUI(modConfig.ModName,
                                      modConfig.HudUIName, {"isHud": 1})
            if node is None:
                node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            self._hudNode = node
            self._hudShown = None
            self._applyHudTimer()
        except Exception:
            self._hudNode = None

    def HudLaserHold(self, down):
        # 屏幕上的【激光】按钮：按住 = 连着放，松开 = 停
        self._hudLaserDown = bool(down)
        self._send(modConfig.EventLaserHold, {"hold": 1 if down else 0})

    def OnPowerState(self, args):
        # 服务端告诉我们：五号化合物还开着没有、还剩几秒
        if not args:
            return
        try:
            if args.get("playerId") != clientApi.GetLocalPlayerId():
                return
            self._powerOn = int(args.get("on", 0)) == 1
            self._powerLeft = int(args.get("left", 0))
        except Exception:
            return
        self._applyHudVisible()
        self._applyHudTimer()

    def _applyHudVisible(self):
        # 只有五号化合物生效期间，屏幕上才出现【激光】【起飞】两个按钮
        node = self._hudNode
        if node is None:
            return
        # 还没收到服务端消息时先藏着（服务端每秒都会补发，很快就能对上）
        show = bool(self._powerOn)
        if show == self._hudShown:
            return
        if not show and self._hudLaserDown:
            self._hudLaserDown = False
            self._send(modConfig.EventLaserHold, {"hold": 0})   # 药效没了，顺手松开激光
        self._hudShown = show
        try:
            node.SetButtonsVisible(show)
        except Exception:
            pass

    def _applyHudTimer(self):
        # 药效期间：屏幕左上角显示还能用多少秒
        if not getattr(cfg, "MODE_HUD_TIMER", True):
            return
        node = self._hudNode
        if node is None:
            return
        left = int(self._powerLeft) if self._powerOn else 0
        try:
            node.SetTimer(bool(self._powerOn) and left > 0, left)
        except Exception:
            pass

    def HudFlyToggle(self):
        # 屏幕上的【起飞】按钮：点一下开 / 关飞行
        self._predictFly()
        self._send(modConfig.EventFlyToggle, None)

    def OnCustomKey(self, args):
        try:
            name = str(args.get("name", ""))
            isDown = str(args.get("isDown", "0")) == "1"
        except Exception:
            return
        if name == cfg.FLY_KEY_NAME:
            if isDown:
                self._predictFly()
                self._send(modConfig.EventFlyToggle, None)
            return
        if name == cfg.LASER_KEY_NAME:
            self._send(modConfig.EventLaserHold, {"hold": 1 if isDown else 0})

    def _send(self, eventName, extra):
        data = {"playerId": clientApi.GetLocalPlayerId()}
        if extra:
            data.update(extra)
        try:
            self.NotifyToServer(eventName, data)
        except Exception:
            pass

    # ==================== 飞行姿态（腿不动 / 疾跑趴下） ====================
    def _ensurePose(self, playerId):
        # 给这个玩家挂上动画和两个控制变量，挂好一次就行
        if not cfg.FLY_POSE_ENABLED:
            return False
        if playerId in self._poseReady:
            return True
        try:
            comp = clientApi.GetEngineCompFactory().CreateActorRender(playerId)
        except Exception:
            return False
        # 变量要先登记，否则条件表达式可能因为变量没注册而整个失效
        try:
            qv = clientApi.GetEngineCompFactory().CreateQueryVariable(playerId)
            qv.Register(cfg.FLY_POSE_VAR, 0.0)
            qv.Register(cfg.FLY_POSE_PRONE_VAR, 0.0)
        except Exception:
            pass
        ok = False
        try:
            if comp.AddPlayerAnimation(cfg.FLY_POSE_KEY, cfg.FLY_POSE_ANIM):
                ok = True
        except Exception:
            pass
        try:
            if comp.AddPlayerScriptAnimate(cfg.FLY_POSE_KEY,
                                           cfg.FLY_POSE_PRONE_VAR + " > 0.5"):
                ok = True
        except Exception:
            pass
        # 只要在飞，就把原版走路动画（root）关掉：
        # 这样飞行时不管有没有在移动，两条腿都是钉住不动的
        if cfg.FLY_POSE_FREEZE_LEGS:
            try:
                comp.AddPlayerScriptAnimate(cfg.FLY_ROOT_ANIM_KEY,
                                            cfg.FLY_POSE_VAR + " < 0.5",
                                            True)
            except Exception:
                pass
        if not ok:
            return False
        try:
            comp.RebuildPlayerRender()
        except Exception:
            pass
        self._poseReady.add(playerId)
        return True

    def _sprintOf(self, playerId):
        # 有没有在疾跑（电脑双击 W / 手机奔跑按钮）；读不到就返回 None
        try:
            comp = clientApi.GetEngineCompFactory().CreatePlayer(playerId)
            if comp is None:
                return None
            return bool(comp.isSprinting())
        except Exception:
            return None

    def _proneFrom(self, playerId, fly, hint):
        # 趴不趴：
        #   默认只看“飞行 + 疾跑”（hint 是服务端按速度算的备选结论）
        #   自己本机读得到疾跑状态就自己算，反应更快
        if not fly:
            return False
        mode = str(getattr(self, "_poseMode", None)
                   or getattr(cfg, "FLY_POSE_MODE", "sprint")).strip().lower()
        if mode == "speed":
            return bool(hint)
        try:
            me = clientApi.GetLocalPlayerId()
        except Exception:
            me = None
        if playerId != me:
            return bool(hint)        # 别人：以服务端的结论为准
        sprint = self._sprintOf(playerId)
        if sprint is None:
            return bool(hint)        # 读不到疾跑状态，退回服务端的判定
        if mode == "both":
            return bool(sprint) or bool(hint)
        return bool(sprint)

    def _setPose(self, playerId, fly, prone):
        try:
            comp = clientApi.GetEngineCompFactory().CreateQueryVariable(playerId)
        except Exception:
            return
        for name in (cfg.FLY_POSE_VAR, cfg.FLY_POSE_PRONE_VAR):
            try:
                comp.Register(name, 0.0)
            except Exception:
                pass
        on = bool(cfg.FLY_POSE_ENABLED) and bool(self._poseOn)
        moving = 1.0 if (on and fly) else 0.0
        lying = 1.0 if (on and fly and prone) else 0.0
        try:
            comp.Set(cfg.FLY_POSE_VAR, moving)
        except Exception:
            pass
        try:
            comp.Set(cfg.FLY_POSE_PRONE_VAR, lying)
        except Exception:
            pass

    def _applyPose(self, playerId):
        state = self._poseState.get(playerId)
        if state is None:
            return
        fly, hint = state
        if not self._ensurePose(playerId):
            return
        self._setPose(playerId, fly, self._proneFrom(playerId, fly, hint))

    def _reportSprint(self):
        # 把自己的疾跑状态报给服务端：服务端要用它算激光从哪儿射出来
        now = time.time()
        gap = float(getattr(cfg, "FLY_POSE_SPRINT_REPORT", 0.2))
        if now - self._sprintT < gap:
            return
        self._sprintT = now
        try:
            me = clientApi.GetLocalPlayerId()
        except Exception:
            return
        sprint = self._sprintOf(me)
        if sprint is None:
            return
        if sprint == self._sprintSent and now - self._sprintSentT < 2.0:
            return          # 没变化就隔 2 秒报一次心跳，不刷流量
        self._sprintSent = sprint
        self._sprintSentT = now
        self._send(modConfig.EventSprintState, {"sprint": 1 if sprint else 0})

    def _predictFly(self):
        # 按飞行键那一下先本地猜一下飞行状态，等服务器消息回来再校正
        try:
            me = clientApi.GetLocalPlayerId()
        except Exception:
            return
        fly = bool(self._poseState.get(me, (False, False))[0])
        self._poseState[me] = (not fly, False)
        self._applyPose(me)

    def OnFlyState(self, args):
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        fly = args.get("fly")
        hint = args.get("prone")
        try:
            fly = int(fly) == 1
        except Exception:
            fly = False
        try:
            hint = int(hint) == 1
        except Exception:
            hint = False
        self._poseState[playerId] = (fly, hint)
        self._applyPose(playerId)

    def OnPoseState(self, args):
        if not args:
            return
        try:
            self._poseOn = int(args.get("on", 1)) == 1
        except Exception:
            self._poseOn = True
        mode = args.get("mode")
        if mode:
            self._poseMode = str(mode).strip().lower()
        for pid in list(self._poseState.keys()):
            self._applyPose(pid)

    # ==================== 光束表现 ====================
    def _sameDimension(self, dim):
        if dim is None:
            return True
        try:
            mine = clientApi.GetEngineCompFactory().CreateDimension(
                clientApi.GetLocalPlayerId()).GetEntityDimensionId()
            return int(mine) == int(dim)
        except Exception:
            return True

    def _isFirstPerson(self):
        try:
            comp = clientApi.GetEngineCompFactory().CreateQueryVariable(
                clientApi.GetLocalPlayerId())
            res = comp.EvalMolangExpression("query.is_first_person")
            return float(res.get("value", 1)) > 0.5
        except Exception:
            return True

    def OnLaserFx(self, args):
        if not args or not getattr(cfg, "FX_ON", True):
            return
        if not self._sameDimension(args.get("dim")):
            return          # 别的维度里的激光，这边不用画
        self._fxT = time.time()
        self._clearShapes()     # 上一发画的光束线先清掉，再画这一发
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
        except Exception:
            return
        # 这一发是不是自己开的火：自己开火时表现要往后让开镜头，不然会糊住视线
        try:
            localId = clientApi.GetLocalPlayerId()
        except Exception:
            localId = None
        mine = bool(args.get("pid")) and args.get("pid") == localId
        shift = 0.0
        skipMuzzle = False
        haloStart = 0.0
        if mine:
            shift = float(cfg.FX_FP_FORWARD) if self._isFirstPerson() \
                else float(cfg.FX_SELF_FORWARD)
            skipMuzzle = bool(cfg.FX_SELF_NO_MUZZLE)
            haloStart = float(getattr(cfg, "FX_SELF_HALO_START", 0.0))
        for index in (1, 2):
            key = str(index)
            if ("ox" + key) not in args:
                continue
            try:
                ox = float(args.get("ox" + key, 0.0))
                oy = float(args.get("oy" + key, 0.0))
                oz = float(args.get("oz" + key, 0.0))
                dx = float(args.get("dx" + key, 0.0))
                dy = float(args.get("dy" + key, 0.0))
                dz = float(args.get("dz" + key, 0.0))
                length = float(args.get("ln" + key, 0.0))
                ex = float(args.get("ex" + key, 0.0))
                ey = float(args.get("ey" + key, 0.0))
                ez = float(args.get("ez" + key, 0.0))
                localHalo = haloStart
                if shift > 0.0 and length > shift + 0.8:
                    ox += dx * shift
                    oy += dy * shift
                    oz += dz * shift
                    length -= shift
                else:
                    skipMuzzle = False
                    localHalo = 0.0
                self._drawBeam(comp, ox, oy, oz, dx, dy, dz, length,
                               ex, ey, ez, skipMuzzle, localHalo)
            except Exception:
                pass
        if cfg.FX_SOUND_ENABLED:
            try:
                self._playSound(float(args.get("ox1", 0.0)),
                                float(args.get("oy1", 0.0)),
                                float(args.get("oz1", 0.0)))
            except Exception:
                pass

    def _warnNoLine(self):
        # 渲染组件用不了：提醒一次（顺便会自动换成备用画法）
        if self._lineWarned:
            return
        self._lineWarned = True
        try:
            self._send(modConfig.EventFxWarn, {})
        except Exception:
            pass

    def _drawComp(self):
        # 渲染组件拿一次就行，后面反复用（每帧都拿会很慢）
        if self._comp is None:
            self._comp = clientApi.GetEngineCompFactory().CreateDrawing(
                clientApi.GetLevelId())
        return self._comp

    def _perpBasis(self, dx, dy, dz):
        # 找一个跟光束方向垂直的单位向量
        if abs(dy) > 0.98:
            upx, upy, upz = 1.0, 0.0, 0.0
        else:
            upx, upy, upz = 0.0, 1.0, 0.0
        ux = dy * upz - dz * upy
        uy = dz * upx - dx * upz
        uz = dx * upy - dy * upx
        size = math.sqrt(ux * ux + uy * uy + uz * uz)
        if size < 1e-6:
            return (0.0, 0.0, 0.0)
        return (ux / size, uy / size, uz / size)

    def _crossBasis(self, dx, dy, dz, ux, uy, uz):
        # 再找一个垂直方向，两个方向一起把细线铺成一圈
        vx = dy * uz - dz * uy
        vy = dz * ux - dx * uz
        vz = dx * uy - dy * ux
        size = math.sqrt(vx * vx + vy * vy + vz * vz)
        if size < 1e-6:
            return (0.0, 0.0, 0.0)
        return (vx / size, vy / size, vz / size)

    def _warnNoLine(self):
        # 渲染组件用不了：提醒一次（顺便会自动换成备用画法）
        if self._lineWarned:
            return
        self._lineWarned = True
        try:
            self._send(modConfig.EventFxWarn, {})
        except Exception:
            pass

    def _drawSolidLine(self, ox, oy, oz, ex, ey, ez, dx, dy, dz):
        # ★ 主力光束：用引擎的“渲染组件”直接画线段。
        #   起点是眼睛、终点是命中点，一整条连着，中间没有任何断点，
        #   也完全不是粒子。围着光束中心铺几条，只是让它看着粗一点。
        try:
            comp = self._drawComp()
        except Exception:
            comp = None
        if comp is None:
            self._warnNoLine()
            return False
        try:
            priority = int(getattr(cfg, "FX_BEAM_LINE_PRIORITY", 0))
        except Exception:
            priority = 0
        # ★ 一条中心线 + 外面套几圈同方向的线：
        #   圈越往外颜色越暗，叠起来就是一条加粗、
        #   边缘发暗的亮线。全部是线，一个粒子都没有。
        lines = [(0.0, 0.0, 0.0, cfg.FX_BEAM_LINE_COLOR)]
        rings = getattr(cfg, "FX_BEAM_LINE_HALO", ()) or ()
        if rings:
            ux, uy, uz = self._perpBasis(dx, dy, dz)
            vx, vy, vz = self._crossBasis(dx, dy, dz, ux, uy, uz)
            for ring in rings:
                try:
                    rad = float(ring[0])
                    num = int(ring[1])
                    color = tuple(ring[2])
                except Exception:
                    continue
                if rad <= 0.0 or num <= 0:
                    continue
                for i in range(num):
                    ang = 2.0 * math.pi * i / num
                    ca = math.cos(ang) * rad
                    sa = math.sin(ang) * rad
                    lines.append((ux * ca + vx * sa, uy * ca + vy * sa,
                                  uz * ca + vz * sa, color))
        made = 0
        for off in lines:
            ax = off[0]
            ay = off[1]
            az = off[2]
            try:
                shape = comp.AddLineShape((ox + ax, oy + ay, oz + az),
                                          (ex + ax, ey + ay, ez + az),
                                          off[3])
            except Exception:
                shape = None
            if shape is None:
                continue
            try:
                shape.SetPriority(priority)
            except Exception:
                pass
            self._shapes.append(shape)
            made += 1
        # 再试试引擎自带的箭头形状：它自带半径，
        # 能吃住的话光束就是一根实心的粗线。
        if getattr(cfg, "FX_BEAM_ARROW", False):
            try:
                arrow = comp.AddArrowShape(
                    (ox, oy, oz), (ex, ey, ez), cfg.FX_BEAM_LINE_COLOR, 20,
                    float(getattr(cfg, "FX_BEAM_ARROW_HEAD", 0.10)),
                    float(getattr(cfg, "FX_BEAM_ARROW_RADIUS", 0.055)))
            except Exception:
                arrow = None
            if arrow is not None:
                try:
                    arrow.SetPriority(priority)
                except Exception:
                    pass
                self._shapes.append(arrow)
                made += 1
        if made <= 0:
            self._warnNoLine()
            return False
        return True

    def _clearShapes(self):
        # 清掉上一次画的光束线：优先让渲染组件整批清（最干净），
        # 万一不支持整批清，再一条一条地删。
        shapes = self._shapes
        self._shapes = []
        done = False
        if shapes and self._comp is not None:
            try:
                done = bool(self._comp.RemoveAll())
            except Exception:
                done = False
        if done:
            return
        for shape in shapes:
            try:
                shape.Remove()
            except Exception:
                pass


    def _spawnRod(self, comp, mx, my, mz, dx, dy, dz, blen):
        # 一根被拉长的光条：中点、方向、长度全部用变量告诉粒子
        # 这样无论发射器旋转怎么算，光条都一定沿着光束
        try:
            parId = comp.Create(ROD_PARTICLE, (mx, my, mz), (0.0, 0.0, 0.0))
        except Exception:
            return
        if not parId:
            return
        try:
            comp.SetVariable(parId, "variable.dx", float(dx))
            comp.SetVariable(parId, "variable.dy", float(dy))
            comp.SetVariable(parId, "variable.dz", float(dz))
            comp.SetVariable(parId, "variable.blen", float(blen))
        except Exception:
            pass

    def _drawRods(self, comp, ox, oy, oz, dx, dy, dz, length):
        # 把整束光切成好几段细光条，首尾相接地铺满
        # 切成短段的好处：就算引擎把光条摆歪了，也只是小小一截，不会挡住视野
        seg = float(getattr(cfg, "FX_BEAM_ROD_SEG", 3.6))
        step = float(getattr(cfg, "FX_BEAM_ROD_STEP", 3.1))
        maxSeg = int(getattr(cfg, "FX_BEAM_ROD_MAX", 4))
        if seg < 0.6:
            seg = 0.6
        if step < 0.3:
            step = 0.3
        if step > seg:
            step = seg
        leftLen = float(length)
        dist = 0.0
        count = 0
        while leftLen > 0.4 and count < maxSeg:
            blen = seg if leftLen > seg else leftLen
            mid = dist + blen * 0.5
            self._spawnRod(comp, ox + dx * mid, oy + dy * mid, oz + dz * mid,
                           dx, dy, dz, blen)
            dist += step
            leftLen -= step
            count += 1

    def _spawnGlow(self, comp, x, y, z, size):
        # 一个很软的红光斑（不是小球，边缘是逐渐淡出去的）
        try:
            parId = comp.Create(GLOW_PARTICLE, (x, y, z), (0.0, 0.0, 0.0))
        except Exception:
            return
        if not parId:
            return
        try:
            comp.SetVariable(parId, "variable.gsz", float(size))
        except Exception:
            pass

    def _drawGlow(self, comp, ox, oy, oz, dx, dy, dz, length, start):
        # 沿光束铺一串光斑。间距比光斑本身小，
        # 所以它们会互相重叠、连成一整条光晕，不会看成一串小球。
        try:
            step = float(getattr(cfg, "FX_BEAM_GLOW_STEP", 0.34))
            span = float(getattr(cfg, "FX_BEAM_GLOW_SPAN", 13.0))
            size = float(getattr(cfg, "FX_BEAM_GLOW_SIZE", 0.38))
            taper = float(getattr(cfg, "FX_BEAM_GLOW_TAPER", 0.25))
            limit = int(getattr(cfg, "FX_BEAM_GLOW_MAX", 46))
            near = float(getattr(cfg, "FX_BEAM_GLOW_START", 1.15))
        except Exception:
            return
        if step <= 0.02 or span <= 0.0 or size <= 0.0 or limit <= 0:
            return
        if start < near:
            start = near
        end = float(length)
        if end > span:
            end = span
        if end - start < 0.2:
            return
        spanLen = end - start
        dist = start
        count = 0
        while dist <= end and count < limit:
            count += 1
            k = (dist - start) / spanLen
            gsz = size * (1.0 - taper * k)
            if gsz < 0.04:
                gsz = 0.04
            self._spawnGlow(comp, ox + dx * dist, oy + dy * dist, oz + dz * dist, gsz)
            dist += step

    def _drawBeam(self, comp, ox, oy, oz, dx, dy, dz, length, ex, ey, ez,
                  skipMuzzle=False, haloStart=0.0):
        # ★ 一整条连续光束（渲染组件画线），从上到下没有断点、没有小球
        drawn = False
        if getattr(cfg, "FX_BEAM_LINE", True):
            drawn = self._drawSolidLine(ox, oy, oz, ex, ey, ez, dx, dy, dz)
        if getattr(cfg, "FX_BEAM_ROD", False) or not drawn:
            # 只在“明确开了备用画法”或“渲染组件不可用”时才用粒子顶上，
            # 至少不会什么都看不见
            self._drawRods(comp, ox, oy, oz, dx, dy, dz, length)
        if getattr(cfg, "FX_MUZZLE_PARTICLE", True) and not skipMuzzle:
            comp.Create(MUZZLE_PARTICLE, (ox, oy, oz), (0, 0, 0))
        # ★ 红色外发光：沿着光束铺一串重叠的柔光，看起来像激光在燃烧
        if getattr(cfg, "FX_BEAM_GLOW", True):
            self._drawGlow(comp, ox, oy, oz, dx, dy, dz, length, haloStart)
        # 命中点的爆点（一个点，不是一串）
        if getattr(cfg, "FX_IMPACT_PARTICLE", True):
            hitLen = dx * (ex - ox) + dy * (ey - oy) + dz * (ez - oz)
            if hitLen < length - 0.05:
                comp.Create(IMPACT_PARTICLE, (ex, ey, ez), (0, 0, 0))

    def OnBeamTest(self, args=None):
        # 聊天指令 #光束测试：在眼前画三条很长的红线，
        # 看看这台机器到底能不能画出来（只测试，不影响激光）
        made = 0
        try:
            comp = self._drawComp()
        except Exception:
            comp = None
        if comp is not None:
            try:
                blk = clientApi.GetEngineCompFactory()
                me = clientApi.GetLocalPlayerId()
                pos = blk.CreatePos(me).GetPos()
                rot = blk.CreateRot(me).GetRot()
            except Exception:
                pos = None
                rot = None
            if pos is not None and rot is not None:
                try:
                    x = float(pos[0])
                    y = float(pos[1])
                    z = float(pos[2])
                    yaw = math.radians(float(rot[1]))
                    pitch = math.radians(float(rot[0]))
                    dx = -math.sin(yaw) * math.cos(pitch)
                    dy = -math.sin(pitch)
                    dz = math.cos(yaw) * math.cos(pitch)
                    sx = x + dx * 2.0
                    sy = y + dy * 2.0
                    sz = z + dz * 2.0
                    for off in (-0.6, 0.0, 0.6):
                        try:
                            shape = comp.AddLineShape(
                                (sx, sy + off, sz),
                                (sx + dx * 26.0, sy + off + dy * 26.0,
                                 sz + dz * 26.0),
                                cfg.FX_BEAM_LINE_COLOR)
                        except Exception:
                            shape = None
                        if shape is not None:
                            try:
                                shape.SetPriority(int(
                                    getattr(cfg, "FX_BEAM_LINE_PRIORITY", 0)))
                            except Exception:
                                pass
                            self._shapes.append(shape)
                except Exception:
                    made = 0
        self._fxT = time.time()
        self._testHold = time.time() + 7.0
        try:
            self._send(modConfig.EventBeamTestResult, {"made": made})
        except Exception:
            pass

    def _playSound(self, x, y, z):
        try:
            comp = clientApi.GetEngineCompFactory().CreateCustomAudio(clientApi.GetLevelId())
            vol = float(getattr(cfg, "LASER_SOUND_VOLUME", 0.9))
            pit = float(getattr(cfg, "LASER_SOUND_PITCH", 1.7))
            result = comp.PlayCustomMusic(cfg.LASER_SOUND, (x, y, z), vol, pit, False, None)
            if result is None or str(result).startswith("-"):
                comp.PlayCustomMusic(cfg.LASER_SOUND_FALLBACK, (x, y, z), vol, pit, False, None)
        except Exception:
            pass
