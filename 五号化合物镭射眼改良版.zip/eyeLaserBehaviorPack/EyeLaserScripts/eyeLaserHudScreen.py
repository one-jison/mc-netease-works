# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 手机屏幕按钮（HUD）
#  屏幕上有两个按钮：
#    【激光】 按住不放 = 连着放，松手 = 停
#    【起飞】 点一下 = 开 / 关飞行
#  写法参考网易官方示例组件 AwesomeMod 的 fpsBattle 按钮
# ============================================================
import mod.client.extraClientApi as clientApi
from EyeLaserScripts import modConfig
from EyeLaserScripts import eyeLaserConfig as cfg

ScreenNode = clientApi.GetScreenNodeCls()


class EyeLaserHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mBtnLaser = self.mPanel + "/btnLaser"
        self.mBtnFly = self.mPanel + "/btnFly"
        self.mLblTimer = self.mPanel + "/lblTimer"
        self.mTimerOn = None
        self.mLaserDown = False

    # UI 建好后引擎会调用这里
    def Create(self):
        self._addTouch(self.mBtnLaser, self.OnLaserTouch)
        self._addTouch(self.mBtnFly, self.OnFlyTouch)
        self.SetButtonsVisible(False)   # 先藏起来，等客户端确认药水生效再露出来
        self.SetTimer(False, 0)         # 左上角倒计时也先藏起来

    def SetButtonsVisible(self, visible):
        # 没喝五号化合物的时候，屏幕上不该出现这两个按钮
        v = bool(visible)
        for path in (self.mBtnLaser, self.mBtnFly):
            try:
                ctrl = self.GetBaseUIControl(path)
                if ctrl is not None:
                    ctrl.SetVisible(v)
                    continue
            except Exception:
                pass
            try:
                self.SetVisible(path, v)
            except Exception:
                pass

    def SetTimer(self, visible, seconds):
        # 屏幕左上角：五号化合物还剩多少秒
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        if show:
            self._writeTimerText(int(seconds))
        if self.mTimerOn == show:
            return
        self.mTimerOn = show
        try:
            ctrl = self.GetBaseUIControl(self.mLblTimer)
            if ctrl is not None:
                ctrl.SetVisible(show)
                return
        except Exception:
            pass
        try:
            self.SetVisible(self.mLblTimer, show)
        except Exception:
            pass

    def _writeTimerText(self, seconds):
        fmt = getattr(cfg, "MODE_HUD_TIMER_FMT", u"%s \u5269\u4f59 %d \u79d2")
        try:
            text = fmt % (getattr(cfg, "MODE_NAME", u""), int(seconds))
        except Exception:
            text = u"%d" % int(seconds)
        warnAt = float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 10.0))
        if int(seconds) <= warnAt:
            color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
        else:
            color = getattr(cfg, "MODE_HUD_TIMER_COLOR", (1.0, 0.85, 0.30))
        try:
            lbl = self.GetBaseUIControl(self.mLblTimer).asLabel()
            lbl.SetText(text)
            try:
                lbl.SetTextColor(color)
            except Exception:
                pass
            try:
                lbl.SetTextFontSize(float(getattr(cfg, "MODE_HUD_TIMER_SCALE", 1.0)))
            except Exception:
                pass
        except Exception:
            pass

    def _addTouch(self, path, callback):
        try:
            self.AddTouchEventHandler(path, callback, {"isSwallow": True})
        except Exception:
            pass

    def _client(self):
        try:
            return clientApi.GetSystem(modConfig.ModName, modConfig.ClientSystemName)
        except Exception:
            return None

    def _event(self, args):
        try:
            return args.get("TouchEvent")
        except Exception:
            return None

    # 【激光】按钮：按住连发，松手停
    def OnLaserTouch(self, args):
        try:
            ev = clientApi.GetMinecraftEnum().TouchEvent
        except Exception:
            return
        t = self._event(args)
        cs = self._client()
        if not cs:
            return
        if t == ev.TouchDown:
            self.mLaserDown = True
            cs.HudLaserHold(True)
        elif t == ev.TouchUp or t == ev.TouchCancel:
            if self.mLaserDown:
                self.mLaserDown = False
                cs.HudLaserHold(False)

    # 【起飞】按钮：点一下开关飞行
    def OnFlyTouch(self, args):
        try:
            ev = clientApi.GetMinecraftEnum().TouchEvent
        except Exception:
            return
        if self._event(args) != ev.TouchUp:
            return
        cs = self._client()
        if cs:
            cs.HudFlyToggle()
