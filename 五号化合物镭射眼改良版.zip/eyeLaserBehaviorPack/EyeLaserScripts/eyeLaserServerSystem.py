# -*- coding: utf-8 -*-
# ============================================================
#  眼球激光 - 服务端
#  负责：飞行开关 / 眼睛激光判定 / 把光束广播给所有客户端
# ============================================================
import math
import time
import mod.server.extraServerApi as serverApi
from EyeLaserScripts import modConfig
from EyeLaserScripts import eyeLaserConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()

# 这些方块不算“踩着地”（站在水里 / 岩浆上也不算飞行贴地）
_NO_GROUND_BLOCKS = (u"minecraft:air", u"minecraft:water",
                     u"minecraft:flowing_water", u"minecraft:lava",
                     u"minecraft:flowing_lava")


class EyeLaserServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(EyeLaserServerSystem, self).__init__(namespace, systemName)
        self._lastFire = {}        # playerId -> 上次开火时间
        self._holding = set()      # 正按住激光键的玩家
        self._autoFire = set()     # 开了"激光连发"的玩家
        self._welcomed = set()
        self._protect = None       # 打不动的方块名单（第一次用到时再建）
        self._speedOff = set()     # 主动关掉提速的玩家
        self._speedT = 0.0         # 上次检查移速的时间
        self._flyTaken = {}        # playerId -> 上一次套用的是不是“飞行加速”
        self._powerUntil = {}      # playerId -> 五号化合物失效的时间戳
        self._potionAt = {}         # playerId -> 什么时候把进游戏送的药水放进背包
        self._powerWarned = {}     # playerId -> 已经提醒过的秒数
        self._powerTipT = {}       # playerId -> 上次“没药水”提示的时间
        self._flyT = 0.0           # 上次检查飞行状态的时间
        self._powerState = {}      # playerId -> 上次同步给客户端的药水开关（0 / 1）
        self._powerSyncT = 0.0     # 上次同步"药水开关"的时间
        self._gmCache = {}         # playerId -> (游戏模式, 采样时间)：判断是不是生存模式
        self._fxWarned = set()     # 已经提醒过"画不出光束线"的玩家
        self._hpT = 0.0            # 上次把血条顶满的时间
        self._lastPos = {}         # playerId -> 上次记下的位置（用来算移动速度）
        self._lastPosT = {}        # playerId -> 上次记位置的时间
        self._flySent = {}         # playerId -> 上次发出去的（飞行, 趴姿）
        self._poseSyncT = 0.0      # 上次同步飞行 / 趴姿的时间
        self._poseForceT = 0.0     # 上次强制重发飞行状态的时间
        self._poseOn = bool(cfg.FLY_POSE_ENABLED)   # 趴着飞的开关
        self._proneNow = {}        # playerId -> 现在到底趴不趴（给开火时取眼睛高度用）
        self._proneSpeed = {}      # playerId -> 上一次量到的水平速度（排查用）
        self._fastSince = {}       # playerId -> 什么时候开始持续冲刺（判定“起趴”）
        self._sprint = {}          # playerId -> 客户端报上来的疾跑状态
        self._sprintT = {}         # playerId -> 上次收到疾跑状态的时间
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        self.ListenForEvent(ns, sn, "ServerChatEvent", self, self.OnChat)
        # 服务端 tick：负责"按住不放 = 连发"
        self.ListenForEvent(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventFlyToggle, self, self.OnFlyToggle)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventLaserHold, self, self.OnLaserHold)
        # 五号化合物：喝下去的时候认一下
        self.ListenForEvent(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        self.ListenForEvent(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)
        # 药效期间锁血无敌：三层拦截，任何掉血路径都挡住
        for evtName, handler in ((u"DamageEvent", self.OnDamage),
                                 (u"ActuallyHurtServerEvent", self.OnActuallyHurt),
                                 (u"HealthChangeBeforeServerEvent",
                                  self.OnHealthChangeBefore)):
            try:
                self.ListenForEvent(ns, sn, evtName, self, handler)
            except Exception:
                pass
        # 客户端报上来的疾跑状态（趴姿 + 激光起点都要用）
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventSprintState, self, self.OnSprintState)
        # 客户端画不出线段时喊一声（渲染组件不可用）
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventFxWarn, self, self.OnFxWarn)
        # 聊天指令 #光束测试 的回执
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventBeamTestResult, self,
                            self.OnBeamTestResult)

    # ==================== 小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _rotOf(self, entityId):
        try:
            rot = serverApi.GetEngineCompFactory().CreateRot(entityId).GetRot()
            return float(rot[0]), float(rot[1])
        except Exception:
            return 0.0, 0.0

    def _dimensionOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    # ==================== 五号化合物（变身能力） ====================
    def _powerOn(self):
        return bool(getattr(cfg, "MODE_ENABLED", True))

    def _powerLeftOf(self, playerId):
        if not self._powerOn():
            return 999999.0
        return max(0.0, float(self._powerUntil.get(playerId, 0.0)) - time.time())

    def _hasPower(self, playerId):
        # 没开这个玩法就当作一直有能力
        if not self._powerOn():
            return True
        return self._powerLeftOf(playerId) > 0.0

    def _syncPowerState(self, playerId, force=False):
        # 把"五号化合物还开着没有 + 还剩几秒"告诉这个玩家的客户端；
        # 客户端拿它决定手机按钮显不显示、屏幕左上角倒计时写什么
        on = 1 if self._hasPower(playerId) else 0
        left = int(math.ceil(self._powerLeftOf(playerId))) if on else 0
        sig = (on, left)
        if not force and self._powerState.get(playerId) == sig:
            return
        try:
            self.NotifyToClient(playerId, modConfig.EventPowerState,
                                {"playerId": playerId, "on": on, "left": left})
        except Exception:
            return          # 没发出去就先不记，等下一轮继续发
        self._powerState[playerId] = sig

    def _givePower(self, playerId, reason=u""):
        dur = float(getattr(cfg, "MODE_DURATION", 90.0))
        left = self._powerLeftOf(playerId)
        self._powerUntil[playerId] = time.time() + dur
        self._powerWarned[playerId] = set()
        self._boostSpeed(playerId)          # 提速立刻生效
        self._syncPowerState(playerId, force=True)   # 按钮立刻出现
        if not getattr(cfg, "MODE_TIP", True):
            return
        if left > dur - 1.0:
            return                          # 刚刚已经提醒过，不重复刷屏
        if left > 0.0:
            self._tip(playerId, u"%s 时间已刷新，再来 %d 秒" % (cfg.MODE_NAME, int(dur)), "LIGHT_PURPLE")
        else:
            self._tip(playerId, u"%s 生效：飞行 + 眼睛激光 + 提速 全部开启，维持 %d 秒，屏幕按钮已出现" % (cfg.MODE_NAME, int(dur)), "LIGHT_PURPLE")
        if getattr(cfg, "MODE_INVINCIBLE_TIP", True) and self._invincibleOn():
            if self._isPowerProtected(playerId):
                self._tip(playerId, u"药效期间你是无敌的：打不死、血条不掉、也不会被击退",
                          "GREEN")

    def _losePower(self, playerId, quiet=False):
        self._powerUntil.pop(playerId, None)
        self._powerWarned.pop(playerId, None)
        # 药效没了：正在连发的激光也一起停掉，屏幕按钮马上收起
        self._holding.discard(playerId)
        self._autoFire.discard(playerId)
        self._syncPowerState(playerId, force=True)
        # 飞行收回去
        try:
            comp = self._flyComp(playerId)
            if comp is not None and bool(comp.IsPlayerFlying()):
                comp.ChangePlayerFlyState(False)
        except Exception:
            pass
        self._flyTaken[playerId] = False
        self._restoreSpeed(playerId)        # 速度回到原版
        self._syncFlyState(playerId)
        if quiet:
            return
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"%s 已失效，能力全部收回，屏幕按钮已收起" % cfg.MODE_NAME, "GOLD")
        # 默认不补药；MODE_REFILL_WHEN_EMPTY 打开时才会自动补一瓶
        self._refillIfEmpty(playerId)

    # ==================== 药效期间：锁血无敌 ====================
    def _invincibleOn(self):
        return bool(getattr(cfg, "MODE_INVINCIBLE", True)) and self._powerOn()

    def _gameTypeOf(self, playerId):
        # 玩家的游戏模式（0 生存 / 1 创造 / 2 冒险 / 6 旁观）
        # 拿不到就返回 None，调用方按"要保护"处理
        now = time.time()
        hit = self._gmCache.get(playerId)
        if hit and now - hit[1] < 2.0:
            return hit[0]
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(
                serverApi.GetLevelId())
            gt = int(comp.GetPlayerGameType(playerId))
        except Exception:
            return None
        self._gmCache[playerId] = (gt, now)
        return gt

    def _isPowerProtected(self, playerId):
        # 这个玩家现在要不要保护（药效还在 + 是生存 / 冒险模式）
        if not self._invincibleOn() or not playerId:
            return False
        try:
            if playerId not in (serverApi.GetPlayerList() or []):
                return False
        except Exception:
            return False
        if not self._hasPower(playerId):
            return False
        if not getattr(cfg, "MODE_INVINCIBLE_SURVIVAL_ONLY", True):
            return True
        gt = self._gameTypeOf(playerId)
        if gt is None:
            return True              # 问不到游戏模式，宁可多保护一层
        gameType = serverApi.GetMinecraftEnum().GameType
        return gt in (int(gameType.Survival), int(gameType.Adventure))

    def _keepFullHp(self, playerId):
        # 兜底：就算有伤害绕过了前面几层，也把血条顶回去
        if not getattr(cfg, "MODE_INVINCIBLE_FULL_HP", True):
            return
        attr = self._attrComp(playerId)
        if attr is None:
            return
        AttrType = serverApi.GetMinecraftEnum().AttrType
        try:
            mx = float(attr.GetAttrMaxValue(AttrType.HEALTH))
            cur = float(attr.GetAttrValue(AttrType.HEALTH))
        except Exception:
            return
        if mx <= 0.0 or cur >= mx - 0.01:
            return
        try:
            attr.SetAttrValue(AttrType.HEALTH, mx, 0)
        except Exception:
            pass

    def OnDamage(self, args):
        # 将要受伤：药效期间把伤害抹平，连击退、点燃一起免掉
        try:
            entityId = args.get("entityId")
            if not self._isPowerProtected(entityId):
                return
            args["damage"] = 0
            args["knock"] = False
            args["ignite"] = False
        except Exception:
            pass

    def OnActuallyHurt(self, args):
        # 护甲 / buff 算完之后的真实伤害：再抹一次
        try:
            entityId = args.get("entityId")
            if not self._isPowerProtected(entityId):
                return
            args["damage"] = 0
        except Exception:
            pass

    def OnHealthChangeBefore(self, args):
        # 生命值变化之前：只要是往下掉就取消（火焰、中毒、掉虚空都算）
        try:
            entityId = args.get("entityId")
            if not entityId or args.get("byScript"):
                return
            if not self._isPowerProtected(entityId):
                return
            try:
                frm = float(args.get("from", 0.0))
                to = float(args.get("to", 0.0))
            except Exception:
                return
            if to < frm:
                args["cancel"] = True
        except Exception:
            pass


    def _warnNoPower(self, playerId):
        if not getattr(cfg, "MODE_TIP", True):
            return
        now = time.time()
        if now - float(self._powerTipT.get(playerId, 0.0)) < 3.0:
            return                          # 别一直刷屏
        self._powerTipT[playerId] = now
        self._tip(playerId, u"还没有能力：先喝一瓶 %s（聊天输 #化合物 可以拿一瓶）" % cfg.MODE_NAME, "RED")

    def _hasPotion(self, playerId):
        # 背包里还有没有五号化合物
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            posType = serverApi.GetMinecraftEnum().ItemPosType
            want = str(getattr(cfg, "MODE_ITEM", "")).lower()
            for item in comp.GetPlayerAllItems(posType.INVENTORY):
                if not item:
                    continue
                name = item.get("newItemName") or item.get("itemName") or ""
                if str(name).lower() == want:
                    return True
        except Exception:
            return False
        return False

    def _giveJoinPotion(self, playerId):
        # 手机端不好打指令：进游戏先把药水放背包里，点按钮就能玩
        if not getattr(cfg, "MODE_JOIN_GIVE", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, int(getattr(cfg, "MODE_JOIN_GIVE_COUNT", 2)))

    def _refillIfEmpty(self, playerId):
        # 变身时间到：按配置决定要不要补一瓶（MODE_REFILL_WHEN_EMPTY，默认关）
        if not getattr(cfg, "MODE_REFILL_WHEN_EMPTY", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, 1)
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"变身时间到，背包里补了一瓶 %s，喝掉就能接着玩" % cfg.MODE_NAME,
                      "LIGHT_PURPLE")

    def _givePotionItem(self, playerId, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            itemDict = {"itemName": cfg.MODE_ITEM, "count": int(num), "auxValue": 0}
            ok = comp.SpawnItemToPlayerInv(itemDict, playerId)
            if getattr(cfg, "MODE_TIP", True):
                if ok:
                    self._tip(playerId, u"已获得 %s ×%d，喝下去就能变身" % (cfg.MODE_NAME, int(num)), "LIGHT_PURPLE")
                else:
                    self._tip(playerId, u"背包放不下，先清一格再试", "RED")
        except Exception:
            pass

    def _checkPotion(self, playerId, itemDict):
        # 判断刚才喝的是不是五号化合物
        if not playerId or not self._powerOn():
            return
        if not isinstance(itemDict, dict):
            return
        name = itemDict.get("itemName") or itemDict.get("newItemName") or ""
        if str(name).lower() != str(getattr(cfg, "MODE_ITEM", "")).lower():
            return
        self._givePower(playerId)

    def OnEatFood(self, args):
        # 玩家把东西喝下去了
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))

    def OnUseItem(self, args):
        # 兜底：万一吃东西那个事件没触发，这里再认一次
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))

    # ==================== 通用广播 ====================
    def _toAllClients(self, eventName, data):
        # 注意：官方接口叫 BroadcastToAllClient（不是 NotifyToAllClients）
        try:
            self.BroadcastToAllClient(eventName, data)
            return
        except Exception:
            pass
        try:
            for pid in (serverApi.GetPlayerList() or []):
                try:
                    self.NotifyToClient(pid, eventName, data)
                except Exception:
                    pass
        except Exception:
            pass

    # ==================== 飞行状态 ====================
    def _flyStateOf(self, playerId):
        comp = self._flyComp(playerId)
        if comp is None:
            return False
        try:
            return bool(comp.IsPlayerFlying())
        except Exception:
            return False

    def _moveSpeedOf(self, playerId):
        # 用两次采样之间的水平位移算速度（格 / 秒）
        pos = self._posOf(playerId)
        if pos is None:
            return 0.0
        now = time.time()
        last = self._lastPos.get(playerId)
        lastT = float(self._lastPosT.get(playerId, 0.0))
        self._lastPos[playerId] = (pos[0], pos[1], pos[2])
        self._lastPosT[playerId] = now
        if last is None:
            return 0.0
        dt = now - lastT
        if dt <= 0.001:
            return 0.0
        dx = float(pos[0]) - float(last[0])
        dz = float(pos[2]) - float(last[2])
        speed = math.sqrt(dx * dx + dz * dz) / dt
        # 跳得太离谱就当传送（换维度 / tp），不算移动。
        # 这条线必须高于正常飞行速度，否则飞得越快越会被误判成“没在动”。
        if speed > float(getattr(cfg, "FLY_POSE_SPEED_CAP", 3000.0)):
            return 0.0
        return speed

    def _isAirborne(self, playerId):
        # 脚底往下 0.12 格是不是空的：踩着地就不算"在天上飞"
        if not getattr(cfg, "FLY_POSE_NEED_AIRBORNE", True):
            return True
        pos = self._posOf(playerId)
        if not pos:
            return True            # 问不到位置就按原来的手感处理
        comp = self._blockComp()
        if comp is None:
            return True
        try:
            blockPos = (int(math.floor(float(pos[0]))),
                        int(math.floor(float(pos[1]) - 0.12)),
                        int(math.floor(float(pos[2]))))
            info = comp.GetBlockNew(blockPos, self._dimensionOf(playerId))
        except Exception:
            return True
        if not info or not hasattr(info, "get"):
            return True
        name = info.get("name")
        if not name:
            return True
        return str(name).lower() in _NO_GROUND_BLOCKS

    def OnSprintState(self, args):
        # 客户端上报：我正在疾跑 / 没在疾跑
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        try:
            self._sprint[playerId] = int(args.get("sprint", 0)) == 1
            self._sprintT[playerId] = time.time()
        except Exception:
            pass

    def _sprintOf(self, playerId):
        # 疾跑状态：True / False；超过 2 秒没收到就返回 None（当作不知道）
        t = float(self._sprintT.get(playerId, 0.0))
        if t <= 0.0 or time.time() - t > 2.0:
            return None
        return bool(self._sprint.get(playerId, False))

    def _updateProne(self, playerId, flying):
        # 趴不趴：默认“飞行 + 疾跑”才算（电脑双击 W / 手机奔跑按钮），
        # 悬停、慢慢飞、站着都不趴。判定方式可以在配置里选。
        if not flying or not getattr(cfg, "FLY_POSE_ENABLED", True) or not self._poseOn:
            self._proneNow[playerId] = False
            self._fastSince.pop(playerId, None)
            self._moveSpeedOf(playerId)          # 照样采样，保持间隔稳定
            return False
        mode = str(getattr(cfg, "FLY_POSE_MODE", "sprint")).strip().lower()
        sprint = self._sprintOf(playerId)
        if mode == "speed" or sprint is None:
            prone = self._speedProne(playerId)
        elif mode == "both":
            prone = bool(sprint) or self._speedProne(playerId)
        else:
            prone = bool(sprint)
        self._proneNow[playerId] = prone
        return prone

    def _speedProne(self, playerId):
        # 备选判定：飞得快 + 持续一小会儿 + 真的在天上
        speed = self._moveSpeedOf(playerId)
        self._proneSpeed[playerId] = speed
        was = bool(self._proneNow.get(playerId, False))
        hi = float(getattr(cfg, "FLY_POSE_MIN_SPEED", 3.0))
        lo = float(getattr(cfg, "FLY_POSE_STOP_SPEED", hi * 0.5))
        if speed < (lo if was else hi):
            self._fastSince.pop(playerId, None)
            return False                         # 慢下来就马上站起来
        now = time.time()
        since = self._fastSince.get(playerId)
        if since is None:
            since = now
            self._fastSince[playerId] = since
        if not was and (now - since) < float(getattr(cfg, "FLY_POSE_HOLD_TIME", 0.0)):
            return False                         # 刚起步还不够久，先站着
        if not self._isAirborne(playerId):
            return False                         # 脚踩着地，不算飞行奔跑
        return True


    def _isProne(self, playerId, flying=None):
        # 只读缓存：趴不趴由 _updateProne 每 0.25 秒算一次，
        # 开火时直接取结果，免得一次次重新采样把判定抖来抖去
        if flying is False:
            return False
        return bool(self._proneNow.get(playerId, False))

    def _syncFlyState(self, playerId, flying=None, force=False):
        if flying is None:
            flying = self._flyStateOf(playerId)
        prone = self._updateProne(playerId, flying)
        sig = (1 if flying else 0, 1 if prone else 0)
        if not force and self._flySent.get(playerId) == sig:
            return flying          # 没变化就不发，省带宽
        self._flySent[playerId] = sig
        self._toAllClients(modConfig.EventFlyState,
                           {"playerId": playerId,
                            "fly": sig[0], "prone": sig[1]})
        return flying

    def _broadcastPoseState(self):
        self._toAllClients(modConfig.EventPoseState,
                           {"on": 1 if self._poseOn else 0,
                            "mode": str(getattr(cfg, "FLY_POSE_MODE", "sprint"))})

    # ==================== 起飞抬升 ====================
    def _takeoffLift(self, playerId):
        if not cfg.FLY_TAKEOFF_LIFT:
            return
        try:
            motion = serverApi.GetEngineCompFactory().CreateActorMotion(playerId)
            motion.SetPlayerMotion((0.0, float(cfg.FLY_TAKEOFF_SPEED), 0.0))
        except Exception:
            pass

    # ==================== 玩家进入 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        if self._powerOn():
            self._tip(playerId, u"药水马上放进背包：喝掉变身 90 秒，屏幕上会出现【起飞】【激光】两个按钮（电脑按 R 和 V）",
                      "LIGHT_PURPLE")
            self._potionAt[playerId] = time.time() + 2.0
        else:
            self._tip(playerId, u"眼球激光已就绪：手机点屏幕右边的【起飞】【激光】按钮，电脑按 R 和 V",
                      "GOLD")
        self._applySpeedState(playerId, True, tip=False)   # 不刷屏，安静地给上提速
        self._syncPowerState(playerId, force=True)

    # ==================== 飞行 ====================
    def _flyComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreateFly(playerId)
        except Exception:
            return None

    def _toggleFly(self, playerId):
        if not self._hasPower(playerId):
            self._warnNoPower(playerId)      # 没喝五号化合物，飞不起来
            return
        comp = self._flyComp(playerId)
        if comp is None:
            return
        canFly = False
        flying = False
        try:
            canFly = bool(comp.IsPlayerCanFly())
        except Exception:
            canFly = False
        try:
            flying = bool(comp.IsPlayerFlying())
        except Exception:
            flying = False
        try:
            if canFly and flying:
                comp.ChangePlayerFlyState(False)          # 关掉飞行，并收回能力
                if cfg.FLY_TIP:
                    self._tip(playerId, u"飞行已关闭", "AQUA")
            else:
                comp.ChangePlayerFlyState(True, cfg.FLY_ENTER_ON_GIVE)
                self._takeoffLift(playerId)               # 直接抬起来，不用自己按空格
                if cfg.FLY_TIP:
                    self._tip(playerId, u"飞行已开启：空格上升、Shift 下降，再按一次开关关闭", "GREEN")
        except Exception:
            pass
        self._syncFlyState(playerId)
        self._applyFlySpeed(playerId)      # 飞行开/关，速度立刻跟着变

    def OnFlyToggle(self, args):
        playerId = args.get("playerId") if args else None
        if not playerId:
            return
        self._toggleFly(playerId)

    # ==================== 激光 ====================
    def OnLaserHold(self, args):
        # 客户端按下 / 松开激光键
        if not args:
            return
        playerId = args.get("playerId")
        if not playerId:
            return
        try:
            hold = int(args.get("hold", 0)) == 1
        except Exception:
            hold = False
        if hold:
            self._holding.add(playerId)
            self._tryFire(playerId, time.time(), holding=True)   # 立刻开火，然后一直连着放
        else:
            self._holding.discard(playerId)

    def OnServerTick(self, args=None):
        try:
            players = set(serverApi.GetPlayerList() or [])
        except Exception:
            players = set()
        if not players:
            return
        now = time.time()

        # -1) 刚进游戏的玩家：等背包准备好，把药水放进去（手机端不打指令也能玩）
        if self._potionAt:
            for playerId in list(self._potionAt.keys()):
                if now < self._potionAt[playerId]:
                    continue
                del self._potionAt[playerId]
                if playerId in players:
                    self._giveJoinPotion(playerId)

        # 0) 五号化合物：到点就收回能力，到点前提醒
        if self._powerOn() and self._powerUntil:
            for playerId in players:
                if playerId not in self._powerUntil:
                    continue
                left = self._powerLeftOf(playerId)
                if left <= 0.0:
                    self._losePower(playerId)
                    continue
                warned = self._powerWarned.setdefault(playerId, set())
                fired = False
                for mark in getattr(cfg, "MODE_WARN_AT", []):
                    mark = float(mark)
                    if left <= mark and mark not in warned:
                        warned.add(mark)
                        fired = True          # 同一次只提醒一句，不刷屏
                if fired and getattr(cfg, "MODE_TIP", True):
                    self._tip(playerId, u"%s 还剩 %d 秒" % (cfg.MODE_NAME, int(left)), "GOLD")

        # 0.1) 定期把"药水开着没有 / 还剩几秒"同步给客户端
        #      （屏幕按钮的显隐 + 左上角倒计时）
        if now - self._powerSyncT >= float(getattr(cfg, "MODE_SYNC_INTERVAL", 0.25)):
            self._powerSyncT = now
            for playerId in players:
                self._syncPowerState(playerId)

        # 0.2) 药效期间锁血无敌：兜底把血条顶满
        if self._invincibleOn() and now - self._hpT >= float(
                getattr(cfg, "MODE_INVINCIBLE_REFRESH", 0.25)):
            self._hpT = now
            for playerId in players:
                if self._isPowerProtected(playerId):
                    self._keepFullHp(playerId)

        # 1) 维持移速：重生 / 换维度 / 重进都会把属性打回原样，所以定期补一次
        if cfg.SPEED_ENABLED and now - self._speedT >= cfg.SPEED_REFRESH:
            self._speedT = now
            for playerId in players:
                if playerId in self._speedOff:
                    continue
                self._boostSpeed(playerId)

        # 1.1) 飞行状态一变就换速度：飞起来就是大幅加速，落地自动回到平常速度
        if cfg.SPEED_ENABLED and now - self._flyT >= float(
                getattr(cfg, "FLY_SPEED_REFRESH", 0.25)):
            self._flyT = now
            self._refreshFlySpeed(players)

        # 1.2) 飞行状态 / 趴姿：每 0.25 秒看一眼速度
        #      （冲刺飞行才趴下；悬停和慢漂都是站姿）
        if now - self._poseSyncT >= float(getattr(cfg, "FLY_POSE_REFRESH", 0.25)):
            self._poseSyncT = now
            forceAll = (now - self._poseForceT >= 5.0)
            if forceAll:
                self._poseForceT = now     # 每 5 秒强制重发一次
            for playerId in players:
                self._syncFlyState(playerId, force=forceAll)

        # 2) 按住激光键 = 连发
        if not self._holding and not self._autoFire:
            return
        for playerId in list(self._holding) + list(self._autoFire):
            if playerId not in players:
                self._holding.discard(playerId)
                self._autoFire.discard(playerId)
                continue
            self._tryFire(playerId, now, holding=True)

    # ==================== 移速提升 ====================
    def _attrComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreateAttr(playerId)
        except Exception:
            return None

    def _speedJobs(self, flying=False, powered=True):
        # 要设置的属性：(AttrType, 目标值)
        # flying=True 时就是“飞行加速”：飞行速度和普通移速一起提上去
        AttrType = serverApi.GetMinecraftEnum().AttrType
        if not powered:
            # 没有五号化合物的时候，就是原版速度
            return [(AttrType.SPEED, cfg.SPEED_BASE_WALK),
                    (AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY)]
        walkMul = float(cfg.SPEED_MULTIPLIER)
        flyMul = float(getattr(cfg, "FLY_SPEED_MULTIPLIER", 10.0))
        if not self._flySpeedOn():
            flyMul = 1.0                       # 关掉飞行加速就回到原版飞行速度
        if flying and self._flySpeedOn():
            walkMul = max(walkMul, float(getattr(cfg, "FLY_SPEED_WALK_BOOST",
                                               cfg.SPEED_MULTIPLIER)))
        jobs = [(AttrType.SPEED, cfg.SPEED_BASE_WALK * walkMul)]
        if cfg.SPEED_BOOST_FLYING:
            jobs.append((AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY * flyMul))
        return jobs

    def _flySpeedOn(self):
        return bool(getattr(cfg, "FLY_SPEED_ENABLED", True))

    def _setAttr(self, attr, attrType, value):
        try:
            cur = float(attr.GetAttrValue(attrType))
        except Exception:
            cur = None
        if cur is not None and abs(cur - value) < 1e-4:
            return True                       # 已经是这个值，不用重复设置
        try:
            attr.SetAttrMaxValue(attrType, value)   # 先把上限抬高，否则会被截断
        except Exception:
            pass
        try:
            attr.SetAttrValue(attrType, value, 1)
            return True
        except Exception:
            return False

    def _boostSpeed(self, playerId, flying=None):
        attr = self._attrComp(playerId)
        if attr is None:
            return
        if flying is None:
            flying = self._flyStateOf(playerId)
        powered = self._hasPower(playerId)
        for attrType, want in self._speedJobs(flying, powered):
            self._setAttr(attr, attrType, want)

    def _applyFlySpeed(self, playerId):
        # 立刻按当前飞行状态换一套速度，不等下一次轮询
        if not cfg.SPEED_ENABLED or playerId in self._speedOff:
            return
        flying = bool(self._flyStateOf(playerId))
        self._flyTaken[playerId] = flying
        self._boostSpeed(playerId, flying)

    def _refreshFlySpeed(self, players):
        # 飞行状态一变（自己按键、双击跳跃、落地）就换速度
        for playerId in players:
            try:
                flying = bool(self._flyStateOf(playerId))
            except Exception:
                continue
            if self._flyTaken.get(playerId) == flying:
                continue
            self._flyTaken[playerId] = flying
            if playerId in self._speedOff:
                continue
            self._boostSpeed(playerId, flying)

    def _restoreSpeed(self, playerId):
        attr = self._attrComp(playerId)
        if attr is None:
            return
        AttrType = serverApi.GetMinecraftEnum().AttrType
        self._setAttr(attr, AttrType.SPEED, cfg.SPEED_BASE_WALK)
        if cfg.SPEED_BOOST_FLYING:
            self._setAttr(attr, AttrType.FLYING_SPEED, cfg.SPEED_BASE_FLY)

    def _applySpeedState(self, playerId, enabled, tip=None):
        if enabled:
            self._speedOff.discard(playerId)
            self._boostSpeed(playerId)
        else:
            self._speedOff.add(playerId)
            self._restoreSpeed(playerId)
        if tip is None:
            tip = cfg.SPEED_TIP
        if tip:
            if enabled:
                self._tip(playerId, u"提速已开启：移速 x%s" % cfg.SPEED_MULTIPLIER, "GREEN")
            else:
                self._tip(playerId, u"提速已关闭，恢复原版速度", "AQUA")

    def _tryFire(self, playerId, now, holding=False):
        if not cfg.LASER_ENABLED:
            return False
        if not self._hasPower(playerId):
            self._warnNoPower(playerId)      # 没喝五号化合物，眼睛射不出东西
            return False
        # 长按的时候用更短的间隔，看起来就是一条连续不断的光束
        if holding:
            cooldown = float(getattr(cfg, "LASER_COOLDOWN_HOLD",
                                     cfg.LASER_COOLDOWN))
        else:
            cooldown = float(cfg.LASER_COOLDOWN)
        if now - self._lastFire.get(playerId, 0.0) < cooldown:
            return False
        self._lastFire[playerId] = now
        self._shoot(playerId)
        return True

    def _shoot(self, playerId):
        # 从两只眼睛各打一道激光
        feet = self._posOf(playerId)
        if not feet:
            return
        pitch, yaw = self._rotOf(playerId)
        try:
            dirVec = serverApi.GetDirFromRot((pitch, yaw))
        except Exception:
            return
        dx, dy, dz = float(dirVec[0]), float(dirVec[1]), float(dirVec[2])

        # 玩家右手方向（用来把两只眼睛分开）
        hlen = math.sqrt(dx * dx + dz * dz)
        if hlen < 1e-4:
            rx, rz = 0.0, 0.0
        else:
            rx, rz = -dz / hlen, dx / hlen

        # 只有真的趴下（冲刺飞行）时头才在前面，激光才从前面出去；
        # 站着飞、悬停、站在地面，眼睛都还在原版高度
        if self._isProne(playerId):
            eyeY = feet[1] + cfg.LASER_EYE_HEIGHT_FLYING
            fwd = cfg.LASER_ORIGIN_FORWARD_FLYING
        else:
            eyeY = feet[1] + cfg.LASER_EYE_HEIGHT
            fwd = cfg.LASER_ORIGIN_FORWARD
        dimensionId = self._dimensionOf(playerId)

        beams = []
        targets = []
        cache = {}        # 本次开火里"这个方块查过/打过了"，两只眼睛共用，避免重复
        for side in (1.0, -1.0):
            ox = feet[0] + rx * cfg.LASER_EYE_GAP * side + dx * fwd
            oy = eyeY + dy * fwd
            oz = feet[2] + rz * cfg.LASER_EYE_GAP * side + dz * fwd
            origin = (ox, oy, oz)

            # 1) 先看这条线上有没有生物
            targetId, targetDist, targetPos = self._findTarget(
                dimensionId, origin, dirVec, playerId)
            reach = targetDist if targetId else float(cfg.LASER_RANGE)

            # 2) 再把路上的方块打穿；碰到基岩这种打不动的就停在它前面
            stopDist = reach
            if cfg.LASER_BREAK_ENABLED:
                stopDist = self._pierce(dimensionId, origin, dirVec, reach, cache)

            if targetId and stopDist >= reach - 1e-3:
                endPos = targetPos                 # 打到了生物，光束停在生物身上
                targets.append(targetId)
            else:
                endPos = (origin[0] + dx * stopDist,
                          origin[1] + dy * stopDist,
                          origin[2] + dz * stopDist)
            beams.append((ox, oy, oz, dx, dy, dz, endPos))

        # 命中第一个生物 -> 造成伤害。两只眼睛都打中同一个目标就吃两次伤害
        for targetId in targets:
            self._hurt(targetId, playerId)

        # 广播给所有玩家（包括自己），所有人的客户端都会画出这两道红光
        self._broadcastFx(dimensionId, beams, playerId)

    def _findTarget(self, dimensionId, origin, dirVec, shooterId):
        # 射线上的生物：取最近的那个（不包含自己）
        try:
            RayFilterType = serverApi.GetMinecraftEnum().RayFilterType
            onlyEntities = RayFilterType.OnlyEntities
        except Exception:
            onlyEntities = 1
        hits = None
        try:
            hits = serverApi.getEntitiesOrBlockFromRay(
                dimensionId, origin, dirVec, int(cfg.LASER_RANGE), True, onlyEntities)
        except Exception:
            hits = None
        bestId = None                # 最近的生物
        bestDist = 0.0               # 它离玩家多少格
        bestPos = (0.0, 0.0, 0.0)    # 打到它身上的位置
        for item in (hits or []):
            if item.get("type") != "Entity":
                continue
            entityId = item.get("entityId")
            if not entityId or entityId == shooterId:
                continue                  # 别把自己当成目标
            hitPos = item.get("hitPos")
            if not hitPos:
                continue
            ex = float(hitPos[0])
            ey = float(hitPos[1])
            ez = float(hitPos[2])
            dist = math.sqrt((ex - origin[0]) ** 2 + (ey - origin[1]) ** 2
                             + (ez - origin[2]) ** 2)
            if bestId is None or dist < bestDist:
                bestId = entityId
                bestDist = dist
                bestPos = (ex, ey, ez)
        if bestId is None:
            return None, None, None
        return bestId, bestDist, bestPos

    # ==================== 打穿方块 ====================
    def _blockComp(self):
        try:
            return serverApi.GetEngineCompFactory().CreateBlockInfo(
                serverApi.GetLevelId())
        except Exception:
            return None

    def _walkVoxels(self, origin, dirVec, maxDist):
        # 沿着射线一个格子一个格子地走（DDA），返回 [(方块坐标, 走到这里有多远), ...]
        dx = float(dirVec[0])
        dy = float(dirVec[1])
        dz = float(dirVec[2])
        bx = int(math.floor(origin[0]))
        by = int(math.floor(origin[1]))
        bz = int(math.floor(origin[2]))
        stepX = 1 if dx > 0 else (-1 if dx < 0 else 0)
        stepY = 1 if dy > 0 else (-1 if dy < 0 else 0)
        stepZ = 1 if dz > 0 else (-1 if dz < 0 else 0)
        INF = float("inf")
        tdx = abs(1.0 / dx) if dx else INF
        tdy = abs(1.0 / dy) if dy else INF
        tdz = abs(1.0 / dz) if dz else INF
        if dx > 0:
            tmx = (bx + 1 - origin[0]) / dx
        elif dx < 0:
            tmx = (bx - origin[0]) / dx
        else:
            tmx = INF
        if dy > 0:
            tmy = (by + 1 - origin[1]) / dy
        elif dy < 0:
            tmy = (by - origin[1]) / dy
        else:
            tmy = INF
        if dz > 0:
            tmz = (bz + 1 - origin[2]) / dz
        elif dz < 0:
            tmz = (bz - origin[2]) / dz
        else:
            tmz = INF
        out = []
        t = 0.0
        for _ in range(256):
            out.append(((bx, by, bz), t))
            if tmx < tmy and tmx < tmz:
                bx += stepX
                t = tmx
                tmx += tdx
            elif tmy < tmz:
                by += stepY
                t = tmy
                tmy += tdy
            else:
                bz += stepZ
                t = tmz
                tmz += tdz
            if t > maxDist:
                break
        return out

    def _isProtected(self, name):
        if not name:
            return False
        if self._protect is None:
            try:
                self._protect = set(cfg.LASER_BREAK_BLACKLIST or [])
            except Exception:
                self._protect = set()
        return name in self._protect

    def _breakBlock(self, comp, pos, dimensionId, cache):
        # 返回 "air"（空的/打掉了）、"stop"（打不动，挡住激光）
        name = None
        try:
            info = comp.GetBlockNew(pos, dimensionId)
            if info:
                name = info.get("name")
        except Exception:
            name = None
        if not name or name == "minecraft:air":
            cache[pos] = "air"
            return "air"
        if self._isProtected(name):
            cache[pos] = "stop"
            return "stop"
        ok = False
        try:
            ok = bool(comp.SetBlockNew(pos, {"name": "minecraft:air", "aux": 0},
                                       1, dimensionId, True, False))
        except Exception:
            ok = False
        cache[pos] = "broken" if ok else "air"
        return cache[pos]

    def _breakAround(self, comp, pos, dimensionId, radius, cache):
        # 把隧道拓宽成正方体（LASER_BREAK_RADIUS > 0 时才用）
        extra = 0
        for ax in range(-radius, radius + 1):
            for ay in range(-radius, radius + 1):
                for az in range(-radius, radius + 1):
                    if ax == 0 and ay == 0 and az == 0:
                        continue
                    np = (pos[0] + ax, pos[1] + ay, pos[2] + az)
                    if cache.get(np) is not None:
                        continue
                    if self._breakBlock(comp, np, dimensionId, cache) == "broken":
                        extra += 1
        return extra

    def _pierce(self, dimensionId, origin, dirVec, maxDist, cache):
        # 打穿路上的方块，返回光束实际能前进的距离
        comp = self._blockComp()
        if comp is None:
            return maxDist
        radius = int(cfg.LASER_BREAK_RADIUS)
        broken = 0
        for pos, dist in self._walkVoxels(origin, dirVec, maxDist):
            if broken >= cfg.LASER_BREAK_MAX_BLOCKS:
                return maxDist
            state = cache.get(pos)
            if state is None:
                state = self._breakBlock(comp, pos, dimensionId, cache)
            if state == "stop":
                return max(0.0, dist - 0.02)      # 停在打不动的方块前面
            if state == "broken":
                broken += 1
                if radius > 0:
                    broken += self._breakAround(comp, pos, dimensionId,
                                                radius, cache)
        return maxDist

    def _hurt(self, targetId, playerId):
        if not cfg.HURT_SELF and targetId == playerId:
            return
        if not cfg.HURT_CREATIVE:
            try:
                gameType = serverApi.GetEngineCompFactory().CreateGame(
                    playerId).GetPlayerGameType(targetId)
                if int(gameType) in (1, 6):      # 1 = 创造，6 = 旁观
                    return
            except Exception:
                pass
        try:
            serverApi.GetEngineCompFactory().CreateHurt(targetId).Hurt(
                float(cfg.LASER_DAMAGE),
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                playerId, None, True)
        except Exception:
            pass

    def _broadcastFx(self, dimensionId, beams, shooterId=None):
        data = {"dim": dimensionId, "pid": shooterId}
        index = 0
        for beam in beams:
            index += 1
            key = str(index)
            ox, oy, oz, dx, dy, dz, endPos = beam
            data["ox" + key] = ox
            data["oy" + key] = oy
            data["oz" + key] = oz
            data["dx" + key] = dx
            data["dy" + key] = dy
            data["dz" + key] = dz
            data["ex" + key] = endPos[0]
            data["ey" + key] = endPos[1]
            data["ez" + key] = endPos[2]
            data["ln" + key] = math.sqrt(
                (endPos[0] - ox) ** 2 + (endPos[1] - oy) ** 2 + (endPos[2] - oz) ** 2)
        self._toAllClients(modConfig.EventLaserFx, data)

    def OnFxWarn(self, args):
        # 客户端说：用来画光束的“渲染组件”用不了，光束只剩下备用画法
        playerId = args.get("playerId") if args else None
        if not playerId or playerId in self._fxWarned:
            return
        self._fxWarned.add(playerId)
        if getattr(cfg, "MODE_TIP", True):
            self._tip(playerId,
                      u"提示：你这边的客户端不支持一体化光束，激光先用备用画法顶着（会像一串光点）。请把 MC Studio 和游戏客户端更新到最新版本",
                      "RED")

    def OnBeamTestResult(self, args):
        # 客户端回话：刚才那个线条测试到底画出几条
        playerId = args.get("playerId") if args else None
        if not playerId:
            return
        try:
            made = int(args.get("made", 0))
        except Exception:
            made = 0
        if made > 0:
            if getattr(cfg, "MODE_TIP", True):
                self._tip(playerId,
                          u"测试成功：你这台机器能画出一体化线条（刚画了 %d 条红线），激光会是一整束。" % made,
                          "GREEN")
        else:
            if getattr(cfg, "MODE_TIP", True):
                self._tip(playerId,
                          u"测试失败：你这台机器不支持画一体化线条，请把 MC Studio 和游戏客户端更新到最新版本。",
                          "RED")
    # ==================== 聊天指令 ====================
    def OnChat(self, args):
        try:
            if not args:
                return
            message = (args.get("message") or "").strip().lower()
            playerId = args.get("playerId")
            if not playerId:
                return
            if message in (u"#飞行", u"#fly"):
                self._toggleFly(playerId)
            elif message in (u"#激光", u"#laser"):
                self._tryFire(playerId, time.time())
            elif message in (u"#光束测试", u"#beamtest"):
                self.NotifyToClient(playerId, modConfig.EventBeamTest, {})
                self._tip(playerId, u"正在测试线条渲染，请看你眼前能不能看到三条长红线", "AQUA")

            elif message in (u"#激光连发", u"#laser auto"):
                if playerId in self._autoFire:
                    self._autoFire.discard(playerId)
                    self._tip(playerId, u"激光连发已关闭", "AQUA")
                else:
                    self._autoFire.add(playerId)
                    self._tip(playerId, u"激光连发已开启（手机端也能用），再输入一次关闭", "GREEN")
            elif message in (u"#速度", u"#speed"):
                if playerId in self._speedOff:
                    self._applySpeedState(playerId, True)
                else:
                    self._applySpeedState(playerId, False)
            elif message.startswith(u"#速度 ") or message.startswith(u"#speed "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = float(raw)
                except Exception:
                    value = None
                if value is None:
                    self._tip(playerId, u"用法： #速度 3    （数字是倍数，范围 %s ~ %s）"
                              % (cfg.SPEED_MIN, cfg.SPEED_MAX), "GOLD")
                else:
                    value = max(cfg.SPEED_MIN, min(cfg.SPEED_MAX, value))
                    cfg.SPEED_MULTIPLIER = value
                    self._applySpeedState(playerId, True, tip=False)
                    self._tip(playerId, u"移速倍数已设为 x%s" % value, "GREEN")
            elif message in (u"#速度重置", u"#speed reset"):
                cfg.SPEED_MULTIPLIER = 1.0
                self._applySpeedState(playerId, True, tip=False)
                self._tip(playerId, u"移速已恢复原版（x1.0）", "AQUA")
            elif message.startswith(u"#化合物") or message.startswith(u"#compound"):
                if not getattr(cfg, "MODE_GIVE_COMMAND", True):
                    return
                num = 1
                parts = message.split(u" ")
                if len(parts) > 1:
                    try:
                        num = int(float(parts[1]))
                    except Exception:
                        num = 1
                num = max(1, min(num, int(getattr(cfg, "MODE_STACK", 16))))
                self._givePotionItem(playerId, num)
            elif message in (u"#飞速", u"#flyspeed"):
                if self._flySpeedOn():
                    cfg.FLY_SPEED_ENABLED = False
                    self._applyFlySpeed(playerId)
                    self._tip(playerId, u"飞行加速已关闭（飞行恢复原版速度）", "AQUA")
                else:
                    cfg.FLY_SPEED_ENABLED = True
                    self._applyFlySpeed(playerId)
                    self._tip(playerId, u"飞行加速已开启：飞起来速度 x%s" % cfg.FLY_SPEED_MULTIPLIER, "GREEN")
            elif message.startswith(u"#飞速 ") or message.startswith(u"#flyspeed "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = float(raw)
                except Exception:
                    value = None
                if value is None:
                    self._tip(playerId, u"用法： #飞速 30    （数字是倍数，范围 %s ~ %s）"
                              % (cfg.FLY_SPEED_MIN, cfg.FLY_SPEED_MAX), "GOLD")
                else:
                    value = max(cfg.FLY_SPEED_MIN, min(cfg.FLY_SPEED_MAX, value))
                    cfg.FLY_SPEED_MULTIPLIER = value
                    cfg.FLY_SPEED_ENABLED = True
                    self._applyFlySpeed(playerId)
                    self._tip(playerId, u"飞行速度倍数已设为 x%s" % value, "GREEN")
            elif message in (u"#飞速重置", u"#flyspeed reset"):
                cfg.FLY_SPEED_MULTIPLIER = float(getattr(cfg, "FLY_SPEED_DEFAULT", 55.0))
                cfg.FLY_SPEED_ENABLED = True
                self._applyFlySpeed(playerId)
                self._tip(playerId, u"飞行速度已恢复默认（x%s）" % int(cfg.FLY_SPEED_MULTIPLIER), "AQUA")
            elif message in (u"#飞行姿态", u"#pose"):
                # 趴下条件，按一下换一种（不用改文件就能现场试）
                order = ["sprint", "both", "speed"]
                cur = str(getattr(cfg, "FLY_POSE_MODE", "sprint")).strip().lower()
                nxt = order[(order.index(cur) + 1) % len(order)] if cur in order else order[0]
                cfg.FLY_POSE_MODE = nxt
                self._poseOn = True
                self._broadcastPoseState()
                if nxt == "sprint":
                    self._tip(playerId, u"趴下条件：疾跑才趴（电脑双击 W / 手机奔跑键）", "GREEN")
                elif nxt == "both":
                    self._tip(playerId, u"趴下条件：疾跑或飞得快都会趴（兜底）", "GOLD")
                else:
                    self._tip(playerId, u"趴下条件：按飞行速度决定", "AQUA")
            elif message in (u"#眼球激光帮助", u"#eyelaser"):
                self._tip(playerId, u"电脑：R 开关飞行，按住 V 发射激光；手机：#化合物（拿药水）#飞行 #激光 #激光连发 #速度 #飞速 #飞行姿态", "GOLD")
            else:
                return
            args["cancel"] = True
        except Exception:
            pass
