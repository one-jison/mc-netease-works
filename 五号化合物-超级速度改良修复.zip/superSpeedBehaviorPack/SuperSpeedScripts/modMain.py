# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from SuperSpeedScripts import modConfig


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class SuperSpeedMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def SuperSpeedServerInit(self):
        serverApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def SuperSpeedServerDestroy(self):
        pass

    @Mod.InitClient()
    def SuperSpeedClientInit(self):
        clientApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def SuperSpeedClientDestroy(self):
        pass
