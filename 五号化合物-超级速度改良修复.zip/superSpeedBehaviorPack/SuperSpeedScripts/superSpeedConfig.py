# -*- coding: utf-8 -*-
# ============================================================
#  超级速度 - 数值配置（想改手感，改这个文件就够了）
# ============================================================

# ---------- 药水 ----------
MODE_ENABLED = True                          # False = 不用喝药水，进游戏就一直是超速状态
MODE_ITEM = "superspeed:potion"              # 药水的物品名（别改）
MODE_NAME = "五号化合物"                        # 显示名字
MODE_DURATION = 90.0                         # ★ 喝下后维持多少秒（90 = 一分半）
MODE_WARN_AT = [30.0, 10.0, 5.0]             # 剩这些秒时各提醒一次
MODE_TIP = True                              # 药水相关提示（聊天框的黄字）
MODE_JOIN_GIVE = True                        # 进游戏自动发药水（手机端不用打指令）
MODE_JOIN_GIVE_COUNT = 2                     # 进游戏发几瓶
MODE_REFILL_WHEN_EMPTY = True                # 药效结束、背包又空了，自动补一瓶
MODE_STACK = 16                              # 一次最多拿几瓶（#化合物 5）
MODE_SYNC_INTERVAL = 0.25                    # 多久把倒计时同步给屏幕一次（秒）

# ---------- 左上角倒计时 ----------
MODE_HUD_TIMER = True                        # ★ 药效期间在屏幕左上角显示剩余秒数
MODE_HUD_TIMER_FMT = u"%s 剩余 %d 秒"         # 显示格式（%s = 药水名，%d = 剩余秒数）
MODE_HUD_TIMER_COLOR = (0.35, 0.95, 1.0)     # 时间还多时的颜色（亮青色）
MODE_HUD_TIMER_WARN_COLOR = (1.0, 0.30, 0.25)  # 快没时间时的颜色（红）
MODE_HUD_TIMER_SPRINT_COLOR = (0.55, 1.0, 0.8)  # 正在超速（疾跑中）时的颜色（亮绿青）
MODE_HUD_TIMER_SPRINT_SUFFIX = u"（疾跑中）"      # 正在超速时在倒计时后面加的字
MODE_HUD_TIMER_WARN_AT = 10.0                # 剩多少秒开始变红
MODE_HUD_TIMER_SCALE = 1.15                  # 字号缩放（1.0 = 默认大小）

# ---------- 超级速度 ----------
SPEED_ENABLED = True              # 速度总开关
SPEED_MULTIPLIER = 20.0           # ★ 药效期间移速倍数（原版 3 倍左右的手感，想更猛就调大）
SPEED_BASE_WALK = 0.1             # 原版玩家走路移速（别改）
SPEED_BASE_FLY = 0.05             # 原版玩家飞行速度（别改）
SPEED_BOOST_FLYING = True         # 飞行速度要不要一起变快（创造模式飞起来也快）
SPEED_FLY_MULTIPLIER = 20.0       # 飞行速度倍数
SPEED_REFRESH = 1.0               # 每隔几秒重新套用一次（重生 / 换维度后自动补回来）
SPEED_FOV_LOCK = True             # 锁住镜头视野，高速跑动时画面不会拉变形
SPEED_MIN = 3.0                   # 聊天指令 #速度倍率 x 允许的最小倍数
SPEED_MAX = 60.0                  # 聊天指令 #速度倍率 x 允许的最大倍数
SPEED_TIP = True                  # 拿到药水 / 药效结束给一句提示

# ---------- 药效期间：饥饿值不掉 ----------
# 超速时体力消耗是按"跑过的距离"算的，跑得越快饿得越快，
# 饿到 6 以下就跑不动了，所以药效期间直接把饥饿值锁住。
MODE_NO_HUNGER = True             # ★ 药效期间饥饿值不掉
MODE_HUNGER_REFRESH = 0.5         # 多久补一次（秒）
MODE_HUNGER_MAX = 20              # 顺便把饥饿值顶满（喝之前饿了也能立刻开跑）
MODE_HUNGER_EXHAUSTION = 999999999.9   # 最大消耗度：设得很大，饥饿度就不会下降
MODE_HUNGER_EXHAUSTION_BASE = 4.0      # 原版的最大消耗度（药效结束要还原回去）

# ---------- 疾跑才生效（核心设定） ----------
SPEED_SPRINT_ONLY = True          # ★ True = 只有疾跑时超级速度才生效，走路就是原版速度
SPEED_REFRESH_SPRINT = 0.1        # 需要疾跑时，多久检查一次疾跑状态（秒），越小越跟手
SPRINT_REPORT = 0.12              # 客户端多久上报一次自己的疾跑状态（秒）
SPRINT_STALE = 2.0                # 超过这么久没收到上报就当"不知道"，改用速度兜底
SPRINT_FALLBACK_SPEED = 4.6       # 兜底：水平速度超过这个值就当成疾跑（格/秒）；
                                  #   原版走路约 4.3，疾跑约 5.6

# ---------- 撞击生物：直接撞死 ----------
IMPACT_MOB_ENABLED = True         # ★ 撞到生物就让它直接死亡
IMPACT_MOB_RADIUS = 2.2           # ★ 以玩家为中心，多大范围内算“撞上”（格）
IMPACT_MOB_MIN_SPEED = 2.5        # ★ 自己得跑多快才算撞（格/秒），站着不动不会秒杀旁边的怪
IMPACT_MOB_COOLDOWN = 0.25        # 同一只生物多久内不重复判定（秒）
IMPACT_MOB_MAX_PER_TICK = 6       # 一次最多撞死几只（性能保护）
IMPACT_MOB_HURT_PLAYERS = False   # True = 别的玩家也会被撞死；False = 只撞生物
IMPACT_MOB_TIP = True             # 撞死生物时在聊天框报一句（撞得多会觉得吵，可以关）

# ---------- 撞击方块：直接撞碎 ----------
IMPACT_BLOCK_ENABLED = True       # ★ 撞到方块就把方块撞碎
IMPACT_BLOCK_RADIUS = 1           # ★ 0 = 只撞出一条 1 格宽的隧道；1 = 3x3 粗细；2 = 5x5
IMPACT_BLOCK_MAX = 24             # 一次最多撞碎多少块（性能保护）
IMPACT_BLOCK_HEIGHT = 2           # 撞碎的隧道有多高（格）；2 = 玩家趴不进也走得进
IMPACT_BLOCK_TAIL = 40
IMPACT_BLOCK_KEEP_GROUND = True    # 不挖自己脚下的地面（True = 平地上跑不留坑）
IMPACT_BLOCK_GROUND_SCAN = 4      # 从脚往下找几格，用来认定“哪一层是地面”            # 一帧最多采样多少个点（性能保护，一般不用改）
IMPACT_MIN_SPEED = 2.5            # ★ 跑多快才开始撞碎方块（格/秒）
IMPACT_SPEED_CAP = 500.0          # 超过这个速度当成传送 / 卡顿，不做撞击判定
IMPACT_BLOCK_BLACKLIST = [        # 这些方块撞不动（也挡不住你，直接穿过去）
    "minecraft:air",
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:light_block",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:end_portal",
    "minecraft:end_portal_frame",
    "minecraft:end_gateway",
    "minecraft:portal",
    "minecraft:allow",
    "minecraft:deny",
    "minecraft:border_block",
    "minecraft:reinforced_deepslate",
    "minecraft:moving_block",
    "minecraft:water",
    "minecraft:flowing_water",
    "minecraft:lava",
    "minecraft:flowing_lava",
]

# ---------- 药效期间：不怕摔 ----------
MODE_NO_FALL_DAMAGE = True        # ★ 超速跑起来掉下悬崖不会摔死
