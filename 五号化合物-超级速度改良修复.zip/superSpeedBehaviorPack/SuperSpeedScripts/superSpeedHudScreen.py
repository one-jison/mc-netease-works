# -*- coding: utf-8 -*-
# ============================================================
#  超级速度 - 左上角倒计时（HUD）
# ============================================================
import mod.client.extraClientApi as clientApi

ScreenNode = clientApi.GetScreenNodeCls()


class SuperSpeedHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPanel = "/hudPanel"
        self.mLblTimer = self.mPanel + "/lblTimer"
        self.mTimerOn = None

    # UI 建好后引擎会调用这里
    def Create(self):
        self.SetTimer(False, 0)          # 没喝药水的时候先藏起来

    def SetTimer(self, visible, seconds, sprint=False):
        # visible = 药效还在不在；seconds = 还剩几秒；sprint = 现在有没有在超速
        from SuperSpeedScripts import superSpeedConfig as cfg
        show = bool(visible) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        if show:
            self._writeTimerText(int(seconds), bool(sprint))
        if self.mTimerOn == show:
            return
        self.mTimerOn = show
        try:
            ctrl = self.GetBaseUIControl(self.mLblTimer)
            if ctrl is not None:
                ctrl.SetVisible(show)
                return
        except Exception:
            pass
        try:
            self.SetVisible(self.mLblTimer, show)
        except Exception:
            pass

    def _writeTimerText(self, seconds, sprint=False):
        from SuperSpeedScripts import superSpeedConfig as cfg
        fmt = getattr(cfg, "MODE_HUD_TIMER_FMT", u"%s 剩余 %d 秒")
        try:
            text = fmt % (getattr(cfg, "MODE_NAME", u""), int(seconds))
        except Exception:
            text = u"%d" % int(seconds)
        if sprint:
            text += getattr(cfg, "MODE_HUD_TIMER_SPRINT_SUFFIX", u"（疾跑中）")
        warnAt = float(getattr(cfg, "MODE_HUD_TIMER_WARN_AT", 10.0))
        if int(seconds) <= warnAt:
            color = getattr(cfg, "MODE_HUD_TIMER_WARN_COLOR", (1.0, 0.30, 0.25))
        elif sprint:
            color = getattr(cfg, "MODE_HUD_TIMER_SPRINT_COLOR", (0.55, 1.0, 0.8))
        else:
            color = getattr(cfg, "MODE_HUD_TIMER_COLOR", (0.35, 0.95, 1.0))
        try:
            lbl = self.GetBaseUIControl(self.mLblTimer).asLabel()
            lbl.SetText(text)
            try:
                lbl.SetTextColor(color)
            except Exception:
                pass
            try:
                lbl.SetTextFontSize(float(getattr(cfg, "MODE_HUD_TIMER_SCALE", 1.0)))
            except Exception:
                pass
        except Exception:
            pass
