# -*- coding: utf-8 -*-
# ============================================================
#  士兵男孩 - 客户端
#    1) 药效期间在屏幕左上角显示剩余时间
#    2) 屏幕上多出一个【爆炸】图标：长按 = 开始蓄力，松手 = 取消
#    3) 收到服务端的特效消息，就画胸口金光 / TNT 同款爆炸动画
#    4) 蓄力期间（手机端）把角色真的按下去，只能潜行移动
# ============================================================
import time
import mod.client.extraClientApi as clientApi
from SoldierBoyScripts import modConfig
from SoldierBoyScripts import soldierBoyConfig as cfg

ClientSystem = clientApi.GetClientSystemCls()

CHARGE_PARTICLE = "soldierboy:charge_core"
GLOW_PARTICLE = "soldierboy:charge_glow"
BLAST_PARTICLE = "soldierboy:blast"
SPARK_PARTICLE = "soldierboy:blast_spark"
# 蓄力时的金光：三档，越后面越亮越大
GOLD_PARTICLES = ("soldierboy:charge_gold_1",
                  "soldierboy:charge_gold_2",
                  "soldierboy:charge_gold_3")
# 爆炸：游戏自带的 TNT 大爆炸粒子（播不出来就用自己复刻的那份）
DEFAULT_TNT = "minecraft:huge_explosion_emitter"
DEFAULT_TNT_FALLBACK = "soldierboy:tnt_blast"
DEFAULT_TNT_SMOKE = "minecraft:explosion_particle"


class SoldierBoyClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        super(SoldierBoyClientSystem, self).__init__(namespace, systemName)
        self._hudNode = None
        self._hudTries = 0
        self._hudRetryT = 0.0
        self._on = False            # 药效还开着吗
        self._left = 0              # 还剩几秒（服务端说的）
        self._charging = False
        self._charge = 0.0          # 服务端给的蓄力秒数
        self._chargeT = 0.0         # 收到上面那个数时本地的时刻（把进度画顺一点）
        self._chargeTime = 5.0
        self._cool = 0.0            # 冷却还剩几秒（服务端给的）
        self._coolT = 0.0
        self._touchDown = False
        self._keyDown = False       # 电脑端 G 键是不是按着
        self._sneakOwn = False      # 是不是“我们”把玩家按蹲下去的
        self._sneakNo = False       # 这个平台改不了潜行就不再试了
        self._sneakT = 0.0          # 按蹲下去的时刻（超时就自动站起来）
        self._tntCache = None       # 爆炸用的粒子名（第一次爆的时候定下来）
        self._lastFxT = 0.0         # 上一次收到服务端特效的时间
        self._localFxAt = 0.0       # 本地补画金光的间隔用
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "OnScriptTickClient", self, self.OnScriptTick)
        self.ListenForEvent(ns, sn, modConfig.UiInitFinishedEvent, self, self.OnUIInitFinished)
        self.ListenForEvent(ns, sn, "OnLocalPlayerStopLoading", self, self.OnStopLoading)
        # 电脑端键盘：按住 G 键 = 蓄力，松开 = 取消
        self.ListenForEvent(ns, sn, "OnKeyPressInGame", self, self.OnKeyPress)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventState, self, self.OnState)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventFx, self, self.OnFx)
        # 服务端说“该蹲下去 / 可以站起来了”
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EventSneak, self, self.OnSneak)

    def OnStopLoading(self, args=None):
        self._hudNode = None
        self._hudTries = 0
        self._touchDown = False
        self._keyDown = False
        self._sneakNo = False
        self._tntCache = None
        self._ensureHud()

    def OnUIInitFinished(self, args=None):
        self._ensureHud()

    def OnScriptTick(self, args=None):
        now = time.time()
        if self._hudNode is None and now - self._hudRetryT >= 3.0:
            self._hudRetryT = now
            self._ensureHud()
        self._sneakWatchdog()
        self._localChargeFx()
        self._applyHud()

    # ==================== 屏幕界面 ====================
    def _ensureHud(self):
        if self._hudNode is not None or self._hudTries >= 5:
            return
        self._hudTries += 1
        try:
            node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            if node is None:
                clientApi.RegisterUI(modConfig.ModName, modConfig.HudUIName,
                                     modConfig.HudUIPyClsPath, modConfig.HudUIScreenDef)
                node = clientApi.CreateUI(modConfig.ModName, modConfig.HudUIName, {"isHud": 1})
                if node is None:
                    node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            self._hudNode = node
            self._applyHud()
        except Exception:
            self._hudNode = None

    def OnState(self, args):
        if not args:
            return
        try:
            if args.get("playerId") != clientApi.GetLocalPlayerId():
                return
            now = time.time()
            self._on = int(args.get("on", 0)) == 1
            self._left = int(args.get("left", 0))
            wasCharging = self._charging
            self._charging = int(args.get("charging", 0)) == 1
            if self._charging and not wasCharging:
                self._lastFxT = now      # 蓄力刚开始，先给服务端特效一点时间
            self._charge = float(args.get("charge", 0.0))
            self._chargeT = now
            self._chargeTime = max(0.1, float(args.get("chargeTime", 5.0)))
            self._cool = float(args.get("cool", 0.0))
            self._coolT = now
        except Exception:
            return
        self._applyHud()

    def _chargeNow(self):
        # 把服务端的蓄力秒数按本地时间往前推，进度看着更顺
        if not self._charging:
            return 0.0
        return max(0.0, min(self._chargeTime, self._charge + (time.time() - self._chargeT)))

    def _coolNow(self):
        return max(0.0, self._cool - (time.time() - self._coolT))

    def _applyHud(self):
        node = self._hudNode
        if node is None:
            return
        show = bool(self._on) and bool(getattr(cfg, "MODE_HUD_TIMER", True))
        try:
            node.SetTimer(show, int(self._left), bool(self._charging))
        except Exception:
            pass
        # 左上角第二行：蓄力进度 / 冷却
        status = u""
        color = None
        if self._on and self._charging:
            chargeTime = max(0.1, self._chargeTime)
            percent = int(round(self._chargeNow() / chargeTime * 100.0))
            status = (getattr(cfg, "MODE_HUD_STATUS_FMT", u"蓄力中 %d%%") % max(0, min(100, percent)))
            color = getattr(cfg, "MODE_HUD_TIMER_CHARGE_COLOR", (1.0, 1.0, 0.55))
        elif self._on and self._coolNow() > 0.0:
            status = (getattr(cfg, "MODE_HUD_COOL_FMT", u"爆炸冷却 %d 秒")
                      % int(self._coolNow() + 0.99))
            color = (0.75, 0.78, 0.85)
        try:
            node.SetStatus(status, bool(status), color)
        except Exception:
            pass
        # 屏幕上的【爆炸】图标：只有药效期间才出现
        visible = bool(self._on) and bool(getattr(cfg, "BLAST_ICON", True)) \
            and bool(getattr(cfg, "BLAST_ENABLED", True))
        try:
            node.SetButtonVisible(visible)
        except Exception:
            pass
        coolText = u""
        if visible and self._coolNow() > 0.0:
            coolText = u"%d" % int(self._coolNow() + 0.99)
        try:
            node.SetButtonLabel(coolText)
        except Exception:
            pass

    # ==================== 屏幕上的【爆炸】图标 ====================
    def HudBlastDown(self):
        # 手指按住图标 / 电脑按住 G 键 = 开始蓄力；返回“这一下有没有真的开始”
        if not self._on:
            return False
        if not getattr(cfg, "BLAST_ENABLED", True):
            return False
        if self._touchDown:
            return True
        self._touchDown = True
        # 不在本地抢先蹲下去：等服务端确认蓄力开始后才蹲，
        # 不然冷却中/没药水时按一下会白蹲
        self._send(modConfig.EventChargeStart)
        return True

    def HudBlastUp(self):
        # 松手 = 取消（服务端已经炸出去的话，这一步它自己会忽略）
        if not self._touchDown:
            return
        self._touchDown = False
        self._send(modConfig.EventChargeCancel)

    # ==================== 电脑端快捷键（按住 G 蓄力）====================
    def OnKeyPress(self, args=None):
        if not args:
            return
        if not getattr(cfg, "BLAST_KEY_ENABLED", True):
            return
        try:
            if str(args.get("key", "")) != str(getattr(cfg, "BLAST_KEY", "71")):
                return
        except Exception:
            return
        try:
            isDown = str(args.get("isDown", "0")) == "1"
        except Exception:
            isDown = False
        if isDown:
            if self._keyDown:
                return
            self._keyDown = self.HudBlastDown()   # 没喝药水时不会把按键状态卡住
        else:
            if not self._keyDown:
                return
            self._keyDown = False
            self.HudBlastUp()

    def _send(self, eventName):
        try:
            self.NotifyToServer(eventName, {"playerId": clientApi.GetLocalPlayerId()})
        except Exception:
            pass

    # ==================== 蓄力时强制潜行（手机端真的蹲下去）====================
    def _playerComp(self):
        try:
            return clientApi.GetEngineCompFactory().CreatePlayer(
                clientApi.GetLocalPlayerId())
        except Exception:
            return None

    def OnSneak(self, args):
        if not args:
            return
        try:
            if args.get("playerId") != clientApi.GetLocalPlayerId():
                return
        except Exception:
            return
        self._applySneak(int(args.get("on", 0)) == 1)

    def _sneakWatchdog(self):
        # ★ 保证“只有蓄力的时候才蹲着”：只要不在蓄力，马上站起来
        if not self._sneakOwn:
            return
        elapsed = time.time() - self._sneakT
        if elapsed < 1.5:
            return                  # 刚蹲下去，先等“正在蓄力”的状态消息到
        # 正常情况：不蓄力就站起来
        if self._charging and elapsed < (self._chargeTime + 5.0):
            return
        # 兜底：蓄力状态信息丢了也不能让玩家一直蹲着
        self._applySneak(False)

    def _applySneak(self, on):
        # 手机端可以让角色真的蹲下去；电脑端这个接口无效，试一次就放弃
        if not getattr(cfg, "CHARGE_FORCE_SNEAK", True):
            return
        if bool(on):
            if self._sneakOwn or self._sneakNo:
                return
            comp = self._playerComp()
            if comp is None:
                return
            try:
                if bool(comp.isSneaking()):
                    return          # 玩家本来就在蹲，那就别动人家
            except Exception:
                return
            if self._toggleSneak(comp, True):
                self._sneakOwn = True
                self._sneakT = time.time()
            return
        # 站起来：只撤销“我们自己按下去的那一次”
        if not self._sneakOwn:
            return
        comp = self._playerComp()
        if comp is None:
            return
        try:
            if not bool(comp.isSneaking()):
                self._sneakOwn = False
                return
        except Exception:
            return
        self._toggleSneak(comp, False)
        self._sneakOwn = False

    def _toggleSneak(self, comp, want):
        # setSneaking 是“切换”，不是“设置”，所以要回头看一眼到底切成了没有
        for _try in range(2):
            try:
                ok = comp.setSneaking()
            except Exception:
                if want:
                    self._sneakNo = True
                return False
            if ok is False:
                if want:
                    self._sneakNo = True
                return False
            try:
                if bool(comp.isSneaking()) == bool(want):
                    return True
            except Exception:
                return True
        if want:
            self._sneakNo = True
        return False

    # ==================== 特效 ====================
    def _sameDimension(self, dim):
        try:
            return int(dim) == int(clientApi.GetEngineCompFactory().CreateDimension(
                clientApi.GetLocalPlayerId()).GetEntityDimensionId())
        except Exception:
            return True

    def OnFx(self, args):
        if not args:
            return
        if not self._sameDimension(args.get("dim")):
            return
        self._lastFxT = time.time()      # 特效通道还活着，不用本地补画
        try:
            x = float(args.get("x", 0.0))
            y = float(args.get("y", 0.0))
            z = float(args.get("z", 0.0))
            scale = float(args.get("scale", 1.0))
        except Exception:
            return
        kind = str(args.get("kind", ""))
        try:
            comp = clientApi.GetEngineCompFactory().CreateParticleSystem(None)
        except Exception:
            return
        if comp is None:
            return
        if kind == "charge":
            self._chargeFx(comp, x, y, z, scale)
        elif kind == "blast":
            self._blastFx(comp, x, y, z, scale)
            if int(args.get("snd", 0)) == 1:
                self._playBlastSound(x, y, z)

    def _localChargeFx(self):
        # 保险措施：万一特效消息没传过来，本地也把自己胸口的金光画出来
        if not self._charging or not getattr(cfg, "CHARGE_FX", True):
            return
        now = time.time()
        if now - self._lastFxT < 0.6:
            return                      # 服务端特效正常，不重复画
        if now - self._localFxAt < float(getattr(cfg, "CHARGE_FX_INTERVAL", 0.12)):
            return
        self._localFxAt = now
        try:
            factory = clientApi.GetEngineCompFactory()
            me = clientApi.GetLocalPlayerId()
            pos = factory.CreatePos(me).GetFootPos()
            comp = factory.CreateParticleSystem(None)
        except Exception:
            return
        if comp is None or not pos:
            return
        chestY = float(pos[1]) + float(getattr(cfg, "BLAST_CENTER_UP", 1.0))
        progress = self._chargeNow() / max(0.1, float(self._chargeTime))
        self._chargeFx(comp, float(pos[0]), chestY, float(pos[2]), progress)

    def _spawn(self, comp, name, pos):
        # 放一个粒子发射器，失败返回 0
        if not name:
            return 0
        try:
            return comp.Create(str(name), (float(pos[0]), float(pos[1]), float(pos[2])),
                               (0, 0, 0)) or 0
        except Exception:
            return 0

    def _chargeFx(self, comp, x, y, z, scale):
        # 胸口的黄金光芒：越蓄越亮、越蓄越大
        progress = max(0.0, min(1.0, float(scale)))
        # 里面一颗小核心 + 外面一层暖光：一直都在
        self._spawn(comp, CHARGE_PARTICLE, (x, y, z))
        self._spawn(comp, GLOW_PARTICLE, (x, y + 0.12, z))
        # 金光分三档，蓄得越多叠得越多（1 档 -> 3 档）
        stage = 1 + int(progress * 2.999)
        if stage > len(GOLD_PARTICLES):
            stage = len(GOLD_PARTICLES)
        for i in range(stage):
            self._spawn(comp, GOLD_PARTICLES[i], (x, y + 0.03, z))
        # 蓄到一半以后：胸口四周再补一圈，一眼就知道“快炸了”
        if progress >= 0.5:
            ring = 0.35 + 0.45 * progress
            for ox, oz in ((ring, 0.0), (-ring, 0.0), (0.0, ring), (0.0, -ring)):
                self._spawn(comp, GOLD_PARTICLES[stage - 1], (x + ox, y + 0.06, z + oz))
        # 到快满的时候：再闪一下，很亮
        if progress >= 0.85:
            self._spawn(comp, GOLD_PARTICLES[-1], (x, y + 0.5, z))
            for ox, oz in ((0.6, 0.6), (-0.6, 0.6), (0.6, -0.6), (-0.6, -0.6)):
                self._spawn(comp, GOLD_PARTICLES[-1], (x + ox, y + 0.3, z + oz))

    def _blastFx(self, comp, x, y, z, radius):
        if getattr(cfg, "BLAST_TNT_FX", True):
            # ★ 和游戏自带的 TNT 一模一样的爆炸动画
            self._tntFx(comp, x, y, z, radius)
            # 再补一点金色火花，爆得更有劲儿
            self._spawn(comp, SPARK_PARTICLE, (x, y, z))
            self._spawn(comp, GLOW_PARTICLE, (x, y + 1.0, z))
            ring = max(2.0, min(12.0, float(radius) * 0.6))
            for ox, oy, oz in ((ring, 0.5, 0.0), (-ring, 0.5, 0.0), (0.0, 0.5, ring),
                               (0.0, 0.5, -ring), (0.0, 2.0, 0.0)):
                self._spawn(comp, SPARK_PARTICLE, (x + ox, y + oy, z + oz))
            return
        # 关掉 TNT 动画时：还用原来那套金色火光
        self._spawn(comp, BLAST_PARTICLE, (x, y, z))
        self._spawn(comp, SPARK_PARTICLE, (x, y, z))
        self._spawn(comp, GLOW_PARTICLE, (x, y + 1.0, z))
        ring = max(2.0, min(12.0, float(radius) * 0.6))
        for ox, oy, oz in ((ring, 0.5, 0.0), (-ring, 0.5, 0.0), (0.0, 0.5, ring),
                           (0.0, 0.5, -ring), (0.0, 2.0, 0.0)):
            self._spawn(comp, SPARK_PARTICLE, (x + ox, y + oy, z + oz))

    def _tntFx(self, comp, x, y, z, radius):
        # 用游戏自带的 TNT 大爆炸粒子；万一播不出来，就换成我们自己复刻的同款
        name = self._tntCache or str(getattr(cfg, "BLAST_TNT_PARTICLE", DEFAULT_TNT) or "")
        fallback = str(getattr(cfg, "BLAST_TNT_FALLBACK", DEFAULT_TNT_FALLBACK) or "")
        if not self._spawn(comp, name, (x, y, z)) and fallback and fallback != name:
            name = fallback
            self._spawn(comp, name, (x, y, z))
        self._tntCache = name
        smoke = str(getattr(cfg, "BLAST_TNT_SMOKE", DEFAULT_TNT_SMOKE) or "")
        if smoke:
            self._spawn(comp, smoke, (x, y, z))
        if not getattr(cfg, "BLAST_TNT_SPREAD", True) or float(radius) < 3.0:
            return
        # 直径大的时候：周围再补几个，爆炸看着更“开”
        off = float(radius) * 0.45
        for ox, oy, oz in ((off, 0.5, 0.0), (-off, 0.5, 0.0),
                           (0.0, 0.5, off), (0.0, 0.5, -off), (0.0, 1.8, 0.0)):
            self._spawn(comp, name, (x + ox, y + oy, z + oz))

    def _playBlastSound(self, x, y, z):
        # 服务端没放出声时的兜底：用资源包里的爆炸声（叠两层，更震撼）
        if not getattr(cfg, "BLAST_SOUND", True):
            return
        try:
            factory = clientApi.GetEngineCompFactory()
            me = clientApi.GetLocalPlayerId()
        except Exception:
            return
        vol = max(0.0, min(1.0, float(getattr(cfg, "BLAST_SOUND_VOLUME", 1.6))))
        try:
            comp = factory.CreateCustomAudio(me)
        except Exception:
            return
        if comp is None:
            return
        for pitch in (0.6, 0.45):
            try:
                comp.PlayCustomMusic("soldierboy.explode",
                                     (float(x), float(y), float(z)), vol, float(pitch))
            except Exception:
                pass
