# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from SoldierBoyScripts import modConfig


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class SoldierBoyMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def SoldierBoyServerInit(self):
        serverApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def SoldierBoyServerDestroy(self):
        pass

    @Mod.InitClient()
    def SoldierBoyClientInit(self):
        clientApi.RegisterSystem(modConfig.ModName,
                                 modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def SoldierBoyClientDestroy(self):
        pass
