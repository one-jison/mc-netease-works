# -*- coding: utf-8 -*-
# ============================================================
#  士兵男孩 - 服务端
#
#  喝下《五号化合物》（8 分钟）之后：
#    ★ 屏幕左上角显示药效剩余时间
#    ★ 屏幕上多出一个【爆炸】图标，长按蓄力 5 秒
#    ★ 蓄力期间只能使用潜行移动（不能跑、不能跳）
#    ★ 蓄力满 -> 胸口黄金光芒越来越亮 -> 以自己为中心炸出一个大坑
#    ★ 爆炸动画用游戏自带的 TNT 大爆炸粒子
#    ★ 其他玩家：有药水的 -> 清掉药水并扣 5 颗心；没药水的 -> 直接炸死
#    ★ 自己：扣掉一半血；之后进入 30 秒冷却
# ============================================================
import math
import time
import mod.server.extraServerApi as serverApi
from SoldierBoyScripts import modConfig
from SoldierBoyScripts import soldierBoyConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()

AIR_BLOCK = {"name": "minecraft:air", "aux": 0}
MIN_Y = -64
MAX_Y = 320


class SoldierBoyServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(SoldierBoyServerSystem, self).__init__(namespace, systemName)
        self._powerUntil = {}      # playerId -> 药效失效的时间戳
        self._powerWarned = {}     # playerId -> 已经提醒过哪些剩余秒数
        self._stateSig = {}        # playerId -> 上次同步给客户端的界面状态
        self._stateT = 0.0         # 上次同步界面状态的时间
        self._potionAt = {}        # playerId -> 进游戏后什么时候发药水
        self._welcomed = set()     # 已经欢迎过的玩家
        self._chargeAt = {}        # playerId -> 这次蓄力是什么时候开始的
        self._chargeFxAt = {}      # playerId -> 上次放胸口黄光的时间
        self._coolUntil = {}       # playerId -> 冷却结束的时间戳
        self._selfHurtAt = {}      # playerId -> 什么时候扣自己那一半血
        self._savedSpeed = {}      # playerId -> 蓄力前的移速（蓄力结束要还回去）
        self._sneakAt = {}         # playerId -> 上次“按回潜行”的时间
        self._sneakOn = set()      # 正在被强制潜行的玩家
        self._protect = None       # 炸不掉的方块名单（第一次用到再建）
        self._sndQueue = []        # 叠层音效里“稍微晚一点放”的那几层
        self._craterQueue = []     # 大坑没炸完的方块（分帧接着炸，避免卡顿）
        self._healthT = 0.0        # 上次检查生命上限的时间
        self._noKill = set([       # 这些不算“生物”，不炸
            "minecraft:armor_stand",
            "minecraft:item",
            "minecraft:xp_orb",
        ])
        self._listenEvents()

    # ==================== 事件监听 ====================
    def _listenEvents(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        self.ListenForEvent(ns, sn, "ServerChatEvent", self, self.OnChat)
        self.ListenForEvent(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        # 死亡 / 重生：药效不能带进棺材里
        self.ListenForEvent(ns, sn, "PlayerDieEvent", self, self.OnPlayerDie)
        self.ListenForEvent(ns, sn, "PlayerRespawnFinishServerEvent",
                            self, self.OnPlayerRespawnFinish)
        # 喝药水：两个事件都听着，哪个先来都认
        self.ListenForEvent(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        self.ListenForEvent(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)
        # 屏幕上的【爆炸】按钮（客户端报上来的）
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventChargeStart, self, self.OnChargeStart)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.EventChargeCancel, self, self.OnChargeCancel)

    # ==================== 小工具 ====================
    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _chestOf(self, entityId):
        # 胸口位置（脚往上抬一点）
        pos = self._posOf(entityId)
        if pos is None:
            return None
        return (float(pos[0]),
                float(pos[1]) + float(getattr(cfg, "BLAST_CENTER_UP", 1.0)),
                float(pos[2]))

    def _dimOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _engineTypeOf(self, entityId):
        try:
            return str(serverApi.GetEngineCompFactory().CreateEngineType(
                entityId).GetEngineTypeStr() or "").lower()
        except Exception:
            return ""

    def _isPlayerId(self, entityId):
        try:
            return entityId in (serverApi.GetPlayerList() or [])
        except Exception:
            return False

    def _isLiving(self, entityId):
        # 有“血量”才算生物；盔甲架 / 掉落物 / 经验球这些一律放过
        try:
            hp = serverApi.GetEngineCompFactory().CreateAttr(entityId).GetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH)
        except Exception:
            return False
        if hp is None:
            return False
        return self._engineTypeOf(entityId) not in self._noKill

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    # ==================== 蓄力时的移动限制（只能潜行）====================
    def _playerComp(self, playerId):
        try:
            return serverApi.GetEngineCompFactory().CreatePlayer(playerId)
        except Exception:
            return None

    def _attrComp(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateAttr(entityId)
        except Exception:
            return None

    def _sneakGap(self):
        try:
            return max(0.1, float(getattr(cfg, "CHARGE_SNEAK_RECHECK", 0.6)))
        except Exception:
            return 0.6

    def _notifySneak(self, playerId, on):
        # 告诉客户端：该蹲下去了 / 可以站起来了
        try:
            self.NotifyToClient(playerId, modConfig.EventSneak,
                                {"playerId": playerId, "on": 1 if on else 0})
        except Exception:
            pass

    def _lockSneak(self, playerId):
        # 蓄力期间只能慢慢挪：不许跳、移速压到潜行档，手机端再真的蹲下去
        if not playerId or not getattr(cfg, "CHARGE_SNEAK_ONLY", True):
            return
        comp = self._playerComp(playerId)
        if comp is not None and getattr(cfg, "CHARGE_NO_JUMP", True):
            try:
                comp.SetPlayerJumpable(False)
            except Exception:
                pass
        self._slowSpeed(playerId)
        if playerId not in self._sneakOn:
            self._sneakOn.add(playerId)
            self._notifySneak(playerId, True)

    def _unlockSneak(self, playerId, forceBase=None):
        # 蓄力结束：把跳跃和移速还给玩家
        if not playerId:
            return
        self._sneakAt.pop(playerId, None)
        if getattr(cfg, "CHARGE_SNEAK_ONLY", True):
            comp = self._playerComp(playerId)
            if comp is not None:
                try:
                    comp.SetPlayerJumpable(True)
                except Exception:
                    pass
            self._restoreSpeed(playerId, forceBase)
        if playerId in self._sneakOn:
            self._sneakOn.discard(playerId)
            self._notifySneak(playerId, False)

    def _slowSpeed(self, playerId):
        # 把移速压到潜行档（原版潜行 = 走路的 0.3 倍）
        if not getattr(cfg, "CHARGE_SLOW_MOVE", True):
            return
        attr = self._attrComp(playerId)
        if attr is None:
            return
        try:
            attrType = serverApi.GetMinecraftEnum().AttrType.SPEED
            cur = float(attr.GetAttrValue(attrType))
        except Exception:
            return
        if playerId not in self._savedSpeed:
            base0 = float(getattr(cfg, "CHARGE_SPEED_BASE", 0.1))
            # 万一这是上一次异常退出留下的“慢速”，别把它当成正常速度记下来
            self._savedSpeed[playerId] = cur if cur >= base0 * 0.6 else base0
        base = float(self._savedSpeed.get(playerId, cur))
        try:
            rate = float(getattr(cfg, "CHARGE_SPEED_RATE", 0.3))
        except Exception:
            rate = 0.3
        want = max(0.005, base * rate)
        if abs(cur - want) < 1e-5:
            return
        try:
            attr.SetAttrValue(attrType, want, 1)
        except Exception:
            pass

    def _restoreSpeed(self, playerId, forceBase=None):
        base = self._savedSpeed.pop(playerId, None)
        if base is None:
            base = forceBase
        if base is None:
            return
        attr = self._attrComp(playerId)
        if attr is None:
            return
        try:
            attrType = serverApi.GetMinecraftEnum().AttrType.SPEED
            attr.SetAttrMaxValue(attrType, max(float(base), 0.1))
        except Exception:
            pass
        try:
            attr.SetAttrValue(attrType, float(base), 1)
        except Exception:
            pass

    def _sneakWatchdog(self, players):
        # ★ 保证“只有蓄力的时候才锁潜行”：不在蓄力中的人，锁一律马上放开
        if not self._savedSpeed and not self._sneakOn:
            return
        forceBase = None
        if getattr(cfg, "CHARGE_SLOW_MOVE", True):
            forceBase = float(getattr(cfg, "CHARGE_SPEED_BASE", 0.1))
        for playerId in list(self._savedSpeed.keys()):
            if playerId in players and playerId not in self._chargeAt:
                self._unlockSneak(playerId, forceBase)
        for playerId in list(self._sneakOn):
            if playerId in players and playerId not in self._chargeAt:
                self._unlockSneak(playerId, forceBase)

    def _cleanLocked(self, players):
        # 有玩家下线了，把他身上的蓄力锁清掉
        for playerId in list(self._savedSpeed.keys()):
            if playerId in players:
                continue
            self._savedSpeed.pop(playerId, None)
            self._sneakAt.pop(playerId, None)
            self._sneakOn.discard(playerId)
        for playerId in list(self._sneakOn):
            if playerId not in players:
                self._sneakOn.discard(playerId)

    # ==================== 药效时间 ====================
    def _powerOn(self):
        return bool(getattr(cfg, "MODE_ENABLED", True))

    def _powerLeftOf(self, playerId):
        if not self._powerOn():
            return 999999.0
        return max(0.0, float(self._powerUntil.get(playerId, 0.0)) - time.time())

    def _hasPower(self, playerId):
        if not playerId:
            return False
        if not self._powerOn():
            return True
        return self._powerLeftOf(playerId) > 0.0

    def _coolLeftOf(self, playerId, now=None):
        if now is None:
            now = time.time()
        return max(0.0, float(self._coolUntil.get(playerId, 0.0)) - now)

    def _syncState(self, playerId, force=False):
        # 把“药效还剩几秒 / 正在蓄力多少 / 冷却还剩几秒”告诉客户端（左上角 + 按钮）
        now = time.time()
        on = 1 if self._hasPower(playerId) else 0
        left = int(math.ceil(self._powerLeftOf(playerId))) if on else 0
        charging = 1 if (on and playerId in self._chargeAt) else 0
        charge = 0.0
        if charging:
            charge = max(0.0, now - float(self._chargeAt.get(playerId, now)))
        cool = self._coolLeftOf(playerId, now)
        sig = (on, left, charging, round(charge, 1) if charging else 0, int(math.ceil(cool)))
        if not force and self._stateSig.get(playerId) == sig:
            return
        try:
            self.NotifyToClient(playerId, modConfig.EventState, {
                "playerId": playerId, "on": on, "left": left,
                "charging": charging, "charge": float(charge),
                "chargeTime": float(getattr(cfg, "BLAST_CHARGE_TIME", 5.0)),
                "cool": float(cool)})
        except Exception:
            return          # 没发出去就先不记，等下一轮继续发
        self._stateSig[playerId] = sig

    def _givePower(self, playerId):
        dur = float(getattr(cfg, "MODE_DURATION", 480.0))
        left = self._powerLeftOf(playerId)
        self._powerUntil[playerId] = time.time() + dur
        self._powerWarned[playerId] = set()
        self._chargeAt.pop(playerId, None)
        self._applyMaxHealth(playerId, True)         # ★ 生命上限 -> 100 颗心
        self._syncState(playerId, force=True)        # 倒计时 + 爆炸图标立刻出现
        if not getattr(cfg, "MODE_TIP", True):
            return
        if left > dur - 1.0:
            self._tip(playerId, u"%s 时间已刷新，再来 %d 分钟" % (cfg.MODE_NAME, int(dur / 60)),
                      "LIGHT_PURPLE")
            return
        hearts = u""
        if getattr(cfg, "MODE_MAX_HEALTH_ENABLED", True):
            hearts = u"生命上限涨到 %d 颗心，" % int(
                round(float(getattr(cfg, "MODE_MAX_HEALTH", 200.0)) / 2.0))
        self._tip(playerId, u"%s 生效：%s屏幕左上角显示剩余时间，屏幕上多出一个【爆炸】图标，"
                            u"长按它蓄力 %d 秒，松手就取消"
                  % (cfg.MODE_NAME, hearts,
                     int(getattr(cfg, "BLAST_CHARGE_TIME", 5.0))), "LIGHT_PURPLE")

    def _losePower(self, playerId, quiet=False):
        wasOn = playerId in self._powerUntil
        self._powerUntil.pop(playerId, None)
        self._powerWarned.pop(playerId, None)
        self._chargeAt.pop(playerId, None)
        self._chargeFxAt.pop(playerId, None)
        self._unlockSneak(playerId)
        if wasOn:
            self._applyMaxHealth(playerId, False)    # ★ 生命上限还原成原版的 10 颗心
        self._syncState(playerId, force=True)        # 倒计时和图标马上收起
        if not quiet and getattr(cfg, "MODE_TIP", True):
            self._tip(playerId, u"%s 已失效" % cfg.MODE_NAME, "GOLD")
            self._refillIfEmpty(playerId)

    def _warn(self, playerId, left):
        marks = self._powerWarned.setdefault(playerId, set())
        for mark in list(getattr(cfg, "MODE_WARN_AT", []) or []):
            if left <= float(mark) and mark not in marks:
                marks.add(mark)
                self._tip(playerId, u"%s 还剩 %d 秒" % (cfg.MODE_NAME, int(mark)), "GOLD")

    # ==================== 药水怎么来 ====================
    def _hasPotion(self, playerId):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            posType = serverApi.GetMinecraftEnum().ItemPosType
            want = str(getattr(cfg, "MODE_ITEM", "")).lower()
            for item in comp.GetPlayerAllItems(posType.INVENTORY):
                if not item:
                    continue
                name = item.get("newItemName") or item.get("itemName") or ""
                if str(name).lower() == want:
                    return True
        except Exception:
            return False
        return False

    def _giveJoinPotion(self, playerId):
        if not getattr(cfg, "MODE_JOIN_GIVE", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, int(getattr(cfg, "MODE_JOIN_GIVE_COUNT", 2)))

    def _refillIfEmpty(self, playerId):
        if not getattr(cfg, "MODE_REFILL_WHEN_EMPTY", True) or not self._powerOn():
            return
        if self._hasPotion(playerId):
            return
        self._givePotionItem(playerId, 1)

    def _givePotionItem(self, playerId, num=1):
        try:
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            itemDict = {"itemName": cfg.MODE_ITEM, "count": int(num), "auxValue": 0}
            ok = comp.SpawnItemToPlayerInv(itemDict, playerId)
            if getattr(cfg, "MODE_TIP", True):
                if ok:
                    self._tip(playerId, u"已获得《%s》×%d，喝下去就能用【爆炸】"
                              % (cfg.MODE_NAME, int(num)), "LIGHT_PURPLE")
                else:
                    self._tip(playerId, u"背包放不下，先清一格再试", "RED")
        except Exception:
            pass

    def _checkPotion(self, playerId, itemDict):
        if not playerId or not self._powerOn():
            return
        if not isinstance(itemDict, dict):
            return
        name = itemDict.get("itemName") or itemDict.get("newItemName") or ""
        if str(name).lower() != str(getattr(cfg, "MODE_ITEM", "")).lower():
            return
        self._givePower(playerId)

    def OnEatFood(self, args):
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))

    def OnUseItem(self, args):
        # 兜底：万一吃东西那个事件没触发，这里再认一次
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))

    # ==================== 蓄力（长按 5 秒）====================
    def OnChargeStart(self, args):
        # 屏幕上按住【爆炸】图标（手机手指 / 电脑鼠标左键）都走这里
        playerId = args.get("playerId") if args else None
        if not playerId:
            return
        if not getattr(cfg, "BLAST_ENABLED", True):
            return
        self._startCharge(playerId)

    def _startCharge(self, playerId, fromChat=False):
        if not getattr(cfg, "BLAST_ENABLED", True):
            return
        now = time.time()
        if not self._hasPower(playerId):
            self._tip(playerId, u"要喝下《%s》才能用这一招" % cfg.MODE_NAME, "RED")
            return
        cool = self._coolLeftOf(playerId, now)
        if cool > 0.0:
            self._tip(playerId, u"胸口还在发烫，%d 秒后才能再炸" % int(math.ceil(cool)), "GOLD")
            self._syncState(playerId, force=True)
            return
        if playerId in self._chargeAt:
            return
        self._chargeAt[playerId] = now
        self._chargeFxAt[playerId] = 0.0
        self._sneakAt[playerId] = now
        chest = self._chestOf(playerId)
        if getattr(cfg, "CHARGE_SOUND", True) and chest is not None:
            self._playVanillaSound(chest, self._dimOf(playerId),
                                   str(getattr(cfg, "CHARGE_SOUND_NAME", "random.fizz")),
                                   0.7, 1.3, radius=28.0)
        if fromChat:
            self._tip(playerId, u"蓄力中……%d 秒后胸口炸开（这段时间只能慢慢挪）"
                      % int(getattr(cfg, "BLAST_CHARGE_TIME", 5.0)), "YELLOW")
        else:
            self._tip(playerId, u"蓄力中……按住别松手，%d 秒后爆炸（松手取消）"
                      % int(getattr(cfg, "BLAST_CHARGE_TIME", 5.0)), "YELLOW")
        self._tip(playerId, u"蓄力期间只能潜行移动（不能跑、不能跳）", "GRAY")
        # 先把“正在蓄力”告诉客户端，再叫它蹲下去，顺序才不会乱
        self._syncState(playerId, force=True)
        self._lockSneak(playerId)        # 蓄力开始：只能潜行移动

    def OnChargeCancel(self, args):
        # 松手 = 取消（服务端已经炸出去的话，这一步它自己会忽略）
        playerId = args.get("playerId") if args else None
        if not playerId:
            return
        if not self._endCharge(playerId):
            return
        self._tip(playerId, u"蓄力中断（松手了）", "GRAY")
        self._syncState(playerId, force=True)

    def _endCharge(self, playerId):
        # 收尾：把蓄力状态清掉，并把移动限制还给玩家
        had = self._chargeAt.pop(playerId, None) is not None
        self._chargeFxAt.pop(playerId, None)
        self._unlockSneak(playerId)
        return had

    def _chargeTick(self, players, now):
        if not self._chargeAt:
            return
        chargeTime = max(0.1, float(getattr(cfg, "BLAST_CHARGE_TIME", 5.0)))
        for playerId in list(self._chargeAt.keys()):
            if playerId not in players:
                self._endCharge(playerId)
                continue
            if not self._hasPower(playerId):
                self._endCharge(playerId)
                self._tip(playerId, u"药效没了，蓄力中断", "GOLD")
                self._syncState(playerId, force=True)
                continue
            done = now - float(self._chargeAt.get(playerId, now))
            if done >= chargeTime:
                self._endCharge(playerId)
                self._blast(playerId, now)
                continue
            # ★ 蓄力期间只能潜行：隔一小会儿再“按回去”一次
            if now - float(self._sneakAt.get(playerId, 0.0)) >= self._sneakGap():
                self._sneakAt[playerId] = now
                self._lockSneak(playerId)
            # 蓄力期间：胸口每 CHARGE_FX_INTERVAL 秒亮一次金光
            if not getattr(cfg, "CHARGE_FX", True):
                continue
            if now - float(self._chargeFxAt.get(playerId, 0.0)) < float(
                    getattr(cfg, "CHARGE_FX_INTERVAL", 0.12)):
                continue
            self._chargeFxAt[playerId] = now
            chest = self._chestOf(playerId)
            if chest is not None:
                self._fx("charge", chest, self._dimOf(playerId), done / chargeTime)

    # ==================== 胸口爆炸 ====================
    def _blast(self, playerId, now):
        self._unlockSneak(playerId)      # 炸了就不再限制移动
        pos = self._posOf(playerId)
        dimensionId = self._dimOf(playerId)
        if pos is None:
            pos = (0.0, 0.0, 0.0)
        center = (float(pos[0]),
                  float(pos[1]) + float(getattr(cfg, "BLAST_CENTER_UP", 1.0)),
                  float(pos[2]))
        radius = float(getattr(cfg, "BLAST_RADIUS", 5.0))

        broken = 0
        if getattr(cfg, "BLAST_BREAK_BLOCKS", True):
            broken = self._crater(center, radius, dimensionId)
        hit = self._blastTargets(center, dimensionId, playerId)

        sndOk = False
        if getattr(cfg, "BLAST_SOUND", True):
            sndOk = self._playBlastSounds(center, dimensionId)   # ★ 叠几层，更震撼
        if getattr(cfg, "BLAST_FX", True):
            self._fx("blast", center, dimensionId, radius, {"snd": 0 if sndOk else 1})

        # 自己那一半血：过一小会儿再扣（先把别人炸飞，手感更爽）
        if getattr(cfg, "BLAST_SELF_HALF_HP", True):
            self._selfHurtAt[playerId] = now + float(
                getattr(cfg, "BLAST_SELF_HURT_DELAY", 0.4))

        self._coolUntil[playerId] = now + float(getattr(cfg, "BLAST_COOLDOWN", 30.0))
        self._syncState(playerId, force=True)

        if not getattr(cfg, "MODE_TIP", True):
            return
        self._tip(playerId, u"胸口炸开！直径 %d 格内化为乌有（炸掉约 %d 块方块 / 炸死 %d 只生物）"
                  % (int(radius * 2), int(broken), int(hit.get("mob", 0))), "GOLD")
        if hit.get("kill", 0) > 0:
            self._tip(playerId, u"炸飞了 %d 名没有药水的玩家" % int(hit["kill"]), "RED")
        if hit.get("vip", 0) > 0:
            self._tip(playerId, u"%d 名有药水的玩家被你清掉药水，只剩一口气"
                      % int(hit["vip"]), "YELLOW")
        if hit.get("mob_vip", 0) > 0:
            self._tip(playerId, u"%d 只带药水效果的生物被清掉药水，只剩一口气"
                      % int(hit["mob_vip"]), "YELLOW")
        self._tip(playerId, u"自己掉一半血，接下来 %d 秒不能再用"
                  % int(getattr(cfg, "BLAST_COOLDOWN", 30.0)), "BLUE")

    def _blastTargets(self, center, dimensionId, ownerId):
        result = {"mob": 0, "mob_vip": 0, "kill": 0, "vip": 0}
        radius = float(getattr(cfg, "BLAST_PLAYER_RADIUS", 8.0))
        mobRadius = float(getattr(cfg, "BLAST_MOB_RADIUS", 7.0))
        span = int(max(radius, mobRadius)) + 1
        try:
            ids = serverApi.GetEngineCompFactory().CreateGame(
                serverApi.GetLevelId()).GetEntitiesInSquareArea(
                    None,
                    (int(center[0] - span), int(center[1] - span), int(center[2] - span)),
                    (int(center[0] + span), int(center[1] + span), int(center[2] + span)),
                    dimensionId)
        except Exception:
            ids = None
        if not ids:
            return result
        for entityId in ids:
            if not entityId or entityId == ownerId:
                continue
            epos = self._posOf(entityId)
            if epos is None:
                continue
            dx = float(epos[0]) - float(center[0])
            dy = float(epos[1]) - float(center[1])
            dz = float(epos[2]) - float(center[2])
            dist = math.sqrt(dx * dx + dy * dy + dz * dz)

            if self._isPlayerId(entityId):
                if not getattr(cfg, "BLAST_PLAYER_ENABLED", True):
                    continue
                if dist > radius:
                    continue
                if self._poweredTarget(entityId):
                    # 身上带药水（本模组药水或原版药水效果）：不死
                    # -> 先清掉药水效果，再只留一点点血
                    self._losePower(entityId, quiet=False)
                    self._clearVanillaEffect(entityId)
                    self._leaveLowHealth(entityId,
                                         float(getattr(cfg, "BLAST_VIP_HP_RATIO", 0.2)),
                                         float(getattr(cfg, "BLAST_VIP_HP_MIN", 2.0)))
                    result["vip"] += 1
                else:
                    # 没药水效果：直接炸死
                    if self._killEntity(entityId, ownerId):
                        result["kill"] += 1
                continue

            # 生物
            if not getattr(cfg, "BLAST_MOB_ENABLED", True):
                continue
            if dist > mobRadius:
                continue
            if not self._isLiving(entityId):
                continue
            if (getattr(cfg, "BLAST_MOB_VIP_ENABLED", True)
                    and self._hasVanillaEffect(entityId)):
                # 身上带药水效果的生物：同样不死，清掉药水后只留残血
                self._clearVanillaEffect(entityId)
                self._leaveLowHealth(entityId,
                                     float(getattr(cfg, "BLAST_MOB_VIP_HP_RATIO", 0.15)),
                                     float(getattr(cfg, "BLAST_MOB_VIP_HP_MIN", 1.0)))
                result["mob_vip"] += 1
                continue
            if self._killEntity(entityId, ownerId):
                result["mob"] += 1
        return result

    def _hurtEntity(self, entityId, damage, attackerId):
        try:
            serverApi.GetEngineCompFactory().CreateHurt(entityId).Hurt(
                float(damage),
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                attackerId, None, True)
            return True
        except Exception:
            return False

    def _killEntity(self, entityId, attackerId=None):
        try:
            game = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
            if game.KillEntity(entityId):
                return True
        except Exception:
            pass
        return self._hurtEntity(entityId, 1000.0, attackerId)

    def _effectsOf(self, entityId):
        # 问一下这个家伙身上有哪些药水效果（玩家 / 生物都能问）
        try:
            comp = serverApi.GetEngineCompFactory().CreateEffect(entityId)
        except Exception:
            return []
        if comp is None:
            return []
        try:
            raw = comp.GetAllEffects()
        except Exception:
            return []
        if not raw:
            return []
        if isinstance(raw, dict):
            out = []
            for key, info in raw.items():
                if isinstance(info, dict):
                    item = dict(info)
                    item.setdefault("effectName", key)
                    out.append(item)
                else:
                    out.append({"effectName": key})
            return out
        try:
            return [item for item in raw if item]
        except Exception:
            return []

    def _effectNameOf(self, info):
        if isinstance(info, dict):
            for key in ("effectName", "name", "effect"):
                value = info.get(key)
                if value:
                    return str(value)
            return ""
        if info is None:
            return ""
        return str(info)

    def _hasVanillaEffect(self, entityId):
        return len(self._effectsOf(entityId)) > 0

    def _clearVanillaEffect(self, entityId):
        # 顺手把原版药水效果也清掉（玩家 / 生物通用）
        if not getattr(cfg, "BLAST_VIP_CLEAR_VANILLA", True):
            return
        try:
            factory = serverApi.GetEngineCompFactory()
        except Exception:
            return
        for info in self._effectsOf(entityId):
            name = self._effectNameOf(info)
            if not name:
                continue
            try:
                factory.CreateEffect(entityId).RemoveEffectFromEntity(name)
            except Exception:
                pass
        if self._isPlayerId(entityId):
            # 玩家再兜一层：原版指令怎么都能清干净
            try:
                factory.CreateCommand(serverApi.GetLevelId()).SetCommand(
                    "/effect @s clear", entityId)
            except Exception:
                pass

    def _poweredTarget(self, playerId):
        # “身上带药水” = 本模组的五号化合物，或者任何一种原版药水效果
        if not getattr(cfg, "BLAST_VIP_CLEAR", True):
            return False
        return self._hasPower(playerId) or self._hasVanillaEffect(playerId)

    # ==================== 生命上限（喝药水 -> 100 颗心）====================
    def _attrNumber(self, attr, attrType, fallback, getter="GetAttrMaxValue"):
        try:
            value = float(getattr(attr, getter)(attrType))
        except Exception:
            return float(fallback)
        if value <= 0.0:
            return float(fallback)
        return value

    def _setMaxHealthValue(self, attr, attrType, value):
        # 有的版本要求传整数，小数被拒就换整数再试一次
        for target in (float(value), int(value)):
            try:
                result = attr.SetAttrMaxValue(attrType, target)
            except Exception:
                continue
            if result is False:
                continue
            return True
        return False

    def _setHealthValue(self, attr, attrType, value):
        for args in ((attrType, float(value)), (attrType, float(value), 1)):
            try:
                attr.SetAttrValue(*args)
                return True
            except Exception:
                continue
        return False

    def _applyMaxHealth(self, playerId, on):
        # ★ 喝下药水 -> 生命上限拉到 MODE_MAX_HEALTH（200 点 = 100 颗心）
        #   药效结束 -> 按比例还原成原版的 20 点（10 颗心）
        if not getattr(cfg, "MODE_MAX_HEALTH_ENABLED", True):
            return False
        attr = self._attrComp(playerId)
        if attr is None:
            return False
        try:
            attrType = serverApi.GetMinecraftEnum().AttrType.HEALTH
        except Exception:
            return False
        base = float(getattr(cfg, "MODE_BASE_MAX_HEALTH", 20.0))
        if on:
            want = float(getattr(cfg, "MODE_MAX_HEALTH", 200.0))
            if want <= base:
                return False
            cur = self._attrNumber(attr, attrType, base, "GetAttrValue")
            self._setMaxHealthValue(attr, attrType, want)
            if getattr(cfg, "MODE_HEAL_ON_GAIN", True):
                self._setHealthValue(attr, attrType, want)          # 直接回满
            else:
                self._setHealthValue(attr, attrType, min(max(cur, 1.0), want))
            return True
        oldMax = self._attrNumber(attr, attrType, base)
        cur = self._attrNumber(attr, attrType, oldMax, "GetAttrValue")
        self._setMaxHealthValue(attr, attrType, base)
        if cur <= 0.0:
            return False                                            # 人都死了，不用管血
        if getattr(cfg, "MODE_RESTORE_HEALTH_ON_LOSE", True) and oldMax > base:
            want = base * (cur / oldMax)                            # 按比例换算
        else:
            want = base
        self._setHealthValue(attr, attrType, max(1.0, min(base, want)))
        return True

    def _leaveLowHealth(self, entityId, ratio, minHp):
        # 被炸到的“身上带药水”的目标：不死，只留一点点血
        attr = self._attrComp(entityId)
        if attr is None:
            return False
        try:
            attrType = serverApi.GetMinecraftEnum().AttrType.HEALTH
        except Exception:
            return False
        maxHp = self._attrNumber(attr, attrType, 0.0)
        if maxHp <= 0.0:
            maxHp = self._maxHealthOf(attr)
        want = max(float(minHp), maxHp * float(ratio))
        return self._setHealthValue(attr, attrType, want)

    def _healthWatchdog(self, players, now):
        # 死了复活 / 换维度之后生命上限会被系统重置，这里隔一会儿补回来
        if not getattr(cfg, "MODE_MAX_HEALTH_ENABLED", True):
            return
        gap = max(0.5, float(getattr(cfg, "MODE_HEALTH_RECHECK", 2.0)))
        if now - self._healthT < gap:
            return
        self._healthT = now
        if not self._powerUntil:
            return
        want = float(getattr(cfg, "MODE_MAX_HEALTH", 200.0))
        try:
            attrType = serverApi.GetMinecraftEnum().AttrType.HEALTH
        except Exception:
            return
        for playerId in players:
            if playerId not in self._powerUntil or not self._hasPower(playerId):
                continue
            attr = self._attrComp(playerId)
            if attr is None:
                continue
            maxHp = self._attrNumber(attr, attrType, -1.0)
            if maxHp >= 0.0 and maxHp + 0.5 < want:
                self._applyMaxHealth(playerId, True)   # 读不到就不动，避免无脑回血

    def _resetMaxHealth(self, playerId):
        # 重生之后：把生命上限直接拉回原版，血量按原样保留
        if not getattr(cfg, "MODE_MAX_HEALTH_ENABLED", True):
            return
        attr = self._attrComp(playerId)
        if attr is None:
            return
        try:
            attrType = serverApi.GetMinecraftEnum().AttrType.HEALTH
        except Exception:
            return
        base = float(getattr(cfg, "MODE_BASE_MAX_HEALTH", 20.0))
        if self._attrNumber(attr, attrType, base) <= base + 0.5:
            return
        self._setMaxHealthValue(attr, attrType, base)
        cur = self._attrNumber(attr, attrType, base, "GetAttrValue")
        if cur > base:
            self._setHealthValue(attr, attrType, base)

    def _maxHealthOf(self, attr):
        # 尽量问出“最大生命值”，问不到就用默认 20 点（10 颗心）
        try:
            AttrType = serverApi.GetMinecraftEnum().AttrType
        except Exception:
            return float(getattr(cfg, "BLAST_FALLBACK_MAX_HEALTH", 20.0))
        for name in ("MAX_HEALTH", "MAXHEALTH"):
            attrType = getattr(AttrType, name, None)
            if attrType is None:
                continue
            for getter in ("GetAttrMaxValue", "GetAttrValue"):
                try:
                    value = float(getattr(attr, getter)(attrType))
                except Exception:
                    continue
                if value > 0.0:
                    return value
        return float(getattr(cfg, "BLAST_FALLBACK_MAX_HEALTH", 20.0))

    def _hurtSelf(self, playerId):
        # 炸完扣自己一半血（默认不会把自己炸死）
        if not getattr(cfg, "BLAST_SELF_HALF_HP", True):
            return
        try:
            attr = serverApi.GetEngineCompFactory().CreateAttr(playerId)
            AttrType = serverApi.GetMinecraftEnum().AttrType
            cur = float(attr.GetAttrValue(AttrType.HEALTH))
        except Exception:
            return
        if cur <= 0.0:
            return
        damage = max(1.0, self._maxHealthOf(attr) * 0.5)
        if getattr(cfg, "BLAST_SELF_LETHAL", False) or cur - damage >= 1.0:
            self._hurtEntity(playerId, damage, playerId)
            return
        # 非致命：至少留 1 点血
        try:
            attr.SetAttrValue(AttrType.HEALTH, 1.0, 1)
        except Exception:
            try:
                attr.SetAttrValue(AttrType.HEALTH, 1.0)
            except Exception:
                pass

    # ==================== 炸方块 ====================
    def _isProtected(self, name):
        if self._protect is None:
            try:
                self._protect = set(cfg.BLAST_BLOCK_BLACKLIST or [])
            except Exception:
                self._protect = set()
        if not name:
            return True
        return name in self._protect

    def _breakOne(self, comp, pos, dimensionId):
        if pos[1] < MIN_Y or pos[1] > MAX_Y:
            return False
        name = None
        aux = 0
        try:
            info = comp.GetBlockNew(pos, dimensionId)
            if info:
                name = info.get("name")
                aux = info.get("aux", 0)
        except Exception:
            return False
        if not name or self._isProtected(name):
            return False
        if getattr(cfg, "BLAST_BREAK_DROP", False):
            try:
                comp.SpawnResources(name, pos, aux, 1.0, 0, dimensionId)
            except Exception:
                pass
        try:
            return bool(comp.SetBlockNew(pos, AIR_BLOCK, 0, dimensionId, True, False))
        except Exception:
            return False

    def _blockComp(self):
        try:
            return serverApi.GetEngineCompFactory().CreateBlockInfo(
                serverApi.GetLevelId())
        except Exception:
            return None

    def _craterCells(self, center, radius):
        # 从圆心往外排好队：先炸中间的，坑才是圆的
        r = int(radius) + 1
        r2 = float(radius) * float(radius)
        cx = int(math.floor(float(center[0])))
        cy = int(math.floor(float(center[1])))
        cz = int(math.floor(float(center[2])))
        cells = []
        for dx in range(-r, r + 1):
            for dy in range(-r, r + 1):
                for dz in range(-r, r + 1):
                    d2 = dx * dx + dy * dy + dz * dz
                    if d2 > r2:
                        continue
                    cells.append((d2, (cx + dx, cy + dy, cz + dz)))
        cells.sort(key=lambda one: one[0])
        return [pos for _d2, pos in cells]

    def _crater(self, center, radius, dimensionId):
        # 以 center 为球心炸出一个坑
        # ★ 直径大的时候一次炸几千块会把游戏卡住，所以分帧炸：
        #    这一帧先炸掉头一批，剩下的排队，每帧再炸一点
        cells = self._craterCells(center, radius)
        if not cells:
            return 0
        limit = int(getattr(cfg, "BLAST_BREAK_MAX", 3500))
        if limit > 0 and len(cells) > limit:
            cells = cells[:limit]
        total = len(cells)
        batch = int(getattr(cfg, "BLAST_BREAK_BATCH", 300))
        if batch <= 0 or total <= batch:
            self._breakCells(cells, dimensionId)
            return total
        self._breakCells(cells[:batch], dimensionId)
        self._craterQueue.append({"cells": cells[batch:], "dim": dimensionId, "i": 0})
        return total

    def _breakCells(self, cells, dimensionId):
        comp = self._blockComp()
        if comp is None or not cells:
            return 0
        broken = 0
        for pos in cells:
            if self._breakOne(comp, pos, dimensionId):
                broken += 1
        return broken

    def _flushCrater(self):
        # 把上一步排队的剩余方块一点点炸完（每帧一小批，不卡）
        if not self._craterQueue:
            return
        batch = max(1, int(getattr(cfg, "BLAST_BREAK_BATCH", 300)))
        comp = self._blockComp()
        if comp is None:
            return
        for item in list(self._craterQueue):
            cells = item.get("cells") or []
            start = int(item.get("i", 0))
            end = min(len(cells), start + batch)
            for pos in cells[start:end]:
                self._breakOne(comp, pos, item.get("dim", 0))
            item["i"] = end
            if end >= len(cells):
                self._craterQueue.remove(item)

    # ==================== 声音 / 特效 ====================
    def _blastSoundLayers(self):
        layers = getattr(cfg, "BLAST_SOUND_LAYERS", None)
        if not layers:
            layers = [(str(getattr(cfg, "BLAST_SOUND_NAME", "random.explode")), 0.0,
                       float(getattr(cfg, "BLAST_SOUND_VOLUME", 1.6)),
                       float(getattr(cfg, "BLAST_SOUND_PITCH", 0.6)))]
        return layers

    def _playBlastSounds(self, center, dimensionId):
        # ★ 爆炸音效叠几层：主爆 + 炸雷 + 后补的低音，听起来才够震撼
        now = time.time()
        played = False
        for layer in self._blastSoundLayers():
            try:
                name, delay, volume, pitch = layer
            except Exception:
                continue
            try:
                delay = float(delay)
            except Exception:
                delay = 0.0
            if delay > 0.0:
                # 稍微晚一点的那一层，先排进队列，由每帧去放
                self._sndQueue.append({"at": now + delay, "pos": center,
                                       "dim": dimensionId, "name": str(name),
                                       "vol": float(volume), "pitch": float(pitch)})
                continue
            if self._playVanillaSound(center, dimensionId, str(name),
                                      float(volume), float(pitch), radius=140.0):
                played = True
        return played

    def _flushSounds(self, now):
        if not self._sndQueue:
            return
        for item in list(self._sndQueue):
            if now < float(item.get("at", 0.0)):
                continue
            self._sndQueue.remove(item)
            self._playVanillaSound(item.get("pos") or (0.0, 0.0, 0.0),
                                   item.get("dim", 0), item.get("name", ""),
                                   item.get("vol", 1.0), item.get("pitch", 1.0),
                                   radius=140.0)

    def _playVanillaSound(self, pos, dimensionId, soundName, volume, pitch, radius=90.0):
        # 用原版 /playsound 指令放音：不依赖资源包，最稳
        try:
            comp = serverApi.GetEngineCompFactory().CreateCommand(serverApi.GetLevelId())
        except Exception:
            return False
        try:
            x, y, z = float(pos[0]), float(pos[1]), float(pos[2])
        except Exception:
            return False
        try:
            players = list(serverApi.GetPlayerList() or [])
        except Exception:
            players = []
        r2 = float(radius) * float(radius)
        played = False
        for playerId in players:
            try:
                if self._dimOf(playerId) != dimensionId:
                    continue
                p = self._posOf(playerId)
                if p:
                    dx, dy, dz = p[0] - x, p[1] - y, p[2] - z
                    if dx * dx + dy * dy + dz * dz > r2:
                        continue
                comp.SetCommand("/playsound %s @s %.2f %.2f %.2f %.2f %.2f" % (
                    soundName, x, y, z, float(volume), float(pitch)), playerId)
                played = True
            except Exception:
                continue
        return played

    def _toAllClients(self, eventName, data):
        # ★ 官方接口叫 BroadcastToAllClient（不是 NotifyToAllClients）
        # 之前用错名字，特效一直没发出去，所以看不到金光
        try:
            self.BroadcastToAllClient(eventName, data)
            return
        except Exception:
            pass
        try:
            for pid in (serverApi.GetPlayerList() or []):
                try:
                    self.NotifyToClient(pid, eventName, data)
                except Exception:
                    pass
        except Exception:
            pass

    def _fx(self, kind, pos, dimensionId, scale=1.0, extra=None):
        # 特效交给客户端画（同维度的玩家都能看见）
        data = {"kind": str(kind),
                "x": float(pos[0]), "y": float(pos[1]), "z": float(pos[2]),
                "dim": dimensionId, "scale": float(scale)}
        if extra:
            data.update(extra)
        self._toAllClients(modConfig.EventFx, data)

    # ==================== 每帧 ====================
    def _stateTick(self, players, now):
        charging = False
        for playerId in players:
            if playerId in self._chargeAt:
                charging = True
                break
        gap = float(getattr(cfg, "STATE_SYNC_CHARGE", 0.1)) if charging else float(
            getattr(cfg, "STATE_SYNC_INTERVAL", 0.25))
        if now - self._stateT < gap:
            return
        self._stateT = now
        for playerId in players:
            self._syncState(playerId)

    def OnServerTick(self, args=None):
        try:
            players = set(serverApi.GetPlayerList() or [])
        except Exception:
            players = set()
        if not players:
            return
        now = time.time()

        # 0) 进游戏发药水（手机端不用打指令）
        if self._potionAt:
            for playerId in list(self._potionAt.keys()):
                if now < self._potionAt[playerId]:
                    continue
                del self._potionAt[playerId]
                if playerId in players:
                    self._giveJoinPotion(playerId)

        # 1) 药效到点 / 快到点提醒
        if self._powerOn() and self._powerUntil:
            for playerId in players:
                if playerId not in self._powerUntil:
                    continue
                left = self._powerLeftOf(playerId)
                if left <= 0.0:
                    self._losePower(playerId)
                    continue
                self._warn(playerId, left)

        # 2) 蓄力中：胸口黄光；蓄满就炸
        if getattr(cfg, "BLAST_ENABLED", True):
            self._chargeTick(players, now)

        # 3) 爆炸之后扣自己那一半血
        if self._selfHurtAt:
            for playerId in list(self._selfHurtAt.keys()):
                if now >= float(self._selfHurtAt[playerId]):
                    del self._selfHurtAt[playerId]
                    self._hurtSelf(playerId)

        # 3.5) 叠层音效里晚放的那几层 + 分批炸方块的后续 + 生命上限看门狗
        self._flushSounds(now)
        self._flushCrater()
        self._healthWatchdog(players, now)

        # 4) 蓄力锁看门狗：只要不在蓄力，立刻解锁
        self._sneakWatchdog(players)
        self._cleanLocked(players)

        # 5) 同步界面状态（左上角倒计时 / 蓄力进度 / 冷却）
        self._stateTick(players, now)

    # ==================== 死亡 / 重生 ====================
    def OnPlayerDie(self, args):
        # ★ 药效期间死亡：药效当场作废，重生之后也不会再挂着
        try:
            playerId = None
            if args:
                playerId = args.get("id") or args.get("playerId")
            if not playerId:
                return
            if playerId not in self._powerUntil:
                return
            self._losePower(playerId, quiet=True)
            self._selfHurtAt.pop(playerId, None)
            self._tip(playerId, u"你死了，《%s》的药效也跟着消失。想再来一瓶："
                                u"工作台 玻璃瓶×1 + 糖×2 + 火药×1" % cfg.MODE_NAME, "RED")
            if getattr(cfg, "MODE_REFILL_ON_DEATH", False):
                self._refillIfEmpty(playerId)
        except Exception:
            pass

    def OnPlayerRespawnFinish(self, args):
        # ★ 重生兜底：万一死亡事件没收到（比如中途重连），这里也要收干净
        try:
            playerId = None
            if args:
                playerId = args.get("playerId") or args.get("id")
            if not playerId:
                return
            self._chargeAt.pop(playerId, None)
            self._chargeFxAt.pop(playerId, None)
            self._selfHurtAt.pop(playerId, None)
            self._losePower(playerId, quiet=True)
            self._resetMaxHealth(playerId)
            self._syncState(playerId, force=True)
        except Exception:
            pass

    # ==================== 进游戏 ====================
    def OnAddPlayer(self, args):
        playerId = None
        if args:
            playerId = args.get("id") or args.get("playerId")
        if not playerId or playerId in self._welcomed:
            return
        self._welcomed.add(playerId)
        if self._powerOn():
            self._tip(playerId, u"药水马上放进背包：喝掉《%s》之后，屏幕上会多出一个"
                                u"【爆炸】图标，长按蓄力 %d 秒，胸口就会炸开"
                      % (cfg.MODE_NAME, int(getattr(cfg, "BLAST_CHARGE_TIME", 5.0))),
                      "LIGHT_PURPLE")
            self._potionAt[playerId] = time.time() + 2.0
        self._syncState(playerId, force=True)

    # ==================== 聊天指令 ====================
    def OnChat(self, args):
        try:
            if not args:
                return
            playerId = args.get("playerId")
            message = (args.get("message") or "").strip().lower()
            if not playerId or not message:
                return
            if message in (u"#士兵男孩", u"#士兵男孩帮助"):
                self._tip(playerId, u"《士兵男孩》：喝五号化合物 -> 长按屏幕上的【爆炸】"
                                    u"图标蓄力 %d 秒 -> 胸口炸开，直径 %d 格内化为乌有"
                          % (int(getattr(cfg, "BLAST_CHARGE_TIME", 5.0)),
                             int(getattr(cfg, "BLAST_DIAMETER", 10))), "GOLD")
                self._tip(playerId, u"电脑端：按住 %s 键（或鼠标左键按住屏幕上的【爆炸】图标）"
                                    u"别松开，满 %d 秒就炸；也可以直接打 #引爆"
                          % (getattr(cfg, "BLAST_KEY_NAME", u"G"),
                             int(getattr(cfg, "BLAST_CHARGE_TIME", 5.0))), "YELLOW")
                self._tip(playerId, u"蓄力期间只能潜行移动（不能跑、不能跳），爆炸动画和游戏自带的 TNT 一模一样",
                          "GRAY")
                self._tip(playerId, u"喝下药水后生命上限变成 %d 颗心；被炸到的目标只要身上带着药水效果，"
                                    u"就只会被清掉药水、剩一点点血，不会当场被炸死"
                          % int(round(float(getattr(cfg, "MODE_MAX_HEALTH", 200.0)) / 2.0)),
                          "LIGHT_PURPLE")
                self._tip(playerId, u"指令：#药水 [数量] 拿药水 / #引爆 直接蓄力 / "
                                    u"#清冷却 消除冷却 / #重置移速 恢复正常速度 / "
                                    u"#爆炸直径 10 / #蓄力 5 / #冷却 30",
                          "YELLOW")
            elif message in (u"#药水", u"#五号化合物"):
                self._givePotionItem(playerId, 1)
            elif message.startswith(u"#药水 ") or message.startswith(u"#五号化合物 "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    num = int(raw)
                except Exception:
                    num = 1
                self._givePotionItem(playerId, max(1, min(16, num)))
            elif message in (u"#引爆", u"#爆炸", u"#蓄力"):
                # 电脑端不方便长按图标时的备用触发：同样要先蓄力 5 秒
                self._startCharge(playerId, fromChat=True)
            elif message in (u"#重置移速", u"#重置速度", u"#恢复移速"):
                # 万一移速被卡在慢速状态，一句话恢复成原版速度
                self._restoreSpeed(playerId, forceBase=float(
                    getattr(cfg, "CHARGE_SPEED_BASE", 0.1)))
                comp = self._playerComp(playerId)
                if comp is not None:
                    try:
                        comp.SetPlayerJumpable(True)
                    except Exception:
                        pass
                self._sneakOn.discard(playerId)
                self._notifySneak(playerId, False)
                self._tip(playerId, u"移速已恢复正常，跳跃也没问题了", "GREEN")
            elif message in (u"#清冷却", u"#消除冷却"):
                self._coolUntil.pop(playerId, None)
                self._syncState(playerId, force=True)
                self._tip(playerId, u"爆炸冷却已清除", "GREEN")
            elif message.startswith(u"#爆炸直径 "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = int(raw)
                except Exception:
                    value = 0
                if value >= 2:
                    radius = max(1.0, min(24.0, value / 2.0))
                    cfg.BLAST_DIAMETER = int(radius * 2)
                    cfg.BLAST_RADIUS = radius
                    self._tip(playerId, u"爆炸直径改成 %d 格" % int(radius * 2), "GREEN")
                else:
                    self._tip(playerId, u"用法：#爆炸直径 10（填偶数，最大 48）", "RED")
            elif message.startswith(u"#蓄力 "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = float(raw)
                except Exception:
                    value = 0.0
                if value > 0.0:
                    cfg.BLAST_CHARGE_TIME = max(0.5, min(30.0, value))
                    self._tip(playerId, u"蓄力时间改成 %.1f 秒" % cfg.BLAST_CHARGE_TIME, "GREEN")
            elif message.startswith(u"#冷却 "):
                raw = message.split(u" ", 1)[1].strip()
                try:
                    value = float(raw)
                except Exception:
                    value = 0.0
                if value >= 0.0:
                    cfg.BLAST_COOLDOWN = max(0.0, min(600.0, value))
                    self._tip(playerId, u"爆炸冷却改成 %d 秒" % int(cfg.BLAST_COOLDOWN), "GREEN")
        except Exception:
            pass
