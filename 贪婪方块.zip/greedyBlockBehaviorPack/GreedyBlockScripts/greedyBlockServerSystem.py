# -*- coding: utf-8 -*-
import mod.server.extraServerApi as serverApi
from GreedyBlockScripts.lootTable import GreedyLootTable

ServerSystem = serverApi.GetServerSystemCls()

# 这些方块属于不可破坏/技术性方块，即使被破坏也不参与随机掉落
IGNORED_BLOCKS = set([
    "minecraft:bedrock",
    "minecraft:invisible_bedrock",
    "minecraft:command_block",
    "minecraft:chain_command_block",
    "minecraft:repeating_command_block",
    "minecraft:barrier",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:jigsaw",
    "minecraft:end_gateway",
    "minecraft:end_portal",
    "minecraft:portal",
    "minecraft:allow",
    "minecraft:deny",
    "minecraft:border_block",
    "minecraft:light_block",
])


class GreedyBlockServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(GreedyBlockServerSystem, self).__init__(namespace, systemName)
        self._lootTable = GreedyLootTable()
        # 玩家即将破坏方块时触发（服务端）
        self.ListenForEvent(serverApi.GetEngineNamespace(),
                            serverApi.GetEngineSystemName(),
                            "ServerPlayerTryDestroyBlockEvent",
                            self, self.OnTryDestroyBlock)

    def OnTryDestroyBlock(self, args):
        fullName = args.get("fullName")
        if fullName in IGNORED_BLOCKS:
            return  # 基岩、命令方块、屏障等不触发随机

        playerId = args.get("playerId")
        if not playerId:
            return

        # 精准采集生效时保留原掉落，不触发随机
        if self._hasSilkTouch(playerId):
            return

        # 取消原版掉落，改从掉落表随机抽 1 个物品
        args["spawnResources"] = False
        itemName = self._lootTable.roll()
        dimensionId = args.get("dimensionId", 0)
        pos = (args.get("x") + 0.5, args.get("y") + 0.5, args.get("z") + 0.5)
        itemDict = {"itemName": itemName, "count": 1, "auxValue": 0}
        try:
            self.CreateEngineItemEntity(itemDict, dimensionId, pos)
        except Exception:
            pass

    def _hasSilkTouch(self, playerId):
        """检查玩家当前手持物品是否带有精准采集附魔。"""
        try:
            itemComp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            slot = itemComp.GetSelectSlotId()
            if slot is None or slot < 0:
                return False
            enchants = itemComp.GetInvItemEnchantData(slot) or []
            silkTouch = serverApi.GetMinecraftEnum().EnchantType.MiningSilkTouch
            for enchant in enchants:
                if enchant and enchant[0] == silkTouch and enchant[1] > 0:
                    return True
        except Exception:
            pass
        return False