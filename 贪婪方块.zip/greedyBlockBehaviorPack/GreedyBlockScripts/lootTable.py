# -*- coding: utf-8 -*-
import random


class GreedyLootTable(object):
    """贪婪方块掉落表。

    修改 TIERS 即可调整掉落内容和概率：
      - 每个元组第 1 项是权重，数值越大越容易抽中；
      - 第 2 项是该档可掉落的物品名列表；
      - 某档总权重 = 权重 * 物品数量。
    """

    TIERS = [
        # 普通档，权重 100
        (100, [
            "minecraft:dirt",         # 泥土
            "minecraft:cobblestone",  # 圆石
            "minecraft:stick",        # 木棍
            "minecraft:apple",        # 苹果
            "minecraft:coal",         # 煤炭
            "minecraft:sand",         # 沙子
        ]),
        # 稀有档，权重 20
        (20, [
            "minecraft:iron_ingot",   # 铁锭
            "minecraft:gold_ingot",   # 金锭
            "minecraft:diamond",      # 钻石
            "minecraft:lapis_lazuli", # 青金石
            "minecraft:ender_pearl",  # 末影珍珠
            "minecraft:blaze_rod",    # 火焰棒
        ]),
        # 传说档，权重 1
        (1, [
            "minecraft:nether_star",          # 下界之星
            "minecraft:dragon_egg",           # 龙蛋
            "minecraft:enchanted_golden_apple",  # 附魔金苹果
            "minecraft:elytra",               # 鞘翅
        ]),
    ]

    def __init__(self):
        self._totalWeight = 0
        for weight, items in self.TIERS:
            self._totalWeight += weight * len(items)

    def roll(self):
        """随机抽取一个物品名，权重越高越容易抽中。"""
        point = random.randint(1, self._totalWeight)
        for weight, items in self.TIERS:
            for itemName in items:
                point -= weight
                if point <= 0:
                    return itemName
        # 理论上不会走到这里，兜底返回最后一项
        return self.TIERS[-1][1][-1]