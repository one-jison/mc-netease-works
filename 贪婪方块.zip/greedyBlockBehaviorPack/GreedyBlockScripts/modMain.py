# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi


@Mod.Binding(name="GreedyBlockMod", version="0.0.1")
class GreedyBlockMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def GreedyBlockServerInit(self):
        serverApi.RegisterSystem(
            "GreedyBlockMod",
            "GreedyBlockServerSystem",
            "GreedyBlockScripts.greedyBlockServerSystem.GreedyBlockServerSystem"
        )

    @Mod.DestroyServer()
    def GreedyBlockServerDestroy(self):
        pass

    @Mod.InitClient()
    def GreedyBlockClientInit(self):
        pass

    @Mod.DestroyClient()
    def GreedyBlockClientDestroy(self):
        pass