# -*- coding: utf-8 -*-
# ============================================================
#  化身 HIM - 所有能调的数字都在这里，改完重进游戏就生效
# ============================================================

MODE_ON = True                 # 整个模组的总开关

# ---------------- 外观 ----------------
MODEL_NAME = "him"             # 资源包里 models/netease_models.json 里登记的名字
HIM_NAME = u"HIM"              # 聊天 / 提示里显示的名字

# ---------------- 变身节奏（秒） ----------------
T_DARK = 0.9        # 阶段1 黑暗降临
T_GATHER = 1.5      # 阶段2 能量聚集
T_APPEAR = 1.3      # 阶段3 HIM 降临
T_SETTLE = 1.0      # 阶段4 完成

T_EXIT_SMOKE = 0.6    # 退场阶段1 紫烟冒起
T_EXIT_SCATTER = 0.7  # 退场阶段2 粒子飘散
T_EXIT_WRAP = 0.6     # 退场阶段3 被烟雾包住
T_EXIT_BURST = 0.9    # 退场阶段4 烟雾炸开、恢复原样

# ---------------- HIM 常驻能力 ----------------
BUFF_ON = True          # True = HIM 状态下自动给速度/跳跃/攻击/抗性
BUFF_TICK = 2.0
BUFF_EXTRA = 4.0
SPEED_AMP = 1
JUMP_AMP = 1
STRENGTH_AMP = 1
RESIST_AMP = 1
FIRE_RESIST = True      # True = 额外给抗火（HIM 不怕火）

AMBIENT_ON = True       # 站着不动时身上偶尔冒紫色粒子
AMBIENT_TICKS = 6
TRAIL_ON = True         # 跑动时背后留紫色残影
TRAIL_SPEED = 0.16
TRAIL_TICKS = 4

# ---------------- 飞行 ----------------
# 双击"跳跃键 / 空格"起飞，再双击一次降落。手机上也可以直接点屏幕左边的【起飞】按钮。
TRANSFORM_DIM = False          # 变身 / 退出变身时的那块紫色透明遮罩
                               # （就是屏幕上那块紫色方块）默认关闭；想恢复改 True
FLY_ON = True
FLY_ABILITY_CMD = True         # 允许用游戏自带的 /ability 指令去发/收飞行能力
FLY_NATIVE_DOUBLE_TAP = True  # 变身就把“能飞”的能力(mayfly)发给玩家：
                               # 双击跳跃交给游戏自己处理（一按就飞、再双击就落）
FLY_DOUBLE_WINDOW = 1.0     # 两次跳跃间隔小于这么多秒，算双击
FLY_LAND_WINDOW = 0.8       # 落地后这么久内再跳一下，就算双击（否则滞空时间会把窗口吃掉）
FLY_AIR_WINDOW = 0.4        # 飞着的时候，0.4 秒内连点两下跳跃 = 立刻降落
FLY_TAKEOFF_GRACE = 0.7     # 刚起飞这么久内，起飞助推顶起来的速度不算“按键”
FLY_EARLY = True            # True = 变身到“闪电落下”那一刻就能起飞，不用等动画播完
FLY_JUMP_RISE = 0.35        # 竖直速度超过这个数，算“正在起跳/上升”
FLY_FLY_RISE = 0.10         # 飞着的时候，竖直速度超过这个数就算“按了一下跳跃”
                            # （飞行上升本来就比普通起跳慢，阈值得低一点）
FLY_GROUND_V = 0.06         # 竖直速度小于这个数，算“落在地上 / 悬停”
FLY_LIFT_ON_TAKEOFF = True   # 起飞瞬间往上抬一下，避免卡在地面
FLY_LIFT_SPEED = 0.8         # 抬升力度
FLY_LIFT_TIME = 0.25         # 起飞后连续抬升多久（秒），保证一定离开地面
FLY_SPEED = 1                # 飞行时额外加的速度等级（每级 +20%）
FLY_SYNC_TICK = 0.25        # 每这么多秒把“到底飞没飞”回传给客户端（双击方向不能猜错）

# ---------------- 技能冷却（秒） ----------------
CD_BOLT = 2.0       # 雷击
CD_FIRE = 3.0       # 火球
CD_FIELD = 5.0      # 黑暗领域
CD_JUDGE = 5.0      # 审判

# ---------------- 技能1 雷击 ----------------
BOLT_RANGE = 42.0
BOLT_RADIUS = 4.5
BOLT_DAMAGE = 20.0
BOLT_KNOCK = 1.8
BOLT_FIRE = True            # True = 被劈中的地方会着火

# ---------------- 技能2 火球 ----------------
FIRE_RANGE = 46.0       # 火球最远飞多远
FIRE_STEP = 0.5         # 每步走多远
FIRE_RADIUS = 1.6       # 路上碰到生物的判定半径
FIRE_DAMAGE = 16.0      # 直接命中伤害
FIRE_KNOCK = 2.0        # 击退力度
FIRE_BURN = 6           # 命中后点燃几秒
FIRE_BLAST_RADIUS = 3.5 # 爆炸波及半径
FIRE_BLAST_DAMAGE = 8.0 # 爆炸伤害
FIRE_BREAK_RADIUS = 2   # 炸掉多大的坑（0 = 不破坏方块）
FIRE_LIGHT = True       # 落点铺一层火

# ---------------- 技能3 黑暗领域 ----------------
# 释放后：脚下出现紫色法阵，法阵从脚下向四周慢慢推进扩散到 30 格；
#         被法阵扫过的非玩家生物全部被吹到空中；
#         等法阵完全铺满之后，才在法阵中心打出冲击波秒杀空中的生物。
FIELD_RANGE = 30.0            # 法阵 / 冲击波半径（格）
FIELD_SECONDS = 6.0           # 法阵持续旋转几秒
FIELD_TICK = 0.5              # 每几秒刷新法阵 + 继续把生物往上推
FIELD_SEAL_TICK = 1.0         # 法阵外圈（seal）刷新间隔
# 法阵从脚下向四周慢慢推进扩散到 FIELD_RANGE 需要几秒；
# 扩散完成的那一刻才打冲击波秒杀空中的生物。
# 注意：粒子 him_wave.json 里把扩散写死成 3 秒 / 30 格（emitter 的 active_time 和
#       radius 公式），改这里的 FIELD_GROW_TIME / FIELD_RANGE 时记得一起改。
FIELD_GROW_TIME = 3.0         # 法阵扩散到 30 格需要几秒
FIELD_LIFT_TIME = 3.0         # 扩散期间一直在吹，扩散完成才放冲击波
FIELD_LIFT = 0.85             # 每次给的向上速度
FIELD_KILL_DAMAGE = 100000.0  # 冲击波对空中生物的伤害（必杀）
FIELD_WAVE_SOUND = "mob.warden.sonic_charge"   # 法阵出现 / 扩散时的蓄势声
FIELD_BLAST_SOUND = "mob.warden.sonic_boom"    # 冲击波秒杀：监守者音波
FIELD_DAMAGE = 2.0            # 旧版数值，保留但不再使用
FIELD_SELF_SPEED = 2

# ---------------- 技能4 审判 ----------------
# 使用后：天空变成深紫色、暗下来；
#         从玩家脚下向四周扩散一圈白色冲击波，一直推到 50 格；
#         被冲击波扫到的非玩家生物瞬间身上起火，紧接着被击杀。
JUDGE_RANGE = 50.0        # 白色冲击波推进到几格
JUDGE_WAVE_TIME = 1.0     # 冲击波从脚下扩散到 50 格用几秒
JUDGE_SWEEP_TICK = 0.2    # 每几秒扫一次（决定冲击波“烧到”生物的速度）
JUDGE_KILL_DELAY = 0.45   # 起火之后过多久击杀
JUDGE_BURN = 8            # 起火几秒
JUDGE_KILL_DAMAGE = 100000.0   # 击杀伤害（必杀）
JUDGE_KILL_FIRE = True    # True = 生物被击杀的位置会燃起火
JUDGE_FOG = ""            # 不再推深紫色天空雾（改成真的把世界时间调到半夜）
JUDGE_FOG_TAG = "himjudge"  # 雾的 userProvidedId，用来 pop 掉
JUDGE_FOG_TIME = 7.0      # 天空保持深紫色几秒
JUDGE_TINT = False        # 取消整屏暗紫遮罩（那个紫色框就是它），见下面的真入夜
JUDGE_BLAST_SOUND = "mob.warden.sonic_boom"   # 冲击波音效
JUDGE_DAMAGE = 45.0       # 旧版数值，保留但不再使用
JUDGE_KNOCK = 3.6         # 旧版数值，保留但不再使用
JUDGE_CHARGE = 2.0        # 蓄力几秒（蓄力时天就开始黑）
# 审判：释放的一瞬间把世界时间调到半夜，技能放完再恢复原状
JUDGE_NIGHT = True
JUDGE_NIGHT_TIME = 18000  # 半夜（0 清晨 / 6000 正午 / 12000 黄昏 / 18000 午夜）
JUDGE_NIGHT_HOLD = 7.0    # 黑夜保持几秒，之后把时间恢复成原来的
JUDGE_STEP = 0.6
# 审判：以玩家为中心，这个格数以内的非玩家生物全部被雷击打中
JUDGE_BOLT = True
JUDGE_BOLT_RANGE = 100.0
JUDGE_BOLT_BATCH = 6     # 每个 tick 同时落几道雷（一次生成太多闪电会卡）

# ---------------- 电脑端键盘快捷键 ----------------
# 键码用 GLFW 键码：R=82 G=71 H=72 J=74 K=75。这几个键原版都没占用，不会和系统冲突。
# 玩家可以在 "设置 -> 键盘 -> 游戏" 里自己改。
PC_KEY_ENABLED = True
KEY_CATEGORY = "gameplay"
KEY_TOGGLE = ("him_toggle", 82, u"R")     # 变身 / 退出
SKILL_KEYS_PC = [
    ("him_sk_bolt", 71, u"G"),      # 雷击
    ("him_sk_fire", 72, u"H"),      # 火球
    ("him_sk_field", 74, u"J"),     # 黑暗领域
    ("him_sk_judge", 75, u"K"),     # 审判
]

# ---------------- 死亡 / 重进世界 ----------------
KEEP_ON_DEATH = False   # False = 死了就变回普通人（避免状态残留）
# ---------------- invincible while transforming ----------------
INVULN_ON_TRANSFORM = True   # lock HP during the transform / exit animation
INVULN_REFRESH = 0.25        # seconds between invulnerability refreshes
INVULN_HIM = True           # True = HIM 状态下也免疫一切伤害（不只是变身动画期间）
INVULN_AMP = 4              # 抗性等级 amp 4 = 抗性 V = 100% 减伤（完全免疫）
INVULN_NO_BURN = True       # 无敌期间不让身上着火（被闪电劈到也不会烧起来）

# ---------------- native lightning / thrown fireball ----------------
BOLT_NATIVE = True           # real vanilla lightning bolt entity + vanilla thunder
BOLT_COLUMN = True           # True = 除了原版闪电，再画一条从天上劈下来的光柱（保证看得见）
BOLT_ZAP = True              # True = 落雷时再补一声炸响
# vanilla minecraft:fireball has "is_summonable": false, so a script can
# not create it at all. We throw our own projectile entity instead (own
# texture + geometry, drawn to look like the vanilla fireball) and blow
# it up ourselves, so the fireball really flies out and really sets the
# place it lands on on fire.
FIRE_ENTITY = "him:fireball"    # projectile registered in the behavior pack
FIRE_SPEED = 1.3                # blocks per tick
FIRE_LIFE = 2.6                 # seconds before it blows up in mid air
FIRE_HIT_R = 1.4                # how close an entity must be to get hit
FIRE_SOUND = "mob.blaze.shoot"  # vanilla launch sound
FIRE_BOOM_SOUND = "random.explode"  # TNT style boom when it hits
FIRE_BURN_R = 3                # how far around the blast gets set on fire

# ---------------- lightning at the moment of the transform ----------------
TRANSFORM_BOLT = True   # several bolts hit the player while transforming
TRANSFORM_BOLT_N = 5    # how many bolts
TRANSFORM_BOLT_NATIVE = True   # True = 变身时生成原版闪电（已恢复）
TRANSFORM_BOLT_THUNDER = "ambient.weather.thunder"   # 不用原版闪电时，用它补一声雷
TRANSFORM_FIRE_R = 3    # how far around the player catches fire

CLEAR_ON_LEAVE = True


# ============================================================
#  下面这些不用动
# ============================================================
def on():
    return bool(MODE_ON)


def buffOn():
    return bool(BUFF_ON)


def flyOn():
    return bool(FLY_ON)


def keepOnDeath():
    return bool(KEEP_ON_DEATH)


def clearOnLeave():
    return bool(CLEAR_ON_LEAVE)


def modelName():
    return str(MODEL_NAME)


# 技能清单：(内部名字, 界面上显示的名字, 冷却秒数)
SKILLS = [
    ("bolt", u"雷击", CD_BOLT),
    ("fire", u"火球", CD_FIRE),
    ("field", u"黑暗领域", CD_FIELD),
    ("judge", u"审判", CD_JUDGE),
]

PHASE_DARK = "dark"
PHASE_GATHER = "gather"
PHASE_APPEAR = "appear"
PHASE_DONE = "done"
PHASE_HIM = "him"
PHASE_X_SMOKE = "x_smoke"
PHASE_X_SCATTER = "x_scatter"
PHASE_X_WRAP = "x_wrap"
PHASE_X_BURST = "x_burst"
PHASE_OFF = "off"


def transformPlan():
    return [
        (PHASE_DARK, float(T_DARK)),
        (PHASE_GATHER, float(T_GATHER)),
        (PHASE_APPEAR, float(T_APPEAR)),
        (PHASE_DONE, float(T_SETTLE)),
    ]


def exitPlan():
    return [
        (PHASE_X_SMOKE, float(T_EXIT_SMOKE)),
        (PHASE_X_SCATTER, float(T_EXIT_SCATTER)),
        (PHASE_X_WRAP, float(T_EXIT_WRAP)),
        (PHASE_X_BURST, float(T_EXIT_BURST)),
    ]


def skillCooldown(key):
    for k, _n, cd in SKILLS:
        if k == key:
            return float(cd)
    return 5.0


def skillName(key):
    for k, n, _cd in SKILLS:
        if k == key:
            return n
    return key
