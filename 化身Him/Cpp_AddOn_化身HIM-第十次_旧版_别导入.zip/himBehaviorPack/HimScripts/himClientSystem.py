# -*- coding: utf-8 -*-
# ============================================================
#  化身 HIM - 客户端
#    · 变身 / 退身的画面全在这里：黑烟、能量聚集、爆发、白光眼睛、冲击波
#    · HIM 状态下常驻少量黑粒子 + 跑动残影（数量都压得很低，不吃性能）
#    · 技能特效由服务端广播过来，谁在场谁都能看见
# ============================================================
import math
import time

import mod.client.extraClientApi as clientApi

from HimScripts import modConfig
from HimScripts import himConfig as cfg

ClientSystem = clientApi.GetClientSystemCls()

# 粒子名（资源包 particles 文件夹里登记的名字）
P_SMOKE = "him:smoke"
P_GATHER = "him:gather"
P_BURST = "him:burst"
P_RING = "him:ring"
P_RUNE = "him:rune"
P_SEAL = "him:seal"
P_BOLT = "him:bolt"
P_FIRE = "him:fire"
P_FIELD = "him:field"
P_JUDGE = "him:judge"
P_SPARK = "him:spark"
P_AFTER = "him:after"
P_TRAIL = "him:trail"
P_WAVE = "him:wave"
P_WAVE_W = "him:wave_white"
P_BOOM = "minecraft:huge_explosion_emitter"

S_TRANSFORM = "him.transform"
S_APPEAR = "him.appear"
S_DONE = "him.done"
S_SKILL = "him.skill"
S_FIRE = "him.fire"
S_BLAST = "him.blast"
S_BOLT = "him.bolt"
S_JUDGE = "him.judge"
S_EXIT = "him.exit"

DIM_OF = {cfg.PHASE_DARK: 1, cfg.PHASE_GATHER: 2, cfg.PHASE_APPEAR: 3,
          cfg.PHASE_DONE: 1,
          cfg.PHASE_X_SMOKE: 1, cfg.PHASE_X_SCATTER: 1,
          cfg.PHASE_X_WRAP: 2, cfg.PHASE_X_BURST: 3}


def _now():
    return time.time()


class HimClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        self.mHud = None
        self.mTries = 0
        self.mTryAt = 0.0
        self.mState = "none"
        self.mPhase = ""
        self.mPhaseAt = 0.0
        self.mPhaseDone = {}
        self.mHimSet = set()      # 现在是 HIM 的实体 id
        self.mModeled = {}        # 已经换成 HIM 模型的实体 id
        self.mCds = {}            # 技能 -> 本地到点时间
        self.mCdTotal = {}
        self.mSpawnAt = {}        # 各类粒子的节流时间
        self.mPending = []        # 需要按时间推进的特效
        self.mSyncAt = 0.0
        self.mTipKey = None
        self.mActAt = {}          # 每个动作上次触发的时间（防止一个按键被触发两次）
        self.mKeysDone = False
        self.mFly = False         # 自己现在在不在飞（服务端同步过来的）
        self.mInv = False         # 自己现在是不是无敌（服务端同步过来的）
        self.mAir = False         # 上一帧是不是在空中
        self.mLastJump = 0.0      # 上一次起跳的时间（双击判定用）
        self.mWin = 0.0           # 本次双击判定用多长的窗口
        self.mFlyGrace = 0.0      # 刚起飞的免打扰期（起飞助推不算按键）
        self.mJudgeTintUntil = 0.0  # 审判的整屏暗紫保持到什么时候
        self.mCanFly = False      # 游戏有没有给我“能飞”的能力(mayfly)：
                                  # 有的话双击跳跃由游戏原生处理，我们不用插手
        self._listen()

    # ==================== 事件 ====================
    def _listen(self):
        ns = clientApi.GetEngineNamespace()
        sn = clientApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "OnScriptTickClient", self, self.OnTick)
        self.ListenForEvent(ns, sn, "OnLocalPlayerStopLoading", self, self.OnStopLoading)
        self.ListenForEvent(ns, sn, "AddPlayerAOIClientEvent", self, self.OnAddAOI)
        self.ListenForEvent(ns, sn, "WalkAnimBeginClientEvent", self, self.OnWalkBegin)
        self.ListenForEvent(ns, sn, "WalkAnimEndClientEvent", self, self.OnWalkEnd)
        self.ListenForEvent(ns, sn, "AttackAnimBeginClientEvent", self, self.OnAttackBegin)
        self.ListenForEvent(ns, sn, "AttackAnimEndClientEvent", self, self.OnAttackEnd)
        self.ListenForEvent(ns, sn, modConfig.UiInitFinishedEvent, self, self.OnUIInitFinished)
        # 电脑端键盘：自定义按键（玩家可以在 设置 -> 键盘 里改）
        self.ListenForEvent(ns, sn, "OnCustomKeyPressInGame", self, self.OnCustomKey)
        # 兜底：自定义按键没登记上时，直接认键码
        self.ListenForEvent(ns, sn, "OnKeyPressInGame", self, self.OnKeyPress)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EvStage, self, self.OnStage)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EvState, self, self.OnState)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EvFx, self, self.OnFx)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EvTip, self, self.OnTip)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName,
                            modConfig.EvSync, self, self.OnSync)

    def OnUIInitFinished(self, args=None):
        self._ensureHud()

    def OnStopLoading(self, args=None):
        self.mHud = None
        self.mTries = 0
        self._ensureHud()
        # 刚进世界 / 重生：先把自己身上的 HIM 模型清干净，再问一下别人谁是 HIM
        self._setModel(self._me(), None)
        self.mState = "none"
        self.mHimSet = set()
        self.mModeled = {}
        self.mCds = {}
        self.mSyncAt = _now() + 1.2
        self._registerKeys()

    def OnAddAOI(self, args=None):
        pid = (args or {}).get("playerId")
        if pid and pid in self.mHimSet:
            self._applyModel(pid)

    # ---------------- 动作切换（跟官方时装模块一个写法）----------------
    def OnWalkBegin(self, args=None):
        self._anim((args or {}).get("id"), "walk")

    def OnWalkEnd(self, args=None):
        self._anim((args or {}).get("id"), "stand")

    def OnAttackBegin(self, args=None):
        self._anim((args or {}).get("id"), "attack")

    def OnAttackEnd(self, args=None):
        self._anim((args or {}).get("id"), "stand")

    def _anim(self, eid, name):
        if not eid or not self.mModeled.get(eid):
            return
        try:
            clientApi.GetEngineCompFactory().CreateModel(eid).PlayAnim(name, True)
        except Exception:
            pass

    # ==================== 每帧 ====================
    def OnTick(self, args=None):
        now = _now()
        if self.mHud is None:
            if now - self.mTryAt >= 2.0:
                self.mTryAt = now
                self._ensureHud()
            return
        if self.mSyncAt > 0.0 and now >= self.mSyncAt:
            self.mSyncAt = now + 20.0
            self._askSync()
        self._tickPending(now)
        self._tickPhase(now)
        self._tickAmbient(now)
        self._tickFly(now)
        self._tickHud()

    # ==================== 界面 ====================
    def _ensureHud(self):
        if self.mHud is not None or self.mTries >= 40:
            return
        self.mTries += 1
        try:
            node = clientApi.GetUI(modConfig.ModName, modConfig.HudUIName)
            if node is None:
                clientApi.RegisterUI(modConfig.ModName, modConfig.HudUIName,
                                     modConfig.HudUIPyClsPath, modConfig.HudUIScreenDef)
                node = clientApi.CreateUI(modConfig.ModName, modConfig.HudUIName,
                                          {"isHud": 1})
            if node is None:
                return
            node.SetOnMain(self._onMain)
            node.SetOnSkill(self._onSkill)
            node.SetOnFly(self._onFly)
            self.mHud = node
            self._registerKeys()
            self._fillSkillNames()
            self._refreshMain()
        except Exception:
            pass

    def _refreshMain(self):
        node = self.mHud
        if node is None:
            return
        him = (self.mState == "him")
        flyOK = self._flyReady()
        pc = self._isPC()
        try:
            if him:
                node.SetMainText(self._withKey(u"\u9000\u51fa HIM", cfg.KEY_TOGGLE[2]))
            else:
                node.SetMainText(self._withKey(u"\u5316\u8eab HIM", cfg.KEY_TOGGLE[2]))
            node.SetMainVisible(True)
            node.SetSkillsVisible(him)
            node.SetFlyVisible(flyOK)
            node.SetFlyText(u"\u964d\u843d" if self.mFly else u"\u8d77\u98de")
            if self.mState == "transform" or self.mState == "exit":
                node.SetHint(u"\u53d8\u8eab\u4e2d \u00b7 \u65e0\u654c\uff0c\u4e0d\u4f1a\u6389\u8840")
            elif him and pc:
                keys = u" ".join([one[2] for one in cfg.SKILL_KEYS_PC])
                node.SetHint(self._invTag(
                    u"\u53f3\u8fb9\u56fe\u6807\u6216 %s \u653e\u6280\u80fd \u00b7 \u53cc\u51fb\u8df3\u8dc3\u8d77\u98de" % keys))
            elif him:
                node.SetHint(self._invTag(
                    u"\u53cc\u51fb\u8df3\u8dc3\u952e\u8d77\u98de\uff0c\u4e5f\u53ef\u4ee5\u70b9\u5de6\u8fb9\u7684\u6309\u94ae"))
            elif pc:
                node.SetHint(u"\u70b9\u5de6\u8fb9\u6309\u94ae\u6216\u6309 %s \u53d8\u8eab" % cfg.KEY_TOGGLE[2])
            else:
                node.SetHint(u"")
        except Exception:
            pass

    def _invTag(self, text):
        if self.mInv:
            return text + u"\u00b7 \u65e0\u654c"
        return text

    def _tickHud(self):
        node = self.mHud
        if node is None:
            return
        if self.mState != "him":
            return
        now = _now()
        for i, (key, _n, _c) in enumerate(cfg.SKILLS):
            end = self.mCds.get(key, 0.0)
            left = max(0.0, end - now)
            try:
                node.SetCooldown(i, left, self.mCdTotal.get(key, 1.0))
            except Exception:
                pass

    # ==================== 按钮回调 ====================
    def _onMain(self):
        try:
            self.NotifyToServer(modConfig.ReqToggle,
                                {"playerId": clientApi.GetLocalPlayerId()})
        except Exception:
            pass

    def _onSkill(self, index):
        # 点下去的那一刻就在图标上开始倒计时，不用等服务端每秒一次的同步
        # （否则按下技能后要等最多 1 秒才看得到数字）
        try:
            key = cfg.SKILLS[int(index)][0]
        except Exception:
            return
        if self.mState == "him":
            now = _now()
            # 技能还在冷却里就别重新计时，免得狂点按钮把数字顶回满
            if self.mCds.get(key, 0.0) <= now + 0.15:
                try:
                    cd = float(cfg.skillCooldown(key))
                    self.mCdTotal[key] = cd
                    self.mCds[key] = now + cd
                except Exception:
                    pass
            self._tickHud()
        try:
            self.NotifyToServer(modConfig.ReqSkill,
                                {"playerId": clientApi.GetLocalPlayerId(), "key": key})
        except Exception:
            pass

    def _onFly(self):
        self._askFly()

    def _askFly(self):
        # 双击跳跃 / 点【起飞】按钮：告诉服务器“我要什么状态”，
        # 而不是“切换一下”。这样就算游戏原生双击也同时切了一次，
        # 两边想要的结果也一样，不会互相抵消（这才是之前“有时不起飞”的原因）
        self._askFlyTo(not self.mFly)

    def _askFlyTo(self, on):
        try:
            self.NotifyToServer(modConfig.ReqFly,
                                {"playerId": clientApi.GetLocalPlayerId(),
                                 "on": 1 if on else 0})
        except Exception:
            pass

    def _vy(self, eid):
        try:
            m = tuple(clientApi.GetEngineCompFactory().CreateActorMotion(eid).GetMotion()
                      or (0.0, 0.0, 0.0))
        except Exception:
            return 0.0
        return float(m[1])

    def _flyReady(self):
        # 什么时候可以飞：HIM 状态随时可以；
        # 变身动画到“HIM 降临”（闪电落下那一刻）之后也马上可以，
        # 不用等整段变身动画播完。
        if self.mState == "him":
            return True
        if self.mState == "transform" and getattr(cfg, "FLY_EARLY", True):
            return self.mPhase in (cfg.PHASE_APPEAR, cfg.PHASE_DONE)
        return False

    def _tickFly(self, now):
        # 双击跳跃键 / 双击空格：连着两下 -> 起飞；飞着的时候连着两下 -> 立刻降落。
        # 注意：如果游戏已经给了我“能飞”的能力(mayfly)，双击是引擎原生行为，
        # 那时脚本只在“还没飞起来”的时候兜底帮忙起飞，降落一律交给引擎，
        # 免得刚飞起来就被脚本按下去。
        if not cfg.flyOn() or not self._flyReady():
            self.mAir = False
            self.mLastJump = 0.0
            self.mWin = 0.0
            return
        if self.mFly and self.mCanFly:
            # 已经在飞 + 引擎管着双击：脚本闭嘴，不要再插一脚
            self.mAir = False
            self.mLastJump = 0.0
            self.mWin = 0.0
            return
        if now < self.mFlyGrace:
            # 刚起飞的一小会儿：起飞助推本身会把竖直速度顶上去，
            # 那不是玩家按的跳跃，不能算成“第一下”，
            # 否则刚起飞想往上飞一按就被当成双击、反手把飞行取消了。
            self.mAir = False
            self.mLastJump = 0.0
            self.mWin = 0.0
            return
        me = self._me()
        if me is None:
            return
        vy = self._vy(me)
        ground = abs(vy) <= float(getattr(cfg, "FLY_GROUND_V", 0.06))
        if ground:
            if self.mAir and not self.mFly:
                # 站在地上刚落地：双击窗口从“落地这一刻”重新开始算，
                # 不然第一跳的滞空时间会把窗口吃掉，玩家要等半天才飞得起来。
                # （飞着的时候悬停不算落地，窗口不重开，
                #   免得上升两下就被判成双击降落）
                self.mLastJump = now
                self.mWin = float(getattr(cfg, "FLY_LAND_WINDOW", 0.8))
            self.mAir = False
            return
        # 飞着的时候用更低的阈值：飞行上升本来就慢，
        # 用地面起跳的 0.35 去卡，双击降落会经常收不到
        if self.mFly:
            rise = float(getattr(cfg, "FLY_FLY_RISE", 0.10))
        else:
            rise = float(cfg.FLY_JUMP_RISE)
        if self.mAir or vy < rise:
            return
        self.mAir = True
        if self.mLastJump > 0.0 and (now - self.mLastJump) <= self.mWin:
            self.mLastJump = 0.0
            self.mWin = 0.0
            if self.mCanFly:
                # 引擎管着双击：这里只兜底“起飞”，降落不碰
                if not self.mFly:
                    self._askFlyTo(True)
            else:
                self._askFly()
        else:
            self.mLastJump = now
            if self.mFly:
                # 飞行中的双击窗口短一点：只有“很快点两下”才算要降落
                self.mWin = float(getattr(cfg, "FLY_AIR_WINDOW", 0.4))
            else:
                self.mWin = float(cfg.FLY_DOUBLE_WINDOW)

    def _askSync(self):
        try:
            self.NotifyToServer(modConfig.ReqSync,
                                {"playerId": clientApi.GetLocalPlayerId()})
        except Exception:
            pass

    # ==================== 电脑端键盘 ====================
    def _isPC(self):
        try:
            return int(clientApi.GetPlatform()) == 0
        except Exception:
            return False

    def _withKey(self, text, ch):
        if not self._isPC() or not ch:
            return text
        return u"%s  [%s]" % (text, ch)

    def _registerKeys(self):
        # 把这些键登记进游戏的按键设置，玩家可以在 "设置 -> 键盘" 里自己改
        if self.mKeysDone or not getattr(cfg, "PC_KEY_ENABLED", True):
            return
        try:
            view = clientApi.GetEngineCompFactory().CreatePlayerView(
                clientApi.GetLevelId())
        except Exception:
            return
        if view is None:
            return
        cat = str(getattr(cfg, "KEY_CATEGORY", "gameplay"))
        name, code, _ch = cfg.KEY_TOGGLE
        try:
            view.RegisterCustomKeyMapping(str(name), int(code), cat)
        except Exception:
            pass
        for one in cfg.SKILL_KEYS_PC:
            try:
                view.RegisterCustomKeyMapping(str(one[0]), int(one[1]), cat)
            except Exception:
                pass
        self.mKeysDone = True

    def _fillSkillNames(self):
        node = self.mHud
        if node is None:
            return
        pc = self._isPC()
        for i, one in enumerate(cfg.SKILLS):
            label = one[1]
            ch = u""
            if pc and i < len(cfg.SKILL_KEYS_PC):
                ch = cfg.SKILL_KEYS_PC[i][2]
                label = label.replace(u"HIM ", u"")
            try:
                node.SetSkillName(i, self._withKey(label, ch))
            except Exception:
                pass

    def _keyMap(self):
        # 内部按键名 -> 要干的事
        m = {}
        try:
            m[str(cfg.KEY_TOGGLE[0])] = "toggle"
        except Exception:
            pass
        for i, one in enumerate(cfg.SKILL_KEYS_PC):
            try:
                m[str(one[0])] = "skill:" + str(cfg.SKILLS[i][0])
            except Exception:
                pass
        return m

    def _codeMap(self):
        # 键码 -> 要干的事（自定义按键没登记上时的兜底）
        m = {}
        try:
            m[str(int(cfg.KEY_TOGGLE[1]))] = "toggle"
        except Exception:
            pass
        for i, one in enumerate(cfg.SKILL_KEYS_PC):
            try:
                m[str(int(one[1]))] = "skill:" + str(cfg.SKILLS[i][0])
            except Exception:
                pass
        return m

    def OnCustomKey(self, args=None):
        if not args or not getattr(cfg, "PC_KEY_ENABLED", True):
            return
        if str(args.get("isDown", "1")) == "0":
            return
        action = self._keyMap().get(str(args.get("name", "")))
        if action:
            self._act(action)

    def OnKeyPress(self, args=None):
        if not args or not getattr(cfg, "PC_KEY_ENABLED", True):
            return
        if str(args.get("isDown", "1")) == "0":
            return
        action = self._codeMap().get(str(args.get("key", "")))
        if action:
            self._act(action)

    def _act(self, action):
        # 同一个动作 0.3 秒内只算一次（两种按键事件可能同时报上来）
        now = _now()
        if now - self.mActAt.get(action, 0.0) < 0.3:
            return
        self.mActAt[action] = now
        if action == "toggle":
            self._onMain()
            return
        if action.startswith("skill:"):
            key = action.split(":", 1)[1]
            for i, one in enumerate(cfg.SKILLS):
                if one[0] == key:
                    self._onSkill(i)
                    return

    # ==================== 服务端消息 ====================
    def OnSync(self, args=None):
        ids = (args or {}).get("him") or []
        local = self._me()
        for pid in ids:
            if pid == local:
                continue
            self.mHimSet.add(pid)
            self._applyModel(pid)

    def OnState(self, args=None):
        if not args:
            return
        st = str(args.get("state", "none"))
        prev = self.mState
        self.mState = st
        now = _now()
        flyNew = bool(int(args.get("fly", 0) or 0))
        if st != "him":
            flyNew = False
        self.mCanFly = bool(int(args.get("canFly", 0) or 0))
        invNew = bool(int(args.get("inv", 0) or 0))
        if st not in ("him", "transform", "exit"):
            invNew = False
        self.mInv = invNew
        cds = args.get("cd") or {}
        for k, left in cds.items():
            try:
                want = now + float(left)
            except Exception:
                continue
            cur = self.mCds.get(k, 0.0)
            if want > cur:
                self.mCds[k] = want
        if args.get("force") or prev != st:
            for key, _n, cd in cfg.SKILLS:
                self.mCdTotal[key] = float(cd)
            if st != "him":
                self.mCds = {}
        if st == "him":
            self.mHimSet.add(self._me())
            self._applyModel(self._me())
        if prev != st or flyNew != self.mFly:
            if flyNew and not self.mFly:
                # 刚起飞：起飞助推会把竖直速度顶一下，
                # 先不看它，免得被当成“按了一下跳跃”
                self.mFlyGrace = now + float(
                    getattr(cfg, "FLY_TAKEOFF_GRACE", 0.7))
                self.mAir = False
                self.mLastJump = 0.0
                self.mWin = 0.0
            else:
                self.mFlyGrace = 0.0
            self.mFly = flyNew
            self._refreshMain()

    def OnTip(self, args=None):
        if not args:
            return
        self._tip(u"%s" % (args.get("text", u""),))

    def _tip(self, text, seconds=2.2):
        if self.mHud is None:
            return
        try:
            self.mHud.SetTip(text, seconds)
        except Exception:
            pass

    def OnStage(self, args=None):
        if not args:
            return
        pid = args.get("playerId")
        phase = str(args.get("phase", ""))
        if not pid:
            return
        local = self._me()
        me = (pid == local)
        if phase in (cfg.PHASE_DONE, cfg.PHASE_HIM):
            self.mHimSet.add(pid)
        elif phase == cfg.PHASE_OFF:
            self.mHimSet.discard(pid)
        # 换模型 / 恢复原样
        if phase == cfg.PHASE_APPEAR:
            if not me:
                self._applyModel(pid)
        elif phase in (cfg.PHASE_X_BURST, cfg.PHASE_OFF):
            self._clearModel(pid)
        elif phase == cfg.PHASE_HIM:
            self._applyModel(pid)
        if me:
            self.mPhase = phase
            self.mPhaseAt = _now()
            self.mPhaseDone = {}
            # 闪电落下那一刻就把【起飞】按钮显示出来
            self._refreshMain()
            try:
                if self.mHud is not None:
                    self.mHud.SetDim(DIM_OF.get(phase, 0))
                    if phase == cfg.PHASE_DONE:
                        self.mHud.SetDim(0)
            except Exception:
                pass
        else:
            self._remoteFx(pid, phase)

    # ==================== 模型 ====================
    def _me(self):
        try:
            return clientApi.GetLocalPlayerId()
        except Exception:
            return None

    def _applyModel(self, eid):
        if not eid or self.mModeled.get(eid):
            return
        if self._setModel(eid, cfg.modelName()):
            self.mModeled[eid] = True

    def _clearModel(self, eid):
        if not eid:
            return
        if eid in self.mModeled or eid == self._me():
            self._setModel(eid, None)
            self.mModeled.pop(eid, None)

    def _setModel(self, eid, name):
        comp = None
        try:
            comp = clientApi.GetEngineCompFactory().CreateModel(eid)
        except Exception:
            comp = None
        if comp is None:
            try:
                comp = clientApi.CreateComponent(eid, "Minecraft", "model")
            except Exception:
                comp = None
        if comp is None:
            return False
        try:
            if name:
                comp.SetModel(name)
            else:
                comp.ResetModel()
            return True
        except Exception:
            return False

    # ==================== 粒子 / 声音小工具 ====================
    def _particle(self, name, pos, direction=(0.0, 0.0, 0.0)):
        try:
            clientApi.GetEngineCompFactory().CreateParticleSystem(None).Create(
                name, (float(pos[0]), float(pos[1]), float(pos[2])),
                (float(direction[0]), float(direction[1]), float(direction[2])))
            return True
        except Exception:
            return False

    def _sound(self, name, pos, volume=1.0, pitch=1.0):
        try:
            comp = clientApi.GetEngineCompFactory().CreateCustomAudio(self._me())
        except Exception:
            return
        try:
            comp.PlayCustomMusic(str(name), (float(pos[0]), float(pos[1]), float(pos[2])),
                                 float(volume), float(pitch))
        except Exception:
            pass

    def _myPos(self):
        p = self._pos(self._me())
        return p if p else (0.0, 0.0, 0.0)

    def _pos(self, eid):
        try:
            p = tuple(clientApi.GetEngineCompFactory().CreatePos(eid).GetFootPos()
                      or (0.0, 0.0, 0.0))
        except Exception:
            return None
        return (float(p[0]), float(p[1]), float(p[2]))

    def _myDim(self):
        try:
            return int(clientApi.GetEngineCompFactory().CreateDimension(
                self._me()).GetEntityDimensionId())
        except Exception:
            return 0

    def _speed(self, eid):
        try:
            m = tuple(clientApi.GetEngineCompFactory().CreateActorMotion(eid).GetMotion()
                      or (0.0, 0.0, 0.0))
        except Exception:
            return 0.0
        return math.sqrt(float(m[0]) ** 2 + float(m[2]) ** 2)

    def _gate(self, key, interval, now):
        if now - self.mSpawnAt.get(key, 0.0) < interval:
            return False
        self.mSpawnAt[key] = now
        return True

    # ==================== 变身动画 ====================
    def _tickPhase(self, now):
        phase = self.mPhase
        if not phase or phase in (cfg.PHASE_OFF, cfg.PHASE_HIM):
            return
        t = now - self.mPhaseAt
        p = self._myPos()
        if phase == cfg.PHASE_DARK:
            if self._once(phase, "snd", now, 0.0):
                self._sound(S_TRANSFORM, p, 1.0, 1.0)
            if self._once(phase, "rune", now, 0.0):
                self._particle(P_RUNE, p)
                self._particle(P_SEAL, p)
            if self._gate("dark_smoke", 0.13, now):
                self._particle(P_SMOKE, p)
            self._dim(1)
        elif phase == cfg.PHASE_GATHER:
            if self._gate("gather", 0.09, now):
                self._particle(P_GATHER, p)
            if self._once(phase, "rune", now, 0.0):
                self._particle(P_RUNE, p)
            if self._once(phase, "seal", now, 0.55):
                self._particle(P_SEAL, p)
            if self._once(phase, "bolt1", now, 0.35) or self._once(phase, "bolt2", now, 1.05):
                self._particle(P_BOLT, p)
            self._dim(2)
        elif phase == cfg.PHASE_APPEAR:
            if self._once(phase, "burst", now, 0.0):
                self._particle(P_BURST, p)
                self._particle(P_SMOKE, p)
                self._dim(3)
            if self._once(phase, "come", now, 0.30):
                self._sound(S_APPEAR, p, 1.0, 1.0)
                self._applyModel(self._me())
                self._particle(P_SPARK, p)
                self._particle(P_RING, p)
                self._dim(2)
            if self._gate("appear_after", 0.16, now):
                self._particle(P_AFTER, p)
        elif phase == cfg.PHASE_DONE:
            if self._once(phase, "snd", now, 0.0):
                self._sound(S_DONE, p, 1.0, 1.0)
            if self._once(phase, "ring", now, 0.1):
                self._particle(P_RING, p)
            if self._gate("done_after", 0.22, now):
                self._particle(P_AFTER, p)
            self._dim(0)
        elif phase == cfg.PHASE_X_SMOKE:
            if self._gate("x_smoke", 0.11, now):
                self._particle(P_SMOKE, p)
            self._dim(1)
        elif phase == cfg.PHASE_X_SCATTER:
            if self._gate("x_scatter", 0.13, now):
                self._particle(P_AFTER, p)
            self._dim(1)
        elif phase == cfg.PHASE_X_WRAP:
            if self._gate("x_wrap", 0.09, now):
                self._particle(P_SMOKE, p)
            if self._once(phase, "wrap", now, 0.0):
                self._particle(P_GATHER, p)
            self._dim(2)
        elif phase == cfg.PHASE_X_BURST:
            if self._once(phase, "burst", now, 0.0):
                self._particle(P_BURST, p)
                self._particle(P_BOLT, p)
                self._sound(S_EXIT, p, 1.0, 1.0)
                self._clearModel(self._me())
                self._dim(3)
            if self._once(phase, "fade", now, 0.32):
                self._dim(0)

    def _once(self, phase, tag, now, at):
        key = (phase, tag)
        if self.mPhaseDone.get(key):
            return False
        if (now - self.mPhaseAt) >= at:
            self.mPhaseDone[key] = True
            return True
        return False

    def _judgeTint(self, on):
        if self.mHud is None:
            return
        try:
            self.mHud.SetJudgeTint(on)
        except Exception:
            pass

    def _dim(self, level):
        if self.mHud is None:
            return
        try:
            self.mHud.SetDim(level)
        except Exception:
            pass

    def _remoteFx(self, pid, phase):
        # 别人变身：这边只放最关键的一两下，省性能
        p = self._pos(pid)
        if p is None:
            return
        if phase == cfg.PHASE_APPEAR:
            self._particle(P_BURST, p)
            self._particle(P_SMOKE, p)
        elif phase == cfg.PHASE_X_BURST:
            self._particle(P_BURST, p)
            self._particle(P_SMOKE, p)
        elif phase == cfg.PHASE_DARK:
            self._particle(P_RUNE, p)

    # ==================== HIM 常驻粒子 ====================
    def _tickAmbient(self, now):
        if self.mState != "him":
            return
        me = self._me()
        if not me:
            return
        if cfg.AMBIENT_ON and self._gate("ambient", cfg.AMBIENT_TICKS / 20.0, now):
            if self._speed(me) < cfg.TRAIL_SPEED:
                self._particle(P_AFTER, self._myPos())
        if cfg.TRAIL_ON and self._gate("trail", cfg.TRAIL_TICKS / 20.0, now):
            if self._speed(me) >= cfg.TRAIL_SPEED:
                self._particle(P_AFTER, self._myPos())

    # ==================== 技能特效 ====================
    def OnFx(self, args=None):
        if not args:
            return
        try:
            if int(args.get("dim", -1)) != self._myDim():
                return
        except Exception:
            pass
        kind = str(args.get("kind", ""))
        now = _now()
        if kind == "fire":
            p1 = (float(args.get("x1", 0)), float(args.get("y1", 0)), float(args.get("z1", 0)))
            p2 = (float(args.get("x2", 0)), float(args.get("y2", 0)), float(args.get("z2", 0)))
            self.mPending.append({"kind": "fire", "p1": p1, "p2": p2,
                                  "t0": now, "dur": 0.22, "n": 0})
            self._sound(S_FIRE, p1, 1.0, 1.0)
        elif kind == "fire_hit":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            self._particle(P_BURST, p)
            self._particle(P_FIRE, p)
            self._particle(P_SPARK, p)
        elif kind == "fire_blast":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            # the vanilla TNT blast particle (white flash + smoke ring),
            # plus a purple HIM ring on top
            self._particle(P_BOOM, p)
            self._particle(P_RING, p)
            self._particle(P_SMOKE, p)
            self._sound(S_BLAST, p, 0.5, 1.0)
        elif kind == "bolt":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            self.mPending.append({"kind": "bolt", "p1": p, "t0": now, "dur": 0.45, "n": 0, "ring": 1})
            self._sound(S_BOLT, p, 1.0, 1.0)
        elif kind == "strike":
            p = (float(args.get("x", 0)), float(args.get("y", 0)),
                 float(args.get("z", 0)))
            # vanilla lightning draws itself and plays its own thunder: no rings.
            # 但万一原版闪电没生成出来，这里再画一条从天上劈下来的光柱，
            # 保证“一道闪电劈下来”一定看得见（不加光环）
            if getattr(cfg, "BOLT_COLUMN", True):
                self.mPending.append({"kind": "bolt", "p1": p, "t0": now,
                                      "dur": 0.45, "n": 0, "ring": 0})
            if getattr(cfg, "BOLT_ZAP", True):
                self._sound(S_BOLT, p, 1.0, 1.0)
            self._particle(P_SPARK, p)
        elif kind == "fire_muzzle":
            p = (float(args.get("x", 0)), float(args.get("y", 0)),
                 float(args.get("z", 0)))
            self._particle(P_FIRE, p)
            self._particle(P_SPARK, p)
        elif kind == "fire_trail":
            p = (float(args.get("x", 0)), float(args.get("y", 0)),
                 float(args.get("z", 0)))
            self._particle(P_TRAIL, p)
        elif kind == "field_on":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            # 向四周慢慢推进扩散到 30 格的法阵波
            self._particle(P_WAVE, p)
            self._particle(P_RUNE, p)
            self._particle(P_RING, p)
            self._particle(P_FIELD, p)
        elif kind == "field_tick":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            self._particle(P_FIELD, p)
            self._particle(P_RUNE, p)
            # 法阵扩散的边沿：在半径 r 的圆周上撒一圈粒子（跟着扩散走）
            r = float(args.get("r", 0) or 0)
            wx = float(args.get("wx") or p[0])
            wy = float(args.get("wy") or p[1])
            wz = float(args.get("wz") or p[2])
            if r > 1.0:
                for i in range(4):
                    a = 6.283185307179586 * (i + 0.5) / 4.0
                    self._particle(P_SPARK, (wx + math.cos(a) * r,
                                             wy + 0.2,
                                             wz + math.sin(a) * r))
            else:
                self._particle(P_SPARK, p)
        elif kind == "field_seal":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            self._particle(P_SEAL, p)
            self._particle(P_RING, p)
        elif kind == "field_blast":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            self._particle(P_BOOM, p)
            self._particle(P_RING, p)
            self._particle(P_SEAL, p)
            self._particle(P_BURST, p)
            self._particle(P_SMOKE, p)
            self._sound(S_BLAST, p, 1.6, 0.8)
        elif kind == "judge_charge":
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            sec = float(args.get("t", cfg.JUDGE_CHARGE))
            self.mPending.append({"kind": "charge", "p1": p, "t0": now,
                                  "dur": sec, "n": 0})
            self._sound(S_JUDGE, p, 1.2, 1.0)
        elif kind == "judge_fire":
            if getattr(cfg, "JUDGE_TINT", True):
                # 整个天空变暗紫（手机端也有）：和雾气同一个时长
                self.mJudgeTintUntil = now + float(
                    getattr(cfg, "JUDGE_FOG_TIME", 7.0))
                self._judgeTint(True)
            p = (float(args.get("x", 0)), float(args.get("y", 0)), float(args.get("z", 0)))
            # 白色冲击波：从脚下向四周扩散到 50 格
            self._particle(P_WAVE_W, p)
            self._particle(P_JUDGE, p)
            self._particle(P_RING, p)
            self._particle(P_BURST, p)
            self._particle(P_BOLT, p)

    def _tickPending(self, now):
        # 审判的整屏暗紫：到点自己收掉
        if self.mJudgeTintUntil > 0.0 and now >= self.mJudgeTintUntil:
            self.mJudgeTintUntil = 0.0
            self._judgeTint(False)
        if not self.mPending:
            return
        keep = []
        for job in self.mPending:
            job["n"] += 1
            t = (now - job["t0"]) / max(0.05, job["dur"])
            if job["kind"] == "fire":
                if t >= 1.0:
                    continue
                k = min(1.0, t)
                p = (job["p1"][0] + (job["p2"][0] - job["p1"][0]) * k,
                     job["p1"][1] + (job["p2"][1] - job["p1"][1]) * k,
                     job["p1"][2] + (job["p2"][2] - job["p1"][2]) * k)
                self._particle(P_FIRE, p)
                if job["n"] % 2 == 0:
                    self._particle(P_SPARK, p)
            elif job["kind"] == "bolt":
                if t >= 1.0:
                    continue
                top = (job["p1"][0], job["p1"][1] + 18.0, job["p1"][2])
                step = 3.0
                y = top[1]
                while y > job["p1"][1] - 0.5:
                    self._particle(P_BOLT, (job["p1"][0], y, job["p1"][2]))
                    y -= step
                if job["n"] == 1 and job.get("ring", 1):
                    self._particle(P_RING, job["p1"])
                    self._particle(P_JUDGE, job["p1"])
            elif job["kind"] == "charge":
                if t >= 1.0:
                    continue
                if job["n"] % 3 == 0:
                    self._particle(P_GATHER, job["p1"])
                    self._particle(P_AFTER, job["p1"])
            keep.append(job)
        self.mPending = keep[-24:]