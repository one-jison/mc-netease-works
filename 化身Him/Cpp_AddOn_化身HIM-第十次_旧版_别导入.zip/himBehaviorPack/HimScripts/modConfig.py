# -*- coding: utf-8 -*-
# ============================================================
#  HIM 模块 - 公共配置（模组名 / 事件名 / 界面名）
#  这里只放"名字"，具体数值都在 himConfig.py
# ============================================================

ModName = "HimMod"
ModVersion = "1.0.0"

ServerSystemName = "HimServerSystem"
ClientSystemName = "HimClientSystem"
ServerSystemClsPath = "HimScripts.himServerSystem.HimServerSystem"
ClientSystemClsPath = "HimScripts.himClientSystem.HimClientSystem"

# ---------------- 界面 ----------------
UiInitFinishedEvent = "UiInitFinished"
HudUIName = "himhud"
HudUIPyClsPath = "HimScripts.himHudScreen.HimHudScreen"
HudUIScreenDef = "himhud.main"

# ---------------- 客户端 -> 服务端 ----------------
ReqToggle = "HimToggle"        # 点了【化身 HIM】/【退出 HIM】
ReqSkill = "HimSkill"          # 点了某个技能按钮
ReqSync = "HimSync"            # 进世界/重生后，问一下谁现在是 HIM
ReqFly = "HimFly"             # 开启 / 关闭飞行（双击跳跃、双击空格、或点【起飞】按钮）

# ---------------- 服务端 -> 客户端 ----------------
EvStage = "HimStage"           # 变身 / 退身的某个阶段
EvState = "HimState"           # 自己的状态 + 技能冷却
EvFx = "HimFx"                 # 技能特效（所有人可见）
EvTip = "HimTip"               # 屏幕正中的大字
EvSync = "HimSyncBack"         # 回答"谁现在是 HIM"
EvHint = "HimHint"             # 主按钮上的文字