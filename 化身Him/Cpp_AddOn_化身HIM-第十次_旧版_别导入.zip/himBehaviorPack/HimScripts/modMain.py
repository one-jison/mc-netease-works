# -*- coding: utf-8 -*-
# ============================================================
#  化身 HIM - 模组入口
# ============================================================
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi

from HimScripts import modConfig

MOD_NAME = modConfig.ModName
MOD_VERSION = modConfig.ModVersion


@Mod.Binding(name=MOD_NAME, version=MOD_VERSION)
class HimMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def InitServer(self):
        serverApi.RegisterSystem(MOD_NAME, modConfig.ServerSystemName,
                                 modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def DestroyServer(self):
        pass

    @Mod.InitClient()
    def InitClient(self):
        clientApi.RegisterSystem(MOD_NAME, modConfig.ClientSystemName,
                                 modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def DestroyClient(self):
        pass