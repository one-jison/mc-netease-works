# -*- coding: utf-8 -*-
# ============================================================
#  化身 HIM - 屏幕界面（HUD）
#    · 屏幕左侧：一个【化身 HIM】/【退出 HIM】大按钮，下面是【起飞】小按钮
#    · 屏幕右边缘：4 个技能按钮，每个都有图标 + 名字 + 冷却倒计时
#    · 屏幕中央：变身完成时闪一句大字，然后自己淡出
#    · 全屏变暗层：变身过程中画面一层层变暗
# ============================================================
import time
import mod.client.extraClientApi as clientApi
from HimScripts import himConfig as cfg

ScreenNode = clientApi.GetScreenNodeCls()

SKILL_KEYS = [k for k, _n, _c in cfg.SKILLS]


class HimHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mMainPanel = "/mainPanel"
        self.mMainText = "/mainPanel/mainText"
        self.mMainBtn = "/mainPanel/mainBtn"
        self.mSkillPanel = "/skillPanel"
        self.mFlyPanel = "/flyPanel"
        self.mFlyBtn = "/flyPanel/flyBtn"
        self.mFlyText = "/flyPanel/flyText"
        self.mTipPanel = "/tipPanel"
        self.mTipText = "/tipPanel/tipText"
        self.mHintPanel = "/hintPanel"
        self.mHintText = "/hintPanel/hintText"
        self.mDim = ["/dim1", "/dim2", "/dim3"]
        self.mJudgeTint = "/judgeTint"
        self.mCd = ["/skillPanel/row%d/cd" % i for i in range(len(SKILL_KEYS))]
        self.mName = ["/skillPanel/row%d/name" % i
                     for i in range(len(SKILL_KEYS))]
        self.mCdText = ["/skillPanel/row%d/cdtext" % i for i in range(len(SKILL_KEYS))]
        self.mTipUntil = 0.0
        self.mTipOn = False
        self.mMainShown = None
        self.mSkillsShown = None
        self.mDimLevel = -1
        self.mCdState = {}
        self.mFlyShown = None
        self.mOnMain = None
        self.mOnSkill = None
        self.mOnFly = None

    # ==================== 生命周期 ====================
    def Create(self):
        self.mTipUntil = 0.0
        self.mTipOn = False
        self.mMainShown = None
        self.mSkillsShown = None
        self.mFlyShown = None
        self.mDimLevel = -1
        self.mCdState = {}
        self._wireButtons()
        self.SetMainVisible(False)
        self.SetSkillsVisible(False)
        self.SetJudgeTint(False)
        self.SetFlyVisible(False)
        self.SetDim(0)
        self.SetTip(u"")
        self.SetHint(u"")

    def Update(self):
        # 中央那行大字：到点自己收掉
        if self.mTipOn and self.mTipUntil > 0.0 and time.time() >= self.mTipUntil:
            self.SetTip(u"")

    # ==================== 按钮接线 ====================
    def SetOnMain(self, callback):
        self.mOnMain = callback

    def SetOnSkill(self, callback):
        self.mOnSkill = callback

    def SetOnFly(self, callback):
        self.mOnFly = callback

    def _wireButtons(self):
        self._wire(self.mMainBtn, self._onMainTouch)
        self._wire(self.mFlyBtn, self._onFlyTouch)
        for i in range(len(SKILL_KEYS)):
            self._wire("/skillPanel/row%d/btn" % i, getattr(self, "_onSkillTouch%d" % i))

    def _wire(self, path, cb):
        try:
            btn = self.GetBaseUIControl(path).asButton()
            btn.AddTouchEventParams({"isSwallow": True})
            btn.SetButtonTouchUpCallback(cb)
        except Exception:
            pass

    def _onMainTouch(self, args=None):
        if self.mOnMain is None:
            return
        try:
            self.mOnMain()
        except Exception:
            pass

    def _onFlyTouch(self, args=None):
        if self.mOnFly is None:
            return
        try:
            self.mOnFly()
        except Exception:
            pass

    def _fire(self, index):
        if self.mOnSkill is None:
            return
        try:
            self.mOnSkill(int(index))
        except Exception:
            pass

    # 七个技能各配一个自己的回调（写成绑定方法最稳，不会被垃圾回收掉）
    def _onSkillTouch0(self, args=None):
        self._fire(0)

    def _onSkillTouch1(self, args=None):
        self._fire(1)

    def _onSkillTouch2(self, args=None):
        self._fire(2)

    def _onSkillTouch3(self, args=None):
        self._fire(3)

    def _onSkillTouch4(self, args=None):
        self._fire(4)

    def _onSkillTouch5(self, args=None):
        self._fire(5)

    def _onSkillTouch6(self, args=None):
        self._fire(6)

    # ==================== 主按钮 ====================
    def SetMainVisible(self, show):
        v = bool(show)
        if self.mMainShown == v:
            return
        self.mMainShown = v
        self._setVisible(self.mMainPanel, v)
        try:
            ctrl = self.GetBaseUIControl(self.mMainBtn).asButton()
            ctrl.SetButtonEnable(v)
        except Exception:
            pass

    def SetMainText(self, text):
        self._setLabel(self.mMainText, text)

    # ==================== 起飞按钮 ====================
    def SetFlyVisible(self, show):
        v = bool(show)
        if self.mFlyShown == v:
            return
        self.mFlyShown = v
        self._setVisible(self.mFlyPanel, v)
        try:
            ctrl = self.GetBaseUIControl(self.mFlyBtn).asButton()
            ctrl.SetButtonEnable(v)
        except Exception:
            pass

    def SetFlyText(self, text):
        self._setLabel(self.mFlyText, text)

    # ==================== 技能面板 ====================
    def SetSkillsVisible(self, show):
        v = bool(show)
        if self.mSkillsShown == v:
            return
        self.mSkillsShown = v
        self._setVisible(self.mSkillPanel, v)
        for i in range(len(SKILL_KEYS)):
            try:
                ctrl = self.GetBaseUIControl(
                    "/skillPanel/row%d/btn" % i).asButton()
                ctrl.SetButtonEnable(v)
            except Exception:
                pass
        if not v:
            for i in range(len(SKILL_KEYS)):
                self.SetCooldown(i, 0.0, 1.0)

    def SetSkillName(self, index, text):
        # 电脑端会在技能名字后面补一个按键提示，比如"能量球 [Z]"
        try:
            path = self.mName[int(index)]
        except Exception:
            return
        self._setLabel(path, u"" if text is None else (u"%s" % text))

    def SetCooldown(self, index, left, total):
        try:
            index = int(index)
            cdPath = self.mCd[index]
            cdTextPath = self.mCdText[index]
        except Exception:
            return
        left = float(left)
        total = float(total)
        key = (round(left, 1), round(total, 1))
        if self.mCdState.get(index) == key:
            return
        self.mCdState[index] = key
        on = left > 0.05
        self._setVisible(cdPath, on)
        self._setVisible(cdTextPath, on)
        if on:
            if left >= 10.0:
                txt = u"%d" % int(round(left))
            else:
                txt = u"%.1f" % left
            self._setLabel(cdTextPath, txt)

    # ==================== 变暗层 ====================
    def SetDim(self, level):
        # 变身 / 退出变身时那块紫色透明方块已经取消了（看着太难看）。
        # 想恢复：把 himConfig.py 里的 TRANSFORM_DIM 改成 True。
        if not bool(getattr(cfg, "TRANSFORM_DIM", False)):
            if self.mDimLevel != 0:
                self.mDimLevel = 0
                for path in self.mDim:
                    self._setVisible(path, False)
            return
        try:
            lv = int(level)
        except Exception:
            lv = 0
        if lv < 0:
            lv = 0
        if lv > 3:
            lv = 3
        if self.mDimLevel == lv:
            return
        self.mDimLevel = lv
        for i, path in enumerate(self.mDim):
            self._setVisible(path, (i + 1) == lv)

    def SetJudgeTint(self, on):
        # 审判的“天空变成暗紫色”。原版雾气在手机上只盖住地平线那一条，
        # 天空本体不变，所以再叠一层整屏暗紫，手机和电脑效果一致。
        self._setVisible(self.mJudgeTint, bool(on))

    # ==================== 中央大字 ====================
    def SetTip(self, text, seconds=2.2):
        text = u"" if text is None else (u"%s" % text)
        if text:
            self.mTipOn = True
            self.mTipUntil = time.time() + max(0.4, float(seconds))
            self._setLabel(self.mTipText, text)
            self._setVisible(self.mTipPanel, True)
        else:
            self.mTipOn = False
            self.mTipUntil = 0.0
            self._setVisible(self.mTipPanel, False)

    # ==================== 底部小提示 ====================
    def SetHint(self, text):
        text = u"" if text is None else (u"%s" % text)
        self._setLabel(self.mHintText, text)
        self._setVisible(self.mHintPanel, bool(text))

    # ==================== 底层小工具 ====================
    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass

    def _setLabel(self, path, text):
        try:
            lbl = self.GetBaseUIControl(path).asLabel()
            lbl.SetText(text)
            return
        except Exception:
            pass
        try:
            self.SetText(path, text)
        except Exception:
            pass