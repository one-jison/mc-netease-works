# -*- coding: utf-8 -*-
# ============================================================
#  化身 HIM - 服务端
#    · 变身 / 退身 的四个阶段在这里掐表推进，再喊客户端放特效
#    · 七个技能都在这里真正生效（伤害 / 击退 / 瞬移 / 召唤 / 领域 / 审判）
#    · 冷却时间以服务端为准，客户端只负责把倒计时画出来
#    · 死亡 / 退出世界 / 重进世界 都会把状态清干净，绝不留残留
# ============================================================
import math
import time

import mod.server.extraServerApi as serverApi

from HimScripts import modConfig
from HimScripts import himConfig as cfg

ServerSystem = serverApi.GetServerSystemCls()

UNBREAKABLE = (
    "minecraft:bedrock", "minecraft:barrier", "minecraft:command_block",
    "minecraft:repeating_command_block", "minecraft:chain_command_block",
    "minecraft:structure_block", "minecraft:structure_void", "minecraft:jigsaw",
    "minecraft:end_portal", "minecraft:end_portal_frame", "minecraft:portal",
    "minecraft:light_block", "minecraft:nether_reactor_core",
)

SKIP_TYPES = (
    "minecraft:item", "minecraft:xp_orb", "minecraft:arrow",
    "minecraft:snowball", "minecraft:egg", "minecraft:ender_pearl",
    "minecraft:fishing_hook", "minecraft:thrown_trident",
)


def _f():
    return serverApi.GetEngineCompFactory()


def _now():
    return time.time()


class HimServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)
        self.mP = {}          # playerId -> 状态记录
        self.mReqSeq = 0
        self.mFires = []      # flying fireballs
        self.mGrantOff = False  # 引擎不支持“只给飞行能力”时不再用它
        self.mCmdOff = False    # /ability 指令也不可用时不再用它
        self.mAbilityApiOK = False  # IsPlayerCanFly 这个接口能不能用
        self.mGmCache = {}       # playerId -> (游戏模式, 时刻)
        self._listen()

    # ==================== 事件 ====================
    def _listen(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, sn, "OnScriptTickServer", self, self.OnServerTick)
        self.ListenForEvent(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        self.ListenForEvent(ns, sn, "DelServerPlayerEvent", self, self.OnPlayerLeave)
        self.ListenForEvent(ns, sn, "PlayerDieEvent", self, self.OnPlayerDie)
        self.ListenForEvent(ns, sn, "PlayerRespawnFinishServerEvent", self, self.OnRespawn)
        self.ListenForEvent(ns, sn, "ServerChatEvent", self, self.OnChat)
        try:
            self.ListenForEvent(ns, sn, "ActuallyHurtServerEvent",
                                self, self.OnHurtGuard)
        except Exception:
            pass
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.ReqToggle, self, self.OnToggleReq)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.ReqSkill, self, self.OnSkillReq)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.ReqSync, self, self.OnSyncReq)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName,
                            modConfig.ReqFly, self, self.OnFlyReq)

    # ==================== 记录 ====================
    # ==================== invincibility / native helpers ====================
    def OnHurtGuard(self, args=None):
        # While the transform plays the player cannot lose HP at all.
        if not args or not getattr(cfg, "INVULN_ON_TRANSFORM", True):
            return
        eid = None
        for k in ("entityId", "hurtEntityId", "id", "playerId"):
            v = args.get(k)
            if v:
                eid = v
                break
        if eid is None:
            return
        rec = self.mP.get(eid)
        if rec is None or not rec.get("inv"):
            return
        try:
            args["damage"] = 0.0
        except Exception:
            pass

    def _health(self, pid):
        try:
            return float(_f().CreateAttr(pid).GetAttrValue(
                serverApi.GetMinecraftEnum().AttrType.HEALTH))
        except Exception:
            return None

    def _lockHp(self, pid, rec, now):
        if not getattr(cfg, "INVULN_ON_TRANSFORM", True):
            return
        if now - float(rec.get("invAt", 0.0)) < \
                float(getattr(cfg, "INVULN_REFRESH", 0.25)):
            return
        rec["invAt"] = now
        # vanilla resistance level 5 == 100% damage reduction
        try:
            ef = _f().CreateEffect(pid)
            ef.AddEffectToEntity(
                "resistance", 1, int(getattr(cfg, "INVULN_AMP", 4)), False)
            if getattr(cfg, "INVULN_NO_BURN", True):
                # 抗火：被闪电劈中也不会烧起来
                ef.AddEffectToEntity("fire_resistance", 2, 0, False)
        except Exception:
            pass
        if getattr(cfg, "INVULN_NO_BURN", True):
            self._extinguish(pid)
        hp = rec.get("hp")
        if hp is None:
            return
        try:
            attr = _f().CreateAttr(pid)
            en = serverApi.GetMinecraftEnum()
            cur = float(attr.GetAttrValue(en.AttrType.HEALTH))
            if cur < float(hp) - 0.01:
                attr.SetAttrValue(en.AttrType.HEALTH, float(hp))
        except Exception:
            pass

    def _extinguish(self, eid):
        # 直接把身上的火灭掉（原版 SetEntityOnFire(0)）
        try:
            _f().CreateAttr(eid).SetEntityOnFire(0.0, 1)
            return True
        except Exception:
            return False

    def _unlockHp(self, pid):
        try:
            ef = _f().CreateEffect(pid)
            ef.RemoveEffectFromEntity("resistance")
            ef.RemoveEffectFromEntity("fire_resistance")
        except Exception:
            pass

    def _spawn(self, typeStr, pos, dimId):
        # ServerSystem.CreateEngineEntityByTypeStr is the one that really works
        # for entities of our own add-on; the comp factory one is only a fallback.
        p = (float(pos[0]), float(pos[1]), float(pos[2]))
        for fn in (getattr(self, "CreateEngineEntityByTypeStr", None),
                   getattr(_f(), "CreateEngineEntityByTypeStr", None)):
            if fn is None:
                continue
            try:
                out = fn(str(typeStr), p, (0.0, 0.0), int(dimId))
            except Exception:
                continue
            if out:
                return out
        return None

    def _kill(self, eid):
        try:
            self.DestroyEntity(eid)
            return True
        except Exception:
            pass
        try:
            _f().CreateGame(serverApi.GetLevelId()).KillEntity(eid)
            return True
        except Exception:
            return False

    def _motion(self, eid, v):
        try:
            _f().CreateActorMotion(eid).SetMotion(
                (float(v[0]), float(v[1]), float(v[2])))
            return True
        except Exception:
            return False

    def _sound(self, pos, dimId, name, volume=1.0, pitch=1.0):
        # plain vanilla /playsound, once per player that is in the same dimension
        try:
            players = list(serverApi.GetPlayerList() or [])
        except Exception:
            return False
        x, y, z = float(pos[0]), float(pos[1]), float(pos[2])
        done = False
        for pid in players:
            try:
                if self._dim(pid) != int(dimId):
                    continue
                if self._cmd("/playsound %s @s %.2f %.2f %.2f %.2f %.2f" % (
                        str(name), x, y, z, float(volume), float(pitch)), pid):
                    done = True
            except Exception:
                continue
        return done

    def _cmd(self, cmd, pid=None):
        try:
            comp = _f().CreateCommand(serverApi.GetLevelId())
            if comp is None:
                return False
            if pid:
                comp.SetCommand(str(cmd), str(pid))
            else:
                comp.SetCommand(str(cmd))
            return True
        except Exception:
            return False

    def _strike(self, pos, dimId, pid=None):
        # native lightning bolt -> vanilla animation + vanilla thunder sound
        if self._spawn("minecraft:lightning_bolt", pos, dimId):
            return True
        # 引擎接口生不出来就跑原版 /summon；
        # 先用“关卡权限”跑（不带玩家），避免普通玩家没权限、
        # 命令被拒之后天上什么都没有。
        cmd = "/summon lightning_bolt %.2f %.2f %.2f" % (
            float(pos[0]), float(pos[1]), float(pos[2]))
        if self._cmd(cmd):
            return True
        return self._cmd(cmd, pid)

    def _fxDim(self, kind, extra, dimId):
        data = {"kind": kind, "dim": int(dimId)}
        if extra:
            data.update(extra)
        self._broadcast(modConfig.EvFx, data)

    # ---------------- thrown fireball ----------------
    def _shootFire(self, pid, eye, d, dimId):
        ent = str(getattr(cfg, "FIRE_ENTITY", "him:fireball"))
        pos = (eye[0] + d[0] * 1.05, eye[1] - 0.25 + d[1] * 1.05,
               eye[2] + d[2] * 1.05)
        eid = self._spawn(ent, pos, dimId)
        if not eid:
            return False
        sp = float(getattr(cfg, "FIRE_SPEED", 1.3))
        if not self._motion(eid, (d[0] * sp, d[1] * sp, d[2] * sp)):
            self._kill(eid)
            return False
        now = _now()
        self.mFires.append({"id": eid, "owner": pid, "dim": int(dimId),
                            "t": now, "d": (d[0], d[1], d[2]),
                            "last": pos, "trail": 0.0, "hit": None})
        self._sound(pos, dimId, str(getattr(cfg, "FIRE_SOUND",
                                            "mob.blaze.shoot")), 1.0, 0.85)
        return True

    def _clearFires(self, pid):
        keep = []
        for fb in self.mFires:
            if fb["owner"] == pid:
                self._kill(fb["id"])
            else:
                keep.append(fb)
        self.mFires = keep

    def _fireTick(self, now):
        if not self.mFires:
            return
        life = float(getattr(cfg, "FIRE_LIFE", 2.6))
        sp = float(getattr(cfg, "FIRE_SPEED", 1.3))
        keep = []
        for fb in self.mFires:
            eid = fb["id"]
            c = self._center(eid)
            if c is None:
                continue
            if self._fireHit(fb, c) or (now - fb["t"]) >= life:
                self._boomFire(fb, c)
                continue
            d = fb["d"]
            fb["last"] = c
            self._motion(eid, (d[0] * sp, d[1] * sp, d[2] * sp))
            if now - fb["trail"] >= 0.08:
                fb["trail"] = now
                self._fxDim("fire_trail", {"x": c[0], "y": c[1], "z": c[2]},
                            fb["dim"])
            keep.append(fb)
        self.mFires = keep

    def _fireHit(self, fb, c):
        dimId = fb["dim"]
        if self._solid(c, dimId):
            return True
        d = fb["d"]
        if self._solid((c[0] + d[0] * 0.6, c[1] + d[1] * 0.6,
                        c[2] + d[2] * 0.6), dimId):
            return True
        r = float(getattr(cfg, "FIRE_HIT_R", 1.4))
        me = str(getattr(cfg, "FIRE_ENTITY", "him:fireball"))
        for eid in self._near(c, dimId, int(r) + 2):
            if eid == fb["id"] or eid == fb["owner"]:
                continue
            t = self._typeOf(eid)
            if t in SKIP_TYPES or t == me:
                continue
            ec = self._center(eid)
            if ec is None:
                continue
            dd = math.sqrt((ec[0] - c[0]) ** 2 + (ec[1] - c[1]) ** 2 +
                           (ec[2] - c[2]) ** 2)
            if dd <= r + 0.9:
                fb["hit"] = eid
                return True
        return False

    def _boomFire(self, fb, pos):
        pid = fb["owner"]
        dimId = fb["dim"]
        self._kill(fb["id"])
        self._fxDim("fire_blast", {"x": pos[0], "y": pos[1], "z": pos[2]}, dimId)
        # same boom sound TNT makes
        self._sound(pos, dimId, str(getattr(cfg, "FIRE_BOOM_SOUND",
                                            "random.explode")), 1.3, 1.0)
        ent = fb.get("hit")
        if ent:
            c = self._center(ent) or pos
            self._fxDim("fire_hit", {"x": c[0], "y": c[1], "z": c[2]}, dimId)
            self._hurt(ent, cfg.FIRE_DAMAGE, pid)
            self._knockback(ent, (pos[0], pos[1] - 0.8, pos[2]), cfg.FIRE_KNOCK)
            self._ignite(ent, cfg.FIRE_BURN)
        # AoE damage + crater + fire all around where it landed
        self._blast(pid, pos, dimId)
        self._fireRing(pos, dimId, int(getattr(cfg, "FIRE_BURN_R", 3)))

    # ---------------- transform lightning ----------------
    def _transformStrike(self, pid):
        # called the moment the HIM reveal starts: a few bolts come down on the
        # player at the same time and the ground around catches fire
        if not getattr(cfg, "TRANSFORM_BOLT", True):
            return
        base = self._foot(pid)
        if base is None:
            return
        dimId = self._dim(pid)
        offs = [(0.0, 0.0), (1.7, 0.0), (-1.7, 0.0), (0.0, 1.7), (0.0, -1.7),
                (1.3, 1.3), (-1.3, -1.3), (1.3, -1.3), (-1.3, 1.3)]
        n = int(getattr(cfg, "TRANSFORM_BOLT_N", 5))
        # 原版那道闪电又粗又亮，很抢戏；默认不用它，
        # 只用我们自己的细光柱，雷声另外用原版雷声补上。
        native = bool(getattr(cfg, "TRANSFORM_BOLT_NATIVE", False))
        for ox, oz in offs[:max(1, n)]:
            pos = (base[0] + ox, base[1], base[2] + oz)
            if native:
                self._strike(pos, dimId, pid)
            self._fxAll(pid, "strike", {"x": pos[0], "y": pos[1], "z": pos[2]})
        if not native:
            self._sound(base, dimId,
                        str(getattr(cfg, "TRANSFORM_BOLT_THUNDER",
                                    "ambient.weather.thunder")), 1.0, 1.0)
        # 闪电会把玩家点着 —— 立刻灭火 + 上抗火，
        # 不然玩家会一直烧、反复掉血，画面抖个不停
        self._extinguish(pid)
        try:
            _f().CreateEffect(pid).AddEffectToEntity(
                "fire_resistance", 8, 0, False)
        except Exception:
            pass
        self._fireRing(base, dimId, int(getattr(cfg, "TRANSFORM_FIRE_R", 3)))

    def _fireRing(self, center, dimId, r):
        # set the ground on fire in a small circle around a point
        r = int(max(1, r))
        cx = int(math.floor(center[0]))
        cy = int(math.floor(center[1]))
        cz = int(math.floor(center[2]))
        for dx in range(-r, r + 1):
            for dz in range(-r, r + 1):
                if dx * dx + dz * dz > r * r:
                    continue
                for dy in (0, -1):
                    self._setFire((cx + dx + 0.5, cy + dy + 0.2, cz + dz + 0.5),
                                  dimId)

    def _rec(self, pid, create=False):
        rec = self.mP.get(pid)
        if rec is None and create:
            rec = {
                "state": "none",       # none / transform / him / exit
                "phase": cfg.PHASE_OFF,
                "plan": [],
                "idx": 0,
                "nextAt": 0.0,
                "seq": 0,
                "cd": {},
                "buffAt": 0.0,
                "stateAt": 0.0,
                "domainUntil": 0.0,
                "domainNext": 0.0,
                "fieldSealAt": 0.0,
                "fieldStart": 0.0,
                "fieldBase": None,
                "fieldLiftUntil": 0.0,
                "fieldBlastAt": 0.0,
                "fieldAir": {},
                "judgeAt": 0.0,
                "judgeBase": None,
                "judgeStart": 0.0,
                "judgeUntil": 0.0,
                "judgeSweepAt": 0.0,
                "judgeKillAt": 0.0,
                "judgeHit": {},
                "judgeBolts": [],
                "judgeNightAt": 0.0,
                "judgeNightStart": 0.0,
                "judgeTimeOld": None,
                "judgeFogOff": 0.0,
                "summons": [],
                "trailAt": 0.0,
                "ambAt": 0.0,
                "inv": False,
                "invAt": 0.0,
                "flySyncAt": 0.0,      # 上次把飞行状态回传给客户端的时刻
                "flyLast": False,       # 上次回传时的飞行状态
                "canLast": False,       # 上次回传时“能不能飞”
                "abilityAt": 0.0,       # 下次可以再尝试发“飞行能力”的时刻
                "hp": None,
            }
            self.mP[pid] = rec
        return rec

    def _drop(self, pid):
        rec = self.mP.pop(pid, None)
        self._clearFires(pid)
        self._unlockHp(pid)
        if rec is None:
            return
        if float(rec.get("judgeFogOff", 0.0)) > 0.0:
            # 玩家跑掉了，别把紫色天空留在别人头上
            self._fogPop()
        # 玩家跑掉了也别把黑夜留在别人头上
        self._judgeNightOff(rec)
        self._killSummons(rec)

    # ==================== 玩家进出 / 死亡 ====================
    def OnAddPlayer(self, args=None):
        pid = (args or {}).get("id") or (args or {}).get("playerId")
        if not pid:
            return
        self._drop(pid)
        self._rec(pid, True)
        # 刚进来时如果身上还挂着上次的模型，客户端一进来会自己 ResetModel
        self._sendState(pid, force=True)

    def OnPlayerLeave(self, args=None):
        pid = (args or {}).get("id") or (args or {}).get("playerId")
        if not pid:
            return
        if cfg.clearOnLeave():
            self._drop(pid)

    def OnPlayerDie(self, args=None):
        pid = (args or {}).get("id") or (args or {}).get("playerId")
        if not pid:
            return
        rec = self._rec(pid, True)
        if rec is None:
            return
        if not cfg.keepOnDeath():
            rec["state"] = "none"
            rec["plan"] = []
            rec["idx"] = 0
            rec["domainUntil"] = 0.0
            rec["fieldLiftUntil"] = 0.0
            rec["fieldBlastAt"] = 0.0
            rec["fieldStart"] = 0.0
            rec["fieldBase"] = None
            rec["fieldAir"] = {}
            rec["judgeAt"] = 0.0
            rec["judgeUntil"] = 0.0
            rec["judgeSweepAt"] = 0.0
            rec["judgeKillAt"] = 0.0
            rec["judgeHit"] = {}
            rec["judgeBolts"] = []
            self._judgeNightOff(rec)
            rec["cd"] = {}
            self._killSummons(rec)
            self._clearBuffs(pid)
            rec["inv"] = False
            self._unlockHp(pid)
            self._setFly(pid, False)
            self._broadcast(modConfig.EvStage,
                            {"playerId": pid, "phase": cfg.PHASE_OFF, "id": rec["seq"]})
            self._sendState(pid, force=True)

    def OnRespawn(self, args=None):
        pid = (args or {}).get("id") or (args or {}).get("playerId")
        if not pid:
            return
        rec = self._rec(pid, True)
        if rec is None:
            return
        if rec["state"] != "him":
            rec["inv"] = False
            self._unlockHp(pid)
            self._broadcast(modConfig.EvStage,
                            {"playerId": pid, "phase": cfg.PHASE_OFF, "id": rec["seq"]})
        self._sendState(pid, force=True)

    def OnChat(self, args=None):
        # 聊天框输入 #him 也能变身 / 退出，方便排查问题
        if not args:
            return
        pid = args.get("playerId")
        msg = u"%s" % (args.get("message", u""),)
        if not pid:
            return
        if msg.strip() == u"#him":
            self._toggle(pid)

    # ==================== 客户端请求 ====================
    def OnToggleReq(self, args=None):
        pid = (args or {}).get("playerId")
        if pid:
            self._toggle(pid)

    def OnSkillReq(self, args=None):
        pid = (args or {}).get("playerId")
        key = (args or {}).get("key")
        if pid and key:
            self._cast(pid, str(key))

    def OnFlyReq(self, args=None):
        args = args or {}
        pid = args.get("playerId")
        if not pid:
            return
        want = args.get("on", None)
        if want is None:
            # 老版本客户端发的是“切换一下”，兼容一下
            self._toggleFly(pid)
        else:
            self._setFlyTo(pid, bool(int(want)))

    def OnSyncReq(self, args=None):
        pid = (args or {}).get("playerId")
        if not pid:
            return
        # 告诉这个客户端：现在场上有谁是 HIM（他才能把别人的模型也换对）
        him = []
        for other, rec in self.mP.items():
            if rec.get("state") == "him":
                him.append(other)
        try:
            self.NotifyToClient(pid, modConfig.EvSync, {"him": him})
        except Exception:
            pass
        self._sendState(pid, force=True)

    # ==================== 变身 / 退身 ====================
    def _toggle(self, pid):
        if not cfg.on():
            return
        rec = self._rec(pid, True)
        if rec is None:
            return
        if rec["state"] == "transform" or rec["state"] == "exit":
            # 正在变身 / 退身：忽略，防止连点把状态弄乱
            self._tip(pid, u"正在" + (u"变身" if rec["state"] == "transform" else u"退出") + u"...")
            return
        if rec["state"] == "him":
            self._startExit(pid, rec)
        else:
            self._startTransform(pid, rec)

    def _startTransform(self, pid, rec):
        self.mReqSeq += 1
        rec["seq"] = self.mReqSeq
        rec["abilityTries"] = 0        # 每次变身重新尝试发一次飞行能力
        rec["state"] = "transform"
        rec["plan"] = cfg.transformPlan()
        rec["idx"] = 0
        rec["phase"] = rec["plan"][0][0]
        rec["nextAt"] = _now() + rec["plan"][0][1]
        rec["cd"] = {}
        rec["inv"] = True
        rec["invAt"] = 0.0
        rec["hp"] = self._health(pid)
        self._lockHp(pid, rec, _now())
        self._broadcast(modConfig.EvStage,
                        {"playerId": pid, "phase": rec["phase"], "id": rec["seq"]})
        self._sendState(pid, force=True)

    def _startExit(self, pid, rec):
        self.mReqSeq += 1
        rec["seq"] = self.mReqSeq
        rec["state"] = "exit"
        rec["plan"] = cfg.exitPlan()
        rec["idx"] = 0
        rec["phase"] = rec["plan"][0][0]
        rec["nextAt"] = _now() + rec["plan"][0][1]
        rec["domainUntil"] = 0.0
        rec["fieldLiftUntil"] = 0.0
        rec["fieldBlastAt"] = 0.0
        rec["fieldStart"] = 0.0
        rec["fieldBase"] = None
        rec["fieldAir"] = {}
        rec["judgeAt"] = 0.0
        rec["judgeUntil"] = 0.0
        rec["judgeSweepAt"] = 0.0
        rec["judgeKillAt"] = 0.0
        rec["judgeHit"] = {}
        rec["judgeBolts"] = []
        self._judgeNightOff(rec)
        self._killSummons(rec)
        self._clearBuffs(pid)
        rec["inv"] = True
        rec["invAt"] = 0.0
        rec["hp"] = self._health(pid)
        self._lockHp(pid, rec, _now())
        self._broadcast(modConfig.EvStage,
                        {"playerId": pid, "phase": rec["phase"], "id": rec["seq"]})
        self._sendState(pid, force=True)

    # ==================== 每 tick ====================
    def OnServerTick(self, args=None):
        now = _now()
        try:
            self._fireTick(now)
        except Exception:
            pass
        if not self.mP:
            return
        for pid in list(self.mP.keys()):
            rec = self.mP.get(pid)
            if rec is None:
                continue
            try:
                self._tickOne(pid, rec, now)
            except Exception:
                pass

    def _tickOne(self, pid, rec, now):
        # ---- 审判的深紫色天空：到点就恢复（不管玩家现在什么状态）----
        fogOff = float(rec.get("judgeFogOff", 0.0))
        if fogOff > 0.0 and now >= fogOff:
            rec["judgeFogOff"] = 0.0
            self._fogPop()
        # ---- 起飞助推：刚起飞的一小段时间里每帧往上抬一下，
        # 不然站在地上起飞会被地面卡住，看起来像“不起飞”
        lift = float(rec.get("flyLift", 0.0))
        if lift > 0.0:
            if now >= lift:
                rec["flyLift"] = 0.0
            else:
                try:
                    _f().CreateActorMotion(pid).SetMotion(
                        (0.0, float(getattr(cfg, "FLY_LIFT_SPEED", 0.8)), 0.0))
                except Exception:
                    pass
        # ---- 创造 / 旁观玩家本来就会飞：万一能力被收走了（老版本误收），
        # 这里每隔 2 秒查一次，发现没有就立刻补回来
        if now >= float(rec.get("abilityAt", 0.0)) and self._creativeLike(pid) and \
                int(rec.get("healTries", 0)) < 8:
            rec["abilityAt"] = now + 2.0
            if not self._canFlyAbility(pid):
                rec["healTries"] = int(rec.get("healTries", 0)) + 1
                self._grantFlyAbility(pid)

        st = rec["state"]

        # ---- 变身到“能飞”的那一刻，就把飞行能力（mayfly）发给玩家：
        # 这样双击跳跃交给游戏原生处理，一按就飞、再双击就落，
        # 不用等脚本认出“第二下真的跳起来了”
        if cfg.flyOn() and self._canFly(rec) and \
                not getattr(self, "mGrantOff", False) and \
                now >= float(rec.get("abilityAt", 0.0)):
            rec["abilityAt"] = now + 2.0        # 失败就 2 秒后再试
            if not self._canFlyAbility(pid) and \
                    int(rec.get("abilityTries", 0)) < 6:
                rec["abilityTries"] = int(rec.get("abilityTries", 0)) + 1
                if self._grantFlyAbility(pid):
                    rec["canLast"] = True
                    self._sendState(pid, force=True)

        if st == "transform" or st == "exit":
            self._lockHp(pid, rec, now)
            if now < rec["nextAt"]:
                return
            rec["idx"] += 1
            plan = rec["plan"]
            if rec["idx"] < len(plan):
                ph, dur = plan[rec["idx"]]
                rec["phase"] = ph
                rec["nextAt"] = now + dur
                self._broadcast(modConfig.EvStage,
                                {"playerId": pid, "phase": ph, "id": rec["seq"]})
                if st == "transform" and ph == cfg.PHASE_APPEAR:
                    self._transformStrike(pid)
                return
            # 这一段走完了
            if st == "transform":
                rec["state"] = "him"
                rec["phase"] = cfg.PHASE_HIM
                rec["buffAt"] = 0.0
                if getattr(cfg, "INVULN_HIM", True):
                    # 变身结束后继续无敌：按当前血量锁住，伤害进不来
                    rec["hp"] = self._health(pid)
                    rec["invAt"] = 0.0
                    self._lockHp(pid, rec, now)
                else:
                    rec["inv"] = False
                    self._unlockHp(pid)
                self._broadcast(modConfig.EvStage,
                                {"playerId": pid, "phase": cfg.PHASE_HIM, "id": rec["seq"]})
                self._sendState(pid, force=True)
            else:
                rec["state"] = "none"
                rec["phase"] = cfg.PHASE_OFF
                rec["inv"] = False
                self._unlockHp(pid)
                self._clearBuffs(pid)
                self._broadcast(modConfig.EvStage,
                                {"playerId": pid, "phase": cfg.PHASE_OFF, "id": rec["seq"]})
                self._sendState(pid, force=True)
            return

        if st != "him":
            # 变身动画走到“闪电落下”之后就可以起飞了，不用等动画播完
            if self._flyState(pid) and not self._canFly(rec) and \
                    not self._creativeLike(pid):
                self._setFly(pid, False)
            return

        # ---- HIM 状态：整个状态期间都免疫一切伤害 ----
        if rec.get("inv"):
            self._lockHp(pid, rec, now)

        # ---- 飞行状态回传：客户端要靠它判断“双击到底是要起飞还是要降落”，
        # 猜错方向就会“双击了却不飞 / 不落地”
        if now - float(rec.get("flySyncAt", 0.0)) >= \
                float(getattr(cfg, "FLY_SYNC_TICK", 0.5)):
            rec["flySyncAt"] = now
            flyNow = bool(self._flyState(pid)) if self._canFly(rec) else False
            canNow = self._canFlyAbility(pid)
            if flyNow != bool(rec.get("flyLast", False)) or \
                    canNow != bool(rec.get("canLast", False)):
                rec["flyLast"] = flyNow
                rec["canLast"] = canNow
                self._sendState(pid, force=True)

        # ---- HIM 状态下的常驻效果 ----
        if cfg.buffOn():
            if now - rec["buffAt"] >= cfg.BUFF_TICK:
                rec["buffAt"] = now
                self._applyBuffs(pid)
        # ---- 黑暗领域：法阵旋转 + 生物上天 + 冲击波秒杀 ----
        if rec["domainUntil"] > now:
            blastAt = float(rec.get("fieldBlastAt", 0.0))
            if blastAt > 0.0 and now >= blastAt:
                rec["fieldBlastAt"] = 0.0
                self._fieldBlast(pid, rec)
            if now >= rec["domainNext"]:
                rec["domainNext"] = now + cfg.FIELD_TICK
                self._domainPulse(pid, rec, now)
        elif rec["domainUntil"] > 0.0:
            rec["domainUntil"] = 0.0
            rec["fieldLiftUntil"] = 0.0
            rec["fieldBlastAt"] = 0.0
            rec["fieldAir"] = {}
            self._fxAll(pid, "field_off", None)
        # ---- 审判：蓄力 -> 白色冲击波扩散 -> 生物起火 -> 击杀 ----
        if rec["judgeAt"] > 0.0 and now >= rec["judgeAt"]:
            rec["judgeAt"] = 0.0
            self._judgeFire(pid, rec)
        if float(rec.get("judgeSweepAt", 0.0)) > 0.0 and \
                now < float(rec.get("judgeUntil", 0.0)) and \
                now >= float(rec.get("judgeSweepAt", 0.0)):
            rec["judgeSweepAt"] = now + \
                float(getattr(cfg, "JUDGE_SWEEP_TICK", 0.2))
            self._judgeSweep(pid, rec, now)
        killAt = float(rec.get("judgeKillAt", 0.0))
        if killAt > 0.0 and now >= killAt:
            rec["judgeKillAt"] = 0.0
            self._judgeKill(pid, rec)
        if rec.get("judgeBolts"):
            self._judgeBoltTick(pid, rec, self._dim(pid))
        # ---- 审判的黑夜：日落 -> 半夜 -> 日出，到点恢复原状 ----
        if float(rec.get("judgeNightAt", 0.0)) > 0.0:
            self._judgeNightTick(rec, now)
        # ---- 召唤物到点消失 ----
        self._expireSummons(rec, now)
        # ---- 状态同步（每秒一次，保证客户端倒计时跟服务端一致）----
        if now - rec["stateAt"] >= 1.0:
            rec["stateAt"] = now
            self._sendState(pid)

    # ==================== 状态同步 ====================
    def _sendState(self, pid, force=False):
        rec = self.mP.get(pid)
        if rec is None:
            return
        now = _now()
        cds = {}
        for k, v in rec["cd"].items():
            left = v - now
            if left > 0.15:
                cds[k] = round(left, 2)
        data = {
            "state": rec["state"],
            "phase": rec["phase"],
            "cd": cds,
            "fly": 1 if self._flyState(pid) else 0,
            "canFly": 1 if self._canFlyAbility(pid) else 0,
            "inv": 1 if rec.get("inv") else 0,
            "force": 1 if force else 0,
        }
        try:
            self.NotifyToClient(pid, modConfig.EvState, data)
        except Exception:
            pass

    def _tip(self, pid, text):
        try:
            self.NotifyToClient(pid, modConfig.EvTip, {"text": text})
        except Exception:
            pass

    def _broadcast(self, event, data):
        try:
            self.BroadcastToAllClient(event, data)
        except Exception:
            pass

    def _fxAll(self, pid, kind, extra):
        data = {"playerId": pid, "kind": kind, "dim": self._dim(pid)}
        if extra:
            data.update(extra)
        self._broadcast(modConfig.EvFx, data)
        return data

    # ==================== 常驻效果 ====================
    def _applyBuffs(self, pid):
        spd = int(cfg.SPEED_AMP)
        if self._flyState(pid):
            spd += int(getattr(cfg, "FLY_SPEED", 1))
        rec = self.mP.get(pid)
        if rec is not None and rec.get("inv"):
            resist = int(getattr(cfg, "INVULN_AMP", 4))
        else:
            resist = int(cfg.RESIST_AMP)
        pairs = (
            ("speed", spd),
            ("jump_boost", cfg.JUMP_AMP),
            ("strength", cfg.STRENGTH_AMP),
            ("resistance", resist),
        )
        if getattr(cfg, "FIRE_RESIST", True):
            pairs = pairs + (("fire_resistance", 0),)
        sec = int(max(1, cfg.BUFF_EXTRA))
        for name, amp in pairs:
            try:
                _f().CreateEffect(pid).AddEffectToEntity(
                    name, sec, int(amp), False)
            except Exception:
                pass

    def _clearBuffs(self, pid):
        if not self._creativeLike(pid):
            self._setFly(pid, False)
        for name in ("speed", "jump_boost", "strength", "resistance",
                     "fire_resistance"):
            try:
                _f().CreateEffect(pid).RemoveEffectFromEntity(name)
            except Exception:
                pass

    def _killSummons(self, rec):
        for eid, _until in rec.get("summons", []):
            try:
                _f().CreateGame(serverApi.GetLevelId()).KillEntity(eid)
            except Exception:
                pass
        rec["summons"] = []

    def _expireSummons(self, rec, now):
        keep = []
        for eid, until in rec.get("summons", []):
            if until <= now:
                try:
                    _f().CreateGame(serverApi.GetLevelId()).KillEntity(eid)
                except Exception:
                    pass
            else:
                keep.append((eid, until))
        rec["summons"] = keep

    # ==================== 位置 / 朝向 ====================
    def _dim(self, pid):
        try:
            return int(_f().CreateDimension(pid).GetEntityDimensionId())
        except Exception:
            return 0

    def _foot(self, eid):
        try:
            p = tuple(_f().CreatePos(eid).GetFootPos() or (0.0, 0.0, 0.0))
        except Exception:
            return None
        return (float(p[0]), float(p[1]), float(p[2]))

    def _eye(self, pid):
        p = self._foot(pid)
        if p is None:
            return None
        return (p[0], p[1] + 1.62, p[2])

    def _center(self, eid):
        try:
            p = tuple(_f().CreatePos(eid).GetPos() or (0.0, 0.0, 0.0))
        except Exception:
            return None
        return (float(p[0]), float(p[1]), float(p[2]))

    def _look(self, pid):
        try:
            rot = tuple(_f().CreateRot(pid).GetRot() or (0.0, 0.0))
        except Exception:
            return (0.0, 0.0, 1.0)
        pitch = math.radians(float(rot[0]))
        yaw = math.radians(float(rot[1]))
        cp = math.cos(pitch)
        return (-math.sin(yaw) * cp, -math.sin(pitch), math.cos(yaw) * cp)

    def _solid(self, pos, dimId):
        try:
            info = _f().CreateBlockInfo(serverApi.GetLevelId()).GetBlockNew(
                (int(math.floor(pos[0])), int(math.floor(pos[1])),
                 int(math.floor(pos[2]))), dimId)
        except Exception:
            return False
        if not info:
            return False
        name = info.get("name", "")
        if not name or name == "minecraft:air":
            return False
        if name in ("minecraft:water", "minecraft:flowing_water", "minecraft:lava",
                    "minecraft:flowing_lava", "minecraft:tallgrass", "minecraft:grass",
                    "minecraft:red_flower", "minecraft:yellow_flower",
                    "minecraft:double_plant", "minecraft:reeds", "minecraft:vine",
                    "minecraft:snow_layer", "minecraft:torch"):
            return False
        return True

    # ==================== 找实体 ====================
    def _near(self, center, dimId, span):
        r = int(max(1, span))
        try:
            ids = _f().CreateGame(serverApi.GetLevelId()).GetEntitiesInSquareArea(
                None,
                (int(center[0] - r), int(center[1] - r), int(center[2] - r)),
                (int(center[0] + r), int(center[1] + r), int(center[2] + r)),
                dimId)
        except Exception:
            return []
        return list(ids) if ids else []

    def _typeOf(self, eid):
        try:
            return str(_f().CreateEngineType(eid).GetEngineTypeStr() or "")
        except Exception:
            return ""

    def _isPlayer(self, eid):
        return self._typeOf(eid) in ("minecraft:player",)

    def _findHit(self, center, dimId, radius, skip):
        best = None
        bestD = float(radius) * float(radius)
        for eid in self._near(center, dimId, radius + 1):
            if eid in skip:
                continue
            t = self._typeOf(eid)
            if not t or t in SKIP_TYPES:
                continue
            p = self._center(eid)
            if p is None:
                continue
            d = ((p[0] - center[0]) ** 2 + (p[1] - center[1]) ** 2 +
                 (p[2] - center[2]) ** 2)
            if d < bestD:
                bestD = d
                best = eid
        return best

    # ==================== 造成伤害 / 击退 ====================
    def _hurt(self, target, damage, attackerId=None):
        try:
            _f().CreateHurt(target).Hurt(
                float(damage),
                serverApi.GetMinecraftEnum().ActorDamageCause.EntityAttack,
                attackerId, None, True)
            return True
        except Exception:
            return False

    def _knockback(self, target, srcPos, power):
        p = self._center(target)
        if p is None:
            return
        dx = p[0] - srcPos[0]
        dz = p[2] - srcPos[2]
        n = math.sqrt(dx * dx + dz * dz)
        if n < 0.15:
            dx, dz, n = 0.0, 1.0, 1.0
        vx = dx / n * power
        vz = dz / n * power
        try:
            _f().CreateActorMotion(target).SetMotion((vx, power * 0.55 + 0.25, vz))
        except Exception:
            pass

    def _pushAwayFrom(self, target, center, power):
        p = self._center(target)
        if p is None:
            return
        dx = p[0] - center[0]
        dy = p[1] - center[1]
        dz = p[2] - center[2]
        n = math.sqrt(dx * dx + dz * dz)
        if n < 0.15:
            dx, dz, n = 0.0, 1.0, 1.0
        try:
            _f().CreateActorMotion(target).SetMotion(
                (dx / n * power, max(0.3, power * 0.5 + dy * 0.25), dz / n * power))
        except Exception:
            pass

    # ==================== 射线 ====================
    def _raycast(self, pid, reach, step, radius, dimId):
        start = self._eye(pid)
        if start is None:
            return ("none", None, None)
        d = self._look(pid)
        skip = (pid,)
        steps = int(max(1, reach / max(0.05, step)))
        last = start
        for i in range(1, steps + 1):
            t = i * step
            p = (start[0] + d[0] * t, start[1] + d[1] * t, start[2] + d[2] * t)
            ent = self._findHit(p, dimId, radius, skip)
            if ent:
                return ("entity", p, ent)
            if self._solid(p, dimId):
                return ("block", last, None)
            last = p
        return ("none", last, None)

    # ==================== 技能总入口 ====================
    def _cast(self, pid, key):
        if not cfg.on():
            return
        rec = self._rec(pid, True)
        if rec is None:
            return
        if rec["state"] != "him":
            return
        now = _now()
        if rec["cd"].get(key, 0.0) > now:
            return
        rec["cd"][key] = now + cfg.skillCooldown(key)
        dimId = self._dim(pid)
        try:
            if key == "bolt":
                self._skBolt(pid, rec, dimId)
            elif key == "fire":
                self._skFire(pid, rec, dimId)
            elif key == "field":
                self._skField(pid, rec, dimId)
            elif key == "judge":
                self._skJudge(pid, rec, dimId)
        except Exception:
            pass
        self._sendState(pid, force=True)

    # ---------- 2 火球 ----------
    def _skFire(self, pid, rec, dimId):
        # HIM throws a real fireball that flies out, leaves a flame trail and
        # sets the spot it hits on fire.
        eye = self._eye(pid)
        d = self._look(pid)
        if eye is not None and d is not None:
            if self._shootFire(pid, eye, d, dimId):
                self._fxAll(pid, "fire_muzzle",
                            {"x": eye[0] + d[0] * 1.15, "y": eye[1] - 0.15,
                             "z": eye[2] + d[2] * 1.15})
                return
        self._fireOld(pid, dimId)

    def _fireOld(self, pid, dimId):
        kind, pos, ent = self._raycast(pid, cfg.FIRE_RANGE, cfg.FIRE_STEP,
                                       cfg.FIRE_RADIUS, dimId)
        if pos is None:
            return
        eye = self._eye(pid) or pos
        self._fxAll(pid, "fire", {"x1": eye[0], "y1": eye[1], "z1": eye[2],
                                  "x2": pos[0], "y2": pos[1], "z2": pos[2]})
        self._fxAll(pid, "fire_blast", {"x": pos[0], "y": pos[1], "z": pos[2]})
        if kind == "entity" and ent:
            self._fxAll(pid, "fire_hit", {"x": pos[0], "y": pos[1], "z": pos[2]})
            self._hurt(ent, cfg.FIRE_DAMAGE, pid)
            self._knockback(ent, eye, cfg.FIRE_KNOCK)
            self._ignite(ent, cfg.FIRE_BURN)
        self._blast(pid, pos, dimId)

    def _ignite(self, eid, sec):
        try:
            _f().CreateAttr(eid).SetEntityOnFire(float(sec), 1)
            return
        except Exception:
            pass
        try:
            _f().CreateEffect(eid).AddEffectToEntity("fire_resistance", 0, 0, False)
        except Exception:
            pass

    def _blast(self, pid, pos, dimId):
        for eid in self._near(pos, dimId, cfg.FIRE_BLAST_RADIUS):
            if eid == pid or self._typeOf(eid) in SKIP_TYPES:
                continue
            c = self._center(eid)
            if c is None:
                continue
            dd = math.sqrt((c[0] - pos[0]) ** 2 + (c[1] - pos[1]) ** 2 +
                           (c[2] - pos[2]) ** 2)
            if dd > cfg.FIRE_BLAST_RADIUS + 1.0:
                continue
            self._hurt(eid, cfg.FIRE_BLAST_DAMAGE, pid)
            self._pushAwayFrom(eid, pos, cfg.FIRE_KNOCK)
            self._ignite(eid, max(2, int(cfg.FIRE_BURN / 2)))
        r = int(getattr(cfg, "FIRE_BREAK_RADIUS", 0) or 0)
        if r > 0:
            self._carve(pos, dimId, r)
        if getattr(cfg, "FIRE_LIGHT", True):
            self._setFire(pos, dimId)

    def _carve(self, pos, dimId, r):
        try:
            bi = _f().CreateBlockInfo(serverApi.GetLevelId())
        except Exception:
            return
        if bi is None:
            return
        cx = int(math.floor(pos[0]))
        cy = int(math.floor(pos[1]))
        cz = int(math.floor(pos[2]))
        for dx in range(-r, r + 1):
            for dy in range(-r, r + 1):
                for dz in range(-r, r + 1):
                    if dx * dx + dy * dy + dz * dz > r * r + 1:
                        continue
                    bp = (cx + dx, cy + dy, cz + dz)
                    try:
                        info = bi.GetBlockNew(bp, dimId)
                    except Exception:
                        continue
                    if not info:
                        continue
                    name = str(info.get("name", ""))
                    if not name or name == "minecraft:air" or name in UNBREAKABLE:
                        continue
                    if name in ("minecraft:water", "minecraft:flowing_water",
                                "minecraft:lava", "minecraft:flowing_lava"):
                        continue
                    try:
                        bi.SetBlockNew(bp, {"name": "minecraft:air", "aux": 0}, 0, dimId)
                    except Exception:
                        pass

    def _setFire(self, pos, dimId):
        try:
            bi = _f().CreateBlockInfo(serverApi.GetLevelId())
        except Exception:
            return
        if bi is None:
            return
        bx = int(math.floor(pos[0]))
        by = int(math.floor(pos[1]))
        bz = int(math.floor(pos[2]))
        for bp in ((bx, by, bz), (bx + 1, by, bz), (bx - 1, by, bz),
                   (bx, by, bz + 1), (bx, by, bz - 1), (bx, by + 1, bz)):
            try:
                info = bi.GetBlockNew(bp, dimId)
            except Exception:
                continue
            if not info or str(info.get("name", "")) != "minecraft:air":
                continue
            try:
                low = bi.GetBlockNew((bp[0], bp[1] - 1, bp[2]), dimId)
            except Exception:
                continue
            if not low or str(low.get("name", "")) in ("minecraft:air", ""):
                continue
            try:
                bi.SetBlockNew(bp, {"name": "minecraft:fire", "aux": 0}, 0, dimId)
            except Exception:
                pass

    # ---------- 3 雷击 ----------
    def _skBolt(self, pid, rec, dimId):
        kind, pos, ent = self._raycast(pid, cfg.BOLT_RANGE, 0.6, 1.2, dimId)
        if pos is None:
            return
        if kind == "entity" and ent:
            c = self._center(ent)
            if c:
                pos = c
        caster = self._foot(pid)
        if caster is None:
            return
        native = False
        if getattr(cfg, "BOLT_NATIVE", True):
            native = self._strike(pos, dimId, pid)
        self._fxAll(pid, "strike" if native else "bolt",
                    {"x": pos[0], "y": pos[1], "z": pos[2]})
        for eid in self._near(pos, dimId, cfg.BOLT_RADIUS):
            if eid == pid or self._typeOf(eid) in SKIP_TYPES:
                continue
            c = self._center(eid)
            if c is None:
                continue
            dd = math.sqrt((c[0] - pos[0]) ** 2 + (c[1] - pos[1]) ** 2 +
                           (c[2] - pos[2]) ** 2)
            if dd > cfg.BOLT_RADIUS + 1.5:
                continue
            self._hurt(eid, cfg.BOLT_DAMAGE, pid)
            self._pushAwayFrom(eid, pos, cfg.BOLT_KNOCK)
        if getattr(cfg, "BOLT_FIRE", True):
            for off in ((0.0, 0.0), (1.6, 0.0), (-1.6, 0.0), (0.0, 1.6), (0.0, -1.6)):
                self._setFire((pos[0] + off[0], pos[1], pos[2] + off[1]), dimId)

    # ---------- 6 黑暗领域 ----------
    # 释放后：脚下出现紫色法阵，法阵从脚下向四周慢慢推进扩散到 30 格；
    #         被法阵扫过的非玩家生物全部被吹到空中；
    #         等法阵完全铺满（覆盖到 30 格）之后，才在法阵中心打出冲击波，
    #         秒杀还飘在空中的生物。
    def _fieldRadius(self, rec, now):
        # 法阵现在扩散到几格了
        full = float(cfg.FIELD_RANGE)
        grow = float(getattr(cfg, "FIELD_GROW_TIME", 3.0))
        t0 = float(rec.get("fieldStart", 0.0))
        if grow <= 0.0 or t0 <= 0.0:
            return full
        k = (now - t0) / grow
        if k < 0.0:
            k = 0.0
        elif k > 1.0:
            k = 1.0
        return full * k

    def _skField(self, pid, rec, dimId):
        now = _now()
        base = self._foot(pid)
        if base is None:
            return
        grow = float(getattr(cfg, "FIELD_GROW_TIME", 3.0))
        rec["domainUntil"] = now + cfg.FIELD_SECONDS
        rec["domainNext"] = now + cfg.FIELD_TICK
        rec["fieldSealAt"] = now + float(getattr(cfg, "FIELD_SEAL_TICK", 1.0))
        rec["fieldStart"] = now
        rec["fieldBase"] = base
        rec["fieldLiftUntil"] = now + grow
        rec["fieldBlastAt"] = now + grow
        rec["fieldAir"] = {}
        self._fxAll(pid, "field_on", {"x": base[0], "y": base[1], "z": base[2],
                                      "r": cfg.FIELD_RANGE, "grow": grow})
        self._sound(base, dimId,
                    str(getattr(cfg, "FIELD_WAVE_SOUND",
                                "mob.warden.sonic_charge")), 1.5, 1.0)
        self._fieldLift(pid, base, dimId, rec, 1.5)

    def _mobsIn(self, pid, base, dimId, r):
        # 半径 r 内的所有“非玩家生物”（玩家不受影响）
        out = []
        r = float(r)
        if r < 0.5:
            return out
        for eid in self._near(base, dimId, int(r) + 1):
            if eid == pid:
                continue
            if self._typeOf(eid) in SKIP_TYPES:
                continue
            if self._isPlayer(eid):
                continue
            c = self._center(eid)
            if c is None:
                continue
            if (c[0] - base[0]) ** 2 + (c[2] - base[2]) ** 2 > r * r:
                continue
            out.append((eid, c))
        return out

    def _fieldLift(self, pid, base, dimId, rec, r):
        # 把被法阵扫过的生物往上推，让它们飘在空中；同时记名单，冲击波按名单秒杀
        up = float(getattr(cfg, "FIELD_LIFT", 0.85))
        for eid, _c in self._mobsIn(pid, base, dimId, r):
            self._motion(eid, (0.0, up, 0.0))
            rec["fieldAir"][eid] = 1

    def _domainPulse(self, pid, rec, now):
        dimId = self._dim(pid)
        feet = self._foot(pid)
        if feet is None:
            return
        wbase = rec.get("fieldBase") or feet
        r = self._fieldRadius(rec, now)
        # 脚下的法阵一直转；顺便把“扩散到几格了”告诉客户端去画边沿
        self._fxAll(pid, "field_tick",
                    {"x": feet[0], "y": feet[1], "z": feet[2],
                     "wx": wbase[0], "wy": wbase[1], "wz": wbase[2], "r": r})
        if now >= float(rec.get("fieldSealAt", 0.0)):
            rec["fieldSealAt"] = now + float(getattr(cfg, "FIELD_SEAL_TICK", 1.0))
            self._fxAll(pid, "field_seal", {"x": feet[0], "y": feet[1],
                                            "z": feet[2]})
        # 还在扩散：把刚被法阵扫过的地方的生物吹起来
        if now < float(rec.get("fieldLiftUntil", 0.0)):
            self._fieldLift(pid, wbase, dimId, rec, r)
        # 领域里自己更强
        try:
            _f().CreateEffect(pid).AddEffectToEntity(
                "speed", 3, int(cfg.SPEED_AMP + cfg.FIELD_SELF_SPEED), False)
            _f().CreateEffect(pid).AddEffectToEntity(
                "strength", 3, int(cfg.STRENGTH_AMP + 1), False)
        except Exception:
            pass

    def _fieldBlast(self, pid, rec):
        # 法阵完全覆盖之后：从法阵中心打出一道冲击波，秒杀飘在空中的生物
        dimId = self._dim(pid)
        base = rec.get("fieldBase")
        if base is None:
            base = self._foot(pid)
        if base is None:
            return
        r = float(cfg.FIELD_RANGE)
        self._fxAll(pid, "field_blast", {"x": base[0], "y": base[1],
                                         "z": base[2], "r": r})
        self._sound(base, dimId,
                    str(getattr(cfg, "FIELD_BLAST_SOUND",
                                "mob.warden.sonic_boom")), 2.0, 0.9)
        self._sound(base, dimId, "random.explode", 1.4, 0.6)
        dmg = float(getattr(cfg, "FIELD_KILL_DAMAGE", 100000.0))
        hit = {}
        for eid in list(rec.get("fieldAir", {}).keys()):
            hit[eid] = 1
        for eid, _c in self._mobsIn(pid, base, dimId, r):
            hit[eid] = 1
        for eid in list(hit.keys()):
            c = self._center(eid)
            if c is None:
                continue
            if (c[0] - base[0]) ** 2 + (c[2] - base[2]) ** 2 > (r + 2.0) ** 2:
                continue
            self._hurt(eid, dmg, pid)
        rec["fieldAir"] = {}
        rec["fieldLiftUntil"] = 0.0
        rec["fieldStart"] = 0.0
        rec["fieldBase"] = None


    # ---------- 7 审判 ----------
    # 使用后：天空变成深紫色、暗下来；
    #         从玩家脚下向四周扩散一圈白色冲击波，一直推到 50 格；
    #         被冲击波扫到的非玩家生物瞬间身上起火，紧接着被击杀。
    def _fogPush(self):
        # 天空变成深紫色（给所有玩家叠一层雾，到点再 pop 掉）
        return self._cmd("/fog @a push %s %s" % (
            str(getattr(cfg, "JUDGE_FOG", "him:judge")),
            str(getattr(cfg, "JUDGE_FOG_TAG", "himjudge"))))

    def _fogPop(self):
        return self._cmd("/fog @a pop %s" % (
            str(getattr(cfg, "JUDGE_FOG_TAG", "himjudge")),))

    def _skJudge(self, pid, rec, dimId):
        now = _now()
        base = self._foot(pid)
        if base is None:
            return
        rec["judgeAt"] = now + cfg.JUDGE_CHARGE
        rec["judgeBase"] = base
        rec["judgeHit"] = {}
        # 天空先入夜：真的把世界时间调到半夜，技能放完再恢复原状
        if getattr(cfg, "JUDGE_FOG", ""):
            self._fogPush()
            rec["judgeFogOff"] = now + float(getattr(cfg, "JUDGE_FOG_TIME", 7.0))
        self._judgeNightOn(rec, now)
        self._fxAll(pid, "judge_charge", {"x": base[0], "y": base[1],
                                          "z": base[2], "t": cfg.JUDGE_CHARGE})

    def _judgeRadius(self, rec, now):
        # 白色冲击波现在推进到几格了
        full = float(cfg.JUDGE_RANGE)
        wav = float(getattr(cfg, "JUDGE_WAVE_TIME", 1.0))
        t0 = float(rec.get("judgeStart", 0.0))
        if wav <= 0.0 or t0 <= 0.0:
            return full
        k = (now - t0) / wav
        if k < 0.0:
            k = 0.0
        elif k > 1.0:
            k = 1.0
        return full * k

    def _judgeFire(self, pid, rec):
        now = _now()
        dimId = self._dim(pid)
        base = rec.get("judgeBase") or self._foot(pid)
        if base is None:
            return
        wav = float(getattr(cfg, "JUDGE_WAVE_TIME", 1.0))
        rec["judgeBase"] = base
        rec["judgeStart"] = now
        rec["judgeUntil"] = now + wav
        rec["judgeSweepAt"] = now
        rec["judgeKillAt"] = now + wav + \
            float(getattr(cfg, "JUDGE_KILL_DELAY", 0.45))
        rec["judgeHit"] = {}
        # 白色冲击波 + 音效
        self._fxAll(pid, "judge_fire", {"x": base[0], "y": base[1],
                                        "z": base[2], "r": cfg.JUDGE_RANGE})
        self._sound(base, dimId,
                    str(getattr(cfg, "JUDGE_BLAST_SOUND",
                                "mob.warden.sonic_boom")), 2.0, 0.7)
        self._sound(base, dimId, "ambient.weather.thunder", 1.8, 0.8)
        # 100 格以内的生物全部被雷击打中
        self._judgeBoltQueue(pid, rec, base, dimId)
        self._judgeSweep(pid, rec, now)

    # ---------- 审判：七秒黑夜（真的调世界时间，不用任何 UI 遮罩）----------
    def _timeComp(self):
        # 世界时间组件（不同版本写法不太一样，挨个试）
        # 天黑天亮要每 tick 调一次，缓存住，别反复创建
        comp = getattr(self, "mTimeComp", None)
        if comp is not None:
            return comp
        try:
            factory = serverApi.GetEngineCompFactory()
        except Exception:
            return None
        owners = []
        try:
            owners.append(serverApi.GetLevelId())
        except Exception:
            pass
        owners.append(None)
        for owner in owners:
            try:
                comp = factory.CreateTime(owner)
            except Exception:
                continue
            if comp is not None:
                self.mTimeComp = comp
                return comp
        return None

    def _timeOfDay(self):
        # 现在走到一天的哪一帧了（0~23999）
        comp = self._timeComp()
        if comp is None:
            return None
        try:
            t = comp.GetTime()
            if t is not None:
                return int(t) % 24000
        except Exception:
            pass
        return None

    def _setTimeOfDay(self, tod):
        comp = self._timeComp()
        if comp is not None:
            try:
                comp.SetTimeOfDay(int(tod))
                return True
            except Exception:
                self.mTimeComp = None   # 句柄可能失效了，下次重新拿
        # 组件用不了就走原版指令
        return self._cmd("/time set %d" % int(tod))

    def _judgeNightOn(self, rec, now):
        # 存下原时间 -> 调到半夜 -> 记下该恢复的时刻
        if not bool(getattr(cfg, "JUDGE_NIGHT", True)):
            return
        if float(rec.get("judgeNightAt", 0.0)) > 0.0:
            return      # 已经在夜里，别把“原来的时间”覆盖成半夜
        old = self._timeOfDay()
        if old is None:
            return      # 读不到当前时间就别乱调，免得好不回来
        if self._isNight(int(old)):
            return      # 本来就是黑天，天已经黑了，不用再动时间
        rec["judgeTimeOld"] = int(old)
        # 不用“啪”一下跳到半夜：交给 tick 一帧一帧滑过去（日落 -> 半夜 -> 日出）
        rec["judgeNightStart"] = now
        rec["judgeNightAt"] = now + float(
            getattr(cfg, "JUDGE_NIGHT_HOLD", 7.0))
        self._judgeNightTick(rec, now)

    def _isNight(self, tod):
        # 现在这个时刻算不算已经是黑夜（黄昏之后、天亮之前）
        lo = int(getattr(cfg, "JUDGE_NIGHT_FROM", 13000)) % 24000
        hi = int(getattr(cfg, "JUDGE_NIGHT_TO", 23000)) % 24000
        t = int(tod) % 24000
        if lo <= hi:
            return lo <= t < hi
        return t >= lo or t < hi

    def _judgeNightTick(self, rec, now):
        # 每 tick 把时间往前推一点：日落 -> 半夜 -> 日出，看起来像真的天黑了
        start = float(rec.get("judgeNightStart", 0.0))
        end = float(rec.get("judgeNightAt", 0.0))
        if start <= 0.0 or end <= 0.0:
            return
        old = rec.get("judgeTimeOld")
        if old is None:
            self._judgeNightOff(rec)
            return
        if now >= end:
            self._judgeNightOff(rec)
            return
        target = int(getattr(cfg, "JUDGE_NIGHT_TIME", 18000)) % 24000
        total = end - start
        tin = max(0.0, float(getattr(cfg, "JUDGE_NIGHT_FADE_IN", 2.0)))
        tout = max(0.0, float(getattr(cfg, "JUDGE_NIGHT_FADE_OUT", 1.5)))
        if tin + tout > total and (tin + tout) > 0.0:
            k = total / (tin + tout)
            tin *= k
            tout *= k
        t = now - start
        # 时间只往前走：从现在 -> 半夜，再从半夜 -> 回到原来那一帧
        d1 = (target - int(old)) % 24000
        d2 = (int(old) - target) % 24000
        if tin > 0.0 and t < tin:
            tod = int(old) + d1 * (t / tin)
        elif tout > 0.0 and t > total - tout:
            tod = target + d2 * ((t - (total - tout)) / tout)
        else:
            tod = target
        self._setTimeOfDay(int(round(tod)) % 24000)

    def _judgeNightOff(self, rec):
        # 把世界时间恢复原状
        if float(rec.get("judgeNightAt", 0.0)) <= 0.0:
            return
        rec["judgeNightAt"] = 0.0
        rec["judgeNightStart"] = 0.0
        old = rec.get("judgeTimeOld")
        rec["judgeTimeOld"] = None
        if old is None:
            return
        self._setTimeOfDay(int(old))

    def _judgeBoltQueue(self, pid, rec, base, dimId):
        # 审判：把 100 格以内的非玩家生物记下来，交给 tick 一批批落雷，
        # 免得一次生成上百个闪电实体把手机卡住
        rec["judgeBolts"] = []
        if not bool(getattr(cfg, "JUDGE_BOLT", True)):
            return
        r = float(getattr(cfg, "JUDGE_BOLT_RANGE", 100.0))
        for eid, _c in self._mobsIn(pid, base, dimId, r):
            rec["judgeBolts"].append(eid)

    def _judgeBoltTick(self, pid, rec, dimId):
        # 每 tick 放出几道原版闪电
        bl = rec.get("judgeBolts")
        if not bl:
            return
        n = int(getattr(cfg, "JUDGE_BOLT_BATCH", 6))
        if n < 1:
            n = 1
        batch = bl[:n]
        del bl[:n]
        for eid in batch:
            c = self._center(eid)
            if c is None:
                continue
            self._strike(c, dimId, pid)

    def _judgeSweep(self, pid, rec, now):
        # 冲击波扫到哪里，那里的生物就起火
        base = rec.get("judgeBase")
        if base is None:
            return
        dimId = self._dim(pid)
        r = self._judgeRadius(rec, now)
        if r < 1.0:
            return
        burn = int(getattr(cfg, "JUDGE_BURN", 8))
        for eid, _c in self._mobsIn(pid, base, dimId, r):
            if eid in rec["judgeHit"]:
                continue
            rec["judgeHit"][eid] = 1
            self._ignite(eid, burn)

    def _judgeKill(self, pid, rec):
        # 起火之后：把被白色冲击波打中的生物全部击杀，
        # 并在它倒下的位置点起一把火
        base = rec.get("judgeBase")
        r = float(cfg.JUDGE_RANGE)
        dmg = float(getattr(cfg, "JUDGE_KILL_DAMAGE", 100000.0))
        dimId = self._dim(pid)
        burnSpot = bool(getattr(cfg, "JUDGE_KILL_FIRE", True))
        if base is not None:
            for eid in list(rec.get("judgeHit", {}).keys()):
                c = self._center(eid)
                if c is None:
                    continue
                if (c[0] - base[0]) ** 2 + (c[2] - base[2]) ** 2 > (r + 2.0) ** 2:
                    continue
                self._hurt(eid, dmg, pid)
                if burnSpot:
                    self._setFire(c, dimId)
        rec["judgeHit"] = {}
        rec["judgeUntil"] = 0.0
        rec["judgeSweepAt"] = 0.0
        rec["judgeBase"] = None


    # ==================== 飞行 ====================
    def _flyComp(self, pid):
        try:
            return _f().CreateFly(pid)
        except Exception:
            return None

    def _flyState(self, pid):
        comp = self._flyComp(pid)
        if comp is None:
            return False
        try:
            return bool(comp.IsPlayerFlying())
        except Exception:
            return False

    def _gameTypeOf(self, pid):
        # 玩家的游戏模式（0 生存 / 1 创造 / 2 冒险 / 6 旁观）
        # 拿不到就返回 None，调用方按“要保护”处理
        now = _now()
        hit = self.mGmCache.get(pid)
        if hit is not None and now - hit[1] < 2.0:
            return hit[0]
        try:
            comp = _f().CreateGame(serverApi.GetLevelId())
            gt = int(comp.GetPlayerGameType(pid))
        except Exception:
            return None
        self.mGmCache[pid] = (gt, now)
        return gt

    def _creativeLike(self, pid):
        # 创造 / 旁观：玩家本来就会飞，能力不是我们给的，
        # 绝对不能去收回（收走了他就飞不起来了）
        gt = self._gameTypeOf(pid)
        if gt is None:
            return True        # 读不到就按“要保护”处理，绝不乱动
        return int(gt) in (1, 6)

    def _canFlyAbility(self, pid):
        # 玩家现在身上有没有“能飞”的能力（mayfly）。
        # 有这个能力，双击跳跃才是引擎原生行为。
        comp = self._flyComp(pid)
        if comp is None:
            return False
        try:
            ok = bool(comp.IsPlayerCanFly())
        except Exception:
            return False
        if ok:
            self.mAbilityApiOK = True     # 接口能用，后面才敢做“收飞行”的动作
        return ok

    def _abilityCmd(self, pid, ability, value):
        # 直接用游戏自带的 /ability 指令改能力（能力和游戏本身完全一致）：
        #   mayfly  = 能不能飞（双击跳跃起飞靠它）
        #   flying  = 现在是不是在飞
        name = u""
        try:
            name = u"%s" % (_f().CreateName(pid).GetName() or u"")
        except Exception:
            name = u""
        if name:
            if self._cmd(u"/ability \"%s\" %s %s" % (name, ability, value)):
                return True
        return self._cmd(u"/ability @s %s %s" % (ability, value), pid)

    def _grantFlyAbility(self, pid):
        # 把“能飞”的能力给下去，但不要立刻起飞。
        # 有了这个能力，双击跳跃就是引擎原生行为，一按就飞、再双击就落，
        # 不用脚本靠“竖直速度突变”去猜你按没按（那才是要按三四下的原因）。
        if not getattr(cfg, "FLY_NATIVE_DOUBLE_TAP", True):
            return False
        comp = self._flyComp(pid)
        if comp is None:
            return False
        if self._canFlyAbility(pid):
            return True
        got = False
        if not getattr(self, "mGrantOff", False):
            try:
                # 两参数写法 = 给能力，第二个参数 False 表示不立刻进入飞行
                comp.ChangePlayerFlyState(True, False)
            except Exception:
                # 这台引擎不认两个参数。绝不退回单参数（那会把玩家拽上天），
                # 改用下面 /ability 指令那条路
                self.mGrantOff = True
            else:
                canFly = self._canFlyAbility(pid)
                flying = self._flyState(pid)
                if flying and not canFly:
                    # 参数含义和预期相反：飞行被打开了、能力却没下来，先关掉
                    try:
                        comp.ChangePlayerFlyState(False)
                    except Exception:
                        pass
                    self.mGrantOff = True
                elif canFly:
                    got = True
        if not got and getattr(cfg, "FLY_ABILITY_CMD", True) and \
                not getattr(self, "mCmdOff", False):
            # 兜底：用 /ability 指令把“能飞”打开
            if self._abilityCmd(pid, "mayfly", "true"):
                got = True
            else:
                self.mCmdOff = True
        if got and not self._creativeLike(pid):
            rec = self.mP.get(pid)
            if rec is not None:
                rec["flyGiven"] = True     # 记下来：这个能力是我们发的，之后要收
        return got

    def _setFly(self, pid, on):
        comp = self._flyComp(pid)
        if comp is None:
            return False
        rec = self.mP.get(pid)
        if not on and self._creativeLike(pid):
            # 创造 / 旁观玩家：只关“现在在飞”，绝不动“能不能飞”这个能力。
            # 用原版指令最稳，指令走不通就干脆不碰他的飞行。
            if self._abilityCmd(pid, "flying", "false"):
                return True
            if self._canFlyAbility(pid):
                return False
            try:
                comp.ChangePlayerFlyState(False)
            except Exception:
                return False
            if not self._grantFlyAbility(pid):
                self.mGrantOff = True
                self.mCmdOff = True
                return False
            return True
        done = False
        if on and getattr(cfg, "FLY_NATIVE_DOUBLE_TAP", True):
            try:
                # 两参数写法 = 给飞行能力 + 直接进入飞行
                comp.ChangePlayerFlyState(True, True)
                done = True
            except Exception:
                done = False
        if not done:
            try:
                comp.ChangePlayerFlyState(bool(on))
            except Exception:
                return False
        if not on:
            # 关飞行时顺手用原版指令再关一次（不依赖引擎接口的返回值）
            if getattr(cfg, "FLY_ABILITY_CMD", True) and \
                    not getattr(self, "mCmdOff", False):
                if not self._abilityCmd(pid, "flying", "false"):
                    self.mCmdOff = True
            if rec is not None:
                rec["flyGiven"] = False    # 能力已经收回来了
        if on and getattr(cfg, "FLY_LIFT_ON_TAKEOFF", True):
            try:
                _f().CreateActorMotion(pid).SetMotion(
                    (0.0, float(getattr(cfg, "FLY_LIFT_SPEED", 0.8)), 0.0))
            except Exception:
                pass
            if rec is not None:
                rec["flyLift"] = _now() + float(getattr(cfg, "FLY_LIFT_TIME", 0.25))
        elif rec is not None:
            rec["flyLift"] = 0.0
        return True

    def _canFly(self, rec):
        # 什么时候可以飞：HIM 状态随时可以；
        # 变身动画进到“HIM 降临”（闪电落下的那一刻）之后也马上可以，
        # 不用等整段变身动画播完。
        st = rec.get("state")
        if st == "him":
            return True
        if st == "transform" and getattr(cfg, "FLY_EARLY", True):
            return rec.get("phase") in (cfg.PHASE_APPEAR, cfg.PHASE_DONE)
        return False

    def _toggleFly(self, pid):
        self._setFlyTo(pid, not self._flyState(pid))

    def _setFlyTo(self, pid, on):
        # 双击跳跃 / 点【起飞】按钮都是“绝对指令”：
        # 要起飞就是起飞，要降落就是降落，重复收到也不会来回打架。
        # （起飞 / 降落不再弹屏幕中间那行大白字）
        if not cfg.flyOn():
            return
        rec = self._rec(pid, True)
        if rec is None:
            return
        on = bool(on)
        if on and not self._canFly(rec):
            if self._canFlyAbility(pid):
                # 本来就会飞（创造 / 旁观）：交给游戏自己，别弹提示
                return
            self._tip(pid, u"先变身 HIM 才能飞")
            return
        if self._flyState(pid) == on:
            return
        if self._setFly(pid, on):
            rec["flyLast"] = on
            rec["flySyncAt"] = _now()
            if not on:
                # 收回飞行时，引擎会把“能飞”的能力一起收走，
                # 这里立刻补回来，下次双击跳跃（原生）才认得
                if self._grantFlyAbility(pid):
                    rec["canLast"] = True
                    rec["abilityAt"] = _now() + 2.0
            self._sendState(pid, force=True)
