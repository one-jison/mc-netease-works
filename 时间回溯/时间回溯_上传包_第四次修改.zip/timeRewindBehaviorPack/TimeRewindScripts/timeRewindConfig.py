# -*- coding: utf-8 -*-
# ============================================================
#  时间回溯 — 所有能调的数字都在这儿，改完重启就生效
# ============================================================

MODE_ON = True                     # 整个模组的总开关
POTION_NAME = u"回溯"               # 药水名字（聊天提示用）
POTION_ITEM = "timerewind:rewind_potion"   # 物品 ID（别乱改）

# ---------------- 喝下去 ----------------
TIP_ON_DRINK = True        # 喝下去时在聊天框里提示一句
# 按钮留多久：0 = 一直留着（直到死亡 / 退出世界），>0 = 这么多秒后自动收掉
BUTTON_SECONDS = 0.0
COOLDOWN_SECONDS = 5.0     # 按一次之后要等几秒才能再按

# ---------------- 按下去发生什么 ----------------
REWIND_SECONDS = 5.0        # 退回几秒前
DAY_NIGHT_ON = True         # True = 按下后昼夜飞快交替
DAY_NIGHT_SECONDS = 10.0    # 昼夜飞快交替持续几秒
DAY_NIGHT_CYCLE = 5.0       # 几秒一轮回（5 = 五秒一轮回）

# ---------------- 按下去之后的节奏 ----------------
REWIND_DELAY = 1.0          # 按下后先让昼夜转这么久，再开始回溯生物和方块（秒）
ANIM_SECONDS = 1.0          # 屏幕上那个转钟的「正在回溯...」动画放多久（秒）
ANIM_FRAMES = 8             # 转钟动画几帧（对应贴图 clock_0..clock_7，别乱改）
ANIM_FPS = 8.0              # 转钟每秒放几帧

# ---------------- 回溯谁 ----------------
ENTITY_RANGE = 100.0        # 身边多少格以内的实体跟着回溯
BLOCK_RANGE = 100.0         # 身边多少格以内的方块跟着回溯
REWIND_PLAYERS = False      # True = 连玩家也一起退回五秒前的位置（默认不动玩家）
REVIVE_DEAD = True          # True = 这五秒里死掉的生物原地复活
REWIND_HEALTH = True        # True = 连血量一起还原

ENTITY_SAMPLE_TICKS = 10    # 每几 tick 记一次实体的位置（10 = 每秒 2 次）
ENTITY_CACHE_TICKS = 20     # 每隔几 tick 重找一次身边的实体（别每帧都找，省性能）
MAX_ENTITIES = 200          # 一次最多记多少个实体（太多会拖性能）
HISTORY_KEEP = 60           # 每个实体最多留多少条记录
DEATH_KEEP = 200            # 最多留多少条“刚刚死掉”的记录
BLOCK_KEEP = 20000          # 最多留多少格方块记录
BLOCK_PER_TICK = 120        # 爆炸一次要记的方块太多，每 tick 慢慢记
MAX_EXPLODE_BLOCKS = 800    # 一次爆炸最多记多少格

# ---------------- 按下去的动静 ----------------
SOUND_ON_USE = True                     # True = 按下去响一声（用的游戏自带音效，不用额外素材）
SOUND_USE = "mob.endermen.portal"       # 那一声用哪个音效
SOUND_VOLUME = 1.0
SOUND_PITCH = 1.0

# ---------------- 电脑端 ----------------
# 电脑端鼠标锁在准心里，指针移不到屏幕上的按钮，所以给一个键盘快捷键。
# 这里用的是“注册自定义按键”：按键会出现在游戏的【设置 -> 按键】里，
# 玩家可以在那儿自己改成别的键。
USE_KEY_ENABLED = True                  # True = 电脑端按这个键就等于点了一下回溯按钮
USE_KEY_NAME = "TimeRewindUse"          # 按键名（内部标识，英文，别用中文）
USE_KEY_CODE = 82                       # 默认键码：82 = R（82=R 71=G 70=F 72=H 74=J 86=V）
USE_KEY_CATEGORY = "gameplay"           # 设置里归到哪一类：gameplay / movement
USE_KEY_LABEL = u"R"                    # 聊天提示里写的键名

# ---------------- 死亡 ----------------
KEEP_HP_ON_DEATH = True     # True = 死前喝过药，重生时血量回到五秒前那个值

# ============================================================
#  下面几个函数不用动，改上面的数字就行
# ============================================================
def rewindSeconds():
    return max(1.0, float(REWIND_SECONDS))


def dayNightOn():
    return bool(DAY_NIGHT_ON)


def dayNightSeconds():
    return max(0.5, float(DAY_NIGHT_SECONDS))


def dayNightStep():
    # 每次推多少帧：24000 帧 = 一整天，20 tick = 1 秒
    cycle = max(0.5, float(DAY_NIGHT_CYCLE))
    return max(1, int(round(24000.0 / (cycle * 20.0))))


def buttonSeconds():
    return max(0.0, float(BUTTON_SECONDS))


def cooldownSeconds():
    return max(0.0, float(COOLDOWN_SECONDS))


def rewindDelay():
    return max(0.0, float(REWIND_DELAY))


def animSeconds():
    return max(0.0, float(ANIM_SECONDS))


def entityRange():
    return max(1.0, float(ENTITY_RANGE))


def blockRange():
    return max(1.0, float(BLOCK_RANGE))


def sampleTicks():
    return max(1, int(ENTITY_SAMPLE_TICKS))


def cacheTicks():
    return max(1, int(ENTITY_CACHE_TICKS))


def soundOn():
    return bool(SOUND_ON_USE)


def keepHpOnDeath():
    return bool(KEEP_HP_ON_DEATH)


def useKeyOn():
    return bool(USE_KEY_ENABLED)


def useKeyLabel():
    return u"%s" % USE_KEY_LABEL
