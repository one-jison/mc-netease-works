# -*- coding: utf-8 -*-
# ============================================================
#  时间回溯 - 屏幕界面（HUD）
#    屏幕左边中间一颗「回溯」按钮：亮 / 灭由服务端说了算，
#    点一下就把消息发给服务端。
# ============================================================
import mod.client.extraClientApi as clientApi

ScreenNode = clientApi.GetScreenNodeCls()


class TimeRewindHudScreen(ScreenNode):

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mBtnPanel = "/hudPanel"
        self.mBtn = self.mBtnPanel + "/btnRewind"
        self.mShown = None
        self.mOnUse = None
        self.mAnimPanel = "/hudPanel/rewindAnim"
        self.mAnimClock = self.mAnimPanel + "/clockBox"
        self.mFrameCount = 8
        self.mFrame = -1

    def Create(self):
        self.mShown = None
        self._wire()
        self.SetButtonVisible(False)
        self.ShowRewindAnim(False)

    # ==================== 正在回溯... 转钟动画 ====================
    def ShowRewindAnim(self, on, frame=0):
        # 整块动画显示 / 隐藏
        v = bool(on)
        self._setVisible(self.mAnimPanel, v)
        if v:
            self.SetAnimFrame(int(frame))
        else:
            self.mFrame = -1

    def SetAnimFrame(self, i):
        # 只让当前这一帧的图显示出来
        n = max(1, int(self.mFrameCount))
        i = int(i) % n
        if i == self.mFrame:
            return
        self.mFrame = i
        for k in range(n):
            self._setVisible(self.mAnimClock + "/f%d" % k, k == i)

    # ==================== 按钮 ====================
    def SetOnUse(self, callback):
        # 客户端把“玩家点了这个按钮要干什么”交进来
        self.mOnUse = callback

    def SetButtonVisible(self, show):
        v = bool(show)
        self.mShown = v
        self._setVisible(self.mBtn, v)
        try:
            self.GetBaseUIControl(self.mBtn).asButton().SetButtonEnable(v)
        except Exception:
            pass

    def _wire(self):
        try:
            btn = self.GetBaseUIControl(self.mBtn).asButton()
            btn.AddTouchEventParams({"isSwallow": True})
            btn.SetButtonTouchUpCallback(self._onTouch)
        except Exception:
            pass

    def _onTouch(self, args=None):
        if self.mOnUse is None:
            return
        try:
            self.mOnUse(args)
        except Exception:
            pass

    # ==================== 底层小工具 ====================
    def _setVisible(self, path, visible):
        try:
            ctrl = self.GetBaseUIControl(path)
            if ctrl is not None:
                ctrl.SetVisible(bool(visible))
                return
        except Exception:
            pass
        try:
            self.SetVisible(path, bool(visible))
        except Exception:
            pass
