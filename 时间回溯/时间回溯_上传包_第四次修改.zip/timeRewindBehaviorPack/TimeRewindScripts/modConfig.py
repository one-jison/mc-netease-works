# -*- coding: utf-8 -*-
# ============================================================
#  时间回溯 — 公共配置（模组名 / 事件名 / 界面名）
# ============================================================
ModName = "TimeRewindMod"
ModVersion = "1.0.0"

ServerSystemName = "TimeRewindServerSystem"
ClientSystemName = "TimeRewindClientSystem"
ServerSystemClsPath = "TimeRewindScripts.timeRewindServerSystem.TimeRewindServerSystem"
ClientSystemClsPath = "TimeRewindScripts.timeRewindClientSystem.TimeRewindClientSystem"

# 服务端 -> 这个玩家自己：左侧那颗「回溯」按钮要不要亮着
EventState = "TimeRewindState"
# 客户端 -> 服务端：玩家按下了回溯按钮
EventUse = "TimeRewindUse"
# 服务端 -> 所有玩家：回溯时的一圈淡蓝色冲击波
EventWave = "TimeRewindWave"

UiInitFinishedEvent = "UiInitFinished"
HudUIName = "timerewindhud"
HudUIPyClsPath = "TimeRewindScripts.timeRewindHudScreen.TimeRewindHudScreen"
HudUIScreenDef = "timerewindhud.main"
