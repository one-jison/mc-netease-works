# -*- coding: utf-8 -*-
# ============================================================
#  时间回溯 — 服务端
#    · 有药水的玩家，身边一百格内的实体每 0.5 秒记一笔（位置 / 朝向 / 血量）
#    · 方块要变之前先把它原来的样子记下来（玩家挖掉 / 被炸掉 / 被放上去）
#    · 按下回溯按钮：昼夜五秒一轮回、持续十秒，
#      实体与方块退回五秒前的样子，这五秒里死掉的生物原地复活
#    · 玩家死亡：按钮收掉；死前喝过药的话，重生时血量回到五秒前那个值
# ============================================================
import time
import collections
import mod.server.extraServerApi as serverApi
from TimeRewindScripts import modConfig
from TimeRewindScripts import timeRewindConfig as cfg


ServerSystem = serverApi.GetServerSystemCls()


class TimeRewindServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        super(TimeRewindServerSystem, self).__init__(namespace, systemName)
        self._has = {}          # playerId -> True：身上有回溯药水
        self._until = {}        # playerId -> 按钮到什么时候收（0 = 一直留着）
        self._lastDrink = {}    # playerId -> 上一次喝下去的时间（一瓶别算两次）
        self._lastUse = {}      # playerId -> 上一次按按钮的时间（冷却）
        self._pending = {}      # playerId -> 到什么时候真正开始回溯（按下后先等一秒）
        self._reviveHp = {}     # playerId -> 重生时把血量还原成多少
        self._hpTask = {}       # playerId -> [还原血量的时间, 数值]
        self._hp = {}           # playerId -> [(时间, 血量), ...]
        self._hist = {}         # entityId -> [(时间, 位置, 朝向, 血量), ...]
        self._deaths = collections.deque()   # (时间, entityId, 类型, 位置, 朝向, 维度)
        self._blocks = {}       # (x, y, z) -> [时间, 维度, 方块字典, 方块状态]
        self._blockQ = collections.deque()
        self._putQ = collections.deque()     # 等着恢复原样的方块（摊到每 tick 慢慢来，别卡帧）
        self._near = {}         # playerId -> (时间, [entityId, ...])
        self._tick = 0
        self._spin = {}         # playerId -> 昼夜飞快交替到什么时候
        self._spinFrom = {}     # playerId -> (维度, 按下去那一刻的时间)：转完要放回去
        self._tod = {}          # 维度 -> 现在推到一天的第几帧
        self._listenEvents()

    # ==================== 事件 ====================
    def _listenEvents(self):
        ns = serverApi.GetEngineNamespace()
        sn = serverApi.GetEngineSystemName()
        L = self.ListenForEvent
        L(ns, sn, "AddServerPlayerEvent", self, self.OnAddPlayer)
        L(ns, sn, "DelServerPlayerEvent", self, self.OnPlayerLeave)
        L(ns, sn, "OnScriptTickServer", self, self.OnServerTick)

        # 喝药水：两个事件都听着，哪个先来都认
        L(ns, sn, "PlayerEatFoodServerEvent", self, self.OnEatFood)
        L(ns, sn, "ActorUseItemServerEvent", self, self.OnUseItem)

        # 方块要变之前，先把它原来的样子记下来（回溯时照这个还原）
        for evt, fn in (("ServerPlayerTryDestroyBlockEvent", self.OnBlockDestroy),
                        ("ServerEntityTryPlaceBlockEvent", self.OnBlockPlace),
                        ("ExplosionServerEvent", self.OnExplode)):
            try:
                L(ns, sn, evt, self, fn)
            except Exception:
                pass

        # 生物死掉：记一笔，回溯时把它拉回来
        L(ns, sn, "MobDieEvent", self, self.OnMobDie)
        # 玩家死了 / 复活了
        L(ns, sn, "PlayerDieEvent", self, self.OnPlayerDie)
        L(ns, sn, "PlayerRespawnFinishServerEvent", self, self.OnPlayerRespawn)

        # 客户端点了屏幕左边那颗「回溯」
        L(modConfig.ModName, modConfig.ClientSystemName,
          modConfig.EventUse, self, self.OnUseButton)
        # 客户端放不出按键音效时，让服务端兜底放一下
        L(modConfig.ModName, modConfig.ClientSystemName,
          modConfig.EventSound, self, self.OnAskSound)

    def OnAddPlayer(self, args=None):
        pid = None
        if args:
            pid = args.get("id") or args.get("playerId")
        if not pid:
            return
        self._near.pop(pid, None)
        self._toPlayer(pid, modConfig.EventState, {"show": 0})

    def OnPlayerLeave(self, args=None):
        pid = None
        if args:
            pid = args.get("id") or args.get("playerId")
        if pid:
            self._clear(pid)

    # ==================== 每 tick ====================
    def OnServerTick(self, args=None):
        now = time.time()
        self._tickHpTask(now)
        self._pendingTick(now)
        self._expire(now)
        self._spinTick(now)
        self._drainBlocks()
        self._drainPut()
        if self._tick % cfg.sampleTicks() == 0:
            self._sample(now)
        self._tick += 1

    def _expire(self, now):
        if not self._has:
            return
        for pid in list(self._has.keys()):
            end = self._until.get(pid, 0.0)
            if end > 0.0 and now >= end:
                self._clear(pid)
                self._toPlayer(pid, modConfig.EventState, {"show": 0})
                self._tip(pid, u"回溯药水到期了", "GRAY")

    def _tickHpTask(self, now):
        if not self._hpTask:
            return
        for pid in list(self._hpTask.keys()):
            when, hp = self._hpTask[pid]
            if now >= when:
                self._hpTask.pop(pid, None)
                self._setHealth(pid, hp)

    # ==================== 喝药水 ====================
    def OnEatFood(self, args=None):
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))

    def OnUseItem(self, args=None):
        if not args:
            return
        self._checkPotion(args.get("playerId"), args.get("itemDict"))

    def _itemNameOf(self, itemDict):
        if not isinstance(itemDict, dict):
            return u""
        name = itemDict.get("newItemName") or itemDict.get("itemName") or u""
        return str(name).lower()

    def _checkPotion(self, playerId, itemDict):
        if not playerId or not cfg.MODE_ON:
            return
        if self._itemNameOf(itemDict) != str(cfg.POTION_ITEM).lower():
            return
        now = time.time()
        if now - float(self._lastDrink.get(playerId, -999.0)) < 1.0:
            return
        self._lastDrink[playerId] = now
        self._drink(playerId)

    def _drink(self, playerId):
        now = time.time()
        self._has[playerId] = True
        sec = cfg.buttonSeconds()
        self._until[playerId] = (now + sec) if sec > 0 else 0.0
        self._lastUse[playerId] = now - cfg.cooldownSeconds()
        self._hp.setdefault(playerId, [])
        self._toPlayer(playerId, modConfig.EventState, {"show": 1})
        if cfg.TIP_ON_DRINK:
            hint = u""
            if getattr(cfg, "USE_KEY_ENABLED", True):
                hint = u"（电脑端按 %s 键）" % getattr(cfg, "USE_KEY_LABEL", u"R")
            self._tip(playerId,
                      u"喝下 %s：屏幕左侧出现回溯按钮%s，按一下就能退回五秒前"
                      % (cfg.POTION_NAME, hint), "LIGHT_PURPLE")

    # ==================== 按下回溯 ====================
    def OnUseButton(self, args=None):
        if not args:
            return
        pid = args.get("playerId")
        if not pid or not cfg.MODE_ON:
            return
        if pid not in self._has:
            # 身上没有药水：直接忽略，不提示任何东西
            return
        now = time.time()
        left = cfg.cooldownSeconds() - (now - float(self._lastUse.get(pid, -999.0)))
        if left > 0.05:
            self._tip(pid, u"回溯冷却中，还要 %.0f 秒" % left, "RED")
            return
        self._lastUse[pid] = now
        # 按一下就把这瓶喝掉了：按钮立刻收掉，想再用得重新喝一瓶
        self._consume(pid)

        # 1) 昼夜立刻开始飞快交替（转完会自动放回原来的时间）
        if cfg.dayNightOn():
            self._spin[pid] = now + cfg.dayNightSeconds()
            dim0 = self._dimOf(pid)
            comp0 = self._timeComp()
            from0 = (self._timeOfDay(comp0, dim0) if comp0 is not None
                     else int(self._tod.get(dim0, 0)))
            self._spinFrom[pid] = (dim0, int(from0))
            self._tod.pop(dim0, None)     # 以真实时间为起点，四秒正好转一整轮
        # 2) 屏幕上的转钟动画先转一秒，再真正回溯生物和方块
        delay = cfg.rewindDelay()
        if delay > 0.01:
            self._pending[pid] = now + delay
        else:
            self._doRewind(pid)

    def _consume(self, playerId):
        # 药水用掉了：按钮收掉、不再采样、也不再算“死前喝过药”。
        # 注意只清“药水状态”，_spin / _pending 要留着，
        # 不然正在转的昼夜和那一秒后的回溯就被取消了。
        self._has.pop(playerId, None)
        self._until.pop(playerId, None)
        self._hpTask.pop(playerId, None)
        self._reviveHp.pop(playerId, None)
        self._hp.pop(playerId, None)
        self._lastDrink.pop(playerId, None)
        self._toPlayer(playerId, modConfig.EventState, {"show": 0})

    def _doRewind(self, playerId):
        # 真正开始回溯：先把这一秒里死掉的生物、动过的方块也算进来
        now = time.time()
        moved, revived = self._rewindEntities(playerId, now)
        blocks = self._rewindBlocks(playerId, now)
        if cfg.soundOn():
            self._playSound(playerId, str(getattr(cfg, "SOUND_USE", "mob.endermen.portal")),
                            float(getattr(cfg, "SOUND_VOLUME", 1.0)),
                            float(getattr(cfg, "SOUND_PITCH", 1.0)), 48.0)
        self._tip(playerId, u"时间回溯：%d 个实体退回五秒前、%d 格方块恢复原样、拉回 %d 只生物"
                  % (moved, blocks, revived), "AQUA")

    def _pendingTick(self, now):
        # 按下按钮之后等的那一秒：到点了才真正回溯
        if not self._pending:
            return
        for pid in list(self._pending.keys()):
            if now >= self._pending[pid]:
                self._pending.pop(pid, None)
                self._doRewind(pid)

    # ==================== 记实体 ====================
    def _sample(self, now):
        if not self._has:
            return
        players = self._playerSet()
        for pid in list(self._has.keys()):
            pos = self._posOf(pid)
            if pos is None:
                continue
            for eid in self._nearby(pid, cfg.entityRange()):
                if eid == pid:
                    continue
                if eid in players and not cfg.REWIND_PLAYERS:
                    continue
                self._push(eid, now)
            # 自己也记一笔位置：按下去后要退回五秒前站的地方
            # （_nearby 里不含自己，所以这里单独推一次）
            if getattr(cfg, "REWIND_SELF", False):
                self._push(pid, now)
            # 玩家自己的血量也记一笔：死前喝过药的话，重生要还原到五秒前那个值
            hp = self._healthOf(pid)
            if hp is not None:
                arr = self._hp.setdefault(pid, [])
                arr.append((now, hp))
                while arr and arr[0][0] < now - 30.0:
                    arr.pop(0)
        self._prune(now)

    def _push(self, entityId, now):
        pos = self._posOf(entityId)
        if pos is None:
            return
        rot = self._rotOf(entityId)
        hp = self._healthOf(entityId)
        arr = self._hist.get(entityId)
        if arr is None:
            arr = []
            self._hist[entityId] = arr
        arr.append((now, (float(pos[0]), float(pos[1]), float(pos[2])), rot, hp))
        keep = max(4, int(cfg.HISTORY_KEEP))
        if len(arr) > keep:
            del arr[0:len(arr) - keep]

    def _prune(self, now):
        dead = now - max(30.0, cfg.rewindSeconds() * 4.0)
        for eid in list(self._hist.keys()):
            arr = self._hist[eid]
            if not arr or arr[-1][0] < dead:
                self._hist.pop(eid, None)
                continue
            while arr and arr[0][0] < now - 30.0:
                arr.pop(0)
        limit = cfg.rewindSeconds() * 3.0
        while self._deaths and (now - self._deaths[0][0]) > limit:
            self._deaths.popleft()
        while len(self._deaths) > max(1, int(cfg.DEATH_KEEP)):
            self._deaths.popleft()

    def _sampleAt(self, entityId, target):
        # 找一个“不晚于 target 的最后一笔”，也就是那个时候的样子
        arr = self._hist.get(entityId)
        if not arr:
            return None
        best = None
        for rec in arr:
            if rec[0] <= target:
                best = rec
            else:
                break
        return best

    # ==================== 实体回溯 ====================
    def _rewindEntities(self, playerId, now):
        target = now - cfg.rewindSeconds()
        pos = self._posOf(playerId)
        if pos is None:
            return 0, 0
        dim = self._dimOf(playerId)
        players = self._playerSet()
        game = self._gameComp()
        moved = 0
        for eid in self._nearby(playerId, cfg.entityRange()):
            if eid == playerId or eid in players:
                continue
            if game is not None:
                try:
                    if not game.IsEntityAlive(eid):
                        continue
                except Exception:
                    pass
            rec = self._sampleAt(eid, target)
            if rec is None:
                continue
            self._putEntity(eid, rec)
            moved += 1
        # 自己也退回五秒前站的位置（默认只回位置，不动血）
        if getattr(cfg, "REWIND_SELF", False):
            rec = self._sampleAt(playerId, target)
            if rec is not None:
                self._putEntity(playerId, rec,
                                bool(getattr(cfg, "REWIND_SELF_HP", False)))
                moved += 1
        revived = self._reviveDead(now, pos, dim, target)
        return moved, revived

    def _putEntity(self, entityId, rec, health=True):
        unused_t, p, rot, hp = rec
        try:
            serverApi.GetEngineCompFactory().CreatePos(entityId).SetFootPos(p)
        except Exception:
            pass
        if rot is not None:
            try:
                serverApi.GetEngineCompFactory().CreateRot(entityId).SetRot(rot)
            except Exception:
                pass
        if health and cfg.REWIND_HEALTH and hp is not None:
            self._setHealth(entityId, hp)

    def _reviveDead(self, now, pos, dim, target):
        if not cfg.REVIVE_DEAD:
            return 0
        n = 0
        r = cfg.entityRange()
        for rec in list(self._deaths):
            t, eid, typeStr, dpos, rot, ddim = rec
            if now - t > cfg.rewindSeconds():
                continue
            if ddim != dim or not typeStr:
                continue
            if not self._within(dpos, pos, r):
                continue
            p = dpos
            old = self._sampleAt(eid, target)
            if old is not None:
                p = old[1]
            if self._spawnMob(typeStr, p, rot, ddim) is not None:
                n += 1
        return n

    def _spawnMob(self, typeStr, pos, rot, dim):
        if not typeStr or ":" not in str(typeStr):
            return None
        try:
            r = (0.0, 0.0) if rot is None else (float(rot[0]), float(rot[1]))
        except Exception:
            r = (0.0, 0.0)
        try:
            return self.CreateEngineEntityByTypeStr(
                str(typeStr), (float(pos[0]), float(pos[1]), float(pos[2])), r, int(dim))
        except Exception:
            return None

    def OnMobDie(self, args=None):
        if not args:
            return
        eid = args.get("id") or args.get("entityId")
        if not eid:
            return
        players = self._playerSet()
        if eid in players:
            return
        now = time.time()
        typeStr = self._typeStrOf(eid)
        rec = self._sampleAt(eid, now - 0.4)
        if rec is not None:
            pos = rec[1]
            rot = rec[2]
        else:
            pos = self._posOf(eid)
            rot = self._rotOf(eid)
        if pos is None or not typeStr:
            return
        self._deaths.append((now, eid, str(typeStr), pos, rot, self._dimOf(eid)))

    # ==================== 方块回溯 ====================
    def OnBlockDestroy(self, args=None):
        if not args or not self._has:
            return
        try:
            self._recordBlock(int(args.get("x")), int(args.get("y")),
                              int(args.get("z")), int(args.get("dimensionId", 0)))
        except Exception:
            pass

    def OnBlockPlace(self, args=None):
        if not args or not self._has:
            return
        try:
            self._recordBlock(int(args.get("x")), int(args.get("y")),
                              int(args.get("z")), int(args.get("dimensionId", 0)))
        except Exception:
            pass

    def OnExplode(self, args=None):
        if not args or not self._has:
            return
        try:
            dim = int(args.get("dimensionId", 0))
        except Exception:
            dim = 0
        n = 0
        cap = max(1, int(cfg.MAX_EXPLODE_BLOCKS))
        for b in (args.get("blocks") or []):
            if not b or len(b) < 3:
                continue
            try:
                self._blockQ.append((int(b[0]), int(b[1]), int(b[2]), dim))
            except Exception:
                continue
            n += 1
            if n >= cap:
                break

    def _drainBlocks(self):
        if not self._blockQ:
            return
        n = max(1, int(cfg.BLOCK_PER_TICK))
        while self._blockQ and n > 0:
            x, y, z, dim = self._blockQ.popleft()
            self._recordBlock(x, y, z, dim)
            n -= 1

    def _recordBlock(self, x, y, z, dim):
        # 方块“要变之前”把它原来的样子记下来。
        # 同一格只留最靠近回溯窗口起点的那一份：
        #   已经有更新的一份（还没过期）就不动它
        key = (int(x), int(y), int(z))
        now = time.time()
        old = self._blocks.get(key)
        if old is not None and (now - old[0]) < cfg.rewindSeconds():
            return
        info = self._blockInfo()
        if info is None:
            return
        try:
            d = info.GetBlockNew(key, int(dim))
        except Exception:
            return
        if not isinstance(d, dict):
            return
        name = d.get("name")
        if not name:
            return
        states = None
        st = self._blockState()
        if st is not None:
            try:
                states = st.GetBlockStates(key, int(dim))
            except Exception:
                states = None
        self._blocks[key] = [now, int(dim),
                             {"name": str(name), "aux": int(d.get("aux") or 0)},
                             states]
        cap = max(100, int(cfg.BLOCK_KEEP))
        if len(self._blocks) > cap:
            items = sorted(self._blocks.items(), key=lambda kv: kv[1][0])
            for k2, _ in items[:max(1, len(items) // 5)]:
                self._blocks.pop(k2, None)

    def _rewindBlocks(self, playerId, now):
        target = now - cfg.rewindSeconds()
        pos = self._posOf(playerId)
        if pos is None:
            return 0
        dim = self._dimOf(playerId)
        r = cfg.blockRange()
        n = 0
        drop = []
        for key, rec in self._blocks.items():
            t, bdim, blockDict, states = rec
            if t < target:
                # 这一格五秒前就已经是现在这样了，不用动
                drop.append(key)
                continue
            if bdim != dim:
                continue
            if not self._within(key, pos, r):
                continue
            # 不在这儿直接改方块：一次改几百格会卡一帧，
            # 丢进队列，由 _drainPut 每 tick 恢复一点，卡顿就摊平了
            self._putQ.append((key, bdim, blockDict, states))
            n += 1
            drop.append(key)
        for k in drop:
            self._blocks.pop(k, None)
        return n

    def _drainPut(self):
        # 每 tick 只恢复几格方块
        if not self._putQ:
            return
        limit = max(1, int(getattr(cfg, "BLOCK_PUT_PER_TICK", 64)))
        done = 0
        while self._putQ and done < limit:
            key, dim, blockDict, states = self._putQ.popleft()
            self._putBlock(key, dim, blockDict, states)
            done += 1

    def _putBlock(self, key, dim, blockDict, states):
        if not blockDict or not blockDict.get("name"):
            return False
        info = self._blockInfo()
        if info is None:
            return False
        cur = None
        try:
            cur = info.GetBlockNew(key, int(dim))
        except Exception:
            cur = None
        if isinstance(cur, dict):
            try:
                if (str(cur.get("name")) == str(blockDict.get("name"))
                        and int(cur.get("aux") or 0) == int(blockDict.get("aux") or 0)):
                    return False
            except Exception:
                pass
        ok = False
        try:
            ok = bool(info.SetBlockNew(key, blockDict, 0, int(dim), True, True))
        except Exception:
            ok = False
        if ok and states:
            st = self._blockState()
            if st is not None:
                try:
                    st.SetBlockStates(key, states, int(dim))
                except Exception:
                    pass
        return ok

    # ==================== 昼夜飞快交替 ====================
    def _spinTick(self, now):
        if not self._spin:
            return
        comp = self._timeComp()
        if comp is None:
            self._spin.clear()
            self._spinFrom.clear()
            return
        step = cfg.dayNightStep()
        # 同一维度还有别人在转的话，先别把时间放回去
        busy = set()
        for pid, end in self._spin.items():
            if now < end:
                f = self._spinFrom.get(pid)
                if f is not None:
                    busy.add(f[0])
        for pid in list(self._spin.keys()):
            if now >= self._spin[pid]:
                self._spin.pop(pid, None)
                f = self._spinFrom.pop(pid, None)
                # 转完了：把时间放回按下去之前那一刻
                if f is not None and f[0] not in busy:
                    self._restoreTime(f)
                continue
            dim = self._dimOf(pid)
            cur = self._tod.get(dim)
            if cur is None:
                cur = self._timeOfDay(comp, dim)
            cur = (int(cur) + int(step)) % 24000
            self._tod[dim] = cur
            try:
                comp.SetTimeOfDay(int(cur))
            except Exception:
                pass

    def _restoreTime(self, f):
        # 把时间放回原来的那一刻
        if not f:
            return
        dim, tod = f
        self._tod[dim] = int(tod)
        comp = self._timeComp()
        if comp is None:
            return
        try:
            comp.SetTimeOfDay(int(tod))
        except Exception:
            pass

    # ==================== 玩家死亡 ====================
    def OnPlayerDie(self, args=None):
        if not args:
            return
        pid = args.get("id") or args.get("playerId")
        if not pid:
            return
        now = time.time()
        if pid in self._has and cfg.keepHpOnDeath():
            hp = self._hpAt(pid, now - cfg.rewindSeconds())
            if hp is not None and hp > 0:
                self._reviveHp[pid] = float(hp)
        self._clear(pid)
        self._toPlayer(pid, modConfig.EventState, {"show": 0})

    def OnPlayerRespawn(self, args=None):
        if not args:
            return
        pid = args.get("playerId") or args.get("id")
        if not pid:
            return
        # 重生之后按钮消失，不再出现
        self._toPlayer(pid, modConfig.EventState, {"show": 0})
        hp = self._reviveHp.pop(pid, None)
        if hp is None or hp <= 0:
            return
        self._setHealth(pid, hp)
        self._hpTask[pid] = [time.time() + 0.6, hp]

    def _hpAt(self, playerId, target):
        arr = self._hp.get(playerId)
        if not arr:
            return None
        best = None
        for rec in arr:
            if rec[0] <= target:
                best = rec
            else:
                break
        return None if best is None else best[1]

    def _clear(self, playerId):
        # 昼夜还没转完人就走了（死了 / 退出世界）：先把时间放回原来的
        f = self._spinFrom.pop(playerId, None)
        if f is not None and playerId in self._spin:
            self._restoreTime(f)
        for d in (self._has, self._until, self._spin, self._hp,
                  self._lastUse, self._near, self._pending):
            d.pop(playerId, None)

    # ==================== 小工具 ====================
    def _within(self, a, b, r):
        try:
            return (abs(float(a[0]) - float(b[0])) <= r
                    and abs(float(a[1]) - float(b[1])) <= r
                    and abs(float(a[2]) - float(b[2])) <= r)
        except Exception:
            return False

    def _nearby(self, playerId, radius):
        now = time.time()
        gap = float(cfg.cacheTicks()) / 20.0
        cached = self._near.get(playerId)
        if cached is not None and (now - cached[0]) < gap:
            return cached[1]
        out = []
        pos = self._posOf(playerId)
        if pos is not None:
            dim = self._dimOf(playerId)
            r = max(1.0, float(radius))
            lo = (pos[0] - r, pos[1] - r, pos[2] - r)
            hi = (pos[0] + r, pos[1] + r, pos[2] + r)
            ids = None
            for owner in (serverApi.GetLevelId(), playerId):
                try:
                    ids = serverApi.GetEngineCompFactory().CreateGame(owner) \
                        .GetEntitiesInSquareArea(None, lo, hi, dim)
                except Exception:
                    ids = None
                if ids:
                    break
            for e in (ids or []):
                if e and e != playerId and e not in out:
                    out.append(e)
        cap = max(1, int(cfg.MAX_ENTITIES))
        if len(out) > cap:
            out = out[:cap]
        self._near[playerId] = (now, out)
        return out

    def _playerSet(self):
        try:
            return set(serverApi.GetPlayerList() or [])
        except Exception:
            return set()

    def _posOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreatePos(entityId).GetFootPos()
        except Exception:
            return None

    def _rotOf(self, entityId):
        try:
            r = serverApi.GetEngineCompFactory().CreateRot(entityId).GetRot()
            if r is None:
                return None
            return (float(r[0]), float(r[1]))
        except Exception:
            return None

    def _dimOf(self, entityId):
        try:
            return serverApi.GetEngineCompFactory().CreateDimension(
                entityId).GetEntityDimensionId()
        except Exception:
            return 0

    def _typeStrOf(self, entityId):
        factory = serverApi.GetEngineCompFactory()
        for maker in ("CreateEngineType", "CreateEntityType"):
            try:
                comp = factory.__getattribute__(maker)(entityId)
                if comp is not None:
                    t = comp.GetEngineTypeStr()
                    if t:
                        return str(t)
            except Exception:
                continue
        return u""

    def _healthAttr(self):
        try:
            return serverApi.GetMinecraftEnum().AttrType.HEALTH
        except Exception:
            return 0

    def _healthOf(self, entityId):
        try:
            comp = serverApi.GetEngineCompFactory().CreateAttr(entityId)
        except Exception:
            return None
        if comp is None:
            return None
        try:
            v = comp.GetAttrValue(self._healthAttr())
            return None if v is None else float(v)
        except Exception:
            return None

    def _setHealth(self, entityId, hp):
        try:
            hp = float(hp)
        except Exception:
            return
        if hp <= 0:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateAttr(entityId)
        except Exception:
            return
        if comp is None:
            return
        attr = self._healthAttr()
        try:
            mx = comp.GetAttrMaxValue(attr)
        except Exception:
            mx = None
        if mx is not None:
            try:
                if hp > float(mx):
                    comp.SetAttrMaxValue(attr, int(hp) + 1)
            except Exception:
                pass
        try:
            comp.SetAttrValue(attr, hp)
        except Exception:
            pass

    def _gameComp(self):
        for owner in (serverApi.GetLevelId(), None):
            try:
                comp = serverApi.GetEngineCompFactory().CreateGame(owner)
            except Exception:
                continue
            if comp is not None:
                return comp
        return None

    def _blockInfo(self):
        for owner in (serverApi.GetLevelId(), None):
            try:
                comp = serverApi.GetEngineCompFactory().CreateBlockInfo(owner)
            except Exception:
                continue
            if comp is not None:
                return comp
        return None

    def _blockState(self):
        for owner in (serverApi.GetLevelId(), None):
            try:
                comp = serverApi.GetEngineCompFactory().CreateBlockState(owner)
            except Exception:
                continue
            if comp is not None:
                return comp
        return None

    def _timeComp(self):
        for owner in (serverApi.GetLevelId(), None):
            try:
                comp = serverApi.GetEngineCompFactory().CreateTime(owner)
            except Exception:
                continue
            if comp is not None:
                return comp
        return None

    def _timeOfDay(self, comp, dim):
        try:
            passed = comp.GetTime()
            if passed is not None:
                return int(passed) % 24000
        except Exception:
            pass
        try:
            c2 = serverApi.GetEngineCompFactory().CreateDimension(serverApi.GetLevelId())
            passed = c2.GetLocalTime(dim)
            if passed is not None:
                return int(passed) % 24000
        except Exception:
            pass
        return 0

    def _tip(self, playerId, text, color="AQUA"):
        try:
            comp = serverApi.GetEngineCompFactory().CreateGame(playerId)
            try:
                comp.SetOneTipMessage(playerId, serverApi.GenerateColor(color) + text)
            except Exception:
                comp.SetOneTipMessage(playerId, text)
        except Exception:
            pass

    def OnAskSound(self, args=None):
        # 客户端自己放不出来，服务端用 /playsound 兜底放一次
        pid = None
        if args:
            pid = args.get("playerId")
        if not pid or not cfg.buttonSoundOn():
            return
        self._playSound(pid, str(cfg.buttonSound()),
                        float(getattr(cfg, "BUTTON_SOUND_VOLUME", 1.0)),
                        float(getattr(cfg, "BUTTON_SOUND_PITCH", 1.0)), 48.0)

    def _playSound(self, entityId, name, volume=1.0, pitch=1.0, radius=32.0):
        if not name:
            return
        try:
            comp = serverApi.GetEngineCompFactory().CreateCommand(serverApi.GetLevelId())
            comp.SetCommand("/playsound %s @a[r=%s] ~ ~ ~ %s %s"
                            % (str(name), float(radius), float(volume), float(pitch)),
                            entityId)
        except Exception:
            pass

    def _toPlayer(self, playerId, eventName, data):
        try:
            self.NotifyToClient(playerId, eventName, data)
        except Exception:
            pass
