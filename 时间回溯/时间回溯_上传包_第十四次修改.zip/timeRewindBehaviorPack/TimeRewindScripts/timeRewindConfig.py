# -*- coding: utf-8 -*-
# ============================================================
#  时间回溯 — 所有能调的数字都在这儿，改完重启就生效
# ============================================================

MODE_ON = True                     # 整个模组的总开关
POTION_NAME = u"回溯"               # 药水名字（聊天提示用）
POTION_ITEM = "timerewind:rewind_potion"   # 物品 ID（别乱改）

# ---------------- 喝下去 ----------------
TIP_ON_DRINK = True        # 喝下去时在聊天框里提示一句
# 按钮留多久：0 = 一直留着（直到死亡 / 退出世界），>0 = 这么多秒后自动收掉
BUTTON_SECONDS = 0.0
COOLDOWN_SECONDS = 5.0     # 按一次之后要等几秒才能再按

# ---------------- 按下去发生什么 ----------------
REWIND_SECONDS = 10.0       # 退回几秒前（10 = 退回十秒前）
DAY_NIGHT_ON = True         # True = 按下后昼夜飞快交替
DAY_NIGHT_SECONDS = 4.0     # 昼夜飞快交替持续几秒（4 = 正好转完一整天）
DAY_NIGHT_CYCLE = 4.0       # 几秒走完这一段（默认 4 秒）
DAY_NIGHT_ONCE = True       # True = 只交替一次：先黑天，再一路走到白天就停（半轮）
                            # False = 转完一整轮：整天转一圈
DAY_NIGHT_START = 18000     # 按下先跳到这个时间再往前走（18000 = 午夜，最黑；走后变白天）

# ---------------- 按下去之后的节奏 ----------------
REWIND_DELAY = 1.0          # 按下后先让昼夜转这么久，再开始回溯生物和方块（秒）
ANIM_SECONDS = 1.0          # 屏幕上那个转钟的「正在回溯...」动画放多久（秒）
ANIM_FRAMES = 8             # 转钟动画几帧（对应贴图 clock_0..clock_7，别乱改）
ANIM_FPS = 8.0              # 转钟每秒放几帧
ANIM_WARM_UP = True         # True = 开局先把这几帧悄悄渲染一遍，第一次放不卡

# ---------------- 回溯时的性能 ----------------
# 一次性恢复太多方块会卡一帧，这里改成每 tick 恢复一点，摊开来做
BLOCK_PUT_PER_TICK = 64     # 每 tick 最多恢复几格方块（64 = 每秒 1280 格）

# ---------------- 回溯谁 ----------------
ENTITY_RANGE = 100.0        # 身边多少格以内的实体跟着回溯
BLOCK_RANGE = 100.0         # 身边多少格以内的方块跟着回溯
REWIND_PLAYERS = False      # True = 连别的玩家也一起退回原位（默认不动别人）
REWIND_SELF = True          # True = 按下去后，自己也退回十秒前站的位置
REWIND_SELF_HP = True       # True = 连自己的血量也一起退回（默认开）
SELF_CHECK_TICKS = 5        # 拉回玩家后，过几 tick 核对一次有没有到位（没到位就补 /tp）

# ---------------- 掉落物 / 背包 / 经验 ----------------
CLEAN_NEW_ITEMS = True      # True = 这段时间里才掉出来的东西（掉落物、经验球）跟着一起清掉
TRASH_TYPES = ("minecraft:item", "minecraft:xp_orb")   # 当作“掉落物”的实体类型
REWIND_INVENTORY = True     # True = 把这一轮里多出来的背包物品收回去（只做减法，不加东西）
REWIND_EXP = True           # True = 把这一轮里多出来的经验扣回去
BAG_KEEP = 40               # 背包 / 经验值最多留多少笔记录（40 笔 = 20 秒）

# ---------------- 箭矢 / 抛射物 ----------------
# 这段时间里刚射出去的箭：不是“收回”，而是放回出膛的位置再飞一次
PROJECTILE_FLY_AGAIN = True
PROJECTILE_TYPES = ("minecraft:arrow", "minecraft:snowball", "minecraft:egg",
                    "minecraft:thrown_trident", "minecraft:ender_pearl",
                    "minecraft:potion", "minecraft:xp_bottle")
PROJECTILE_KEEP_SPEED = True   # 把出膛时那一箭的速度也写回去（插墙上的箭才会再飞）
SHOT_KEEP = 60              # 出膛点记录最多留多少笔
REVIVE_DEAD = True          # True = 这段时间里死掉的生物原地复活
REWIND_HEALTH = True        # True = 连血量一起还原

ENTITY_SAMPLE_TICKS = 10    # 每几 tick 记一次实体的位置（10 = 每秒 2 次）
ENTITY_CACHE_TICKS = 20     # 每隔几 tick 重找一次身边的实体（别每帧都找，省性能）
MAX_ENTITIES = 200          # 一次最多记多少个实体（太多会拖性能）
HISTORY_KEEP = 60           # 每个实体最多留多少条记录
DEATH_KEEP = 200            # 最多留多少条“刚刚死掉”的记录
BLOCK_KEEP = 20000          # 最多留多少格方块记录
MAX_EXPLODE_BLOCKS = 800    # 一次爆炸最多记多少格（爆炸那一刻当场记，不用排队）
EXPLODE_SCAN_RADIUS = 6     # 只有拿不到爆炸方块列表时，才围着爆点扫这么大一圈兜底

# ---------------- 按下按钮那一声 ----------------
# 音效文件：资源包 sounds/timerewind/rewind.ogg（从视频里抽出来的音轨）
BUTTON_SOUND = "timerewind.rewind"    # 名字和 sound_definitions.json 里对应
BUTTON_SOUND_VOLUME = 1.0
BUTTON_SOUND_PITCH = 1.0
BUTTON_SOUND_ON = True                # False = 按下按钮不出这一声

# ---------------- 按下去的动静 ----------------
SOUND_ON_USE = True                     # True = 按下去响一声（用的游戏自带音效，不用额外素材）
SOUND_USE = "mob.endermen.portal"       # 那一声用哪个音效
SOUND_VOLUME = 1.0
SOUND_PITCH = 1.0

# ---------------- 电脑端 ----------------
# 电脑端鼠标锁在准心里，指针移不到屏幕上的按钮，所以给一个键盘快捷键。
# 这里用的是“注册自定义按键”：按键会出现在游戏的【设置 -> 按键】里，
# 玩家可以在那儿自己改成别的键。
USE_KEY_ENABLED = True                  # True = 电脑端按这个键就等于点了一下回溯按钮
USE_KEY_NAME = "TimeRewindUse"          # 按键名（内部标识，英文，别用中文）
USE_KEY_CODE = 82                       # 默认键码：82 = R（82=R 71=G 70=F 72=H 74=J 86=V）
USE_KEY_CATEGORY = "gameplay"           # 设置里归到哪一类：gameplay / movement
USE_KEY_LABEL = u"R"                    # 聊天提示里写的键名

# ---------------- 死亡 ----------------
KEEP_HP_ON_DEATH = True     # True = 死前喝过药，重生时血量回到十秒前那个值

# ============================================================
#  下面几个函数不用动，改上面的数字就行
# ============================================================
def rewindSeconds():
    return max(1.0, float(REWIND_SECONDS))


def dayNightOn():
    return bool(DAY_NIGHT_ON)


def dayNightOnce():
    return bool(DAY_NIGHT_ONCE)


def dayNightStart():
    return int(DAY_NIGHT_START) % 24000


def dayNightSeconds():
    return max(0.5, float(DAY_NIGHT_SECONDS))


def dayNightStep():
    # 每次推多少帧：24000 帧 = 一整天（半轮 12000 帧），20 tick = 1 秒
    cycle = max(0.5, float(DAY_NIGHT_CYCLE))
    frames = 12000.0 if bool(DAY_NIGHT_ONCE) else 24000.0
    return max(1, int(round(frames / (cycle * 20.0))))


def buttonSeconds():
    return max(0.0, float(BUTTON_SECONDS))


def cooldownSeconds():
    return max(0.0, float(COOLDOWN_SECONDS))


def rewindDelay():
    return max(0.0, float(REWIND_DELAY))


def buttonSoundOn():
    return bool(BUTTON_SOUND_ON)


def buttonSound():
    return u"%s" % BUTTON_SOUND


def animWarmUp():
    return bool(ANIM_WARM_UP)


def animSeconds():
    return max(0.0, float(ANIM_SECONDS))


def entityRange():
    return max(1.0, float(ENTITY_RANGE))


def blockRange():
    return max(1.0, float(BLOCK_RANGE))


def sampleTicks():
    return max(1, int(ENTITY_SAMPLE_TICKS))


def cacheTicks():
    return max(1, int(ENTITY_CACHE_TICKS))


def soundOn():
    return bool(SOUND_ON_USE)


def keepHpOnDeath():
    return bool(KEEP_HP_ON_DEATH)


def useKeyOn():
    return bool(USE_KEY_ENABLED)


def useKeyLabel():
    return u"%s" % USE_KEY_LABEL
